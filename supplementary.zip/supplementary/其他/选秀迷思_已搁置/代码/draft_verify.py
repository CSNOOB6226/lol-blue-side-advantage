"""Verify the 'draft value' package: first-pick null, blue-side real, counterpick null.
Replicate on 2025 (China excluded) + region/patch robustness on 2026.
"""
import pandas as pd, numpy as np, warnings, os
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F26 = os.path.join(ROOT,'数据/原始数据/2026年非中国赛区比赛数据.csv')
F25 = os.path.join(ROOT,'数据/原始数据/2025年英雄联盟职业比赛原始数据.csv')
NEED=['position','gameid','side','result','golddiffat15','champion','firstPick','league','patch',
      'datacompleteness','pick1','pick2','pick3','pick4','pick5']
SF={1:1,2:4,3:5,4:8,5:9}; SS={1:2,2:3,3:6,4:7,5:10}

def load(p,nonchina=False):
    d=pd.read_csv(p,usecols=lambda c:c in NEED,low_memory=False)
    if nonchina:
        ch=[l for l in d.league.unique() if 'LPL' in str(l) or 'LDL' in str(l)]
        d=d[~d.league.isin(ch)]
    return d[d.datacompleteness=='complete']

def firstpick_vs_side(d, tag):
    tm=d[d.position=='team'][['gameid','side','result']].copy()
    fp=d[d.position=='top'][['gameid','side','firstPick']].copy()
    t=tm.merge(fp,on=['gameid','side']).dropna(subset=['firstPick'])
    t['blue']=(t.side=='Blue').astype(int)
    # document how often firstPick deviates from blue (the natural-experiment variation)
    share_blue=t[t.firstPick==1].blue.mean()
    print('[%s] firstPick==1 is Blue %.1f%% of the time; raw firstPick WR=%.3f, raw blue WR=%.3f'%(
        tag,100*share_blue,t[t.firstPick==1].result.mean(),t[t.blue==1].result.mean()))
    try:
        m=smf.logit('result~firstPick+blue',t).fit(disp=0,cov_type='cluster',cov_kwds={'groups':t.gameid})
        print('[%s] firstPick OR=%.3f (p=%.3g) | blue OR=%.3f (p=%.3g)'%(
            tag,np.exp(m.params.firstPick),m.pvalues.firstPick,np.exp(m.params.blue),m.pvalues.blue))
    except Exception:
        m=smf.logit('result~blue',t).fit(disp=0,cov_type='cluster',cov_kwds={'groups':t.gameid})
        print('[%s] firstPick~=blue (collinear, cannot separate); blue-only OR=%.3f (p=%.3g)'%(
            tag,np.exp(m.params.blue),m.pvalues.blue))

def counterpick_all(d, tag):
    teams=d[d.position=='team'][['gameid','side','pick1','pick2','pick3','pick4','pick5']].copy()
    print('[%s] counterpick by lane: gold@15(cp/bp), win OR per SD later-reveal (|side,firstPick)'%tag)
    for role in ['top','jng','mid','bot','sup']:
        pr=d[d.position==role][['gameid','side','champion','golddiffat15','result','firstPick']].copy()
        m=pr.merge(teams,on=['gameid','side'],how='left')
        def pidx(r):
            for i in range(1,6):
                if r.get(f'pick{i}')==r['champion']: return i
            return np.nan
        m['pi']=m.apply(pidx,axis=1); m=m.dropna(subset=['pi','firstPick'])
        m['go']=m.apply(lambda r:(SF if r.firstPick==1 else SS)[int(r.pi)],axis=1)
        opp=m[['gameid','side','go']].copy(); opp['side']=opp.side.map({'Blue':'Red','Red':'Blue'}); opp=opp.rename(columns={'go':'oppgo'})
        m=m.merge(opp,on=['gameid','side'],how='left').dropna(subset=['oppgo'])
        m['cp']=(m.go>m.oppgo).astype(int); m['gap']=m.go-m.oppgo
        m['blue']=(m.side=='Blue').astype(int); m['zgap']=(m.gap-m.gap.mean())/m.gap.std()
        cp=m[m.cp==1]; bp=m[m.cp==0]
        reg=smf.logit('result~zgap+blue',m).fit(disp=0,cov_type='cluster',cov_kwds={'groups':m.gameid})
        print('   %-4s gold %4.0f/%4.0f  winrate %.3f/%.3f  winOR=%.3f (p=%.3g)'%(role,
            cp.golddiffat15.mean(),bp.golddiffat15.mean(),cp.result.mean(),bp.result.mean(),
            np.exp(reg.params.zgap),reg.pvalues.zgap))

if __name__=='__main__':
    print('========== 2026 ==========')
    d26=load(F26)
    firstpick_vs_side(d26,'2026')
    counterpick_all(d26,'2026')
    print('\n-- 2026 raw win rates by major league: firstPick team vs Blue side --')
    tm=d26[d26.position=='team'][['gameid','side','result','league']].merge(
        d26[d26.position=='top'][['gameid','side','firstPick']],on=['gameid','side']).dropna()
    tm['blue']=(tm.side=='Blue').astype(int)
    for lg in tm.league.value_counts().head(10).index:
        s=tm[tm.league==lg]
        print('   %-5s n=%4d  firstPick WR=%.3f   Blue WR=%.3f'%(lg,len(s),
            s[s.firstPick==1].result.mean(), s[s.blue==1].result.mean()))

    print('\n========== 2025 (non-China) ==========')
    d25=load(F25,nonchina=True)
    firstpick_vs_side(d25,'2025')
    counterpick_all(d25,'2025')
