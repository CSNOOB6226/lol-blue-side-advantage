import pandas as pd, numpy as np, warnings, os
warnings.filterwarnings('ignore')
import statsmodels.api as sm
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
from prep import load, z
FIG='figures'
d,prof = load()
def logit(df,xvars,y='result'):
    X=sm.add_constant(df[xvars])
    return sm.Logit(df[y],X).fit(disp=0,cov_type='cluster',cov_kwds={'groups':df['gameid']})
def OR(m,n): return f"OR={np.exp(m.params[n]):.3f} (b={m.params[n]:+.3f},SE={m.bse[n]:.3f},p={m.pvalues[n]:.2e})"

d['z_team_gd15']=z(d['team_golddiff15'])
d['z_top_gs15']=z(d['top_gs15'])
d['z_top_gd15']=z(d['top_golddiffat15'])
d['z_ci']=z(d['top_carry_index'])
d['z_len']=z(d['gamelength_min'])

print("="*70); print("ANALYSIS 2: WEAK-SIDE TOP — does concentrating gold share in the")
print("  top lane hurt, holding the team's total gold lead fixed?"); print("="*70)
m=logit(d.dropna(subset=['z_top_gs15']),['z_top_gs15','z_team_gd15'])
print("\nresult ~ top_gold_share@15 + team_golddiff@15")
print("  top_gold_share :",OR(m,'z_top_gs15'))
print("  team_golddiff  :",OR(m,'z_team_gd15'))
# by archetype interaction
dd=d.dropna(subset=['top_arch','z_top_gs15']).copy()
print("\n-- top_gold_share effect WITHIN each archetype (controlling team gold) --")
for a in ['tank','bruiser','carry']:
    s=dd[dd.top_arch==a]; mm=logit(s,['z_top_gs15','z_team_gd15'])
    print(f"  {a:7s} (n={len(s)}): top_share {OR(mm,'z_top_gs15')}")

# win-rate-by-bin within team-gold strata
dd['gd_stratum']=pd.cut(dd['team_golddiff15'],[-1e9,-1500,1500,1e9],labels=['team behind','even','team ahead'])
dd['share_bin']=pd.qcut(dd['top_gs15'],5,labels=['Q1 low share','Q2','Q3','Q4','Q5 high share'])
piv=dd.groupby(['gd_stratum','share_bin'])['result'].mean().unstack()
print("\nWin rate by top gold-share quintile within team-gold strata:")
print((piv*100).round(1).to_string())
fig,ax=plt.subplots(figsize=(7,4.5))
for s in piv.index:
    ax.plot(range(5),piv.loc[s].values,marker='o',label=str(s))
ax.set_xticks(range(5)); ax.set_xticklabels(['Q1\nlow','Q2','Q3','Q4','Q5\nhigh'])
ax.set_xlabel('上单经济占比@15 (top gold share)'); ax.set_ylabel('胜率 win rate')
ax.set_title('Weak-side: 同样团队经济下，上单占比越高胜率越低'); ax.legend(); ax.grid(alpha=.3)
fig.tight_layout(); fig.savefig(f'{FIG}/A2_weakside_share.png',dpi=130); plt.close()

print("\n"+"="*70); print("ANALYSIS 3: TANK vs CARRY x GAME LENGTH (crossover)"); print("="*70)
dd3=d.dropna(subset=['top_carry_index']).copy()
dd3['ci_x_len']=dd3['z_ci']*dd3['z_len']
m3=logit(dd3,['z_ci','z_len','ci_x_len','z_team_gd15'])
print("result ~ carry_index * gamelength + team_golddiff")
for v in ['z_ci','z_len','ci_x_len','z_team_gd15']: print(f"  {v:12s}:",OR(m3,v))
# win rate by archetype x length tercile
dd3['len_t']=pd.qcut(dd3['gamelength_min'],3,labels=['short(<28.5)','med','long(>34)'])
wr=dd3.groupby(['len_t','top_arch'])['result'].mean().unstack()*100
print("\nWin rate (%) by game-length tercile x archetype:")
print(wr.round(1).to_string())
# carry needs a lead? interaction carry_index * top_golddiff
dd3['ci_x_gd']=dd3['z_ci']*dd3['z_top_gd15']
m3b=logit(dd3,['z_ci','z_top_gd15','ci_x_gd','z_team_gd15'])
print("\nresult ~ carry_index * top_golddiff + team_gold  (does a top LEAD pay off more for carries?)")
for v in ['z_ci','z_top_gd15','ci_x_gd']: print(f"  {v:12s}:",OR(m3b,v))
fig,ax=plt.subplots(figsize=(7,4.5))
for a in ['tank','bruiser','carry']:
    ax.plot(range(3),wr[a].values,marker='o',label=a)
ax.set_xticks(range(3)); ax.set_xticklabels(wr.index.tolist())
ax.set_xlabel('游戏时长 game length'); ax.set_ylabel('胜率 win rate %')
ax.set_title('Tank vs Carry 上单：胜率随游戏时长的变化'); ax.legend(); ax.grid(alpha=.3)
fig.tight_layout(); fig.savefig(f'{FIG}/A3_tank_carry_length.png',dpi=130); plt.close()

print("\n"+"="*70); print("ANALYSIS 5: CHAMPION-SPECIFIC gold-to-win conversion"); print("="*70)
rows=[]
for ch,n in d['top_champion'].value_counts().items():
    if n<60: continue
    s=d[d.top_champion==ch].copy()
    if s['result'].nunique()<2: continue
    s['z_gd']=z(s['top_golddiffat15']); s['z_tg']=z(s['team_golddiff15'])
    try:
        mm=logit(s,['z_gd','z_tg']); ci=prof.set_index('champion').loc[ch,'carry_index']
        rows.append((ch,n,np.exp(mm.params['z_gd']),mm.params['z_gd'],mm.pvalues['z_gd'],s['result'].mean(),ci))
    except Exception as e: pass
cv=pd.DataFrame(rows,columns=['champion','n','OR_goldconv','beta','p','winrate','carry_index']).sort_values('OR_goldconv',ascending=False)
print("\nPer-champion: OR of WINNING per +1SD of OWN top gold lead (controlling team gold)")
print("(high OR = this champ's personal lead converts to wins; low = wasted)")
print(cv.round(3).to_string(index=False))
cv.to_csv('outputs/champion_goldconv.csv',index=False)
fig,ax=plt.subplots(figsize=(8,5))
sc=ax.scatter(cv['carry_index'],cv['OR_goldconv'],s=cv['n']/3,c=cv['winrate'],cmap='coolwarm',edgecolor='k')
for _,r in cv.iterrows(): ax.annotate(r['champion'],(r['carry_index'],r['OR_goldconv']),fontsize=7)
ax.axhline(1,ls='--',c='grey'); plt.colorbar(sc,label='overall win rate')
ax.set_xlabel('carry_index (tank<-  ->carry)'); ax.set_ylabel('OR: own gold lead -> win (conversion)')
ax.set_title('英雄经济转化率 vs 英雄定位 (气泡=对局数)')
fig.tight_layout(); fig.savefig(f'{FIG}/A5_champ_conversion.png',dpi=130); plt.close()
print("\nFigures saved to analysis/figures/")
