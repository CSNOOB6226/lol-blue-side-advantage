import pandas as pd, numpy as np
F = "topics/数据/原始数据/2026年非中国赛区比赛数据.csv"
df = pd.read_csv(F, low_memory=False)

# Missingness in timing columns by position
key = ['goldat10','xpat10','csat10','golddiffat10','xpdiffat10','csdiffat10',
       'goldat15','golddiffat15','xpdiffat15','csdiffat15','goldat20','golddiffat20']
print("=== Missing (%) for top-lane rows ===")
top = df[df.position=='top']
print((top[key].isna().mean()*100).round(2))

print("\n=== earnedgoldshare describe (top rows) ===")
print(top['earnedgoldshare'].describe())

print("\n=== team row: which gold cols populated? ===")
team = df[df.position=='team']
for c in ['totalgold','earnedgold','golddiffat15','golddiffat10','goldat15','result','gamelength']:
    print(f"{c}: missing {team[c].isna().mean()*100:.1f}%")

print("\n=== gamelength (minutes) describe, team rows ===")
print((team['gamelength']/60).describe().round(2))

print("\n=== result balance (team rows) ===")
print(team['result'].value_counts())

# Top champions
print("\n=== Top-lane champions (top 25) ===")
print(top['champion'].value_counts().head(25))

print("\n=== sample: one game, top + team rows ===")
g = df.gameid.iloc[0]
cols=['side','position','champion','result','totalgold','earnedgoldshare','golddiffat15','goldat15']
print(df[df.gameid==g][cols].to_string())
