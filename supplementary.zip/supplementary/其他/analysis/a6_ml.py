import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, StratifiedKFold, cross_val_predict
from sklearn.inspection import permutation_importance
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
import xgboost as xgb, shap
from prep import load
d,_=load()

# STRICTLY pre-15 features (no post-game / circular vars)
feats=['team_golddiff10','team_golddiff15',
       'top_golddiffat15','jng_golddiffat15','mid_golddiffat15','bot_golddiffat15','sup_golddiffat15',
       'top_golddiffat10','jng_golddiffat10','mid_golddiffat10','bot_golddiffat10','sup_golddiffat10',
       'top_xpdiffat15','mid_xpdiffat15','bot_xpdiffat15',
       'top_csdiffat15','top_gs15','firstblood','firstdragon','void_grubs','grub_diff']
X=d[feats].fillna(0).values; y=d['result'].values
cv=StratifiedKFold(5,shuffle=True,random_state=1)

lr=LogisticRegression(max_iter=2000)
Xs=StandardScaler().fit_transform(X)
auc_lr=cross_val_score(lr,Xs,y,cv=cv,scoring='roc_auc')
rf=RandomForestClassifier(n_estimators=400,max_depth=None,min_samples_leaf=20,n_jobs=-1,random_state=1)
auc_rf=cross_val_score(rf,X,y,cv=cv,scoring='roc_auc')
xgm=xgb.XGBClassifier(n_estimators=400,max_depth=4,learning_rate=0.05,subsample=0.9,
                      colsample_bytree=0.9,eval_metric='logloss',random_state=1)
auc_xgb=cross_val_score(xgm,X,y,cv=cv,scoring='roc_auc')
print("="*70); print("ANALYSIS 6: ML models on STRICTLY pre-15 features (predict final win)")
print("="*70)
print(f"5-fold AUC  Logistic={auc_lr.mean():.4f}  RandomForest={auc_rf.mean():.4f}  XGBoost={auc_xgb.mean():.4f}")
print("(If RF/XGB ~ Logistic, relationships are mostly LINEAR; flexible models")
print(" find little extra nonlinearity/interaction.)")

# Permutation importance (XGBoost, held-out)
from sklearn.model_selection import train_test_split
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.3,stratify=y,random_state=1)
xgm.fit(Xtr,ytr)
pi=permutation_importance(xgm,Xte,yte,scoring='roc_auc',n_repeats=20,random_state=1,n_jobs=-1)
imp=pd.DataFrame({'feature':feats,'perm_importance':pi.importances_mean,'sd':pi.importances_std}).sort_values('perm_importance',ascending=False)
print("\nPermutation importance (drop in AUC when shuffled), top->bottom:")
print(imp.round(4).to_string(index=False))
imp.to_csv('outputs/perm_importance.csv',index=False)

# rank of each individual lane's at15 golddiff
print("\nRank of individual lane gold-diff@15 features (within the list above):")
order=imp.reset_index(drop=True)
for r in ['top','jng','mid','bot','sup']:
    f=f'{r}_golddiffat15'; rk=order.index[order.feature==f][0]+1
    print(f"  {f:18s} rank {rk}/{len(feats)}  perm_imp={float(order.loc[order.feature==f,'perm_importance'].iloc[0]):.4f}")

# SHAP
expl=shap.TreeExplainer(xgm); sv=expl.shap_values(Xte)
msa=np.abs(sv).mean(0)
shap_imp=pd.DataFrame({'feature':feats,'mean_abs_shap':msa}).sort_values('mean_abs_shap',ascending=False)
print("\nMean |SHAP| (XGBoost):")
print(shap_imp.round(4).to_string(index=False))
plt.figure(); shap.summary_plot(sv,Xte,feature_names=feats,show=False,max_display=21)
plt.tight_layout(); plt.savefig('figures/A6_shap_summary.png',dpi=130,bbox_inches='tight'); plt.close()
# bar fig
fig,ax=plt.subplots(figsize=(7,6)); o=imp.sort_values('perm_importance')
ax.barh(o['feature'],o['perm_importance'],xerr=o['sd'],color='steelblue')
ax.set_xlabel('Permutation importance (AUC drop)'); ax.set_title('特征重要性：team gold 主导，top 个人指标垫底')
fig.tight_layout(); fig.savefig('figures/A6_perm_importance.png',dpi=130); plt.close()
print("\nFigures saved: A6_shap_summary.png, A6_perm_importance.png")
