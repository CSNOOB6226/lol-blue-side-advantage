import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import statsmodels.api as sm
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
from prep import load, z
d,_=load()
d['team_xpdiff15']=d[[f'{r}_xpdiffat15' for r in ['top','jng','mid','bot','sup']]].sum(axis=1)
d['team_csdiff15']=d[[f'{r}_csdiffat15' for r in ['top','jng','mid','bot','sup']]].sum(axis=1)
d['team_killdiff15']=d['team_killsat15']-d['team_deathsat15']
for c in ['team_golddiff15','team_xpdiff15','team_csdiff15','team_killdiff15']: d['z_'+c]=z(d[c])
FE=pd.concat([pd.get_dummies(d['league'],prefix='lg',drop_first=True).astype(float),
              pd.get_dummies(d['patch'].astype(str),prefix='p',drop_first=True).astype(float),
              (d['side']=='Blue').astype(float).rename('blue')],axis=1)
def fit(cols):
    X=sm.add_constant(pd.concat([d[cols],FE],axis=1))
    return sm.Logit(d['result'],X).fit(disp=0,cov_type='cluster',cov_kwds={'groups':d['gameid']})

print("="*70); print("G1 CONFIRM — 'What kind of lead is real?' (+league/patch/side FE)")
print("="*70)
base=fit(['z_team_golddiff15'])
addk=fit(['z_team_golddiff15','z_team_killdiff15'])
addx=fit(['z_team_golddiff15','z_team_xpdiff15','z_team_csdiff15'])
full=fit(['z_team_golddiff15','z_team_xpdiff15','z_team_csdiff15','z_team_killdiff15'])
def lr(m_small,m_big,k):
    chi=2*(m_big.llf-m_small.llf); from scipy.stats import chi2; return chi, chi2.sf(chi,k)
print(f"  gold only          : pseudoR2={base.prsquared:.4f}")
c,p=lr(base,addk,1); print(f"  + KILL diff        : pseudoR2={addk.prsquared:.4f}  LR chi2(1)={c:.2f} p={p:.3f}  <- kills add ~nothing")
c,p=lr(base,addx,2); print(f"  + XP & CS diff     : pseudoR2={addx.prsquared:.4f}  LR chi2(2)={c:.2f} p={p:.2e}  <- big jump")
print("\n  Full model coefficients (all controlling each other + FE):")
for v,lab in [('z_team_golddiff15','gold diff@15'),('z_team_xpdiff15','XP diff@15'),
              ('z_team_csdiff15','CS diff@15'),('z_team_killdiff15','KILL diff@15')]:
    print(f"    {lab:13s}: OR={np.exp(full.params[v]):.3f}  (p={full.pvalues[v]:.2e})")

print("\n"+"="*70); print("G2 CONFIRM — First blood after controlling the gold it created (+FE)")
print("="*70)
fb1=fit(['firstblood']); fb2=fit(['firstblood','z_team_golddiff15'])
print(f"  firstblood alone : OR={np.exp(fb1.params['firstblood']):.3f} (p={fb1.pvalues['firstblood']:.2e})")
print(f"  + team gold@15   : OR={np.exp(fb2.params['firstblood']):.3f} (p={fb2.pvalues['firstblood']:.2e})  <- collapses below 1")

# ---- figures ----
# G1 composition coefficient plot
labs=['gold diff@15','XP diff@15','CS diff@15','KILL diff@15']
vs=['z_team_golddiff15','z_team_xpdiff15','z_team_csdiff15','z_team_killdiff15']
ors=[np.exp(full.params[v]) for v in vs]
lo=[np.exp(full.params[v]-1.96*full.bse[v]) for v in vs]
hi=[np.exp(full.params[v]+1.96*full.bse[v]) for v in vs]
fig,ax=plt.subplots(figsize=(7,3.6)); ypos=range(len(vs))
ax.errorbar(ors,ypos,xerr=[np.array(ors)-np.array(lo),np.array(hi)-np.array(ors)],fmt='o',color='#4f81bd',capsize=4)
ax.axvline(1,ls='--',c='k'); ax.set_yticks(ypos); ax.set_yticklabels(labs)
ax.set_xlabel('OR per +1SD (controlling the others + 联赛/版本/红蓝方)')
ax.set_title('同样的15分钟领先，"由什么构成"决定它值不值钱\n击杀差≈1(无独立价值)，经验/补刀差才带额外信息')
for x,y in zip(ors,ypos): ax.text(x,y+0.12,f'{x:.2f}',ha='center',fontsize=9)
fig.tight_layout(); fig.savefig('figures/G1_lead_quality.png',dpi=130); plt.close()

# G4 region determinism
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, StratifiedKFold
d['gold_leader_wins']=((d['team_golddiff15']>0)&(d['result']==1))|((d['team_golddiff15']<0)&(d['result']==0))
cv=StratifiedKFold(5,shuffle=True,random_state=1); rows=[]
for lg in d['league'].value_counts()[lambda s:s>=400].index:
    s=d[d.league==lg]; rows.append((lg,s['gold_leader_wins'].mean()*100))
rr=pd.DataFrame(rows,columns=['league','leader_wr']).sort_values('leader_wr')
fig,ax=plt.subplots(figsize=(7,3.6))
ax.barh(rr['league'],rr['leader_wr'],color='#c0504d'); ax.axvline(74.6,ls='--',c='k')
ax.set_xlabel('15分钟经济领先方最终获胜率 %'); ax.set_xlim(60,85)
ax.set_title('比赛有多"一锤定音"？各赛区差异(虚线=总体74.6%)\nLEC最容易翻盘, LJL最雪球')
for i,(_,r) in enumerate(rr.iterrows()): ax.text(r['leader_wr']+0.3,i,f"{r['leader_wr']:.1f}",va='center',fontsize=8)
fig.tight_layout(); fig.savefig('figures/G4_region_determinism.png',dpi=130); plt.close()
print("\nFigures saved: G1_lead_quality.png, G4_region_determinism.png")
