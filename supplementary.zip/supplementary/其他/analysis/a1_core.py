import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import statsmodels.api as sm
from prep import load, z
d,_ = load()

def logit(df, yvar, xvars):
    X = sm.add_constant(df[xvars]); y = df[yvar]
    m = sm.Logit(y, X).fit(disp=0, cov_type='cluster', cov_kwds={'groups':df['gameid']})
    return m

# standardized predictors (player cols use *at15, team cols use _15)
rename_map = {'top_golddiff15':'top_golddiffat15','top_xpdiff15':'top_xpdiffat15',
              'top_csdiff15':'top_csdiffat15','top_golddiff10':'top_golddiffat10',
              'team_golddiff15':'team_golddiff15','team_golddiff10':'team_golddiff10'}
for short,real in rename_map.items():
    d['z_'+short] = z(d[real])
for r in ['top','jng','mid','bot','sup']:
    d['z_'+r+'_gd15'] = z(d[r+'_golddiffat15'])

print("="*70)
print("ANALYSIS 1: Does the TOP laner's gold lead predict the win,")
print("            before vs after controlling for TEAM total gold lead?")
print("="*70)
def OR(m, name):
    b=m.params[name]; se=m.bse[name]; p=m.pvalues[name]
    return f"OR={np.exp(b):.3f}  (beta={b:+.3f}, SE={se:.3f}, p={p:.2e})"

m1 = logit(d,'result',['z_top_golddiff15'])
print("\n[M1] result ~ top_golddiff15 (alone)")
print("   top_golddiff15:", OR(m1,'z_top_golddiff15'), " pseudoR2=%.3f"%m1.prsquared)

m2 = logit(d,'result',['z_top_golddiff15','z_team_golddiff15'])
print("\n[M2] result ~ top_golddiff15 + team_golddiff15")
print("   top_golddiff15 :", OR(m2,'z_top_golddiff15'))
print("   team_golddiff15:", OR(m2,'z_team_golddiff15'), " pseudoR2=%.3f"%m2.prsquared)

m3 = logit(d,'result',['z_top_golddiff15','z_top_xpdiff15','z_top_csdiff15','z_team_golddiff15'])
print("\n[M3] add top XP diff & CS diff (all controlling team gold)")
for v in ['z_top_golddiff15','z_top_xpdiff15','z_top_csdiff15','z_team_golddiff15']:
    print(f"   {v:18s}:", OR(m3,v))

print("\n" + "="*70)
print("ANALYSIS 4: Decompose team lead into the 5 lanes' individual gold")
print("   leads. Marginal value of a +1 SD gold lead in each role:")
print("="*70)
m4 = logit(d,'result',['z_top_gd15','z_jng_gd15','z_mid_gd15','z_bot_gd15','z_sup_gd15'])
rows=[]
for r in ['top','jng','mid','bot','sup']:
    v='z_'+r+'_gd15'; rows.append((r, np.exp(m4.params[v]), m4.params[v], m4.bse[v], m4.pvalues[v]))
rows.sort(key=lambda x:-x[1])
print(f"{'lane':5s} {'OR':>7s} {'beta':>8s} {'SE':>6s} {'p':>10s}")
for r,o,b,se,p in rows:
    print(f"{r:5s} {o:7.3f} {b:+8.3f} {se:6.3f} {p:10.2e}")
print("   pseudoR2=%.3f"%m4.prsquared)
print("\n(Each lane's +1SD gold lead ~ same gold magnitude; higher OR = that")
print(" lane's gold lead converts to wins more efficiently.)")
