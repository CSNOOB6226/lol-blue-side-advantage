"""Build master team-game analysis table from Oracle's Elixir 2026 non-China data."""
import pandas as pd, numpy as np, json, warnings
warnings.filterwarnings('ignore')
F = "topics/数据/原始数据/2026年非中国赛区比赛数据.csv"
df = pd.read_csv(F, low_memory=False)

roles = ['top','jng','mid','bot','sup']
# ---- per-(game,side) context from team row ----
team = df[df.position=='team'].copy()
ctx_cols = ['gameid','side','result','gamelength','league','split','playoffs','year','patch',
            'goldat10','goldat15','golddiffat10','golddiffat15','xpat15','csat15',
            'killsat15','deathsat15','team kpm',
            'firstblood','firstdragon','dragons','opp_dragons','firstherald','heralds',
            'void_grubs','opp_void_grubs','firstbaron','barons','firsttower','towers','opp_towers',
            'firsttothreetowers','golddiffat20','golddiffat25']
team = team[ctx_cols].rename(columns={
    'goldat10':'team_goldat10','goldat15':'team_goldat15',
    'golddiffat10':'team_golddiff10','golddiffat15':'team_golddiff15',
    'golddiffat20':'team_golddiff20','golddiffat25':'team_golddiff25',
    'xpat15':'team_xpat15','csat15':'team_csat15','killsat15':'team_killsat15','deathsat15':'team_deathsat15'})
base = team.copy()
base['gamelength_min'] = base['gamelength']/60.0

# ---- per-role player features merged in ----
pcols = ['gameid','side','champion','goldat10','goldat15','golddiffat10','golddiffat15',
         'xpdiffat10','xpdiffat15','csdiffat10','csdiffat15','xpat15','csat15',
         'killsat15','deathsat15','assistsat15',
         'damageshare','damagemitigatedperminute','damagetakenperminute','dpm','earnedgoldshare']
for r in roles:
    sub = df[df.position==r][pcols].copy()
    ren = {c: f'{r}_{c}' for c in pcols if c not in ('gameid','side')}
    sub = sub.rename(columns=ren)
    base = base.merge(sub, on=['gameid','side'], how='left')

# ---- derived: gold shares at 15 (non-circular, pre-15) ----
for r in roles:
    base[f'{r}_gs15'] = base[f'{r}_goldat15']/base['team_goldat15']
    base[f'{r}_gs10'] = base[f'{r}_goldat10']/base['team_goldat10']
base['top_xpshare15'] = base['top_xpat15']/base['team_xpat15']
base['top_csshare15'] = base['top_csat15']/base['team_csat15']

# net objective tempo (descriptive)
base['drag_diff'] = base['dragons']-base['opp_dragons']
base['grub_diff'] = base['void_grubs']-base['opp_void_grubs']
base['tower_diff'] = base['towers']-base['opp_towers']

base.to_csv('analysis/team_game.csv', index=False)
print('Saved analysis/team_game.csv shape=', base.shape)

# ---- data-driven champion archetype (tank<->carry) from damage profile ----
top = df[df.position=='top'].copy()
prof = top.groupby('champion').agg(
    n=('champion','size'),
    dmgshare=('damageshare','mean'),
    mitig=('damagemitigatedperminute','mean'),
    taken=('damagetakenperminute','mean'),
    dpm=('dpm','mean'),
    egshare=('earnedgoldshare','mean')).reset_index()
prof = prof[prof.n>=20].copy()
# carry index: high damage share, low mitigation = carry; high mitigation, low dmgshare = tank
z = lambda s:(s-s.mean())/s.std()
prof['carry_index'] = z(prof.dmgshare) - z(prof.mitig)
prof = prof.sort_values('carry_index')
prof.to_csv('analysis/outputs/champion_profile.csv', index=False)
pd.set_option('display.width',200)
print('\n=== Champion archetype axis (sorted tank -> carry) ===')
print(prof[['champion','n','dmgshare','mitig','dpm','egshare','carry_index']].round(3).to_string(index=False))
