"""Shared prep: load master table, attach champion archetypes, standardize."""
import pandas as pd, numpy as np, os
HERE = os.path.dirname(os.path.abspath(__file__))
def load():
    d = pd.read_csv(os.path.join(HERE,'team_game.csv'), low_memory=False)
    prof = pd.read_csv(os.path.join(HERE,'outputs','champion_profile.csv'))
    # 3-class archetype from data-driven carry_index
    def lab(ci):
        if ci <= -1.0: return 'tank'
        if ci >= 0.6:  return 'carry'
        return 'bruiser'
    prof['archetype'] = prof['carry_index'].apply(lab)
    cmap = dict(zip(prof.champion, prof.archetype))
    cidx = dict(zip(prof.champion, prof.carry_index))
    d['top_arch'] = d['top_champion'].map(cmap)
    d['top_carry_index'] = d['top_champion'].map(cidx)
    return d, prof

def z(s):
    return (s - s.mean())/s.std()

if __name__ == '__main__':
    d, prof = load()
    print('master shape', d.shape)
    print('\narchetype counts (top-laner team-games):')
    print(d['top_arch'].value_counts(dropna=False))
    print('\nmean win rate by archetype:')
    print(d.groupby('top_arch')['result'].mean().round(3))
