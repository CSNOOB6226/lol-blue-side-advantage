from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUTPUT = str(Path(__file__).resolve().parents[1] / "论文/League_of_Legends_电竞统计论文分析.docx")
Path(OUTPUT).parent.mkdir(parents=True, exist_ok=True)

BLUE = RGBColor(31, 78, 121)
DARK_BLUE = RGBColor(17, 45, 78)
MUTED = RGBColor(90, 98, 108)
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F2F4F7"
WHITE = RGBColor(255, 255, 255)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=100, start=120, bottom=100, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_repeat_keep(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    keep_next = OxmlElement("w:keepNext")
    p_pr.append(keep_next)


def set_font(run, size=11, bold=False, italic=False, color=None):
    run.font.name = "Arial"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "PingFang SC")
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = color


def add_rich_paragraph(doc, segments, style=None, align=None, before=0, after=6):
    p = doc.add_paragraph(style=style)
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.15
    for text, kwargs in segments:
        run = p.add_run(text)
        set_font(run, **kwargs)
    return p


def add_body(doc, text, bold_prefix=None):
    if bold_prefix and text.startswith(bold_prefix):
        return add_rich_paragraph(
            doc,
            [
                (bold_prefix, {"bold": True}),
                (text[len(bold_prefix):], {}),
            ],
        )
    return add_rich_paragraph(doc, [(text, {})])


def add_bullet(doc, text, level=0):
    style = "List Bullet" if level == 0 else "List Bullet 2"
    p = doc.add_paragraph(style=style)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    set_font(p.add_run(text))
    return p


def add_number(doc, text):
    p = doc.add_paragraph(style="List Number")
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    set_font(p.add_run(text))
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    p.paragraph_format.keep_with_next = True
    set_font(
        p.add_run(text),
        size={1: 16, 2: 13, 3: 12}[level],
        bold=True,
        color=BLUE if level < 3 else DARK_BLUE,
    )
    return p


def add_equation(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.keep_together = True
    set_font(p.add_run(text), size=11, italic=True, color=DARK_BLUE)
    return p


def add_link_line(doc, label, url):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    set_font(p.add_run(f"{label}："), bold=True)
    set_font(p.add_run(url), color=BLUE)
    return p


def add_section_intro(doc):
    add_heading(doc, "文献筛选说明", 1)
    add_body(doc, "这五篇论文分别涵盖：")
    for item in [
        "实时胜率预测（Win Probability）",
        "选手英雄熟练度（Player-Champion Experience）",
        "队内经济分配（Gold Allocation）",
        "选手表现评估（Player Performance Evaluation）",
        "团队层级比赛预测（Team-Level Match Prediction）",
    ]:
        add_bullet(doc, item)
    add_body(
        doc,
        "需要特别注意：只有第 3 篇直接使用职业比赛数据。其他论文主要使用排位赛数据，因此不能直接把结论套用到职业比赛，最好使用 Oracle’s Elixir 数据重新验证。",
    )


def add_paper_1(doc):
    add_heading(doc, "1. Smart Kills and Worthless Deaths: eSports Analytics for League of Legends", 1)
    add_heading(doc, "完整引用", 2)
    add_body(doc, "Maymin, P. Z. (2021). “Smart kills and worthless deaths: eSports analytics for League of Legends.” Journal of Quantitative Analysis in Sports, 17(1), 11–27.")
    add_link_line(doc, "论文链接", "https://doi.org/10.1515/jqas-2019-0096")

    add_heading(doc, "研究问题", 2)
    add_body(doc, "高频率的游戏状态数据，是否能够比普通的击杀、死亡和经济数据更准确地：")
    add_bullet(doc, "预测比赛胜率；")
    add_bullet(doc, "衡量单个选手对团队胜利的贡献？")

    add_heading(doc, "数据集", 2)
    add_body(doc, "作者通过观战系统、Computer Vision（计算机视觉）和客户端数据收集技术，获得了数百万场 LoL 排位赛数据。")
    add_body(doc, "主要分析使用：")
    for item in [
        "约 150,000 场同一版本的比赛；",
        "玩家段位覆盖 Bronze 至 Challenger；",
        "每分钟抽取一次比赛状态；",
        "记录英雄位置、技能、伤害、视野和资源状态。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "研究方法", 2)
    for item in [
        "Logistic Regression（逻辑回归）",
        "Stochastic Gradient Descent，SGD（随机梯度下降）",
        "Fast-and-Frugal Trees，FFT（快速简约决策树）",
        "Correlation Analysis（相关分析）",
        "Role-Specific Regression（分位置回归）",
        "Computer Vision Data Collection（计算机视觉数据采集）",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "主要变量", 2)
    for item in [
        "Game minute",
        "Team kills",
        "Towers destroyed",
        "Major monsters killed",
        "Champion location",
        "Movement and map coverage",
        "Damage dealt and received",
        "Vision and vision denial",
        "Health、mana 和 cooldowns",
        "Smart kills",
        "Worthless deaths",
        "Survivability",
        "Time management",
        "Laning performance",
        "Gold-related metrics",
    ]:
        add_bullet(doc, item)
    add_body(doc, "其中：")
    add_bullet(doc, "Smart Kill：击杀发生后，团队预测胜率明显提高的击杀。")
    add_bullet(doc, "Worthless Death：死亡没有给团队带来足够战略回报，同时显著降低胜率的死亡。")

    add_heading(doc, "主要结论", 2)
    add_body(doc, "根据行动对胜率的影响进行加权后，得到的高级指标比普通 KDA 更能解释团队胜利。")
    add_body(doc, "作者构建的简化决策树使用高级表现指标，预测准确率约为 80%。")
    add_body(doc, "普通击杀并不一定有价值。只有显著提高团队胜率的击杀，才真正体现选手贡献。")

    add_heading(doc, "局限性", 2)
    for item in [
        "使用排位赛而非职业比赛；",
        "数据采集方式复杂，Oracle’s Elixir 无法完整复现；",
        "数据跨越多个 Patch；",
        "简化的胜率模型没有加入经济差、英雄阵容和选手实力；",
        "结果主要是预测关系，不能证明因果关系。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "对你的项目有什么启发", 2)
    add_body(doc, "你可以使用 Win Probability Added，WPA（胜率贡献值）衡量上单选手的关键行动。")
    add_body(doc, "例如：")
    add_equation(doc, "WPA = P(行动后获胜) − P(行动前获胜)")
    add_body(doc, "这样可以区分：")
    for item in ["有价值的上单击杀；", "无意义的单杀；", "为团队争取资源的牺牲；", "对胜率破坏严重的死亡。"]:
        add_bullet(doc, item)

    add_heading(doc, "最相关的研究主题", 2)
    add_body(doc, "5. Early-Game Win Probability Modeling")


def add_paper_2(doc):
    add_heading(doc, "2. Using Machine Learning to Predict Game Outcomes Based on Player-Champion Experience in League of Legends", 1)
    add_heading(doc, "完整引用", 2)
    add_body(doc, "Do, T. D., Wang, S. I., Yu, D. S., McMillian, M. G., & McMahan, R. P. (2021). “Using Machine Learning to Predict Game Outcomes Based on Player-Champion Experience in League of Legends.” Proceedings of the 16th International Conference on the Foundations of Digital Games.")
    add_link_line(doc, "论文链接", "https://doi.org/10.1145/3472538.3472579")
    add_link_line(doc, "预印本链接", "https://arxiv.org/abs/2108.02799")

    add_heading(doc, "研究问题", 2)
    add_body(doc, "在比赛正式开始之前，仅根据玩家对所选英雄的熟练程度，能否预测比赛结果？")

    add_heading(doc, "数据集", 2)
    for item in [
        "Riot Games API",
        "5,000 场不重复的 2020 年排位赛",
        "North America 服务器",
        "Iron 至 Diamond 段位",
        "80% Training Set",
        "20% Test Set",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "研究方法", 2)
    for item in [
        "Deep Neural Network，DNN（深度神经网络）",
        "Random Forest，RF（随机森林）",
        "Gradient Boosting（梯度提升）",
        "Support Vector Classifier，SVC（支持向量分类器）",
        "k-Nearest Neighbors，kNN（K近邻）",
        "Pearson Correlation（皮尔逊相关）",
        "Stratified Cross-Validation（分层交叉验证）",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "主要变量", 2)
    add_body(doc, "每名玩家的变量包括：")
    for item in [
        "Champion mastery points",
        "Player-champion win rate",
        "Season games played on champion",
        "Champion games among the last 20 games",
    ]:
        add_bullet(doc, item)
    add_body(doc, "团队层级变量包括：")
    for item in ["Mean", "Median", "Variance", "Standard deviation", "Skewness", "Kurtosis"]:
        add_bullet(doc, item)
    add_body(doc, "最终模型共有 44 个特征变量。")

    add_heading(doc, "主要结论", 2)
    for item in [
        "Gradient Boosting 准确率约为 75.4%；",
        "DNN 准确率约为 75.1%；",
        "Champion win rate 和 mastery points 具有较强预测能力；",
        "单纯的英雄使用场次没有同样强的预测能力。",
    ]:
        add_bullet(doc, item)
    add_body(doc, "这说明“玩过很多场”不一定等于“真正擅长这个英雄”。")

    add_heading(doc, "局限性", 2)
    for item in [
        "样本只有 5,000 场；",
        "只包含一个服务器和一个赛季；",
        "没有覆盖最高水平职业比赛；",
        "没有充分控制英雄对线关系、阵容、版本和战队实力；",
        "随机划分数据不能检验模型对未来 Patch 的预测能力。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "对你的项目有什么启发", 2)
    add_body(doc, "分析“某个英雄获得额外经济是否有效”时，应该控制：")
    for item in [
        "选手对该英雄的熟练度；",
        "选手过去使用该英雄的表现；",
        "Player × Champion Interaction（选手与英雄交互效应）。",
    ]:
        add_bullet(doc, item)
    add_body(doc, "同一名上单选手使用熟练英雄和不熟练英雄时，额外 500 gold 的价值可能不同。")

    add_heading(doc, "最相关的研究主题", 2)
    add_body(doc, "4. Marginal Value of Gold by Champion")


def add_paper_3(doc):
    add_heading(doc, "3. Analysis of Team Resource Allocation and Win Percentages in League of Legends", 1)
    add_heading(doc, "完整引用", 2)
    add_body(doc, "Larose, C. D., & Mehling, S. A. (2022). “Analysis of Team Resource Allocation and Win Percentages in League of Legends.” Proceedings of the Joint Statistical Meetings, 699–715.")
    add_link_line(doc, "论文链接", "https://0633e92166c0a27ea1aa-ab47878a9e45eb9e2f15be38a59f867e.ssl.cf1.rackcdn.com/JTJLFYSY-2258804-1828585-Upload-1669675867.pdf")

    add_heading(doc, "研究问题", 2)
    add_body(doc, "职业比赛中，15 分钟时团队经济在五个位置之间的分配方式，如何影响最终胜率？")

    add_heading(doc, "数据集", 2)
    for item in [
        "Oracle’s Elixir",
        "2019 LCS Spring 和 Summer",
        "184 场常规赛",
        "主要模型排除了 15 分钟经济差绝对值超过 2,000 的比赛",
    ]:
        add_bullet(doc, item)
    add_body(doc, "作者这样处理，是为了重点研究经济接近、胜负尚未明显确定的比赛。")

    add_heading(doc, "研究方法", 2)
    for item in [
        "Classification and Regression Trees，CART",
        "Association Rule Mining（关联规则挖掘）",
        "Correlation Analysis",
        "Train/Test Evaluation",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "主要变量", 2)
    for item in [
        "Top gold share at 15",
        "Jungle gold share at 15",
        "Mid gold share at 15",
        "Bot gold share at 15",
        "Support gold share at 15",
        "Team side",
        "Gold difference at 15",
        "Match result",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "主要结论", 2)
    add_body(doc, "CART 模型准确率为 60.7%，高于只预测蓝色方获胜的 53.5% baseline。")
    add_body(doc, "主要发现包括：")
    for item in [
        "红色方上单经济占比过高时，蓝色方反而更容易获胜；",
        "蓝色方上单保持正常经济占比时，蓝色方胜率更高；",
        "上单和下路经济占比之间存在明显 Trade-off（资源取舍）；",
        "在经济接近的比赛中，较平衡的经济分配通常与更高胜率相关；",
        "“把上单养得特别肥”并不一定是最优策略。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "局限性", 2)
    for item in [
        "样本量较小；",
        "只研究一个赛区和一个赛季；",
        "CART 得到的阈值可能不稳定；",
        "没有控制英雄类型、对线组合、选手实力、Patch 和战队实力；",
        "经济分配与胜率之间是相关关系，不是因果关系；",
        "上单经济占比高，可能是团队落后后进行边线补发育的结果。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "对你的项目有什么启发", 2)
    add_body(doc, "这是与你当前研究最接近的论文。")
    add_body(doc, "你可以：")
    for item in [
        "使用更多年份和赛区；",
        "将 Top 分为 Tank Top 和 Carry Top；",
        "使用 Restricted Cubic Splines（限制性三次样条）；",
        "加入 Team、Player、Champion 和 Patch Fixed Effects；",
        "检验 Carry Top 是否存在真正的 Gold Threshold。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "最相关的研究主题", 2)
    add_body(doc, "3. Carry Top Gold Threshold")
    add_body(doc, "同时与以下主题高度相关：")
    add_bullet(doc, "1. Tank Top vs Carry Top")
    add_bullet(doc, "2. Weak-Side Top Effect")


def add_paper_4(doc):
    add_heading(doc, "4. The SIDO Performance Model for League of Legends", 1)
    add_heading(doc, "完整引用", 2)
    add_body(doc, "Zhang, A. X., & Naidu, P. (2024). “The SIDO Performance Model for League of Legends.” arXiv preprint arXiv:2403.04873.")
    add_link_line(doc, "论文链接", "https://arxiv.org/abs/2403.04873")

    add_heading(doc, "研究问题", 2)
    add_body(doc, "能否将选手表现拆分为：")
    add_number(doc, "自己获得的资源；")
    add_number(doc, "为队友创造的资源；")
    add_number(doc, "阻止对手获得的资源？")

    add_heading(doc, "数据集", 2)
    for item in [
        "Riot API 高分段排位赛",
        "NA、EUW 和 Korea 服务器",
        "Patch 13.14–13.18",
        "每日排名前 1,000 的账号",
        "账号至少参加 50 场比赛",
        "英雄至少由 30 个不同账号使用",
        "使用 7、15 和 25 分钟的游戏状态",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "研究方法", 2)
    for item in [
        "Hierarchical Bayesian Models（层级贝叶斯模型）",
        "Player Random Effects",
        "Champion Random Effects",
        "Plus-Minus Model",
        "Residual-Based Contribution Models（基于残差的贡献模型）",
        "t-tests",
        "Metric Stability Analysis（指标稳定性分析）",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "主要变量", 2)
    for item in [
        "Gold earned",
        "Damage dealt to champions",
        "Damage taken",
        "Player",
        "Champion",
        "Role",
        "Region",
        "Game phase",
        "Ally residual performance",
        "Enemy residual performance",
        "Professional-player account status",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "核心框架", 2)
    add_body(doc, "SIDO 将选手表现拆分为：")
    add_equation(doc, "Own Contribution + Ally-Enabling Contribution + Enemy-Denial Contribution")
    add_body(doc, "也就是：")
    for item in ["自己获得多少资源；", "帮助队友获得多少资源；", "阻止敌人获得多少资源。"]:
        add_bullet(doc, item)

    add_heading(doc, "主要结论", 2)
    for item in [
        "SIDO 比简单平均值和传统 Plus-Minus Model 更能区分高水平选手；",
        "职业打野的重要能力之一是阻止敌人获得经济；",
        "ADC 更依赖个人机械和直接输出；",
        "Jungle 和 Support 的价值更多体现在战略和团队贡献；",
        "不能只用选手自己的经济或伤害判断表现。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "局限性", 2)
    for item in [
        "Solo Queue 与职业战队协作环境不同；",
        "职业选手账号识别不完整；",
        "Ally 和 Enemy Contribution 的区分能力较低；",
        "数据只覆盖较短的 Patch 范围；",
        "模型较复杂，对本科研究来说需要适当简化。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "对你的项目有什么启发", 2)
    add_body(doc, "你可以把上单表现拆分为：")
    add_equation(doc, "Own Gold + Gold Enabled for Teammates + Gold Denied from Opponents")
    add_body(doc, "这特别适合分析 Weak-Side Top。")
    add_body(doc, "弱侧上单可能：")
    for item in [
        "自己经济较低；",
        "被对方打野频繁针对；",
        "吸收大量压力；",
        "让己方下路和打野获得更多资源；",
        "自己虽然 GD15 为负，但团队整体因此获益。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "最相关的研究主题", 2)
    add_body(doc, "2. Weak-Side Top Effect")
    add_body(doc, "同时与 4. Marginal Value of Gold by Champion 高度相关。")


def add_paper_5(doc):
    add_heading(doc, "5. Multi-Objective Multi-Instance Learning: A New Approach to Machine Learning for eSports", 1)
    add_heading(doc, "完整引用", 2)
    add_body(doc, "Birant, K. U., & Birant, D. (2023). “Multi-Objective Multi-Instance Learning: A New Approach to Machine Learning for eSports.” Entropy, 25(1), 28.")
    add_link_line(doc, "论文链接", "https://doi.org/10.3390/e25010028")

    add_heading(doc, "研究问题", 2)
    add_body(doc, "把五名选手共同视为一个团队进行建模，是否比把每名选手视为独立样本更能准确预测比赛结果？")

    add_heading(doc, "数据集", 2)
    for item in [
        "Kaggle 公开 LoL 排位赛数据",
        "1,834,520 条玩家记录",
        "North America 和 Europe",
        "Season 3–7",
        "约 40 个比赛表现变量",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "研究方法", 2)
    for item in [
        "Multi-Instance Logistic Regression",
        "Multi-Instance SVM",
        "Multi-Instance Boosting",
        "Decision Trees",
        "SimpleMI",
        "10-Fold Cross-Validation",
        "Mann–Whitney U Test",
        "Feature Importance Analysis",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "主要变量", 2)
    for item in [
        "Kills",
        "Deaths",
        "Assists",
        "Damage",
        "Healing",
        "Wards",
        "Vision score",
        "Gold earned",
        "Turret kills",
        "Rewards",
        "Per-minute statistics",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "主要结论", 2)
    for item in [
        "团队层级的 Multi-Instance Models 通常优于玩家层级模型；",
        "SimpleMI 平均准确率约为 94%；",
        "Turret kills、deaths per minute 和 assists per minute 是重要预测变量；",
        "不同赛季的模型表现存在明显差异。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "局限性", 2)
    add_body(doc, "该论文存在一个非常重要的问题：许多变量可能来自比赛结束后的统计数据。")
    add_body(doc, "如果使用最终塔数、最终死亡数或最终伤害预测胜负，就会产生：")
    add_body(doc, "Outcome Leakage / Data Leakage（结果泄漏或数据泄漏）")
    add_body(doc, "模型准确率虽然很高，但不代表它真的能在比赛早期预测胜负。")
    add_body(doc, "其他限制包括：")
    for item in [
        "随机交叉验证没有检验未来赛季；",
        "没有充分处理 Patch 变化；",
        "重点是预测准确率，而不是统计解释；",
        "模型不适合直接回答因果性战略问题。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "对你的项目有什么启发", 2)
    add_body(doc, "LoL 数据具有明显的层级结构：")
    add_equation(doc, "Player ⊂ Role ⊂ Team ⊂ Match")
    add_body(doc, "因此不能把每个 Player-Game Row 当作完全独立的观察值。")
    add_body(doc, "你可以使用：")
    for item in [
        "Mixed-Effects Logistic Regression",
        "Clustered Standard Errors",
        "Team Fixed Effects",
        "Player Random Effects",
        "Champion Random Effects",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "最相关的研究主题", 2)
    add_body(doc, "5. Early-Game Win Probability Modeling")
    add_body(doc, "它最重要的价值是提醒你避免 Data Leakage。")


def add_synthesis(doc):
    add_heading(doc, "综合对比表", 1)
    rows = [
        ("Common datasets", "Riot API 排位赛、Kaggle Riot 数据、Oracle’s Elixir 职业比赛数据、固定分钟游戏状态"),
        ("Common variables", "Gold、gold share、gold difference、kills、deaths、assists、damage、towers、objectives、champion、role、game time"),
        ("Common methods", "Logistic Regression、Decision Trees、Gradient Boosting、Neural Networks、Cross-Validation、Hierarchical Models"),
        ("Common weaknesses", "排位赛结论难以推广到职业比赛；Patch 不稳定；职业比赛样本较小；随机验证代替时间验证；Data Leakage"),
        ("Player evaluation weakness", "经常只使用个人经济、伤害和 KDA，忽略吸收压力、帮助队友和限制敌人的贡献"),
        ("Statistical weakness", "忽略同一战队、选手和英雄的重复观察；缺乏 Clustered Standard Errors 或 Mixed Models"),
        ("Causal weakness", "大部分研究只能说明相关或预测关系，不能证明改变经济分配会导致胜率提高"),
        ("Evaluation weakness", "过度强调 Accuracy，较少报告 Calibration、Brier Score、Log Loss 和不确定性区间"),
        ("Research gaps", "Weak-Side Top、英雄特定经济效率、非线性经济阈值、Tank/Carry Interaction、资源机会成本"),
        ("Validation gaps", "很少进行跨 Patch、跨赛季、跨赛区和真正 Out-of-Sample 的验证"),
    ]
    table = doc.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.columns[0].width = Inches(1.75)
    table.columns[1].width = Inches(4.75)
    hdr = table.rows[0].cells
    hdr[0].text = "比较维度"
    hdr[1].text = "常见做法或发现"
    set_repeat_table_header(table.rows[0])
    for cell in hdr:
        set_cell_shading(cell, LIGHT_BLUE)
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for p in cell.paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:
                set_font(r, bold=True, color=DARK_BLUE)
    for label, detail in rows:
        cells = table.add_row().cells
        cells[0].width = Inches(1.75)
        cells[1].width = Inches(4.75)
        cells[0].text = label
        cells[1].text = detail
        for cell in cells:
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.05
                for r in p.runs:
                    set_font(r, size=9.5)
        set_cell_shading(cells[0], LIGHT_GRAY)
        for r in cells[0].paragraphs[0].runs:
            r.bold = True


def add_borrowed_ideas(doc):
    add_heading(doc, "A. 五个可以直接借鉴的研究设计", 1)

    add_heading(doc, "1. Gold-Share Threshold Model", 2)
    add_body(doc, "借鉴 Larose 与 Mehling，但不要只使用一棵决策树寻找阈值。")
    add_body(doc, "可以建立：")
    add_equation(doc, "P(Win) = f(Top Gold Share₁₅) + Controls")
    add_body(doc, "其中 f 使用：")
    for item in ["Restricted Cubic Splines；", "Segmented Regression；", "Quadratic Terms。"]:
        add_bullet(doc, item)
    add_body(doc, "这样可以检验上单经济是否存在：")
    for item in ["递增收益；", "边际收益递减；", "最优区间；", "过度投资后的负面效果。"]:
        add_bullet(doc, item)

    add_heading(doc, "2. Champion-Adjusted Gold Efficiency", 2)
    add_body(doc, "借鉴 SIDO，使用 Champion Random Effects 和 Player Random Effects。")
    add_body(doc, "例如：")
    add_equation(doc, "Damageᵢ = β₀ + β₁Goldᵢ + uChampion + uPlayer + εᵢ")
    add_body(doc, "比较不同英雄将经济转化为伤害或胜率的效率。")

    add_heading(doc, "3. Top-Lane Win Probability Added", 2)
    add_body(doc, "借鉴 Maymin，先建立早期胜率模型，再衡量上单事件造成的胜率变化。")
    add_body(doc, "可以研究：")
    for item in [
        "First Blood involving top",
        "Top death before 15",
        "Rift Herald",
        "First top turret",
        "Teleport play",
        "Top-lane solo kill",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "4. Player-Champion Interaction", 2)
    add_body(doc, "借鉴 Do et al.，分析：")
    add_equation(doc, "Player × Champion")
    add_body(doc, "避免把英雄强度误认为选手实力，也避免把选手熟练度误认为英雄本身的经济效率。")

    add_heading(doc, "5. Nested Team Modeling", 2)
    add_body(doc, "借鉴 MOMIL 的团队层级思想，但使用更容易解释的统计模型：")
    add_equation(doc, "Player-Game ⊂ Team-Game ⊂ Match")
    add_body(doc, "本科项目推荐：")
    for item in [
        "Mixed-Effects Logistic Regression；",
        "Team Fixed Effects；",
        "Patch Fixed Effects；",
        "Clustered Standard Errors by Match 或 Team。",
    ]:
        add_bullet(doc, item)


def add_rare_analyses(doc):
    add_heading(doc, "B. 五个较少见但可行的 Oracle’s Elixir 分析", 1)

    add_heading(doc, "1. Nonlinear Marginal Value of Top Gold", 2)
    add_body(doc, "研究额外上单经济是否对 Tank 和 Carry 产生不同的边际价值：")
    add_equation(doc, "P(Win) = f(Top Gold Share₁₅) + Top Type + f(Gold Share) × Top Type + Controls")
    add_body(doc, "核心问题是：")
    for item in [
        "Carry Top 是否需要达到某个经济门槛才真正有效？",
        "Tank Top 是否在低经济区间仍然保持较高战略价值？",
        "Carry Top 获得过多经济后是否出现 Diminishing Returns？",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2. Weak-Side Residual Performance Index", 2)
    add_body(doc, "先预测一名上单在特定条件下应该取得的 GD15：")
    add_equation(doc, "GD15̂ = f(Champion Matchup, Side, Player, Opponent, Patch, Team Strength)")
    add_body(doc, "然后计算：")
    add_equation(doc, "Weak-Side Residual = Actual GD15 − GD15̂")
    add_body(doc, "如果选手原本预计会落后 700 gold，但实际只落后 250 gold：")
    add_equation(doc, "−250 − (−700) = 450")
    add_body(doc, "那么他的弱侧表现实际上高于预期。")

    add_heading(doc, "3. Gold Opportunity-Cost Analysis", 2)
    add_body(doc, "研究将经济分配给上单，而不是 Mid 或 Bot，是否值得。")
    add_body(doc, "因为五个位置的 Gold Share 加总约等于 100%，这是 Compositional Data（组成数据）。")
    add_body(doc, "推荐使用：")
    for item in [
        "Log-Ratio Transformation；",
        "Isometric Log-Ratio，ILR；",
        "Relative Gold Share；",
        "Role-to-Role Gold Trade-Off。",
    ]:
        add_bullet(doc, item)
    add_body(doc, "这样可以回答：")
    add_body(doc, "在团队总经济不变时，把 1% 经济占比从 Bot 转移给 Top，与胜率有什么关系？")

    add_heading(doc, "4. Champion-Specific Gold Response Curves", 2)
    add_body(doc, "针对样本充足的英雄，分别估计：")
    add_equation(doc, "Gold → Damage")
    add_body(doc, "以及：")
    add_equation(doc, "Gold → P(Win)")
    add_body(doc, "使用 Partial Pooling（部分汇聚）让小样本英雄向所属类型平均值收缩。")
    add_body(doc, "这能比较：")
    for item in [
        "不同 Carry Top 的经济转化效率；",
        "Tank 与 Carry 的曲线形状；",
        "哪些英雄需要达到 Item Spike 后才显著受益。",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "5. Strategy-Player Compatibility", 2)
    add_body(doc, "计算每名上单选手历史上的正常资源分配方式：")
    add_equation(doc, "Historical Top Gold Share")
    add_body(doc, "再计算当前比赛偏离其习惯风格的程度：")
    add_equation(doc, "|Current Gold Share − Historical Gold Share|")
    add_body(doc, "检验：")
    for item in [
        "战队突然让弱侧型选手承担 Carry 是否降低胜率；",
        "资源型选手使用 Tank 时是否浪费其优势；",
        "Player Style 与 Team Strategy 是否存在显著 Interaction Effect。",
    ]:
        add_bullet(doc, item)

    add_body(doc, "后续我会继续保持这种语言格式：标题、模型名和核心术语保留英文，解释、分析和研究建议全部使用中文。")


def configure_styles(doc):
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.49)
    section.footer_distance = Inches(0.49)

    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "PingFang SC")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.15

    for name, size, color, before, after in [
        ("Heading 1", 16, BLUE, 16, 8),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ]:
        style = doc.styles[name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "PingFang SC")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for list_style in ["List Bullet", "List Bullet 2", "List Number"]:
        style = doc.styles[list_style]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "PingFang SC")
        style.font.size = Pt(11)
        style.paragraph_format.space_after = Pt(4)
        style.paragraph_format.line_spacing = 1.15


def add_header_footer(section):
    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hp.paragraph_format.space_after = Pt(0)
    set_font(hp.add_run("League of Legends 电竞统计研究 | 论文分析"), size=9, color=MUTED)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = fp.add_run("Page ")
    set_font(run, size=9, color=MUTED)
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)


def build():
    doc = Document()
    configure_styles(doc)
    add_header_footer(doc.sections[0])

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(110)
    p.paragraph_format.space_after = Pt(12)
    set_font(p.add_run("League of Legends 电竞统计研究"), size=28, bold=True, color=DARK_BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    set_font(p.add_run("五篇论文分析与研究设计建议"), size=18, bold=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    set_font(p.add_run("主题：Top Lane Resource Allocation、Player Performance 与 Win Probability"), size=11, color=MUTED)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(p.add_run("本科统计研究项目资料"), size=11, color=MUTED)

    doc.add_page_break()
    add_section_intro(doc)
    add_paper_1(doc)
    add_paper_2(doc)
    add_paper_3(doc)
    add_paper_4(doc)
    add_paper_5(doc)
    add_synthesis(doc)
    add_borrowed_ideas(doc)
    add_rare_analyses(doc)

    doc.core_properties.title = "League of Legends 电竞统计研究：五篇论文分析与研究设计建议"
    doc.core_properties.subject = "League of Legends esports statistics literature review"
    doc.core_properties.author = "Vincent"
    doc.core_properties.keywords = "League of Legends, esports, statistics, Oracle's Elixir"
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    build()
