from pathlib import Path
import re

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


SOURCE = Path(__file__).resolve().parent / "inputs/topic1_source.txt"
OUT = Path(__file__).resolve().parents[1]

BLUE = RGBColor(46, 116, 181)
DARK_BLUE = RGBColor(31, 77, 120)
LIGHT_BLUE = "E8EEF5"
GRID = "B8C4D1"


ZH = {
    "Topic1Knowledge": "主题1知识",
    "Weak Side Top Effect & Logistic Regression Notes": "弱侧上路效应与逻辑回归笔记",
    "Research Question": "研究问题",
    "Topic 1 aims to answer:": "主题1旨在回答：",
    "Does playing weak-side top lane increase a team's probability of winning?": "上路采取弱侧打法是否会提高队伍的获胜概率？",
    "More specifically:": "更具体地说：",
    "Is a Stable Weak Side Top (receiving fewer resources but not falling far behind) associated with higher win probability?": "稳定弱侧上路（获得较少资源但没有大幅落后）是否与更高的获胜概率相关？",
    "Variables": "变量",
    "Response Variable": "响应变量",
    "result": "result",
    "Meaning:": "含义：",
    "1 = team won": "1 = 队伍获胜",
    "0 = team lost": "0 = 队伍失利",
    "This is the dependent variable.": "这是因变量。",
    "Main Explanatory Variables": "主要解释变量",
    "Model 1": "模型1",
    "Top Gold Share at 15 minutes": "15分钟时上路经济占比",
    "Top lane gold as a proportion of total team gold.": "上路经济占全队总经济的比例。",
    "The same variable expressed in percentage points.": "以百分点表示的同一个变量。",
    "Example:": "示例：",
    "Used only for easier interpretation.": "仅用于更便于解释。",
    "Important:": "重要：",
    "TopGoldShare15 and TopGoldShare15PP are the same information and should not be entered into the same regression model.": "TopGoldShare15与TopGoldShare15PP包含相同的信息，不应同时放入同一个回归模型。",
    "Model 2": "模型2",
    "Indicator variable:": "指示变量：",
    "Top lane resource share belongs to the lowest 25% of all observations.": "上路资源占比属于所有观测值中最低的25%。",
    "Bottom Quartile": "下四分位数",
    "Procedure:": "步骤：",
    "Sort all TopGoldShare15 values.": "对所有TopGoldShare15值进行排序。",
    "Find the lowest 25%.": "找出最低的25%。",
    "The cutoff happens to be:": "临界值恰好为：",
    "18.8% of team gold.": "占全队经济的18.8%。",
    "Model 3": "模型3",
    "Top receives few resources but remains relatively close to the opponent.": "上路获得较少资源，但与对手的差距仍相对较小。",
    "Interpretation:": "解释：",
    "Weak Side but not losing lane badly.": "处于弱侧，但对线没有严重落后。",
    "Control Variables": "控制变量",
    "GoldDiff15": "GoldDiff15",
    "Top lane gold difference at 15 minutes.": "15分钟时上路经济差。",
    "Purpose:": "目的：",
    "Control for lane advantage.": "控制对线优势。",
    "Side": "Side",
    "Blue Side vs Red Side.": "蓝色方与红色方。",
    "Control for drafting advantages.": "控制选角优势。",
    "League": "League",
    "LCK, LEC, LCS, etc.": "LCK、LEC、LCS等。",
    "Control for regional play-style differences.": "控制赛区打法风格差异。",
    "Patch": "Patch",
    "Game version.": "游戏版本。",
    "Control for balance changes.": "控制平衡性改动。",
    "Logistic Regression": "逻辑回归",
    "Why Not Linear Regression?": "为什么不使用线性回归？",
    "Outcome:": "结果变量：",
    "Only win or lose.": "只有获胜或失利。",
    "Linear regression is not suitable.": "线性回归并不适用。",
    "Logistic Regression Model": "逻辑回归模型",
    "where": "其中",
    "Odds": "优势比",
    "Definition:": "定义：",
    "Winning is four times as likely as losing.": "获胜的可能性是失利的四倍。",
    "Log Odds": "对数优势",
    "This is the left-hand side of the logistic regression equation.": "这是逻辑回归方程的左侧。",
    "From Variables to Win Probability": "从变量到获胜概率",
    "Step 1:": "步骤1：",
    "Step 2:": "步骤2：",
    "Step 3:": "步骤3：",
    "Pipeline:": "流程：",
    "Variables": "变量",
    "Log Odds": "对数优势",
    "Probability": "概率",
    "Win/Lose": "获胜/失利",
    "How Are The β Coefficients Estimated?": "如何估计β系数？",
    "This is the key idea behind Logistic Regression.": "这是逻辑回归背后的关键思想。",
    "Unlike linear regression, Logistic Regression does not minimize SSE.": "与线性回归不同，逻辑回归并不最小化SSE。",
    "Instead, it uses:": "相反，它使用：",
    "Maximum Likelihood Estimation (MLE)": "最大似然估计（MLE）",
    "Step 1": "步骤1",
    "Guess a set of β values.": "猜测一组β值。",
    "Step 2": "步骤2",
    "Compute:": "计算：",
    "for every match.": "对每一场比赛进行计算。",
    "Step 3": "步骤3",
    "Convert each": "将每一个",
    "into": "转换为",
    "using": "使用",
    "Step 4": "步骤4",
    "Compare with actual results.": "与实际结果进行比较。",
    "If": "如果",
    "contribution:": "贡献为：",
    "Step 5": "步骤5",
    "Multiply all contributions together.": "将所有贡献相乘。",
    "This is the Likelihood.": "这就是似然。",
    "Step 6": "步骤6",
    "Adjust β repeatedly until Likelihood is maximized.": "反复调整β，直到似然达到最大值。",
    "The resulting β values are the final regression coefficients.": "所得β值就是最终的回归系数。",
    "Odds Ratio (OR)": "优势比（OR）",
    "Formula:": "公式：",
    "Binary Variable Example": "二元变量示例",
    "Stable Weak Side teams have 3.93 times the winning odds of the reference group.": "稳定弱侧队伍的获胜优势是参考组的3.93倍。",
    "Continuous Variable Example": "连续变量示例",
    "For every 1 percentage-point increase in Top Gold Share, the winning odds become 0.565 times the previous odds.": "上路经济占比每增加1个百分点，获胜优势变为原来的0.565倍。",
    "Odds change.": "发生变化的是优势。",
    "Not win probability.": "不是获胜概率。",
    "Likelihood": "似然",
    "Likelihood measures how well the model explains the observed outcomes.": "似然衡量模型解释观测结果的程度。",
    "use": "使用",
    "Multiply all observations together.": "将所有观测值相乘。",
    "Large Likelihood means better fit.": "似然越大，拟合越好。",
    "Log Likelihood (LL)": "对数似然（LL）",
    "Overall model fit.": "模型的整体拟合程度。",
    "Rule:": "规则：",
    "Closer to 0 is better.": "越接近0越好。",
    "Conclusion:": "结论：",
    "M1 has the best fit.": "M1的拟合最好。",
    "Null Model and Null LL": "空模型与空模型对数似然",
    "Null Model:": "空模型：",
    "Contains only an intercept.": "仅包含截距项。",
    "No explanatory variables.": "不包含解释变量。",
    'Equivalent to:': "等同于：",
    '"Guessing based only on overall win rate."': "“仅根据总体胜率进行猜测。”",
    "Null LL measures the fit of this baseline model.": "空模型对数似然衡量这一基准模型的拟合程度。",
    "McFadden R²": "McFadden R²",
    "Improvement relative to the Null Model.": "相对于空模型的改进程度。",
    "Rule of Thumb": "经验法则",
    "McFadden R²": "McFadden R²",
    "Very weak": "非常弱",
    "Some explanatory power": "具有一定解释力",
    "Good": "良好",
    "Strong": "强",
    "Very strong": "非常强",
    "M1 = Strong": "M1 = 强",
    "M2 = Good": "M2 = 良好",
    "M3 = Some explanatory power": "M3 = 具有一定解释力",
    "LR Chi-Square Test": "LR卡方检验",
    "Test variable importance.": "检验变量的重要性。",
    "where:": "其中：",
    "Full Model = original model": "完整模型 = 原始模型",
    "Reduced Model = model after removing a variable": "简化模型 = 移除某个变量后的模型",
    "Large LR Chi-square:": "较大的LR卡方值：",
    "Removing the variable causes major deterioration.": "移除该变量会导致模型显著恶化。",
    "Therefore the variable is important.": "因此，该变量很重要。",
    "GoldDiff is the most important variable.": "GoldDiff是最重要的变量。",
    "p-value": "p值",
    "Test statistical significance.": "检验统计显著性。",
    "Extremely significant": "极其显著",
    "Very significant": "非常显著",
    "Significant": "显著",
    "Marginal": "边际显著",
    "Not significant": "不显著",
    "F-Test (STAT331)": "F检验（STAT331）",
    "Linear Regression uses:": "线性回归使用：",
    "instead of Log Likelihood.": "而不是对数似然。",
    "Determine whether removing a variable significantly worsens the model.": "判断移除某个变量是否会使模型显著恶化。",
    "Relationship Between F-Test and LR Test": "F检验与LR检验之间的关系",
    "Linear Regression:": "线性回归：",
    "Remove variable": "移除变量",
    "Compare SSE": "比较SSE",
    "Logistic Regression:": "逻辑回归：",
    "Compare Log Likelihood": "比较对数似然",
    "Both answer the same question:": "两者回答的是同一个问题：",
    '"Is this variable important?"': "“这个变量重要吗？”",
    "Prediction vs Explanation": "预测与解释",
    "Predictive Model": "预测模型",
    "Goal:": "目标：",
    "Predict outcomes as accurately as possible.": "尽可能准确地预测结果。",
    "Metrics:": "指标：",
    "Accuracy": "准确率",
    "AUC": "AUC",
    "R²": "R²",
    "Question:": "问题：",
    "Who wins?": "谁会获胜？",
    "Explanatory Model": "解释模型",
    "Understand relationships.": "理解变量之间的关系。",
    "Coefficients": "系数",
    "Odds Ratios": "优势比",
    "p-values": "p值",
    "Why do teams win?": "队伍为什么会获胜？",
    "Topic 1 is primarily an explanatory study rather than a predictive study.": "主题1主要是一项解释性研究，而不是预测性研究。",
    "Key Takeaways": "关键要点",
    "Minimize SSE": "最小化SSE",
    "Maximize Likelihood": "最大化似然",
    "The most important concept learned:": "学到的最重要概念：",
    "Logistic Regression estimates β using Maximum Likelihood Estimation rather than minimizing SSE.": "逻辑回归使用最大似然估计来估计β，而不是最小化SSE。",
    "Model": "模型",
    "LL": "LL",
    "Interpretation": "解释",
    "Variable": "变量",
    "LR Chi²": "LR卡方值",
    "< 0.02": "< 0.02",
    "0.02 - 0.05": "0.02 - 0.05",
    "0.05 - 0.10": "0.05 - 0.10",
    "0.10 - 0.20": "0.10 - 0.20",
    "> 0.20": "> 0.20",
}


def font_run(run, size=7.4, bold=False, color=None, name="Calibri"):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = color


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=60, start=90, bottom=60, end=90):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def configure_document(doc, chinese=False):
    section = doc.sections[0]
    section.top_margin = Inches(0.42)
    section.bottom_margin = Inches(0.42)
    section.left_margin = Inches(0.56)
    section.right_margin = Inches(0.56)
    section.header_distance = Inches(0.18)
    section.footer_distance = Inches(0.20)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(7.4)
    normal.paragraph_format.space_after = Pt(0.4)
    normal.paragraph_format.line_spacing = 0.88

    for style_name, size, color, before, after in (
        ("Heading 1", 11.8, BLUE, 4, 1.5),
        ("Heading 2", 9.4, BLUE, 3, 1),
        ("Heading 3", 8.5, DARK_BLUE, 2, 0.7),
    ):
        style = styles[style_name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for style_name in ("List Bullet", "List Number"):
        style = styles[style_name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(7.4)
        style.paragraph_format.left_indent = Inches(0.28)
        style.paragraph_format.first_line_indent = Inches(-0.14)
        style.paragraph_format.space_after = Pt(0.5)
        style.paragraph_format.line_spacing = 0.95

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = header.add_run("TOPIC 1 | LOGISTIC REGRESSION" if not chinese else "主题1 | 逻辑回归")
    font_run(r, 7.0, bold=True, color=RGBColor(105, 115, 125))

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = footer.add_run("Topic1 Knowledge")
    font_run(r, 7.0, color=RGBColor(120, 125, 130))


def translate_text(text):
    if text in ZH:
        return ZH[text]
    numbered_heading = re.fullmatch(r"(\d+)\.\s+(.+)", text)
    if numbered_heading and numbered_heading.group(2) in ZH:
        return f"{numbered_heading.group(1)}. {ZH[numbered_heading.group(2)]}"
    replacements = {
        "Win": "获胜",
        "Lose": "失利",
        "Otherwise": "否则",
        "TopGoldShare15 \\le 0.188": "TopGoldShare15 \\le 0.188",
        "GoldDiff15 \\ge -500": "GoldDiff15 \\ge -500",
    }
    out = text
    for old, new in replacements.items():
        out = out.replace(old, new)
    return out


def add_title_block(doc, title, subtitle, chinese=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(title)
    font_run(r, 18, bold=True, color=RGBColor(22, 55, 82))
    p2 = doc.add_paragraph()
    p2.paragraph_format.space_after = Pt(7)
    r = p2.add_run(subtitle)
    font_run(r, 10.3, bold=True, color=BLUE)
    p_pr = p2._p.get_or_add_pPr()
    border = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "10")
    bottom.set(qn("w:space"), "5")
    bottom.set(qn("w:color"), "2E74B5")
    border.append(bottom)
    p_pr.append(border)


def add_equation(doc, lines, chinese=False):
    display = []
    for line in lines:
        stripped = line.strip()
        if chinese:
            stripped = translate_text(stripped)
        display.append(stripped)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(0.5)
    p.paragraph_format.space_after = Pt(1.2)
    p.paragraph_format.keep_together = True
    text = "\n".join(display)
    r = p.add_run(text)
    font_run(r, 7.7, name="Cambria Math")


def parse_table(lines, chinese=False):
    rows = []
    for line in lines:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r"[-:]+", c or "-") for c in cells):
            continue
        if chinese:
            cells = [translate_text(c) for c in cells]
        rows.append(cells)
    return rows


def add_table(doc, rows):
    cols = max(len(r) for r in rows)
    table = doc.add_table(rows=len(rows), cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    widths = [Inches(3.15), Inches(3.15)] if cols == 2 else [Inches(6.3 / cols)] * cols
    for i, row_data in enumerate(rows):
        for j in range(cols):
            cell = table.cell(i, j)
            cell.width = widths[j]
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            text = row_data[j] if j < len(row_data) else ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            r = p.add_run(text)
            font_run(r, 7.1, bold=(i == 0))
            if i == 0:
                set_cell_shading(cell, LIGHT_BLUE)
        if i == 0:
            set_repeat_table_header(table.rows[0])
    table.style = "Table Grid"
    after = doc.add_paragraph()
    after.paragraph_format.space_after = Pt(0)


def build(chinese=False):
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    doc = Document()
    configure_document(doc, chinese)

    title = translate_text("Topic1Knowledge") if chinese else "Topic1Knowledge"
    subtitle = translate_text("Weak Side Top Effect & Logistic Regression Notes") if chinese else "Weak Side Top Effect & Logistic Regression Notes"
    add_title_block(doc, title, subtitle, chinese)

    i = 2
    in_equation = False
    equation_lines = []
    while i < len(lines):
        raw = lines[i]
        stripped = raw.strip()
        if stripped == "---" or stripped == "":
            i += 1
            continue
        if stripped == "[":
            in_equation = True
            equation_lines = []
            i += 1
            continue
        if in_equation:
            if stripped == "]":
                add_equation(doc, equation_lines, chinese)
                in_equation = False
            else:
                equation_lines.append(raw)
            i += 1
            continue
        if stripped.startswith("|"):
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                table_lines.append(lines[i])
                i += 1
            add_table(doc, parse_table(table_lines, chinese))
            continue
        heading = re.match(r"^(#{1,3})\s+(.*)$", stripped)
        if heading:
            level = len(heading.group(1))
            text = heading.group(2)
            if chinese:
                text = translate_text(text)
            p = doc.add_paragraph(text, style=f"Heading {level}")
            p.paragraph_format.keep_with_next = True
            i += 1
            continue
        bullet = re.match(r"^-\s+(.*)$", stripped)
        if bullet:
            text = translate_text(bullet.group(1)) if chinese else bullet.group(1)
            doc.add_paragraph(text, style="List Bullet")
            i += 1
            continue
        numbered = re.match(r"^\d+\.\s+(.*)$", stripped)
        if numbered:
            text = translate_text(numbered.group(1)) if chinese else numbered.group(1)
            doc.add_paragraph(text, style="List Number")
            i += 1
            continue
        if stripped in ("→",):
            i += 1
            continue
        text = translate_text(stripped) if chinese else stripped
        p = doc.add_paragraph()
        p.paragraph_format.keep_together = False
        if stripped.endswith(":") or stripped in {"Important:", "Interpretation:", "Conclusion:", "Purpose:", "Goal:", "Metrics:", "Question:"}:
            r = p.add_run(text)
            font_run(r, 7.4, bold=True, color=DARK_BLUE)
        elif stripped == "→":
            r = p.add_run(text)
            font_run(r)
        else:
            r = p.add_run(text)
            font_run(r)
        i += 1

    # Make arrow pipelines compact and visually continuous.
    for p in doc.paragraphs:
        if p.text in {"Variables", "Log Odds", "Odds", "Probability", "Win/Lose",
                      "变量", "对数优势", "优势比", "概率", "获胜/失利",
                      "Remove variable", "Compare SSE", "Compare Log Likelihood",
                      "移除变量", "比较SSE", "比较对数似然"}:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(0.5)

    filename = "Topic1_Knowledge_Full_Chinese.docx" if chinese else "Topic1_Knowledge_Full_English.docx"
    path = OUT / filename
    doc.save(path)
    return path


if __name__ == "__main__":
    print(build(False))
    print(build(True))
