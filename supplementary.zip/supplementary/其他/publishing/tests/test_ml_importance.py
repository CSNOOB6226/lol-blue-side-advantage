import importlib.util
from pathlib import Path
import unittest

import numpy as np
import pandas as pd


SCRIPT = (
    Path(__file__).resolve().parents[2]
    / "topics/代码/机器学习/变量重要性分析.py"
)
RUNNER_SCRIPT = (
    Path(__file__).resolve().parents[2]
    / "topics/代码/机器学习/分析两个主题_机器学习变量重要性.py"
)


def load_module():
    spec = importlib.util.spec_from_file_location("ml_importance", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_runner_module():
    spec = importlib.util.spec_from_file_location("ml_runner", RUNNER_SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class MLImportanceTests(unittest.TestCase):
    def test_strict_15_minute_features_exclude_unbounded_objective_totals(self):
        runner = load_runner_module()
        forbidden = {
            "dragon_diff",
            "herald_diff",
            "void_grubs_diff",
            "firstblood",
            "firstdragon",
            "firstherald",
            "void_grubs",
            "grub_diff",
        }

        self.assertFalse(forbidden & set(runner.STRICT_15_MINUTE_FEATURES))

    def test_grouped_holdout_keeps_each_game_in_one_partition(self):
        module = load_module()
        groups = pd.Series(np.repeat([f"g{i}" for i in range(20)], 2))

        train_idx, test_idx = module.grouped_holdout_indices(
            groups, test_size=0.25, random_state=7
        )

        train_games = set(groups.iloc[train_idx])
        test_games = set(groups.iloc[test_idx])
        self.assertFalse(train_games & test_games)
        self.assertEqual(train_games | test_games, set(groups))

    def test_validate_features_reports_all_missing_columns(self):
        module = load_module()
        data = pd.DataFrame({"result": [0, 1], "present": [1.0, 2.0]})

        with self.assertRaisesRegex(
            ValueError, "missing_a, missing_b"
        ):
            module.validate_features(
                data, ["present", "missing_a", "missing_b"], "result", "gameid"
            )

    def test_run_analysis_returns_all_models_and_sorted_importance(self):
        module = load_module()
        rng = np.random.default_rng(4)
        games = np.repeat([f"g{i}" for i in range(60)], 2)
        signal = rng.normal(size=len(games))
        noise = rng.normal(size=len(games))
        result = (signal + rng.normal(scale=0.5, size=len(games)) > 0).astype(int)
        data = pd.DataFrame(
            {
                "gameid": games,
                "result": result,
                "signal": signal,
                "noise": noise,
            }
        )

        output = module.run_importance_analysis(
            data=data,
            target="result",
            features=["signal", "noise"],
            group_col="gameid",
            n_splits=3,
            n_repeats=3,
            random_state=3,
            fast=True,
        )

        self.assertEqual(
            set(output["metrics"]["model"]),
            {"Logistic Regression", "Random Forest", "XGBoost"},
        )
        self.assertEqual(
            list(output["permutation_importance"]["feature"]),
            list(
                output["permutation_importance"]
                .sort_values("importance_mean", ascending=False)["feature"]
            ),
        )
        self.assertEqual(
            set(output["shap_importance"]["feature"]), {"signal", "noise"}
        )
        self.assertGreater(
            output["permutation_importance"].iloc[0]["importance_mean"],
            output["permutation_importance"].iloc[-1]["importance_mean"],
        )


if __name__ == "__main__":
    unittest.main()
