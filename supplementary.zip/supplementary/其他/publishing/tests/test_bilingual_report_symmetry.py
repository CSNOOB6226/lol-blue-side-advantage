from hashlib import sha256
from pathlib import Path
import unittest

from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph


ROOT = Path(__file__).resolve().parents[2]
TOPIC1 = ROOT / "topics/报告/主题一_弱势上单策略/主题一_弱势上单策略_中英文报告.docx"
TOPIC3 = ROOT / "topics/报告/主题三_输出型上单经济门槛/主题三_输出型上单经济门槛_中英文报告_修订版.docx"


def body_blocks(doc):
    for child in doc.element.body.iterchildren():
        if child.tag == qn("w:p"):
            yield "paragraph", child
        elif child.tag == qn("w:tbl"):
            yield "table", child


def language_signatures(path, english_marker, chinese_marker):
    doc = Document(path)
    active = None
    signatures = {"en": [], "zh": []}
    for kind, element in body_blocks(doc):
        if kind == "paragraph":
            text = Paragraph(element, doc._body).text.strip()
            if text == english_marker:
                active = "en"
                continue
            if text == chinese_marker:
                active = "zh"
                continue
            if active is None:
                continue

            p_style = element.find(qn("w:pPr"))
            style_id = None
            if p_style is not None:
                style = p_style.find(qn("w:pStyle"))
                if style is not None:
                    style_id = style.get(qn("w:val"))
            drawings = element.findall(".//" + qn("a:blip"))
            if drawings:
                hashes = []
                for drawing in drawings:
                    rel_id = drawing.get(qn("r:embed"))
                    hashes.append(sha256(doc.part.related_parts[rel_id].blob).hexdigest())
                signatures[active].append(("image", tuple(hashes)))
            elif style_id and style_id.startswith("Heading"):
                signatures[active].append(("heading", style_id))
            elif text:
                signatures[active].append(("paragraph", style_id or "Normal"))
        else:
            if active is None:
                continue
            rows = element.findall(qn("w:tr"))
            cols = rows[0].findall(qn("w:tc")) if rows else []
            signatures[active].append(("table", len(rows), len(cols)))
    return signatures


class BilingualReportSymmetryTests(unittest.TestCase):
    def assert_symmetric(self, path, english_marker, chinese_marker):
        signatures = language_signatures(path, english_marker, chinese_marker)
        self.assertEqual(signatures["en"], signatures["zh"])

    def test_topic1_english_and_chinese_have_identical_structure_and_images(self):
        self.assert_symmetric(TOPIC1, "English Report", "中文报告")

    def test_topic3_english_and_chinese_have_identical_structure_and_images(self):
        self.assert_symmetric(
            TOPIC3, "Version B: English Report", "Version A: Chinese Report"
        )


if __name__ == "__main__":
    unittest.main()
