import { buildSlide } from "./deck-slides.mjs";
export async function slide09(presentation, ctx) { return buildSlide(9, presentation, ctx); }
