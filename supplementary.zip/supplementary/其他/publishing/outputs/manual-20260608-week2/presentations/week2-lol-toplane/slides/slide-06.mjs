import { buildSlide } from "./deck-slides.mjs";
export async function slide06(presentation, ctx) { return buildSlide(6, presentation, ctx); }
