export const C = {
  bg: "#07111F",
  bg2: "#0B1B2C",
  panel: "#10263A",
  panel2: "#0D2235",
  gold: "#C89B3C",
  gold2: "#E0B75B",
  cyan: "#19B5C5",
  cyan2: "#6ADBE4",
  white: "#F2EDE0",
  muted: "#9FB2C3",
  slate: "#5F7184",
  green: "#4DD3A7",
  red: "#D16B6B",
  line: "#26435F"
};

export const F = {
  title: "PingFang SC",
  body: "PingFang SC",
  latin: "Arial",
  mono: "Arial"
};

export const M = {
  left: 70,
  right: 70,
  top: 54,
  bottom: 48
};

