import { buildSlide } from "./deck-slides.mjs";
export async function slide01(presentation, ctx) { return buildSlide(1, presentation, ctx); }
