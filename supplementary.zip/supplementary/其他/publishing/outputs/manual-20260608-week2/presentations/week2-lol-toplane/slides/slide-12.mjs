import { buildSlide } from "./deck-slides.mjs";
export async function slide12(presentation, ctx) { return buildSlide(12, presentation, ctx); }
