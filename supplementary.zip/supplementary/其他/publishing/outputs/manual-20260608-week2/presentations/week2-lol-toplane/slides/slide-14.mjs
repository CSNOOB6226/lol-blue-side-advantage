import { buildSlide } from "./deck-slides.mjs";
export async function slide14(presentation, ctx) { return buildSlide(14, presentation, ctx); }
