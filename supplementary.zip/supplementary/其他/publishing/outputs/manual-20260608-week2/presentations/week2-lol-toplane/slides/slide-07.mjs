import { buildSlide } from "./deck-slides.mjs";
export async function slide07(presentation, ctx) { return buildSlide(7, presentation, ctx); }
