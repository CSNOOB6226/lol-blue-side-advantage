import { buildSlide } from "./deck-slides.mjs";
export async function slide11(presentation, ctx) { return buildSlide(11, presentation, ctx); }
