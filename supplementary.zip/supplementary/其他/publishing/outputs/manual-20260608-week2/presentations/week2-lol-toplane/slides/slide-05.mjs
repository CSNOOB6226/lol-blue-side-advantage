import { buildSlide } from "./deck-slides.mjs";
export async function slide05(presentation, ctx) { return buildSlide(5, presentation, ctx); }
