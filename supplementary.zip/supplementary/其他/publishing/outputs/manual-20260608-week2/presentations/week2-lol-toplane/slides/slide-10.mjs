import { buildSlide } from "./deck-slides.mjs";
export async function slide10(presentation, ctx) { return buildSlide(10, presentation, ctx); }
