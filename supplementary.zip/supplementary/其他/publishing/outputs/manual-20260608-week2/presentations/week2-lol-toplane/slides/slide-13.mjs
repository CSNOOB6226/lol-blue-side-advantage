import { buildSlide } from "./deck-slides.mjs";
export async function slide13(presentation, ctx) { return buildSlide(13, presentation, ctx); }
