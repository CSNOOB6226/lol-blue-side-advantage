import { C, F, M } from "./theme.mjs";

export function rect(ctx, slide, x, y, w, h, fill = C.panel, line = C.line, lw = 1, name) {
  return ctx.addShape(slide, {
    x, y, w, h, name,
    fill,
    line: ctx.line(line, lw)
  });
}

export function text(ctx, slide, value, x, y, w, h, opts = {}) {
  return ctx.addText(slide, {
    text: value,
    x, y, w, h,
    fontSize: opts.size ?? 22,
    color: opts.color ?? C.white,
    bold: opts.bold ?? false,
    typeface: opts.face ?? F.body,
    align: opts.align ?? "left",
    valign: opts.valign ?? "top",
    fill: opts.fill ?? "#00000000",
    line: ctx.line(opts.line ?? "#00000000", opts.lineWidth ?? 0),
    insets: opts.insets ?? { left: 0, right: 0, top: 0, bottom: 0 },
    name: opts.name
  });
}

export function background(ctx, slide, page, kicker, title, source = "Sources: final Topic 1 and Topic 3 reports") {
  rect(ctx, slide, 0, 0, ctx.W, ctx.H, C.bg, "#00000000", 0, "background");
  rect(ctx, slide, 0, 0, 18, ctx.H, C.gold, "#00000000", 0, "gold-spine");
  rect(ctx, slide, 18, 0, 4, ctx.H, C.cyan, "#00000000", 0, "cyan-spine");
  rect(ctx, slide, 1015, 0, 265, ctx.H, "#06101C", "#00000000", 0, "right-shadow");
  for (let i = 0; i < 6; i += 1) {
    rect(ctx, slide, 1020 + i * 24, 58 + i * 22, 100, 1.4, i % 2 ? C.line : C.gold, "#00000000", 0, `data-line-${i}`);
  }
  kickerRow(ctx, slide, kicker, M.left, 35);
  text(ctx, slide, title, M.left, 66, 870, 90, { size: 37, bold: true, color: C.white, name: "slide-title" });
  text(ctx, slide, source, M.left, 692, 760, 16, { size: 10.5, color: C.slate, face: F.latin, name: "source-footer" });
  text(ctx, slide, String(page).padStart(2, "0"), 1190, 680, 40, 24, { size: 16, color: C.gold, align: "right", face: F.latin, name: "page-marker" });
}

export function kickerRow(ctx, slide, label, x, y) {
  rect(ctx, slide, x, y + 8, 9, 9, C.gold, "#00000000", 0, "kicker-marker");
  text(ctx, slide, label.toUpperCase(), x + 20, y, 420, 25, { size: 11, color: C.gold2, bold: true, face: F.latin, valign: "middle", name: "kicker-label" });
}

export function panel(ctx, slide, x, y, w, h, opts = {}) {
  const s = rect(ctx, slide, x, y, w, h, opts.fill ?? C.panel, opts.line ?? C.line, opts.lineWidth ?? 1, opts.name);
  if (opts.topRule) rect(ctx, slide, x, y, w, 3, opts.topRule === "cyan" ? C.cyan : C.gold, "#00000000", 0);
  return s;
}

export function metric(ctx, slide, label, value, x, y, w, opts = {}) {
  panel(ctx, slide, x, y, w, 74, { fill: opts.fill ?? C.panel2, line: opts.line ?? C.line });
  text(ctx, slide, value, x + 18, y + 12, w - 36, 30, { size: opts.size ?? 26, bold: true, color: opts.color ?? C.gold2, face: F.latin });
  text(ctx, slide, label, x + 18, y + 43, w - 36, 18, { size: 13, color: C.muted });
}

export function bulletList(ctx, slide, items, x, y, w, opts = {}) {
  let cy = y;
  for (const item of items) {
    rect(ctx, slide, x, cy + 8, 6, 6, opts.marker ?? C.gold, "#00000000", 0);
    text(ctx, slide, item, x + 18, cy, w - 18, opts.lineH ?? 35, { size: opts.size ?? 19, color: opts.color ?? C.white });
    cy += opts.gap ?? 38;
  }
}

export function smallTable(ctx, slide, headers, rows, x, y, widths, rowH = 38, opts = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  panel(ctx, slide, x, y, total, rowH * (rows.length + 1), { fill: C.panel2, line: C.line });
  rect(ctx, slide, x, y, total, rowH, C.panel, "#00000000", 0);
  let cx = x;
  headers.forEach((h, i) => {
    text(ctx, slide, h, cx + 10, y + 8, widths[i] - 20, rowH - 23, { size: opts.headerSize ?? 13, bold: true, color: C.gold2, face: F.latin, valign: "middle" });
    cx += widths[i];
  });
  rows.forEach((row, r) => {
    const yy = y + rowH * (r + 1);
    if (r % 2 === 0) rect(ctx, slide, x, yy, total, rowH, "#0B2032", "#00000000", 0);
    rect(ctx, slide, x, yy, total, 1, C.line, "#00000000", 0);
    let xx = x;
    row.forEach((cell, i) => {
      const color = opts.goldCols?.includes(i) ? C.gold2 : opts.cyanCols?.includes(i) ? C.cyan2 : C.white;
      text(ctx, slide, String(cell), xx + 10, yy + 8, widths[i] - 20, rowH - 23, { size: opts.size ?? 14, color, face: i === 0 ? F.body : F.latin, valign: "middle", align: opts.alignCols?.[i] ?? "left" });
      xx += widths[i];
    });
  });
}

export function barChart(ctx, slide, data, x, y, w, h, opts = {}) {
  const max = opts.max ?? Math.max(...data.map(d => d.value));
  const rowH = h / data.length;
  data.forEach((d, i) => {
    const yy = y + i * rowH;
    text(ctx, slide, d.label, x, yy + 8, 132, 24, { size: 15, color: C.muted });
    rect(ctx, slide, x + 145, yy + 13, w - 230, 15, "#18324A", "#00000000", 0);
    rect(ctx, slide, x + 145, yy + 13, (w - 230) * d.value / max, 15, d.color ?? C.gold, "#00000000", 0);
    text(ctx, slide, d.display ?? d.value.toFixed(3), x + w - 70, yy + 4, 70, 25, { size: 16, color: d.color ?? C.gold2, face: F.latin, align: "right" });
  });
}

export function lineChart(ctx, slide, seriesA, seriesB, x, y, w, h, opts = {}) {
  panel(ctx, slide, x, y, w, h, { fill: "#081928", line: C.line });
  const left = x + 64;
  const top = y + 42;
  const cw = w - 110;
  const ch = h - 92;
  for (let i = 0; i <= 4; i += 1) {
    const gy = top + ch * i / 4;
    rect(ctx, slide, left, gy, cw, 1, "#1C3852", "#00000000", 0);
  }
  const vals = [...seriesA, ...seriesB].map(p => p[1]);
  const minY = opts.minY ?? Math.min(...vals);
  const maxY = opts.maxY ?? Math.max(...vals);
  const xs = seriesA.map(p => p[0]);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const pt = ([vx, vy]) => [left + (vx - minX) / (maxX - minX) * cw, top + (1 - (vy - minY) / (maxY - minY)) * ch];
  function drawSeries(series, color, name) {
    const points = series.map(pt);
    for (let i = 0; i < points.length - 1; i += 1) {
      const [x1, y1] = points[i];
      const [x2, y2] = points[i + 1];
      const dx = x2 - x1;
      const dy = y2 - y1;
      const len = Math.sqrt(dx * dx + dy * dy);
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      const line = rect(ctx, slide, x1, y1 - 1.5, len, 3, color, "#00000000", 0, `${name}-seg-${i}`);
      line.rotation = angle;
    }
    points.forEach(([px, py], i) => {
      rect(ctx, slide, px - 4, py - 4, 8, 8, color, "#00000000", 0, `${name}-dot-${i}`);
    });
  }
  drawSeries(seriesA, C.cyan, "tank");
  drawSeries(seriesB, C.gold, "carry");
  text(ctx, slide, "Tank", x + w - 138, y + 20, 48, 18, { size: 13, color: C.cyan2, face: F.latin });
  text(ctx, slide, "Carry", x + w - 78, y + 20, 58, 18, { size: 13, color: C.gold2, face: F.latin });
  text(ctx, slide, "-2000", left - 8, y + h - 36, 54, 16, { size: 11, color: C.slate, face: F.latin });
  text(ctx, slide, "0", left + cw / 2 - 10, y + h - 36, 30, 16, { size: 11, color: C.slate, face: F.latin, align: "center" });
  text(ctx, slide, "3000", left + cw - 35, y + h - 36, 54, 16, { size: 11, color: C.slate, face: F.latin, align: "right" });
}

export function formula(ctx, slide, lines, x, y, w, h) {
  panel(ctx, slide, x, y, w, h, { fill: "#081827", line: C.gold, lineWidth: 1.2, topRule: "gold" });
  text(ctx, slide, lines.join("\n"), x + 30, y + 18, w - 60, h - 36, { size: 22, color: C.white, face: F.mono, valign: "middle" });
}
