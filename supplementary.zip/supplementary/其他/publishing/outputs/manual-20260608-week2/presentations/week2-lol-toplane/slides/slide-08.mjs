import { buildSlide } from "./deck-slides.mjs";
export async function slide08(presentation, ctx) { return buildSlide(8, presentation, ctx); }
