import { buildSlide } from "./deck-slides.mjs";
export async function slide02(presentation, ctx) { return buildSlide(2, presentation, ctx); }
