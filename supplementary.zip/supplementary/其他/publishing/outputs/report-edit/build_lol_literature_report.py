from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT = str(Path(__file__).resolve().parents[3] / "论文/League_of_Legends_电竞统计论文分析_报告版修订.docx")
Path(OUT).parent.mkdir(parents=True, exist_ok=True)


def set_run_font(run, size=None, bold=None, color=None, font="Calibri"):
    run.font.name = font
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)


def set_para_spacing(paragraph, before=0, after=6, line=1.10):
    fmt = paragraph.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line


def add_p(doc, text="", style=None, size=11, bold=False, color="111827", after=6, before=0):
    p = doc.add_paragraph(style=style)
    set_para_spacing(p, before=before, after=after)
    if text:
        r = p.add_run(text)
        set_run_font(r, size=size, bold=bold, color=color)
    return p


def add_heading(doc, text, level):
    p = doc.add_paragraph(style=f"Heading {level}")
    set_para_spacing(p, before=16 if level == 1 else 10, after=6)
    r = p.add_run(text)
    set_run_font(r, size={1: 16, 2: 13, 3: 12}[level], bold=True, color="2E74B5" if level < 3 else "1F4D78")
    return p


def add_bullets(doc, items, level=0):
    style = "List Bullet" if level == 0 else "List Bullet 2"
    for item in items:
        p = doc.add_paragraph(style=style)
        set_para_spacing(p, after=4, line=1.167)
        r = p.add_run(item)
        set_run_font(r, size=10.5, color="111827")


def add_numbered(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Number")
        set_para_spacing(p, after=4, line=1.167)
        r = p.add_run(item)
        set_run_font(r, size=10.5, color="111827")


def add_callout(doc, title, body):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), "F4F6F9")
    tc_pr.append(shd)
    p = cell.paragraphs[0]
    set_para_spacing(p, after=3)
    r = p.add_run(title)
    set_run_font(r, size=10.5, bold=True, color="1F4D78")
    p2 = cell.add_paragraph()
    set_para_spacing(p2, after=0, line=1.15)
    r2 = p2.add_run(body)
    set_run_font(r2, size=10.5, color="111827")
    doc.add_paragraph()


def add_citation(doc, citation, links=None):
    add_p(doc, "完整引用", size=10.5, bold=True, color="1F4D78", after=2)
    add_p(doc, citation, size=10.5, color="111827", after=2)
    if links:
        for label, url in links:
            add_p(doc, f"{label}：{url}", size=9.5, color="4B5563", after=1)


def setup_styles(doc):
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    for name in ["Heading 1", "Heading 2", "Heading 3"]:
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string("2E74B5" if name != "Heading 3" else "1F4D78")


def build():
    doc = Document()
    setup_styles(doc)

    p = add_p(doc, "League of Legends 电竞统计研究", size=24, bold=True, color="0B2545", after=2)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = add_p(doc, "五篇论文分析与研究设计建议：报告版修订", size=18, bold=True, color="2E74B5", after=10)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = add_p(doc, "主题：Top Lane Resource Allocation、Gold Distribution、Marginal Value of Gold 与 Win Probability", size=11, color="4B5563", after=18)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_callout(
        doc,
        "修订说明",
        "本版删除原文中“综合对比表”及其以下旧研究设计清单，并删除原论文三的旧写法。第三篇改为围绕 Analysis of Team Resource Allocation and Win Percentages in League of Legends 的项目化分析，重点服务当前 LOL 项目的 Tank vs Carry、Weak Side Top、Gold Distribution、Marginal Value of Gold 与 Win Probability 研究设计。"
    )

    add_heading(doc, "一、文献筛选说明", 1)
    add_p(doc, "这五篇论文覆盖了从胜率预测、英雄熟练度、队内经济分配、选手表现评估到团队层级建模的主要 LoL 电竞统计研究路径。需要注意的是，只有第三篇直接使用职业比赛数据；其他论文主要基于排位赛或公开游戏数据，因此其结论不能直接套用到职业比赛，而应使用 Oracle’s Elixir 职业比赛数据重新验证。", size=11)
    add_bullets(doc, [
        "实时胜率预测（Win Probability）",
        "选手英雄熟练度（Player-Champion Experience）",
        "队内经济分配（Gold Allocation / Gold Share）",
        "选手表现评估（Player Performance Evaluation）",
        "团队层级比赛预测（Team-Level Match Prediction）",
    ])

    add_heading(doc, "二、论文一：Smart Kills and Worthless Deaths", 1)
    add_citation(
        doc,
        "Maymin, P. Z. (2021). Smart kills and worthless deaths: eSports analytics for League of Legends. Journal of Quantitative Analysis in Sports, 17(1), 11–27.",
        [("论文链接", "https://doi.org/10.1515/jqas-2019-0096")],
    )
    add_heading(doc, "研究问题与数据", 2)
    add_p(doc, "这篇论文关注高频率游戏状态数据能否比传统 KDA、击杀数和经济数据更准确地预测比赛胜率，并衡量单个选手对团队胜利的贡献。作者通过观战系统、Computer Vision 和客户端数据采集技术获得大量 LoL 排位赛数据，主要分析约 150,000 场同一版本比赛，并按分钟记录英雄位置、技能、伤害、视野和资源状态。")
    add_heading(doc, "主要方法与变量", 2)
    add_bullets(doc, [
        "方法包括 Logistic Regression、Stochastic Gradient Descent、Fast-and-Frugal Trees、Correlation Analysis、Role-Specific Regression 和 Computer Vision Data Collection。",
        "主要变量包括 game minute、team kills、towers destroyed、major monsters、champion location、damage、vision、health/mana/cooldowns、gold-related metrics 等。",
        "核心概念包括 Smart Kill 与 Worthless Death。Smart Kill 指击杀发生后团队预测胜率明显提高；Worthless Death 指死亡没有带来足够战略回报，同时显著降低胜率。"
    ])
    add_heading(doc, "主要结论", 2)
    add_bullets(doc, [
        "用行动对胜率的影响进行加权后，高级指标比普通 KDA 更能解释团队胜利。",
        "简化决策树使用高级表现指标后，预测准确率约为 80%。",
        "普通击杀不一定有价值；只有显著提高团队胜率的击杀，才真正体现选手贡献。"
    ])
    add_heading(doc, "局限性与项目启发", 2)
    add_bullets(doc, [
        "局限性：使用排位赛而非职业比赛；数据采集方式复杂，Oracle’s Elixir 无法完整复现；跨 Patch 数据和简化胜率模型会影响解释力；结果主要是预测关系，不能证明因果关系。",
        "项目启发：可以建立 Early-Game Win Probability Model，再计算上单事件的 Win Probability Added, WPA。例如 Top death before 15、Top solo kill、Rift Herald 参与、Teleport play 等事件，都可以用 WPA 衡量其真实价值。"
    ])

    add_heading(doc, "三、论文二：Player-Champion Experience and Game Outcome Prediction", 1)
    add_citation(
        doc,
        "Do, T. D., Wang, S. I., Yu, D. S., McMillian, M. G., & McMahan, R. P. (2021). Using Machine Learning to Predict Game Outcomes Based on Player-Champion Experience in League of Legends. Proceedings of FDG 2021.",
        [("论文链接", "https://doi.org/10.1145/3472538.3472579"), ("预印本链接", "https://arxiv.org/abs/2108.02799")],
    )
    add_heading(doc, "研究问题与数据", 2)
    add_p(doc, "这篇论文研究在比赛开始之前，仅根据玩家对所选英雄的熟练程度，能否预测比赛结果。数据来自 Riot Games API，包括 North America 服务器 5,000 场不重复的 2020 年排位赛，段位覆盖 Iron 至 Diamond，并采用 80% training set 与 20% test set。")
    add_heading(doc, "主要方法与变量", 2)
    add_bullets(doc, [
        "方法包括 Deep Neural Network、Random Forest、Gradient Boosting、Support Vector Classifier、k-Nearest Neighbors、Pearson Correlation 和 Stratified Cross-Validation。",
        "玩家层级变量包括 champion mastery points、player-champion win rate、season games played on champion、champion games among last 20 games。",
        "团队层级变量包括 mean、median、variance、standard deviation、skewness、kurtosis，最终模型共有 44 个特征变量。"
    ])
    add_heading(doc, "主要结论", 2)
    add_bullets(doc, [
        "Gradient Boosting 准确率约为 75.4%，DNN 准确率约为 75.1%。",
        "Champion win rate 和 mastery points 具有较强预测能力。",
        "单纯的英雄使用场次没有同样强的预测能力，说明“玩过很多场”不等于真正擅长。"
    ])
    add_heading(doc, "局限性与项目启发", 2)
    add_bullets(doc, [
        "局限性：样本只有 5,000 场，只包含一个服务器和一个赛季，没有覆盖职业比赛，也没有充分控制 matchup、阵容、版本和战队实力。",
        "项目启发：分析某个英雄获得额外经济是否有效时，应控制 Player × Champion Interaction。同一名上单使用熟练英雄和不熟练英雄时，额外 500 gold 的 marginal value 可能不同。"
    ])

    add_heading(doc, "四、论文三：Team Resource Allocation and Win Percentages", 1)
    add_citation(
        doc,
        "Larose, C. D., & Mehling, S. A. (2022). Analysis of Team Resource Allocation and Win Percentages in League of Legends. Proceedings of the Joint Statistical Meetings, 699–715.",
        [("论文链接", "https://0633e92166c0a27ea1aa-ab47878a9e45eb9e2f15be38a59f867e.ssl.cf1.rackcdn.com/JTJLFYSY-2258804-1828585-Upload-1669675867.pdf")],
    )
    add_heading(doc, "论文核心内容", 2)
    add_p(doc, "这篇论文与当前项目高度相关。作者使用 Oracle’s Elixir 职业比赛数据，样本为 LCS 2019 Spring + Summer Regular Season。研究对象不是 Team Gold 总经济，而是 Gold Share，即某个位置在团队总经济中占据的比例：Gold Share = Player Gold / Team Gold。")
    add_p(doc, "作者只保留前 15 分钟数据，避免 Baron、Inhibitor 等明显受到比赛结果影响的后期变量造成 outcome leakage。为了避免“经济领先方本来就容易赢”的问题，作者删除了 15 分钟经济差超过 2,000 的比赛，只研究相对接近、胜负尚未完全确定的比赛。")
    add_heading(doc, "主要发现", 2)
    add_bullets(doc, [
        "EDA 发现 Top Gold Share 较高时，队伍不一定更容易赢；Bot Gold Share 较高时更容易赢；Support Gold Share 较高时也更容易赢。",
        "CART 和 Association Rules 都显示，Top Gold Share 高往往与更低胜率相关，Bot Gold Share 高则更容易赢。",
        "最重要的发现之一是：如果 Red Top Gold Share 很高，即 Red side top lane 吃了大量资源，Blue side 胜率反而显著提高。",
        "最终结论是：在接近均势的职业比赛中，团队经济分配越均衡，胜率越高；过度集中资源给 Top Lane 可能不是最佳策略。职业比赛更像团队资源协同，而不是单核 Carry。"
    ])
    add_heading(doc, "1. 与 Topic 2（Weak Side Top）和 Topic 3（Gold Distribution）的联系", 2)
    add_bullets(doc, [
        "与 Weak Side Top 的联系：这篇论文提供了一个非常直接的理论支持，即上路少吃资源并不必然是劣势。如果 Top Gold Share 过高反而与更低胜率相关，那么 weak-side top 可能是一种合理的资源配置，而不是单纯的牺牲位。",
        "与 Gold Distribution 的联系：论文把研究对象从 total gold 转向 role-level gold share，这正是 Topic 3 的核心。它说明在团队总经济接近时，资源如何在 Top、Jungle、Mid、Bot、Support 之间分配，可能比团队总经济本身更能解释胜负差异。",
        "与 Marginal Value of Gold 的联系：如果 Top Gold Share 高不一定提高胜率，那么上单额外经济的 marginal value 可能低于 Bot 或 Mid，或者只在特定 champion type、team composition、game state 下才有效。",
        "与 Tank vs Carry 的联系：论文没有区分 Tank Top 与 Carry Top，但它提出了关键疑问：Top lane 获得更多 gold 到底是在创造 carry value，还是在挤占其他位置更高边际价值的资源？这正是当前项目可以推进的地方。"
    ])
    add_heading(doc, "2. 已经被这篇论文做过、应避免重复的部分", 2)
    add_bullets(doc, [
        "不要简单重复“用 15 分钟 Gold Share 预测胜负”的基本问题。论文已经证明 role-level gold share 具有研究价值。",
        "不要只用 CART 或 Association Rules 找阈值。CART 结果直观，但阈值可能不稳定；当前项目应使用 Logistic Regression、Restricted Cubic Splines、interaction terms 或 compositional data methods 做更稳健的统计检验。",
        "不要只研究 2019 LCS 或单一赛区。单赛区单赛季的结论很容易受 meta、版本、队伍风格影响。",
        "不要只比较 Top Gold Share 高低。更有价值的问题是 Top Gold Share 的效应是否受到 top type、champion class、team resource distribution、objectives、side、patch 和 team strength 调节。",
        "不要忽略经济领先本身。论文删除 15 分钟经济差超过 2,000 的比赛是合理设计，但当前项目可以同时报告 close-game subsample 与 full-sample robustness check。"
    ])
    add_heading(doc, "3. 论文没有回答、可以成为 follow-up paper 的问题", 2)
    add_bullets(doc, [
        "它没有回答 Tank Top 与 Carry Top 的 gold share 是否具有不同边际价值。",
        "它没有回答上单经济占比高是主动资源投入，还是队伍落后后被动边线补发育造成的结果。",
        "它没有控制 champion selection、matchup、player strength、team strength 与 patch effects。",
        "它没有研究 gold distribution 的动态过程，例如 10 分钟、15 分钟、20 分钟经济分配如何改变胜率。",
        "它没有把 neutral objectives 纳入完整解释框架，例如 Void Grubs、Dragon、Herald、First Turret 与 Top Gold Share 之间是否存在 trade-off。"
    ])
    add_heading(doc, "4. Topic 3（Distribution vs Total Gold）如何设计成自然升级版", 2)
    add_p(doc, "Topic 3 可以被设计为这篇论文的自然升级版：从“Gold Share 是否相关”推进到“在控制 total gold advantage 后，role-level distribution 是否仍然有独立解释力，以及不同上单类型是否改变 gold 的边际价值”。")
    add_bullets(doc, [
        "Unit of observation：team-game 或 matched team pair。每场比赛两条 team-game observations，并按 match clustered standard errors。",
        "Dependent variable：result，1 = win, 0 = loss。",
        "核心解释变量：top_gold_share15、bot_gold_share15、mid_gold_share15、jungle_gold_share15、support_gold_share15、team_gold_diff15、top_gold_diff15、is_carry、is_tank、carry × top_gold_share15。",
        "建模策略：Logistic Regression 作为 baseline；Restricted Cubic Splines 检验 nonlinear marginal value；interaction terms 检验 Tank vs Carry 差异；ILR / log-ratio transformation 处理 Gold Share 的 compositional data 问题。",
        "控制变量：side、league、patch_str、team fixed effects、opponent strength、champion class、matchup、game_length、dragon_diff、herald_diff、void_grubs_diff、first_turret 或 plates。",
        "关键检验：在控制 team_gold_diff15 后，role-level gold distribution 是否仍然显著；Top share 的 marginal value 是否低于 Bot/Mid；Carry Top 是否存在经济门槛；Weak Side Top 是否在资源转移给 Bot/Mid 时提高胜率。"
    ])
    add_heading(doc, "5. 使用 LCK 2026 或多赛区数据的优势", 2)
    add_bullets(doc, [
        "时间优势：2019 LCS 与 2026 职业比赛的版本、地图资源和上单生态差异很大。2026 数据更贴近当前 meta，尤其可以纳入 Void Grubs 等新资源。",
        "赛区优势：LCK 的宏观纪律、资源交换和上单使用方式可能与 LCS 不同；多赛区数据还能检验规律是否具有 external validity。",
        "样本优势：LCK 2026 约 300+ 场已经比单一短赛季更适合做稳定模型；如果扩展到多个赛区，样本量和 champion variation 会进一步提高。",
        "变量优势：当前项目可以加入 champion selection、tank/carry classification、objectives、patch controls、team/player fixed effects，比原论文更接近真正的战略解释。",
        "研究问题优势：原论文主要回答“Top share 高低是否相关”；我们的项目可以回答“什么类型的 Top、在什么资源结构下、额外 gold 的 marginal value 是否真的高”。"
    ])
    add_heading(doc, "6. 可直接延伸且具有发表潜力的新研究问题", 2)
    add_numbered(doc, [
        "Weak-Side Top Value：在控制 team gold difference、Bot/Mid gold share 和 early objectives 后，低 Top Gold Share 是否仍然提高 win probability？这种效应是否只存在于 Tank Top 或稳定抗压型上单？",
        "Role-Specific Marginal Value of Gold：在接近均势的职业比赛中，Top、Mid、Bot 每增加 1% Gold Share 对 win probability 的边际影响是否不同？Top lane 是否存在 diminishing returns？",
        "Tank vs Carry Gold Response Curves：Tank Top 与 Carry Top 的 gold-to-win conversion curve 是否不同？Carry Top 是否真的需要达到某个 15 分钟经济门槛才超过 Tank Top？",
        "Gold Concentration vs Team Coordination：经济分配越集中，胜率是否下降？这个关系是否因赛区、版本、objective trade pattern 和 champion composition 而变化？",
        "Proactive Funnel or Reactive Farming：Top Gold Share 高到底是团队主动 funnel top，还是落后方通过边线补发育导致？可以用 10/15/20 分钟资源路径、objective control 和 gold swing sequence 来区分。"
    ])

    add_heading(doc, "五、论文四：The SIDO Performance Model for League of Legends", 1)
    add_citation(
        doc,
        "Zhang, A. X., & Naidu, P. (2024). The SIDO Performance Model for League of Legends. arXiv preprint arXiv:2403.04873.",
        [("论文链接", "https://arxiv.org/abs/2403.04873")],
    )
    add_heading(doc, "研究问题与框架", 2)
    add_p(doc, "SIDO 试图将选手表现拆分为 Own Contribution、Ally-Enabling Contribution 和 Enemy-Denial Contribution，也就是自己获得多少资源、帮助队友获得多少资源、阻止敌人获得多少资源。")
    add_heading(doc, "主要方法与变量", 2)
    add_bullets(doc, [
        "数据来自 Riot API 高分段排位赛，覆盖 NA、EUW 和 Korea，Patch 13.14–13.18。",
        "方法包括 Hierarchical Bayesian Models、Player Random Effects、Champion Random Effects、Plus-Minus Model、Residual-Based Contribution Models 和 Metric Stability Analysis。",
        "变量包括 gold earned、damage dealt、damage taken、player、champion、role、region、game phase、ally residual performance、enemy residual performance。"
    ])
    add_heading(doc, "主要结论", 2)
    add_bullets(doc, [
        "SIDO 比简单平均值和传统 Plus-Minus Model 更能区分高水平选手。",
        "职业打野的重要能力之一是阻止敌人获得经济；ADC 更依赖个人机械和直接输出。",
        "Jungle 和 Support 的价值更多体现在战略和团队贡献，不能只用选手自己的经济或伤害判断表现。"
    ])
    add_heading(doc, "局限性与项目启发", 2)
    add_bullets(doc, [
        "局限性：Solo Queue 与职业战队协作环境不同；职业选手账号识别不完整；Ally 与 Enemy Contribution 的区分能力有限；Patch 范围较短；模型较复杂，本科项目需要简化。",
        "项目启发：Weak Side Top 可以被理解为 Own Gold 较低但 Ally-Enabling 或 Enemy-Denial 较高的角色。上单 GD15 为负不一定代表低价值，可能说明他吸收压力并释放队友资源。"
    ])

    add_heading(doc, "六、论文五：Multi-Objective Multi-Instance Learning for eSports", 1)
    add_citation(
        doc,
        "Birant, K. U., & Birant, D. (2023). Multi-Objective Multi-Instance Learning: A New Approach to Machine Learning for eSports. Entropy, 25(1), 28.",
        [("论文链接", "https://doi.org/10.3390/e25010028")],
    )
    add_heading(doc, "研究问题与数据", 2)
    add_p(doc, "这篇论文将五名选手共同视为一个团队进行建模，研究团队层级模型是否比把每名选手视为独立样本更能预测比赛结果。数据来自 Kaggle 公开 LoL 排位赛数据，包含 1,834,520 条玩家记录，覆盖 North America、Europe 与 Season 3–7。")
    add_heading(doc, "方法、结论与局限性", 2)
    add_bullets(doc, [
        "方法包括 Multi-Instance Logistic Regression、Multi-Instance SVM、Multi-Instance Boosting、Decision Trees、SimpleMI、10-Fold Cross-Validation 和 Mann–Whitney U Test。",
        "主要结论：团队层级 Multi-Instance Models 通常优于玩家层级模型；SimpleMI 平均准确率约为 94%；turret kills、deaths per minute 和 assists per minute 是重要预测变量。",
        "核心局限：许多变量可能来自比赛结束后的统计数据，存在 Outcome Leakage / Data Leakage。模型准确率很高并不代表它能在早期预测胜负，也不适合直接回答因果性战略问题。",
        "项目启发：LoL 数据具有明显层级结构 Player ⊂ Role ⊂ Team ⊂ Match。当前项目应考虑 Mixed-Effects Logistic Regression、Clustered Standard Errors、Team Fixed Effects、Player Random Effects 或 Champion Random Effects。"
    ])

    add_heading(doc, "七、报告小结", 1)
    add_p(doc, "这五篇文献共同说明，当前 LOL 项目的核心不应只是“谁经济更多谁更容易赢”，而应转向资源的分配结构、边际价值、位置差异、英雄差异和团队层级依赖。第三篇论文是与当前项目最直接相关的基础文献，但它也留下了最清晰的扩展空间：从 2019 LCS 的 Gold Share 相关性分析，升级到多赛区、多版本、Tank vs Carry 分类、early objectives 控制、fixed effects 和 nonlinear marginal value 的职业比赛研究。")
    add_p(doc, "因此，Topic 2（Weak Side Top）可以被定位为“低 Top Gold Share 是否仍有战略价值”的问题；Topic 3（Gold Distribution）可以被定位为“在控制 Team Gold 与早期资源后，经济分配结构是否仍独立影响 Win Probability”的问题。这样既承接已有论文，又不会重复已有结论。")

    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
