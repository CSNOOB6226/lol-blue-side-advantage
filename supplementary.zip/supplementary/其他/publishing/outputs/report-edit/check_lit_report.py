from pathlib import Path
from docx import Document


path = str(Path(__file__).resolve().parents[3] / "论文/League_of_Legends_电竞统计论文分析_报告版修订.docx")
text = "\n".join(p.text for p in Document(path).paragraphs)
checks = [
    "综合对比表",
    "Gold-Share Threshold Model",
    "五个较少见但可行",
    "与 Topic 2（Weak Side Top）和 Topic 3（Gold Distribution）的联系",
    "已被这篇论文做过",
    "follow-up paper",
    "Distribution vs Total Gold",
    "LCK 2026",
    "具有发表潜力",
]
print("file", path)
print("chars", len(text))
for check in checks:
    print(f"{check}: {check in text}")
