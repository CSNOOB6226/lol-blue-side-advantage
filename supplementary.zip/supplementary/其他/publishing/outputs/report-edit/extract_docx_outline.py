from pathlib import Path
from docx import Document


path = str(Path(__file__).resolve().parents[3] / "论文/League_of_Legends_电竞统计论文分析.docx")
doc = Document(path)

for i, para in enumerate(doc.paragraphs):
    text = para.text.strip()
    if text:
        print(f"{i:03d}: {text[:260]}")

print("\nTABLES")
for ti, table in enumerate(doc.tables):
    print(f"table {ti}: {len(table.rows)} rows x {len(table.columns)} cols")
    for row in table.rows[:3]:
        print(" | ".join(cell.text.strip().replace("\n", " / ")[:80] for cell in row.cells))
