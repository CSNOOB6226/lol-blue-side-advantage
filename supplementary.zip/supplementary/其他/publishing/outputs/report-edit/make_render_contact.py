from pathlib import Path
import math
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[3]
D = ROOT / "publishing/outputs/report-edit/rendered_lit_report"
files = sorted(D.glob("page-*.png"), key=lambda p: int(p.stem.split("-")[1]))

cols = 3
thumb_w = 310
pad = 20
label_h = 22
thumbs = []
for f in files:
    img = Image.open(f).convert("RGB")
    h = int(img.height * thumb_w / img.width)
    thumbs.append((f, img.resize((thumb_w, h))))

thumb_h = max(t.height for _, t in thumbs)
sheet = Image.new("RGB", (cols * (thumb_w + pad) + pad, math.ceil(len(files) / cols) * (thumb_h + label_h + pad) + pad), "white")
draw = ImageDraw.Draw(sheet)

for i, (path, img) in enumerate(thumbs):
    x = pad + (i % cols) * (thumb_w + pad)
    y = pad + (i // cols) * (thumb_h + label_h + pad)
    sheet.paste(img, (x, y))
    draw.text((x, y + img.height + 4), path.name, fill=(0, 0, 0))

sheet.save(D / "contact-sheet.png")
