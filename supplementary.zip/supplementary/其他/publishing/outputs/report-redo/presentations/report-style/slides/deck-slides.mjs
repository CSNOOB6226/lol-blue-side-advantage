import { C, F } from "./theme.mjs";
import { base, bullets, callout, header, metric, rect, reportImage, text } from "./helpers.mjs";

const slides = [
  async (ctx, slide) => {
    base(ctx, slide, 1, "Week 2 Research Meeting");
    rect(ctx, slide, 58, 82, 6, 455, C.gold, "#00000000", 0);
    text(ctx, slide, "上单资源配置研究进展", 88, 106, 800, 56, { size: 38, color: C.blue, bold: true });
    text(ctx, slide, "Weak-Side Top Strategy / Carry Top Gold Threshold", 90, 176, 830, 30, { size: 21, color: C.blue2, face: F.latin });
    text(ctx, slide, "基于两个报告的中文 research presentation 版本；变量名、模型名与统计术语保留 academic English。", 90, 235, 900, 42, { size: 22, color: C.ink });
    metric(ctx, slide, "filtered games", "5,000", 90, 380, 210);
    metric(ctx, slide, "Topic 1 top-lane rows", "10,000", 328, 380, 240);
    metric(ctx, slide, "Topic 3 model rows", "9,695", 596, 380, 230);
    callout(ctx, slide, "Deck principle: follow the report sections, preserve tables/equations as source evidence, keep interpretation light for oral delivery.", 90, 540, 930, 78, { size: 18, face: F.latin });
  },
  async (ctx, slide) => {
    header(ctx, slide, 2, "Deck Structure", "汇报结构严格跟随两个主题报告");
    bullets(ctx, slide, [
      "Topic 1: Research Question → Data/Sample → Variables → Regression Models → Results → Indicators → Limitations",
      "Topic 3: Research Question → Data/Sample → Variables → Logistic Model → Regression Results → Threshold Prediction → Limitations",
      "所有表格与公式页优先使用报告截图，不在 PPT 内重新排版或改写。",
      "中文为主；变量名、model name、odds ratio、p-value、confidence interval 等保留 academic English。"
    ], 100, 190, 1040, { size: 22, gap: 62, lineH: 48 });
  },
  async (ctx, slide) => {
    base(ctx, slide, 3, "Topic 1 Divider");
    text(ctx, slide, "Topic 1", 78, 118, 320, 36, { size: 24, color: C.gold, bold: true, face: F.latin });
    text(ctx, slide, "弱势上单策略", 78, 168, 720, 64, { size: 48, color: C.blue, bold: true });
    text(ctx, slide, "Weak-Side Top Strategy", 82, 252, 640, 32, { size: 24, color: C.blue2, face: F.latin });
    callout(ctx, slide, "核心不是“不给资源就赢”，而是低资源配置是否需要同时满足 lane stability。", 82, 360, 820, 96, { size: 26, bold: true });
  },
  async (ctx, slide) => {
    header(ctx, slide, 4, "Topic 1 · Research Question", "弱势路上单是否会提高队伍胜率？");
    bullets(ctx, slide, [
      "研究对象：职业英雄联盟中，队伍是否可以在前期给上路较少资源，同时维持较高胜率。",
      "核心资源指标：top_gold_share15，即上单 15 分钟经济占全队 15 分钟经济的比例。",
      "核心假设：weak-side strategy 不是简单“不给上路资源”，而是低资源 + 上单不在 15 分钟前严重落后。",
      "因此模型区分 weak_side_q1 与 stable_weak_side，避免把“被打崩”误当成战术性弱侧。"
    ], 92, 188, 1010, { size: 22, gap: 64, lineH: 50 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 5, "Topic 1 · Data and Sample", "Oracle's Elixir 数据过滤后构造 top-lane team-game 样本");
    metric(ctx, slide, "original rows", "65,448", 96, 185, 190);
    metric(ctx, slide, "original games", "5,454", 314, 185, 190);
    metric(ctx, slide, "after removing LPL-related games", "60,000 rows", 532, 185, 250);
    metric(ctx, slide, "filtered games", "5,000", 810, 185, 190);
    callout(ctx, slide, "每场比赛包含两名上单，因此 Topic 1 的分析单位是 top-lane team-game record；最终样本为 10,000 条上单队伍记录。", 100, 330, 1000, 88, { size: 23 });
    bullets(ctx, slide, [
      "删除范围：所有 LPL 比赛，以及任何包含 LPL 队伍的比赛。",
      "原因：避免 LPL 队伍与其他赛区混合时产生 league/team composition confounding。",
      "模型控制：side、league、patch_str、game_length_5min。"
    ], 126, 475, 900, { size: 21, gap: 46 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 6, "Topic 1 · Variables", "变量解释表来自中文报告原文");
    await reportImage(ctx, slide, "t1_variables.png", 118, 170, 1040, 455);
  },
  async (ctx, slide) => {
    header(ctx, slide, 7, "Topic 1 · Regression Models", "三个 Logistic Regression 模型公式");
    await reportImage(ctx, slide, "t1_models.png", 115, 178, 1050, 350);
    callout(ctx, slide, "M1 使用连续 top_gold_share15_pp；M2 使用 weak_side_q1；M3 使用 stable_weak_side 作为核心解释变量。", 150, 570, 930, 58, { size: 20 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 8, "Topic 1 · Main Results", "weak_side_q1 与 stable_weak_side 的 odds ratio 均显著大于 1");
    bullets(ctx, slide, [
      "回归结果显示，weak_side_q1 和 stable_weak_side 的 odds ratio 都显著大于 1。",
      "stable_weak_side 的 odds ratio 约为 3.93，95% confidence interval 约为 [3.32, 4.66]，p < 0.001。",
      "报告层面的结论：低资源但不崩的上单，与更高胜率之间存在很强统计关联。"
    ], 100, 190, 980, { size: 24, gap: 78, lineH: 58 });
    callout(ctx, slide, "这里保留为 results summary；更细的 strategic interpretation 留给口头说明。", 150, 565, 850, 58, { size: 20, face: F.latin });
  },
  async (ctx, slide) => {
    header(ctx, slide, 9, "Topic 1 · Indicators and Limitations", "统计指标与数据局限性");
    callout(ctx, slide, "指标含义", 82, 175, 220, 52, { size: 24, bold: true });
    bullets(ctx, slide, [
      "p-value: 判断结果是否可能只是随机噪声。",
      "95% confidence interval: odds ratio 的合理范围。",
      "McFadden pseudo R²: Logistic Regression 中类似 R² 的拟合指标。",
      "Likelihood-ratio / ANOVA-style table: 比较完整模型和删去变量后的模型解释力。"
    ], 100, 255, 500, { size: 19, gap: 55, lineH: 42 });
    callout(ctx, slide, "数据局限性", 682, 175, 220, 52, { size: 24, bold: true, bar: C.blue2 });
    bullets(ctx, slide, [
      "尚未引入完整早期资源：Void Grubs、Dragon、First Turret、plates 等。",
      "缺少 jungle proximity / gank pressure，不能直接识别真实放养上路。",
      "top_gold_share15 同时反映 strategy 与 15 分钟前 lane outcome，因此不能直接下因果结论。"
    ], 700, 255, 470, { size: 19, gap: 65, lineH: 50, marker: C.blue2 });
  },
  async (ctx, slide) => {
    base(ctx, slide, 10, "Topic 3 Divider");
    text(ctx, slide, "Topic 3", 78, 118, 320, 36, { size: 24, color: C.gold, bold: true, face: F.latin });
    text(ctx, slide, "输出型上单经济门槛", 78, 168, 820, 64, { size: 46, color: C.blue, bold: true });
    text(ctx, slide, "Carry Top Gold Threshold", 82, 252, 640, 32, { size: 24, color: C.blue2, face: F.latin });
    callout(ctx, slide, "问题不是 carry 和 tank 谁“天然更强”，而是在控制队友与资源优势后，carry 需要多少上路经济领先才明显更值得。", 82, 360, 930, 100, { size: 24, bold: true });
  },
  async (ctx, slide) => {
    header(ctx, slide, 11, "Topic 3 · Research Question", "Carry / warrior-carry 上单需要多少经济领先？");
    bullets(ctx, slide, [
      "在控制队友经济优势、队友人头优势和中立资源后，carry / warrior-carry 上单是否比 tank 上单更容易赢？",
      "更具体地说：carry top 需要在 15 分钟领先 tank top 多少经济，预测胜率才会明显超过 tank top？",
      "核心模型检验 interaction term: is_carry × top_gold_diff15_500。",
      "如果 interaction term 显著为正，说明 carry top 的经济领先转化率高于 tank top。"
    ], 92, 188, 1010, { size: 22, gap: 64, lineH: 50 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 12, "Topic 3 · Data and Sample", "样本构造基于非 LPL 过滤后的 top-lane team-game observations");
    metric(ctx, slide, "initial non-LPL games", "5,000", 105, 190, 220);
    metric(ctx, slide, "top-lane observations", "10,000", 362, 190, 240);
    metric(ctx, slide, "model sample", "9,695", 640, 190, 220);
    metric(ctx, slide, "champion inclusion rule", "≥21 top apps", 900, 190, 240);
    bullets(ctx, slide, [
      "只保留出场次数足够的上单英雄，避免 rare champion 影响类别估计。",
      "Carry / warrior-carry 与 tank 的比较在同一个 Logistic Regression 中完成。",
      "控制变量包括 teammate advantage、neutral objectives、side、league、patch_str、game length。"
    ], 130, 380, 950, { size: 22, gap: 60, lineH: 48 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 13, "Topic 3 · Variables", "变量解释表来自中文报告原文");
    await reportImage(ctx, slide, "t3_variables.png", 100, 165, 1080, 475);
  },
  async (ctx, slide) => {
    header(ctx, slide, 14, "Topic 3 · Regression Formula", "Logistic Regression 公式与模型设定");
    await reportImage(ctx, slide, "t3_formula.png", 85, 185, 1110, 245);
    callout(ctx, slide, "因为 dependent variable 是 result (win/loss)，模型使用 Logistic Regression；报告主要解释 coefficient、odds ratio、p-value 与 confidence interval。", 105, 515, 1030, 76, { size: 22, face: F.latin });
  },
  async (ctx, slide) => {
    header(ctx, slide, 15, "Topic 3 · Core Carry Threshold Variables", "核心 carry 门槛变量回归表");
    await reportImage(ctx, slide, "t3_core_results.png", 96, 178, 1080, 350);
    callout(ctx, slide, "注意 carry_x_top_gold_diff15_500 的 p-value = 0.613：当前模型没有发现 carry 的经济转化斜率显著高于 tank。", 118, 565, 1040, 58, { size: 20 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 16, "Topic 3 · Teammate and Objective Controls", "队友与中立资源控制变量回归表");
    await reportImage(ctx, slide, "t3_controls_results.png", 96, 178, 1080, 398);
  },
  async (ctx, slide) => {
    header(ctx, slide, 17, "Topic 3 · Statistical Indicators", "模型拟合与统计指标解释");
    bullets(ctx, slide, [
      "Coefficient: 对 log-odds 的影响；odds ratio: 胜率 odds 的倍数变化。",
      "standard error 与 z statistic 用于衡量估计不确定性与显著性。",
      "p-value 判断变量是否显著；confidence interval 给出 odds ratio 的合理范围。",
      "Logistic Regression 不主要报告普通 R² / adjusted R² / F statistic，而使用 McFadden pseudo R² 与 likelihood-ratio / ANOVA-style table。"
    ], 88, 178, 640, { size: 18.5, gap: 53, lineH: 43 });
    await reportImage(ctx, slide, "t3_model_fit.png", 745, 218, 430, 95);
  },
  async (ctx, slide) => {
    header(ctx, slide, 18, "Topic 3 · ANOVA-Style Tests", "Likelihood-ratio / ANOVA-style table");
    await reportImage(ctx, slide, "t3_anova_part1.png", 95, 165, 1085, 290);
    await reportImage(ctx, slide, "t3_anova_part2.png", 95, 485, 1085, 150);
  },
  async (ctx, slide) => {
    header(ctx, slide, 19, "Topic 3 · Economic Threshold Prediction", "经济门槛预测表");
    await reportImage(ctx, slide, "t3_thresholds.png", 145, 165, 990, 485);
  },
  async (ctx, slide) => {
    header(ctx, slide, 20, "Topic 3 · Practical Significance", "测试范围内没有找到 carry 明显高于 tank 的 10pp 门槛");
    bullets(ctx, slide, [
      "报告结论：在测试的经济差范围内，模型没有发现 carry top 预测胜率比 tank top 高至少 10 percentage points 的门槛。",
      "这不是简单比较 carry 和 tank 谁更强，而是在控制队友和资源优势后估计 carry 需要多少经济领先才明显更值得。",
      "表格中 carry_minus_tank 随 top_gold_diff15 增加反而逐步变小，说明 interaction term 方向并不支持“carry 越领先越更优”的强结论。"
    ], 95, 190, 1010, { size: 22, gap: 82, lineH: 58 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 21, "Topic 3 · Limitations and Future Work", "数据局限性与后续方向");
    await reportImage(ctx, slide, "t3_practical_limitations.png", 95, 170, 1080, 260);
    callout(ctx, slide, "补充局限性：目前虽然加入了 dragon_diff、herald_diff、void_grubs_diff，但仍缺少更细的早期资源时序，例如潮虫具体时间/数量、小龙属性、一塔、塔皮、换线与 jungle pathing。", 110, 492, 1040, 86, { size: 21, bar: C.blue2 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 22, "Appendix · Full Coefficient Table A", "完整系数表，part 1");
    await reportImage(ctx, slide, "t3_appendix_coefficients_1.png", 210, 160, 850, 495);
  },
  async (ctx, slide) => {
    header(ctx, slide, 23, "Appendix · Full Coefficient Table B", "完整系数表，part 2");
    await reportImage(ctx, slide, "t3_appendix_coefficients_2.png", 235, 160, 800, 500);
  },
  async (ctx, slide) => {
    header(ctx, slide, 24, "Appendix · Full Coefficient Table C", "完整系数表，part 3");
    await reportImage(ctx, slide, "t3_appendix_coefficients.png", 235, 160, 800, 500);
  },
];

export async function buildSlide(n, presentation, ctx) {
  const slide = presentation.slides.add();
  const fn = slides[n - 1];
  if (!fn) throw new Error(`Missing slide ${n}`);
  await fn(ctx, slide);
  return slide;
}
