from pathlib import Path


slides = Path(__file__).resolve().parent / "slides"
for i in range(1, 25):
    n = f"{i:02d}"
    (slides / f"slide-{n}.mjs").write_text(
        f'import {{ buildSlide }} from "./deck-slides.mjs";\n'
        f"export async function slide{n}(presentation, ctx) {{ return buildSlide({i}, presentation, ctx); }}\n",
        encoding="utf-8",
    )
