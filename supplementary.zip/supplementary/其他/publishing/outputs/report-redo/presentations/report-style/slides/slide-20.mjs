import { buildSlide } from "./deck-slides.mjs";
export async function slide20(presentation, ctx) { return buildSlide(20, presentation, ctx); }
