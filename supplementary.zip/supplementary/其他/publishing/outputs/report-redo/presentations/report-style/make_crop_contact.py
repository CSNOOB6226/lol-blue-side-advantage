from pathlib import Path
import math
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[5]
D = ROOT / "publishing/outputs/report-redo/presentations/report-style/assets/crops"
files = sorted(D.glob("*.png"))
cols = 3
thumb_w = 360
thumb_h = 280
pad = 28
label_h = 26

sheet = Image.new(
    "RGB",
    (cols * (thumb_w + pad) + pad, math.ceil(len(files) / cols) * (thumb_h + label_h + pad) + pad),
    "white",
)
draw = ImageDraw.Draw(sheet)

for idx, path in enumerate(files):
    img = Image.open(path).convert("RGB")
    ratio = thumb_w / img.width
    resized_h = int(img.height * ratio)
    img = img.resize((thumb_w, resized_h))
    if img.height > thumb_h:
        img = img.crop((0, 0, thumb_w, thumb_h))
    x = pad + (idx % cols) * (thumb_w + pad)
    y = pad + (idx // cols) * (thumb_h + label_h + pad)
    sheet.paste(img, (x, y))
    draw.text((x, y + thumb_h + 4), path.name, fill=(0, 0, 0))

sheet.save(ROOT / "publishing/outputs/report-redo/presentations/report-style/assets/crop-contact.png")
