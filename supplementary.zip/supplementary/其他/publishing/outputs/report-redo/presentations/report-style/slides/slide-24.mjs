import { buildSlide } from "./deck-slides.mjs";
export async function slide24(presentation, ctx) { return buildSlide(24, presentation, ctx); }
