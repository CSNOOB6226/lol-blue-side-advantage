export const C = {
  paper: "#F7F8FA",
  white: "#FFFFFF",
  ink: "#111827",
  muted: "#4B5563",
  faint: "#E5E7EB",
  blue: "#153E63",
  blue2: "#2F5D86",
  gold: "#C89B3C",
  gold2: "#E0B75B",
  panel: "#EEF3F8",
  line: "#CBD5E1",
  green: "#1F8A70",
  red: "#B94A48",
};

export const F = {
  title: "PingFang SC",
  body: "PingFang SC",
  latin: "Arial",
  mono: "Arial",
};

export const S = {
  W: 1280,
  H: 720,
  margin: 58,
};
