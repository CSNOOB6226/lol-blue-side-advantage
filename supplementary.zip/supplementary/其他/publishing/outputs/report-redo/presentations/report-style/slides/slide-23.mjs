import { buildSlide } from "./deck-slides.mjs";
export async function slide23(presentation, ctx) { return buildSlide(23, presentation, ctx); }
