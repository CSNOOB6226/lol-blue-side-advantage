import { buildSlide } from "./deck-slides.mjs";
export async function slide22(presentation, ctx) { return buildSlide(22, presentation, ctx); }
