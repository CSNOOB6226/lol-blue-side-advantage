import { buildSlide } from "./deck-slides.mjs";
export async function slide17(presentation, ctx) { return buildSlide(17, presentation, ctx); }
