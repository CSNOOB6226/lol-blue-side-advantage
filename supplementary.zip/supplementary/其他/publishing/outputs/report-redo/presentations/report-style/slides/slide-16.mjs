import { buildSlide } from "./deck-slides.mjs";
export async function slide16(presentation, ctx) { return buildSlide(16, presentation, ctx); }
