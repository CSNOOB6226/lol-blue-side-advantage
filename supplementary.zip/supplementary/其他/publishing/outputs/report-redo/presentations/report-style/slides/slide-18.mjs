import { buildSlide } from "./deck-slides.mjs";
export async function slide18(presentation, ctx) { return buildSlide(18, presentation, ctx); }
