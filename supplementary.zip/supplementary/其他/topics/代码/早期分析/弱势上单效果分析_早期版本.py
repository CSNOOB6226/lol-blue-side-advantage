from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import norm


TOPICS_DIR = Path(__file__).resolve().parents[2]
INPUT_WITH_TYPE = TOPICS_DIR / "数据/主题三_输出型上单经济门槛/2026年上路英雄类型数据.csv"
SOURCE_TOP_PLAYER = TOPICS_DIR / "数据/通用上单数据/非中国赛区上单逐场数据.csv"
OUTPUT_DIR = TOPICS_DIR / "数据/主题一_弱势上单策略"
REPORT_DIR = TOPICS_DIR / "报告/主题一_弱势上单策略"
WEAK_SIDE_DATASET = OUTPUT_DIR / "2026年上路弱势策略变量数据.csv"


TANK_CHAMPIONS = {
    "Cho'Gath",
    "Dr. Mundo",
    "Galio",
    "Gnar",
    "Gragas",
    "K'Sante",
    "Malphite",
    "Maokai",
    "Ornn",
    "Poppy",
    "Sejuani",
    "Shen",
    "Sion",
    "Skarner",
    "Tahm Kench",
    "Udyr",
    "Volibear",
    "Zac",
}


def ensure_champion_type_file() -> pd.DataFrame:
    if INPUT_WITH_TYPE.exists():
        return pd.read_csv(INPUT_WITH_TYPE)

    df = pd.read_csv(SOURCE_TOP_PLAYER)
    df["champion_type"] = np.where(
        df["champion"].isin(TANK_CHAMPIONS), "tank", "warrior_carry"
    )
    df.to_csv(INPUT_WITH_TYPE, index=False)
    return df


def add_weak_side_variables(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    earned_gold_share_median = df["earnedgoldshare"].median()
    earned_gold_share_bottom30 = df["earnedgoldshare"].quantile(0.30)
    deaths_median = df["deaths"].median()

    df["weak_side_median"] = (
        df["earnedgoldshare"] < earned_gold_share_median
    ).astype(int)
    df["weak_side_bottom30"] = (
        df["earnedgoldshare"] <= earned_gold_share_bottom30
    ).astype(int)
    df["stable_top"] = (df["deaths"] <= deaths_median).astype(int)
    df["stable_weak_side"] = (
        (df["weak_side_bottom30"] == 1) & (df["stable_top"] == 1)
    ).astype(int)

    return df


def win_rate_table(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    table = (
        df.groupby(group_cols, dropna=False)
        .agg(games=("result", "size"), wins=("result", "sum"), win_rate=("result", "mean"))
        .reset_index()
    )
    return table.sort_values(group_cols)


def prepare_design(
    df: pd.DataFrame,
    numeric_cols: list[str],
    categorical_cols: list[str],
    binary_cols: list[str],
    interaction: bool = False,
) -> tuple[pd.DataFrame, pd.Series]:
    model_df = df[["result"] + numeric_cols + categorical_cols + binary_cols].dropna().copy()
    y = model_df["result"].astype(float)

    x_parts = []

    if binary_cols:
        x_parts.append(model_df[binary_cols].astype(float))

    if numeric_cols:
        numeric = model_df[numeric_cols].astype(float)
        scaled = (numeric - numeric.mean()) / numeric.std(ddof=0)
        scaled = scaled.add_suffix("_z")
        x_parts.append(scaled)

    if categorical_cols:
        categorical = pd.get_dummies(
            model_df[categorical_cols].astype(str), drop_first=True, dtype=float
        )
        x_parts.append(categorical)

    x = pd.concat(x_parts, axis=1) if x_parts else pd.DataFrame(index=model_df.index)

    if interaction:
        champion_type_tank = (model_df["champion_type"].astype(str) == "tank").astype(float)
        if "weak_side_bottom30" in x.columns:
            x["weak_side_bottom30_x_tank"] = x["weak_side_bottom30"] * champion_type_tank

    x.insert(0, "intercept", 1.0)
    return x, y


def fit_logit(x: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
    x_values = x.to_numpy(dtype=float)
    y_values = y.to_numpy(dtype=float)

    def objective(beta: np.ndarray) -> float:
        eta = x_values @ beta
        # Stable negative log likelihood.
        return float(np.sum(np.logaddexp(0, eta) - y_values * eta))

    def gradient(beta: np.ndarray) -> np.ndarray:
        eta = x_values @ beta
        p = expit(eta)
        return x_values.T @ (p - y_values)

    result = minimize(
        objective,
        np.zeros(x_values.shape[1]),
        jac=gradient,
        method="L-BFGS-B",
        options={"maxiter": 5000, "ftol": 1e-10, "gtol": 1e-8},
    )

    beta = result.x
    p = expit(x_values @ beta)
    weights = p * (1 - p)
    hessian = (x_values.T * weights) @ x_values
    covariance = np.linalg.pinv(hessian)
    standard_error = np.sqrt(np.diag(covariance))
    z_score = beta / standard_error
    p_value = 2 * (1 - norm.cdf(np.abs(z_score)))
    ci_low = beta - 1.96 * standard_error
    ci_high = beta + 1.96 * standard_error

    table = pd.DataFrame(
        {
            "variable": x.columns,
            "coefficient": beta,
            "standard_error": standard_error,
            "z_score": z_score,
            "p_value": p_value,
            "odds_ratio": np.exp(beta),
            "ci_low": ci_low,
            "ci_high": ci_high,
            "odds_ratio_ci_low": np.exp(ci_low),
            "odds_ratio_ci_high": np.exp(ci_high),
        }
    )
    table["significant_5pct"] = table["p_value"] < 0.05
    table["converged"] = bool(result.success)
    table["n_obs"] = len(y)
    return table


def model_table(
    df: pd.DataFrame,
    model_name: str,
    numeric_cols: list[str],
    categorical_cols: list[str],
    binary_cols: list[str],
    interaction: bool = False,
) -> pd.DataFrame:
    x, y = prepare_design(df, numeric_cols, categorical_cols, binary_cols, interaction)
    table = fit_logit(x, y)
    table.insert(0, "model", model_name)
    return table


def write_interpretation(all_models: pd.DataFrame, summary_tables: dict[str, pd.DataFrame]) -> None:
    lines = [
        "Topic 3: Weak-side Top Effect",
        "",
        "Y variable: result, where 1 = win and 0 = loss.",
        "Main X variables: weak_side_bottom30 and stable_weak_side.",
        "Numeric controls are standardized, so their odds ratios are interpreted per one standard deviation increase.",
        "Binary variables have odds ratios for changing from 0 to 1.",
        "",
    ]

    for name, table in summary_tables.items():
        lines.append(f"{name}:")
        lines.append(table.to_string(index=False))
        lines.append("")

    focus_vars = [
        "weak_side_bottom30",
        "stable_weak_side",
        "weak_side_bottom30_x_tank",
    ]
    focus = all_models[all_models["variable"].isin(focus_vars)].copy()
    lines.append("Key regression interpretation:")
    for _, row in focus.iterrows():
        direction = "increases" if row["odds_ratio"] > 1 else "decreases"
        significance = (
            "statistically significant at 5%"
            if row["p_value"] < 0.05
            else "not statistically significant at 5%"
        )
        lines.append(
            f"- {row['model']} / {row['variable']}: odds ratio = "
            f"{row['odds_ratio']:.3f}, p = {row['p_value']:.4f}. "
            f"This {direction} the odds of winning and is {significance}."
        )

    lines.append("")
    lines.append(
        "Caution: this is observational esports data. The model shows association, not guaranteed causation."
    )

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    (REPORT_DIR / "早期模型结果解释.txt").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    df = ensure_champion_type_file()
    df = add_weak_side_variables(df)
    df.to_csv(WEAK_SIDE_DATASET, index=False)

    summary_tables = {
        "按弱势上单中位数分组的胜率": win_rate_table(df, ["weak_side_median"]),
        "按弱势上单后30分位分组的胜率": win_rate_table(df, ["weak_side_bottom30"]),
        "稳定弱势上单胜率": win_rate_table(df, ["stable_weak_side"]),
        "按英雄类型与弱势策略分组的胜率": win_rate_table(
            df, ["champion_type", "weak_side_bottom30"]
        ),
    }

    for name, table in summary_tables.items():
        table.to_csv(OUTPUT_DIR / f"{name}.csv", index=False)

    models = [
        model_table(
            df,
            "model_1",
            numeric_cols=[],
            categorical_cols=["side", "league"],
            binary_cols=["weak_side_bottom30"],
        ),
        model_table(
            df,
            "model_2",
            numeric_cols=["golddiffat15", "xpdiffat15", "csdiffat15"],
            categorical_cols=["side", "league"],
            binary_cols=["weak_side_bottom30"],
        ),
        model_table(
            df,
            "model_3",
            numeric_cols=["golddiffat15", "xpdiffat15", "csdiffat15"],
            categorical_cols=["champion_type", "side", "league"],
            binary_cols=["weak_side_bottom30"],
            interaction=True,
        ),
        model_table(
            df,
            "model_4",
            numeric_cols=["golddiffat15", "xpdiffat15", "csdiffat15"],
            categorical_cols=["side", "league"],
            binary_cols=["stable_weak_side"],
        ),
    ]

    all_models = pd.concat(models, ignore_index=True)
    all_models.to_csv(OUTPUT_DIR / "早期全部模型_逻辑回归系数.csv", index=False)

    model_output_names = {
        "model_1": "早期模型一_回归系数.csv",
        "model_2": "早期模型二_回归系数.csv",
        "model_3": "早期模型三_回归系数.csv",
        "model_4": "早期模型四_回归系数.csv",
    }
    for model_name, table in all_models.groupby("model"):
        table.to_csv(OUTPUT_DIR / model_output_names[model_name], index=False)

    write_interpretation(all_models, summary_tables)

    print(f"Saved weak-side dataset: {WEAK_SIDE_DATASET}")
    print(f"Saved outputs in: {OUTPUT_DIR}")
    print()
    print(summary_tables["按弱势上单后30分位分组的胜率"].to_string(index=False))
    print()
    focus = all_models[
        all_models["variable"].isin(
            ["weak_side_bottom30", "stable_weak_side", "weak_side_bottom30_x_tank"]
        )
    ]
    print(focus[["model", "variable", "coefficient", "odds_ratio", "p_value"]].to_string(index=False))


if __name__ == "__main__":
    main()
