from pathlib import Path

import pandas as pd

# Load CSV
topics_dir = Path(__file__).resolve().parents[2]
file_name = topics_dir / "数据/原始数据/2026年英雄联盟职业比赛原始数据.csv"
df = pd.read_csv(file_name, low_memory=False)

print("Full dataset shape:", df.shape)
print("\nAvailable leagues:")
print(df["league"].value_counts().head(30))

# Filter LCK Rounds 1-2 top lane
top_lck = df[
    (df["league"] == "LCK") &
    (df["split"] == "Rounds 1-2") &
    (df["position"] == "top")
].copy()

print("\nLCK Rounds 1-2 top-lane shape:", top_lck.shape)
print("\nFirst few rows:")
print(top_lck[["date", "teamname", "playername", "champion", "result"]].head())

# Useful columns; only keep columns that exist in the file
wanted_cols = [
    "gameid", "date", "league", "split", "patch",
    "side", "teamname", "opponent", "playername", "champion", "result",
    "gamelength",
    "kills", "deaths", "assists",
    "damagetochampions", "dpm", "damageshare",
    "totalgold", "earnedgold", "earned gpm", "earnedgoldshare",
    "goldat10", "xpat10", "csat10",
    "golddiffat10", "xpdiffat10", "csdiffat10",
    "goldat15", "xpat15", "csat15",
    "golddiffat15", "xpdiffat15", "csdiffat15",
    "goldat20", "xpat20", "csat20",
    "golddiffat20", "xpdiffat20", "csdiffat20",
    "dragons", "opp_dragons", "heralds", "opp_heralds",
    "void_grubs", "opp_void_grubs",
    "towers", "opp_towers"
]

existing_cols = [c for c in wanted_cols if c in top_lck.columns]
top_lck_clean = top_lck[existing_cols].copy()

# Champion summary
summary = (
    top_lck_clean
    .groupby("champion")
    .agg(
        games=("gameid", "count"),
        wins=("result", "sum"),
        winrate=("result", "mean"),
        avg_gold_diff_15=("golddiffat15", "mean"),
        avg_xp_diff_15=("xpdiffat15", "mean"),
        avg_cs_diff_15=("csdiffat15", "mean"),
        avg_damage_share=("damageshare", "mean"),
        avg_earned_gold_share=("earnedgoldshare", "mean")
    )
    .sort_values("games", ascending=False)
)

# Save outputs
output_dir = topics_dir / "数据/早期分析数据"
output_dir.mkdir(parents=True, exist_ok=True)
top_lck_clean.to_csv(output_dir / "早期韩国赛区上单逐场数据.csv", index=False)
summary.to_csv(output_dir / "早期韩国赛区上单英雄汇总.csv")

print("\nTop 20 champions:")
print(summary.head(20))

print("\nDone.")
print("Saved:", output_dir / "早期韩国赛区上单逐场数据.csv")
print("Saved:", output_dir / "早期韩国赛区上单英雄汇总.csv")
