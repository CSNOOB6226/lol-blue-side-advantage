from pathlib import Path
import warnings

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import (
    GroupShuffleSplit,
    StratifiedGroupKFold,
    cross_val_score,
)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier


warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "Microsoft YaHei", "Arial"]
plt.rcParams["axes.unicode_minus"] = False


def grouped_holdout_indices(groups, test_size=0.25, random_state=42):
    groups = pd.Series(groups).reset_index(drop=True)
    splitter = GroupShuffleSplit(
        n_splits=1, test_size=test_size, random_state=random_state
    )
    train_idx, test_idx = next(
        splitter.split(np.zeros(len(groups)), groups=groups.to_numpy())
    )
    return train_idx, test_idx


def validate_features(data, features, target, group_col):
    required = list(features) + [target, group_col]
    missing = sorted(set(required) - set(data.columns))
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))


def model_factories(random_state=42, fast=False):
    trees = 35 if fast else 350
    return {
        "Logistic Regression": make_pipeline(
            StandardScaler(),
            LogisticRegression(max_iter=3000, random_state=random_state),
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=trees,
            min_samples_leaf=5 if fast else 15,
            max_features="sqrt",
            n_jobs=1,
            random_state=random_state,
        ),
        "XGBoost": XGBClassifier(
            n_estimators=trees,
            max_depth=3 if fast else 4,
            learning_rate=0.08 if fast else 0.04,
            min_child_weight=3,
            subsample=0.9,
            colsample_bytree=0.9,
            eval_metric="logloss",
            n_jobs=1,
            random_state=random_state,
        ),
    }


def _prepare_complete_cases(data, target, features, group_col):
    validate_features(data, features, target, group_col)
    clean = data[[group_col, target] + list(features)].copy()
    clean[features] = clean[features].replace([np.inf, -np.inf], np.nan)
    clean[features] = clean[features].fillna(clean[features].median(numeric_only=True))
    clean = clean.dropna(subset=[target, group_col])
    if clean[features].isna().any().any():
        bad = clean[features].columns[clean[features].isna().any()].tolist()
        raise ValueError("Features contain only missing values: " + ", ".join(bad))
    return clean


def _shap_importance(model, x_test, features):
    import shap

    explainer = shap.TreeExplainer(model)
    values = explainer.shap_values(x_test)
    if isinstance(values, list):
        values = values[-1]
    values = np.asarray(values)
    if values.ndim == 3:
        values = values[:, :, -1]
    return (
        pd.DataFrame(
            {
                "feature": features,
                "mean_abs_shap": np.abs(values).mean(axis=0),
            }
        )
        .sort_values("mean_abs_shap", ascending=False)
        .reset_index(drop=True)
    )


def run_importance_analysis(
    data,
    target,
    features,
    group_col="gameid",
    n_splits=5,
    n_repeats=20,
    test_size=0.25,
    random_state=42,
    fast=False,
):
    clean = _prepare_complete_cases(data, target, features, group_col)
    x = clean[features].astype(float)
    y = clean[target].astype(int)
    groups = clean[group_col]
    train_idx, test_idx = grouped_holdout_indices(
        groups, test_size=test_size, random_state=random_state
    )
    x_train, x_test = x.iloc[train_idx], x.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    train_groups = groups.iloc[train_idx]

    cv = StratifiedGroupKFold(
        n_splits=n_splits, shuffle=True, random_state=random_state
    )
    rows = []
    fitted = {}
    for name, model in model_factories(random_state, fast).items():
        scores = cross_val_score(
            model,
            x_train,
            y_train,
            groups=train_groups,
            cv=cv,
            scoring="roc_auc",
            n_jobs=1,
        )
        model.fit(x_train, y_train)
        heldout_auc = roc_auc_score(y_test, model.predict_proba(x_test)[:, 1])
        fitted[name] = model
        rows.append(
            {
                "model": name,
                "cv_auc_mean": scores.mean(),
                "cv_auc_sd": scores.std(ddof=1),
                "heldout_auc": heldout_auc,
                "train_rows": len(train_idx),
                "test_rows": len(test_idx),
                "train_games": train_groups.nunique(),
                "test_games": groups.iloc[test_idx].nunique(),
            }
        )

    xgb_model = fitted["XGBoost"]
    perm = permutation_importance(
        xgb_model,
        x_test,
        y_test,
        scoring="roc_auc",
        n_repeats=n_repeats,
        random_state=random_state,
        n_jobs=1,
    )
    perm_table = (
        pd.DataFrame(
            {
                "feature": features,
                "importance_mean": perm.importances_mean,
                "importance_sd": perm.importances_std,
            }
        )
        .sort_values("importance_mean", ascending=False)
        .reset_index(drop=True)
    )
    shap_table = _shap_importance(xgb_model, x_test, features)

    return {
        "metrics": pd.DataFrame(rows).sort_values(
            "cv_auc_mean", ascending=False
        ).reset_index(drop=True),
        "permutation_importance": perm_table,
        "shap_importance": shap_table,
        "train_games": set(train_groups),
        "test_games": set(groups.iloc[test_idx]),
    }


def save_analysis_outputs(output, output_dir, prefix):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "metrics": output_dir / f"{prefix}_模型表现.csv",
        "permutation": output_dir / f"{prefix}_置换重要性.csv",
        "shap": output_dir / f"{prefix}_SHAP重要性.csv",
    }
    output["metrics"].to_csv(paths["metrics"], index=False)
    output["permutation_importance"].to_csv(paths["permutation"], index=False)
    output["shap_importance"].to_csv(paths["shap"], index=False)
    return paths


def plot_model_auc(metrics, output_path, title):
    ordered = metrics.sort_values("cv_auc_mean")
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    ax.barh(
        ordered["model"],
        ordered["cv_auc_mean"],
        xerr=ordered["cv_auc_sd"],
        color=["#8da0cb", "#66c2a5", "#fc8d62"],
        alpha=0.9,
    )
    ax.set_xlabel("Grouped cross-validation ROC AUC")
    ax.set_title(title)
    ax.set_xlim(max(0.5, ordered["cv_auc_mean"].min() - 0.08), 1.0)
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_permutation_importance(table, output_path, title, top_n=15):
    shown = table.head(top_n).sort_values("importance_mean")
    fig, ax = plt.subplots(figsize=(8.0, max(4.8, 0.38 * len(shown))))
    ax.barh(
        shown["feature"],
        shown["importance_mean"],
        xerr=shown["importance_sd"],
        color="#3b82a0",
        alpha=0.9,
    )
    ax.axvline(0, color="#333333", linewidth=0.8)
    ax.set_xlabel("Permutation importance: held-out AUC decrease")
    ax.set_title(title)
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
