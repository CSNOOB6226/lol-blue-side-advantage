from pathlib import Path
import importlib.util

import pandas as pd


ROOT = Path(__file__).resolve().parents[3]
TOPICS = ROOT / "topics"
MASTER_PATH = ROOT / "analysis/team_game.csv"
TOPIC3_PATH = TOPICS / "数据/主题三_输出型上单经济门槛/主题三_回归模型数据.csv"
MODULE_PATH = Path(__file__).with_name("变量重要性分析.py")

TOPIC1_DATA = TOPICS / "数据/主题一_弱势上单策略"
TOPIC1_FIG = TOPICS / "报告/主题一_弱势上单策略/机器学习图表"
TOPIC3_DATA = TOPICS / "数据/主题三_输出型上单经济门槛"
TOPIC3_FIG = TOPICS / "报告/主题三_输出型上单经济门槛/机器学习图表"


def load_ml_module():
    spec = importlib.util.spec_from_file_location("ml_importance", MODULE_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


STRICT_15_MINUTE_FEATURES = [
    "team_golddiff10",
    "team_golddiff15",
    "top_golddiffat10",
    "jng_golddiffat10",
    "mid_golddiffat10",
    "bot_golddiffat10",
    "sup_golddiffat10",
    "top_golddiffat15",
    "jng_golddiffat15",
    "mid_golddiffat15",
    "bot_golddiffat15",
    "sup_golddiffat15",
    "top_xpdiffat15",
    "jng_xpdiffat15",
    "mid_xpdiffat15",
    "bot_xpdiffat15",
    "sup_xpdiffat15",
    "top_csdiffat15",
    "top_gs15",
]


def prepare_topic1(master):
    data = master.copy()
    q25 = data["top_gs15"].quantile(0.25)
    data["weak_side_q1"] = (data["top_gs15"] <= q25).astype(int)
    data["stable_weak_side"] = (
        (data["weak_side_q1"] == 1) & (data["top_golddiffat15"] >= -500)
    ).astype(int)
    focused = [
        "stable_weak_side",
        "weak_side_q1",
        "top_gs15",
        "top_golddiffat15",
        "top_xpdiffat15",
        "top_csdiffat15",
        "team_golddiff15",
    ]
    full = list(dict.fromkeys(focused + STRICT_15_MINUTE_FEATURES))
    return data, focused, full


def prepare_topic3(master):
    topic3 = pd.read_csv(TOPIC3_PATH, low_memory=False)
    extra = master.drop(columns=["result"], errors="ignore")
    data = topic3.merge(extra, on=["gameid", "side"], how="left", validate="one_to_one")
    focused = [
        "is_carry",
        "top_gold_diff15_500",
        "carry_x_top_gold_diff15_500",
        "non_top_gold_diff15_500",
        "non_top_kill_diff15",
    ]
    full = list(dict.fromkeys(focused + STRICT_15_MINUTE_FEATURES))
    return data, focused, full


def run_one(ml, data, features, data_dir, fig_dir, prefix, title):
    output = ml.run_importance_analysis(
        data=data,
        target="result",
        features=features,
        group_col="gameid",
        n_splits=5,
        n_repeats=20,
        test_size=0.25,
        random_state=20260613,
    )
    ml.save_analysis_outputs(output, data_dir, prefix)
    fig_dir.mkdir(parents=True, exist_ok=True)
    ml.plot_model_auc(
        output["metrics"],
        fig_dir / f"{prefix}_模型AUC.png",
        f"{title}: Logistic vs RF vs XGBoost",
    )
    ml.plot_permutation_importance(
        output["permutation_importance"],
        fig_dir / f"{prefix}_置换重要性.png",
        f"{title}: XGBoost held-out permutation importance",
    )
    if output["train_games"] & output["test_games"]:
        raise RuntimeError(f"{prefix} has game leakage between train and test sets")
    return output


def main():
    ml = load_ml_module()
    master = pd.read_csv(MASTER_PATH, low_memory=False)
    topic1, topic1_focused, topic1_full = prepare_topic1(master)
    topic3, topic3_focused, topic3_full = prepare_topic3(master)

    jobs = [
        (
            topic1,
            topic1_focused,
            TOPIC1_DATA,
            TOPIC1_FIG,
            "主题一_专属变量",
            "Topic 1 focused features",
        ),
        (
            topic1,
            topic1_full,
            TOPIC1_DATA,
            TOPIC1_FIG,
            "主题一_完整15分钟变量",
            "Topic 1 full early-game features",
        ),
        (
            topic3,
            topic3_focused,
            TOPIC3_DATA,
            TOPIC3_FIG,
            "主题三_专属变量",
            "Topic 3 focused features",
        ),
        (
            topic3,
            topic3_full,
            TOPIC3_DATA,
            TOPIC3_FIG,
            "主题三_完整15分钟变量",
            "Topic 3 full early-game features",
        ),
    ]
    for data, features, data_dir, fig_dir, prefix, title in jobs:
        print(f"\nRunning {prefix}: rows={len(data):,}, features={len(features)}")
        output = run_one(
            ml, data, features, data_dir, fig_dir, prefix, title
        )
        print(output["metrics"].round(4).to_string(index=False))
        print(output["permutation_importance"].head(10).round(4).to_string(index=False))


if __name__ == "__main__":
    main()
