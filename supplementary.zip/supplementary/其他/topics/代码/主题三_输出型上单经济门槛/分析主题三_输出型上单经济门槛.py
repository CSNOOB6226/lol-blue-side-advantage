from pathlib import Path
import math

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


TOPICS_DIR = Path(__file__).resolve().parents[2]
SRC = TOPICS_DIR / "数据/原始数据/2026年英雄联盟职业比赛原始数据.csv"
DATA_DIR = TOPICS_DIR / "数据/主题三_输出型上单经济门槛"
REPORT_DIR = TOPICS_DIR / "报告/主题三_输出型上单经济门槛"
DATASET_OUT = DATA_DIR / "主题三_回归模型数据.csv"
COEF_OUT = DATA_DIR / "主题三_逻辑回归系数.csv"
FIT_OUT = DATA_DIR / "主题三_模型拟合指标.csv"
LR_OUT = DATA_DIR / "主题三_似然比检验表.csv"
PRED_OUT = DATA_DIR / "主题三_经济门槛预测.csv"
MD_OUT = REPORT_DIR / "主题三_输出型上单经济门槛_分析报告.md"
DOCX_OUT = REPORT_DIR / "主题三_输出型上单经济门槛_中英文报告_修订版.docx"
ML_FIG_DIR = REPORT_DIR / "机器学习图表"


def load_ml_results():
    return {
        "focused_metrics": pd.read_csv(DATA_DIR / "主题三_专属变量_模型表现.csv"),
        "focused_importance": pd.read_csv(DATA_DIR / "主题三_专属变量_置换重要性.csv"),
        "full_metrics": pd.read_csv(DATA_DIR / "主题三_完整15分钟变量_模型表现.csv"),
        "full_importance": pd.read_csv(DATA_DIR / "主题三_完整15分钟变量_置换重要性.csv"),
    }


TANK_CHAMPIONS = {
    "K'Sante", "Sion", "Gnar", "Ornn", "Gragas", "Shen", "Malphite",
    "Galio", "Poppy", "Volibear", "Dr. Mundo", "Cho'Gath",
}

MODEL_CONTINUOUS_FEATURES = [
    "is_carry",
    "top_gold_diff15_500",
    "carry_x_top_gold_diff15_500",
    "non_top_gold_diff15_500",
    "non_top_kill_diff15",
]


def sigmoid(z):
    z = np.clip(z, -35, 35)
    return 1 / (1 + np.exp(-z))


def normal_p(z):
    return math.erfc(abs(z) / math.sqrt(2))


def chi2_sf(x, df):
    if x <= 0:
        return 1.0
    if df == 1:
        return math.erfc(math.sqrt(x / 2))
    if df % 2 == 0:
        half = x / 2
        total = 0.0
        term = 1.0
        for j in range(df // 2):
            if j > 0:
                term *= half / j
            total += term
        return min(1.0, max(0.0, math.exp(-half) * total))
    z = ((x / df) ** (1 / 3) - (1 - 2 / (9 * df))) / math.sqrt(2 / (9 * df))
    return 0.5 * math.erfc(z / math.sqrt(2))


def markdown_table(df, floatfmt=".3f"):
    out = df.reset_index() if df.index.name else df.reset_index(drop=True)
    rows = ["| " + " | ".join(map(str, out.columns)) + " |"]
    rows.append("| " + " | ".join("---" for _ in out.columns) + " |")
    for _, row in out.iterrows():
        vals = []
        for value in row:
            if isinstance(value, (float, np.floating)):
                vals.append(format(float(value), floatfmt))
            elif isinstance(value, (int, np.integer)):
                vals.append(str(int(value)))
            else:
                vals.append(str(value))
        rows.append("| " + " | ".join(vals) + " |")
    return "\n".join(rows)


def fit_logit(data, ycol, cont_cols, cat_cols=None, ridge=1e-6, max_iter=100):
    cat_cols = cat_cols or []
    parts = [pd.Series(1.0, index=data.index, name="Intercept")]
    for col in cont_cols:
        parts.append(data[col].astype(float).rename(col))
    for col in cat_cols:
        parts.append(pd.get_dummies(data[col].astype(str), prefix=col, drop_first=True, dtype=float))
    x = pd.concat(parts, axis=1)
    y = data[ycol].astype(float).to_numpy()
    xn = x.to_numpy(float)
    beta = np.zeros(xn.shape[1])
    for _ in range(max_iter):
        pred = sigmoid(xn @ beta)
        w = np.clip(pred * (1 - pred), 1e-6, None)
        z = xn @ beta + (y - pred) / w
        xtw = xn.T * w
        h = xtw @ xn + ridge * np.eye(xn.shape[1])
        nb = np.linalg.solve(h, xtw @ z)
        if np.max(np.abs(nb - beta)) < 1e-7:
            beta = nb
            break
        beta = nb
    pred = sigmoid(xn @ beta)
    w = np.clip(pred * (1 - pred), 1e-6, None)
    h = (xn.T * w) @ xn + ridge * np.eye(xn.shape[1])
    cov = np.linalg.inv(h)
    se = np.sqrt(np.diag(cov))
    zstat = beta / se
    p = np.array([normal_p(v) for v in zstat])
    ll = float(np.sum(y * np.log(np.clip(pred, 1e-12, 1)) + (1 - y) * np.log(np.clip(1 - pred, 1e-12, 1))))
    ybar = np.clip(y.mean(), 1e-12, 1 - 1e-12)
    ll_null = float(np.sum(y * np.log(ybar) + (1 - y) * np.log(1 - ybar)))
    res = pd.DataFrame({
        "variable": x.columns,
        "coef_log_odds": beta,
        "std_error": se,
        "z_stat": zstat,
        "p_value": p,
        "odds_ratio": np.exp(beta),
        "or_ci_low": np.exp(beta - 1.96 * se),
        "or_ci_high": np.exp(beta + 1.96 * se),
    })
    metrics = {
        "N": int(len(y)),
        "df_model": int(x.shape[1] - 1),
        "log_likelihood": ll,
        "null_log_likelihood": ll_null,
        "mcfadden_pseudo_r2": 1 - (ll / ll_null),
    }
    return res, x, metrics


def lr_test(data, full_cont, full_cat, drop_cont=(), drop_cat=(), label=""):
    _, _, full = fit_logit(data, "result", full_cont, full_cat)
    red_cont = [c for c in full_cont if c not in set(drop_cont)]
    red_cat = [c for c in full_cat if c not in set(drop_cat)]
    _, _, reduced = fit_logit(data, "result", red_cont, red_cat)
    lr = 2 * (full["log_likelihood"] - reduced["log_likelihood"])
    df = full["df_model"] - reduced["df_model"]
    return {
        "test": label,
        "dropped": ", ".join(list(drop_cont) + list(drop_cat)),
        "lr_chi_square": lr,
        "df": df,
        "p_value": chi2_sf(lr, df),
    }


def fmt_p(p):
    if p < 0.001:
        return "<0.001"
    return f"{p:.3f}"


def prepare_dataset():
    df = pd.read_csv(SRC, low_memory=False)
    team_rows_all = df[df["position"] == "team"].copy()
    lpl_teams = set(team_rows_all.loc[team_rows_all["league"].eq("LPL"), "teamname"].dropna())
    lpl_related_games = set(df.loc[df["league"].eq("LPL"), "gameid"].dropna())
    lpl_related_games |= set(team_rows_all.loc[team_rows_all["teamname"].isin(lpl_teams), "gameid"].dropna())
    df = df[~df["gameid"].isin(lpl_related_games)].copy()

    top = df[df["position"] == "top"].copy()
    champion_counts = top["champion"].value_counts()
    study_champions = set(champion_counts[champion_counts >= 21].index)
    top = top[top["champion"].isin(study_champions)].copy()
    top["champion_class"] = np.where(top["champion"].isin(TANK_CHAMPIONS), "tank", "carry_warrior")
    top["is_carry"] = (top["champion_class"] == "carry_warrior").astype(int)

    team_cols = [
        "gameid", "side", "goldat15", "golddiffat15", "killsat15", "opp_killsat15",
    ]
    team = df[df["position"] == "team"][team_cols].copy()
    team = team.rename(columns={
        "goldat15": "team_goldat15",
        "golddiffat15": "team_gold_diff15",
        "killsat15": "team_killsat15",
        "opp_killsat15": "opp_team_killsat15",
    })
    data = top.merge(team, on=["gameid", "side"], how="left")
    data["top_gold_diff15_500"] = data["golddiffat15"] / 500
    data["non_top_gold_diff15_500"] = (data["team_gold_diff15"] - data["golddiffat15"]) / 500
    data["top_kill_diff15"] = data["killsat15"] - data["opp_killsat15"]
    data["team_kill_diff15"] = data["team_killsat15"] - data["opp_team_killsat15"]
    data["non_top_kill_diff15"] = data["team_kill_diff15"] - data["top_kill_diff15"]
    data["patch_str"] = data["patch"].astype(str)
    data["carry_x_top_gold_diff15_500"] = data["is_carry"] * data["top_gold_diff15_500"]
    keep = [
        "gameid", "date", "league", "split", "patch_str", "side", "teamname", "playername",
        "champion", "champion_class", "is_carry", "result", "gamelength",
        "goldat15", "golddiffat15", "top_gold_diff15_500", "carry_x_top_gold_diff15_500",
        "team_gold_diff15", "non_top_gold_diff15_500", "team_kill_diff15", "non_top_kill_diff15",
    ]
    model = data[keep].dropna(subset=[
        "result", "is_carry", "top_gold_diff15_500", "carry_x_top_gold_diff15_500",
        "non_top_gold_diff15_500", "non_top_kill_diff15",
        "side", "league", "patch_str",
    ]).copy()
    return df, model, champion_counts


def average_prediction(data, coef, xcols, carry, gold500):
    pred_df = data.copy()
    pred_df["is_carry"] = carry
    pred_df["top_gold_diff15_500"] = gold500
    pred_df["carry_x_top_gold_diff15_500"] = carry * gold500
    # Use observed team controls and categorical controls; average over the real sample distribution.
    parts = [pd.Series(1.0, index=pred_df.index, name="Intercept")]
    for col in MODEL_CONTINUOUS_FEATURES:
        parts.append(pred_df[col].astype(float).rename(col))
    for col in ["side", "league", "patch_str"]:
        d = pd.get_dummies(pred_df[col].astype(str), prefix=col, drop_first=True, dtype=float)
        parts.append(d)
    x = pd.concat(parts, axis=1)
    aligned = x.reindex(columns=xcols, fill_value=0.0)
    beta = coef.set_index("variable").loc[xcols, "coef_log_odds"].to_numpy()
    return float(sigmoid(aligned.to_numpy(float) @ beta).mean())


def style_doc(doc):
    sec = doc.sections[0]
    sec.top_margin = Inches(0.7)
    sec.bottom_margin = Inches(0.7)
    sec.left_margin = Inches(0.7)
    sec.right_margin = Inches(0.7)
    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    styles["Normal"].font.size = Pt(9.5)
    for name in ["Heading 1", "Heading 2", "Heading 3"]:
        styles[name].font.name = "Aptos Display"
        styles[name]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        styles[name].font.color.rgb = RGBColor(31, 78, 121)


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def cell_text(cell, text, bold=False):
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(str(text))
    r.bold = bold
    r.font.size = Pt(8)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc, df, max_rows=None):
    if max_rows:
        df = df.head(max_rows)
    table = doc.add_table(rows=1, cols=len(df.columns))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, col in enumerate(df.columns):
        cell_text(table.rows[0].cells[i], col, True)
        shade(table.rows[0].cells[i], "D9EAF7")
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for i, value in enumerate(row):
            col = df.columns[i]
            if isinstance(value, (float, np.floating)):
                if col.lower() in {"p", "p_value", "p-value"}:
                    text = fmt_p(float(value))
                else:
                    text = f"{float(value):.3f}"
            elif isinstance(value, (int, np.integer)):
                text = str(int(value))
            else:
                text = str(value)
            cell_text(cells[i], text)
    for row in table.rows:
        tr_pr = row._tr.get_or_add_trPr()
        cant_split = OxmlElement("w:cantSplit")
        tr_pr.append(cant_split)
    doc.add_paragraph()


def add_formula(doc, formula):
    p = doc.add_paragraph()
    p.style = doc.styles["Intense Quote"]
    r = p.add_run(formula)
    r.font.name = "Courier New"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Courier New")
    r.font.size = Pt(8.5)


def build_reports(model, coef_focus, coef_full, fit, lr_table, pred_table, desc, threshold):
    ml = load_ml_results()
    eq = (
        "logit(P(Win_i = 1)) = beta0 + beta1(is_carry_i) + beta2(top_gold_diff15_500_i) "
        "+ beta3(is_carry_i * top_gold_diff15_500_i) + beta4(non_top_gold_diff15_500_i) "
        "+ beta5(non_top_kill_diff15_i) + beta6(side_i) + beta7(league_i) "
        "+ beta8(patch_i) + error_i"
    )
    threshold_sentence = (
        f"The model reaches the 10 percentage-point dominance rule at about +{threshold:.0f} top-lane gold at 15 minutes."
        if threshold is not None
        else "The model does not find a point in the tested range where carry top exceeds tank top by at least 10 percentage points."
    )
    threshold_cn = (
        f"按照 Carry 预测胜率至少比 Tank 高 10 个百分点的标准，模型估计门槛大约是 15 分钟上路 +{threshold:.0f} 金币。"
        if threshold is not None
        else "在测试的经济差范围内，模型没有发现 Carry 上单预测胜率比 Tank 上单高至少 10 个百分点的门槛。"
    )
    core_vars = ["is_carry", "top_gold_diff15_500", "carry_x_top_gold_diff15_500"]
    team_control_vars = [
        "non_top_gold_diff15_500", "non_top_kill_diff15",
    ]
    core_table = coef_focus[coef_focus["variable"].isin(core_vars)].copy()
    controls_table = coef_focus[coef_focus["variable"].isin(team_control_vars)].copy()
    appendix_table = coef_full.copy()
    appendix_table["p_value"] = appendix_table["p_value"].map(lambda v: "<0.001" if v < 0.001 else f"{v:.3f}")
    appendix_table = appendix_table[
        ["variable", "coef_log_odds", "std_error", "z_stat", "p_value", "odds_ratio", "or_ci_low", "or_ci_high"]
    ]
    md = [
        "# Topic 3: Carry Top Gold Threshold\n\n",
        "## English Report\n\n",
        "### Research Question\n\n",
        "After controlling for teammates' 15-minute gold and kill advantage, how much 15-minute top-lane gold advantage does a carry/warrior-carry top laner need before clearly outperforming a tank top laner in win probability?\n\n",
        "### Dataset\n\n",
        f"The analysis uses the 2026 Oracle's Elixir match dataset. LPL and LPL-related games were removed. The final model sample contains {len(model):,} top-lane team-game observations and {model['champion'].nunique()} champions with at least 21 top-lane appearances before complete-case filtering.\n\n",
        "### Model Equation\n\n",
        f"`{eq}`\n\n",
        "### Key Regression Results\n\n",
        "Core carry-threshold variables:\n\n",
        markdown_table(core_table, ".4f"),
        "\n\nTeammate 15-minute controls:\n\n",
        markdown_table(controls_table, ".4f"),
        "\n\n### Model Fit\n\n",
        markdown_table(pd.DataFrame([fit]), ".4f"),
        "\n\n### ANOVA-Style Likelihood-Ratio Table\n\n",
        markdown_table(lr_table, ".4f"),
        "\n\n### Threshold Predictions\n\n",
        markdown_table(pred_table, ".3f"),
        "\n\n### Preliminary Conclusion\n\n",
        f"{threshold_sentence} The interaction term is the key test: it asks whether top-lane gold advantage changes win probability differently for carry tops than for tank tops, after controlling for 15-minute non-top teammate gold and kill advantage, side, league, and patch.\n\n",
        "### Machine-Learning Robustness and Variable Importance\n\n",
        "Logistic Regression, Random Forest, and XGBoost were compared using five-fold cross-validation grouped by `gameid`. Only variables available by 15 minutes were used in these predictive models; final game length and end-of-game totals were excluded. Logistic regression remains the inferential model, while permutation importance and SHAP are used only to assess predictive contribution.\n\n",
        markdown_table(ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]], ".4f"),
        "\n\nFocused-model XGBoost permutation importance:\n\n",
        markdown_table(ml["focused_importance"].head(8), ".4f"),
        "\n\nThe 15-minute non-top teammate gold difference dominates the predictions. `is_carry` and `is_carry × top gold difference` have approximately zero permutation importance, reinforcing the regression result that carry identity does not create a meaningful gold-conversion premium.\n\n",
        "### Full 15-Minute Feature Appendix\n\n",
        markdown_table(ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]], ".4f"),
        "\n\n",
        markdown_table(ml["full_importance"].head(15), ".4f"),
        "\n\nPredictive importance is not a causal effect and does not have the same interpretation as a coefficient, confidence interval, or p-value.\n\n",
        "## 中文报告\n\n",
        "### 研究问题\n\n",
        "在控制队友15分钟经济优势和人头优势后，Carry/战士型上单需要在15分钟领先 Tank 上单多少经济，胜率才会明显超过 Tank 上单？\n\n",
        "### 数据\n\n",
        f"本分析使用 2026 Oracle's Elixir 总数据，并删除 LPL 以及 LPL 队伍相关比赛。最终模型样本包含 {len(model):,} 条上单-队伍比赛记录，使用的是完整案例过滤后、登场数足够的 {model['champion'].nunique()} 个上单英雄。\n\n",
        "### 模型公式\n\n",
        f"`{eq}`\n\n",
        "### 核心回归结果\n\n",
        "核心 Carry 门槛变量：\n\n",
        markdown_table(core_table, ".4f"),
        "\n\n队友与资源控制变量：\n\n",
        markdown_table(controls_table, ".4f"),
        "\n\n### 模型拟合\n\n",
        markdown_table(pd.DataFrame([fit]), ".4f"),
        "\n\n### ANOVA-style / 似然比检验表\n\n",
        markdown_table(lr_table, ".4f"),
        "\n\n### 经济门槛预测表\n\n",
        markdown_table(pred_table, ".3f"),
        "\n\n### 初步结论\n\n",
        f"{threshold_cn} 这个研究的核心不是 Carry 和 Tank 谁平均胜率更高，而是 Carry 上单是否需要更高的上路经济领先，才能在控制队友15分钟优势后真正超过 Tank 上单。\n\n",
        "### 机器学习稳健性与变量重要性\n\n",
        "补充分析使用按 `gameid` 分组的五折交叉验证，对比 Logistic Regression、Random Forest 和 XGBoost。机器学习胜负预测只使用15分钟及以前变量，不使用最终局长和赛后总量。逻辑回归仍负责统计推断，置换重要性和 SHAP 只衡量预测贡献。\n\n",
        markdown_table(ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]], ".4f"),
        "\n\n",
        markdown_table(ml["focused_importance"].head(8), ".4f"),
        "\n\n非上路队友15分钟经济差占据主要预测价值；`is_carry` 与 Carry × 上路经济差交互项的重要性约为零，与回归中“Carry 没有额外经济转化溢价”的结论一致。\n\n",
        "### 完整15分钟变量附录\n\n",
        markdown_table(ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]], ".4f"),
        "\n\n",
        markdown_table(ml["full_importance"].head(15), ".4f"),
        "\n\n变量重要性不等于因果效应，也不能替代系数、置信区间和 p-value。\n",
    ]
    MD_OUT.write_text("".join(md))

    doc = Document()
    style_doc(doc)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title.add_run("Topic 3: Carry Top Gold Threshold")
    r.bold = True
    r.font.size = Pt(18)
    r.font.color.rgb = RGBColor(31, 78, 121)
    doc.add_paragraph("Bilingual undergraduate statistics report using logistic regression").alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading("Version B: English Report", 1)
    doc.add_heading("1. Research Question", 2)
    doc.add_paragraph("After controlling for teammates' 15-minute gold and kill advantage, how much 15-minute top-lane gold advantage does a carry/warrior-carry top laner need before clearly outperforming a tank top laner in win probability?")
    doc.add_heading("2. Dataset and Sample", 2)
    doc.add_paragraph(f"The report uses the full 2026 Oracle's Elixir match dataset. LPL and LPL-related games were removed. The model sample contains {len(model):,} top-lane team-game observations. Champions were kept if they had at least 21 top-lane appearances before complete-case filtering.")
    doc.add_heading("3. Variables", 2)
    var_table = pd.DataFrame([
        ["result", "Dependent", "1 = win, 0 = loss."],
        ["is_carry", "Main independent", "1 = carry/warrior-carry top, 0 = tank top."],
        ["top_gold_diff15_500", "Main independent", "Top-lane gold difference at 15 minutes, measured per 500 gold."],
        ["is_carry × top_gold_diff15_500", "Interaction", "Tests whether gold advantage changes win probability differently for carry tops than tank tops."],
        ["non_top_gold_diff15_500", "Control", "Team gold difference at 15 excluding top-lane gold difference, per 500 gold."],
        ["non_top_kill_diff15", "Control", "Team kill difference at 15 excluding top-lane kill difference."],
        ["side / league / patch_str", "Controls", "Controls for side, competition environment, and version."],
    ], columns=["Variable", "Type", "Meaning"])
    add_table(doc, var_table)
    doc.add_heading("4. Why Logistic Regression Is Appropriate", 2)
    doc.add_paragraph("The dependent variable is binary: a team either wins or loses. Logistic regression estimates the probability of winning and reports effects in log-odds or odds-ratio form.")
    doc.add_heading("5. Regression Equation", 2)
    add_formula(doc, eq)
    doc.add_heading("6. Regression Results", 2)
    doc.add_paragraph("The main regression table is split into two shorter tables so no important rows are hidden by a page break. The full coefficient table, including side, league, and patch dummy controls, appears in the appendix.")
    doc.add_heading("6.1 Core Carry-Threshold Variables", 3)
    add_table(doc, core_table)
    doc.add_heading("6.2 Teammate 15-Minute Control Variables", 3)
    add_table(doc, controls_table)
    doc.add_heading("7. Statistical Indicators", 2)
    doc.add_paragraph("Coefficients show effects on log-odds. Standard errors measure uncertainty. z statistics equal coefficient divided by standard error. p-values test whether the effect is statistically different from zero. Confidence intervals give plausible ranges for odds ratios. Ordinary R-squared, adjusted R-squared, and F statistics are not the main indicators for logistic regression, so McFadden pseudo R-squared and likelihood-ratio tests are reported instead.")
    add_table(doc, pd.DataFrame([fit]))
    add_table(doc, lr_table)
    doc.add_heading("8. Threshold Predictions", 2)
    add_table(doc, pred_table)
    doc.add_heading("9. Practical Significance and Preliminary Conclusion", 2)
    doc.add_paragraph(threshold_sentence)
    doc.add_paragraph("In gameplay terms, this means the study is estimating the gold lead a carry top needs before the carry pick becomes clearly better than a tank pick, after controlling for teammates' 15-minute gold and kill advantage.")
    doc.add_heading("10. Limitations and Future Work", 2)
    doc.add_paragraph("The study is observational, so it shows association rather than causation. Future work should add champion-specific controls, team fixed effects, patch-specific models, and alternative dominance thresholds such as 5 or 15 percentage points.")
    doc.add_heading("Appendix A. Full Coefficient Table", 2)
    doc.add_paragraph("This appendix includes all coefficients used in the logistic regression, including categorical dummy controls for side, league, and patch. These controls are important for adjustment, but they are not the main substantive focus of the study.")
    add_table(doc, appendix_table)
    doc.add_heading("11. Machine-Learning Robustness and Variable Importance", 2)
    doc.add_paragraph("As a predictive robustness check, Logistic Regression, Random Forest, and XGBoost were evaluated with five-fold cross-validation grouped by gameid. This keeps both sides of the same match in one fold. Only variables observed by 15 minutes were used, excluding final game length and end-of-game totals.")
    add_table(doc, ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    doc.add_paragraph("The 15-minute non-top teammate gold difference dominates held-out predictive importance. Carry identity and its interaction with top gold difference contribute approximately zero additional AUC. This supports, but does not causally prove, the regression conclusion that carry tops do not have a distinct gold-conversion premium.")
    add_table(doc, ml["focused_importance"].head(8))
    if (ML_FIG_DIR / "主题三_专属变量_置换重要性.png").exists():
        doc.add_picture(str(ML_FIG_DIR / "主题三_专属变量_置换重要性.png"), width=Inches(6.2))
    doc.add_heading("Appendix B. Full 15-Minute Feature Model", 2)
    add_table(doc, ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    add_table(doc, ml["full_importance"].head(5))

    doc.add_section(WD_SECTION.NEW_PAGE)
    doc.add_heading("Version A: Chinese Report", 1)
    doc.add_heading("1. 研究问题", 2)
    doc.add_paragraph("在控制队友15分钟经济优势和人头优势后，Carry/战士型上单需要在15分钟领先 Tank 上单多少经济，胜率才会明显超过 Tank 上单？")
    doc.add_heading("2. 数据与样本", 2)
    doc.add_paragraph(f"本报告使用 2026 Oracle's Elixir 总数据，并删除 LPL 和 LPL 队伍相关比赛。模型样本包含 {len(model):,} 条上单-队伍比赛记录。英雄池保留至少有 21 场上单登场的英雄。")
    doc.add_heading("3. 变量解释", 2)
    var_cn = pd.DataFrame([
        ["result", "因变量", "1 = 赢，0 = 输。"],
        ["is_carry", "核心自变量", "1 = Carry/战士型上单，0 = Tank 上单。"],
        ["top_gold_diff15_500", "核心自变量", "15分钟上路经济差，每500金币为一个单位。"],
        ["is_carry × top_gold_diff15_500", "交互项", "检验 Carry 上单是否比 Tank 更能把经济领先转化为胜率。"],
        ["non_top_gold_diff15_500", "控制变量", "排除上单后的队友15分钟经济差，每500金币为单位。"],
        ["non_top_kill_diff15", "控制变量", "排除上单后的队友15分钟人头差。"],
        ["side / league / patch_str", "控制变量", "控制蓝红方、赛区和版本。"],
    ], columns=["变量", "类型", "含义"])
    add_table(doc, var_cn)
    doc.add_heading("4. 为什么使用逻辑回归", 2)
    doc.add_paragraph("因为因变量 result 是赢/输二分类变量，所以逻辑回归比普通线性回归更合适。逻辑回归估计的是队伍获胜概率。")
    doc.add_heading("5. 回归公式", 2)
    add_formula(doc, eq)
    doc.add_heading("6. 回归结果", 2)
    doc.add_paragraph("为避免表格在分页处断开导致看起来像缺少变量，正文把回归结果拆成两个短表。完整系数表，包括 side、league、patch 的 dummy control coefficients，放在附录。")
    doc.add_heading("6.1 核心 Carry 门槛变量", 3)
    add_table(doc, core_table)
    doc.add_heading("6.2 队友15分钟控制变量", 3)
    add_table(doc, controls_table)
    doc.add_heading("7. 统计指标解释", 2)
    doc.add_paragraph("Coefficient 表示对 log-odds 的影响；standard error 表示估计不确定性；z statistic 等于 coefficient 除以 standard error；p-value 用来判断变量是否显著；confidence interval 给出 odds ratio 的合理范围。因为这是逻辑回归，普通 R²、Adjusted R² 和 F statistic 不是主要指标，所以报告 McFadden pseudo R² 和 likelihood-ratio / ANOVA-style table。")
    add_table(doc, pd.DataFrame([fit]))
    add_table(doc, lr_table)
    doc.add_heading("8. 经济门槛预测", 2)
    add_table(doc, pred_table)
    doc.add_heading("9. 实际意义与初步结论", 2)
    doc.add_paragraph(threshold_cn)
    doc.add_paragraph("游戏含义是：这个模型不是简单比较 Carry 和 Tank 谁更强，而是在控制队友和资源优势后，估计 Carry 上单需要多少经济领先，才明显比 Tank 更值得。")
    doc.add_heading("10. 局限与未来研究", 2)
    doc.add_paragraph("本研究是观察性分析，只能说明相关性，不能直接证明因果。未来可以加入英雄固定效应、队伍固定效应、按版本分组建模，并测试 5 或 15 个百分点的不同优势门槛。")
    doc.add_heading("附录 A：完整系数表", 2)
    doc.add_paragraph("本附录包含逻辑回归中的所有系数，包括 side、league 和 patch 的 dummy control coefficients。这些变量用于控制蓝红方、赛区和版本差异，但不是本文主要研究重点。")
    add_table(doc, appendix_table)
    doc.add_heading("11. 机器学习稳健性与变量重要性", 2)
    doc.add_paragraph("补充分析使用按 gameid 分组的五折交叉验证，对比 Logistic Regression、Random Forest 和 XGBoost，确保同一场比赛的蓝红双方不会进入不同折。机器学习模型只使用15分钟及以前变量，不使用最终局长和赛后总量。")
    add_table(doc, ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    doc.add_paragraph("非上路队友15分钟经济差主导测试集预测；Carry 身份及其与上路经济差的交互项几乎没有额外重要性。这与回归中 Carry 缺少独立经济转化溢价的结论一致，但变量重要性不等于因果效应，也没有传统 p-value。")
    add_table(doc, ml["focused_importance"].head(8))
    if (ML_FIG_DIR / "主题三_专属变量_模型AUC.png").exists():
        doc.add_picture(str(ML_FIG_DIR / "主题三_专属变量_模型AUC.png"), width=Inches(6.2))
    doc.add_heading("附录 B：完整15分钟变量模型", 2)
    add_table(doc, ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    add_table(doc, ml["full_importance"].head(5))
    while doc.paragraphs and not doc.paragraphs[-1].text.strip():
        paragraph = doc.paragraphs[-1]
        paragraph._element.getparent().remove(paragraph._element)
    doc.save(DOCX_OUT)
    build_mirrored_topic3_docx(
        model, core_table, controls_table, appendix_table, fit, lr_table,
        pred_table, threshold_sentence, threshold_cn, eq, ml
    )


def add_topic3_language(
    doc, language, model, core_table, controls_table, appendix_table, fit,
    lr_table, pred_table, threshold_text, eq, ml
):
    zh = language == "zh"
    headings = {
        "research": "1. 研究问题" if zh else "1. Research Question",
        "data": "2. 数据与样本" if zh else "2. Dataset and Sample",
        "variables": "3. 变量解释" if zh else "3. Variables",
        "why": "4. 为什么使用逻辑回归" if zh else "4. Why Logistic Regression Is Appropriate",
        "equation": "5. 回归公式" if zh else "5. Regression Equation",
        "results": "6. 回归结果" if zh else "6. Regression Results",
        "core": "6.1 核心 Carry 门槛变量" if zh else "6.1 Core Carry-Threshold Variables",
        "controls": "6.2 队友15分钟控制变量" if zh else "6.2 Teammate 15-Minute Controls",
        "indicators": "7. 统计指标解释" if zh else "7. Statistical Indicators",
        "predictions": "8. 经济门槛预测" if zh else "8. Threshold Predictions",
        "conclusion": "9. 实际意义与初步结论" if zh else "9. Practical Significance and Preliminary Conclusion",
        "limits": "10. 局限与未来研究" if zh else "10. Limitations and Future Work",
        "appendix_a": "附录 A：完整系数表" if zh else "Appendix A. Full Coefficient Table",
        "ml": "11. 机器学习稳健性与变量重要性" if zh else "11. Machine-Learning Robustness and Variable Importance",
        "appendix_b": "附录 B：完整15分钟变量模型" if zh else "Appendix B. Full 15-Minute Feature Model",
    }

    doc.add_heading(headings["research"], 2)
    doc.add_paragraph(
        "在控制队友15分钟经济和人头优势后，Carry/战士型上单需要多少15分钟上路经济领先，才能在预测胜率上明显超过Tank上单？"
        if zh else
        "After controlling for teammates' 15-minute gold and kill advantage, how much 15-minute top-lane gold advantage does a carry/warrior-carry top need before clearly outperforming a tank top in predicted win probability?"
    )

    doc.add_heading(headings["data"], 2)
    doc.add_paragraph(
        f"本报告使用2026 Oracle's Elixir数据，删除LPL及LPL队伍相关比赛。模型样本包含{len(model):,}条上单-队伍比赛记录，并保留至少有21场上单登场的英雄。"
        if zh else
        f"The report uses the 2026 Oracle's Elixir dataset after removing LPL and LPL-related games. The model contains {len(model):,} top-lane team-game observations and retains champions with at least 21 top-lane appearances."
    )

    doc.add_heading(headings["variables"], 2)
    if zh:
        variables = pd.DataFrame([
            ["result", "因变量", "1 = 赢，0 = 输。"],
            ["is_carry", "核心自变量", "1 = Carry/战士型上单，0 = Tank上单。"],
            ["top_gold_diff15_500", "核心自变量", "15分钟上路经济差，每500金币为一个单位。"],
            ["is_carry × top_gold_diff15_500", "交互项", "检验Carry是否更能把上路经济领先转化为胜率。"],
            ["non_top_gold_diff15_500", "控制变量", "排除上单后的队友15分钟经济差，每500金币为单位。"],
            ["non_top_kill_diff15", "控制变量", "排除上单后的队友15分钟人头差。"],
            ["side / league / patch_str", "控制变量", "控制蓝红方、赛区和版本。"],
        ], columns=["变量", "类型", "含义"])
    else:
        variables = pd.DataFrame([
            ["result", "Dependent", "1 = win, 0 = loss."],
            ["is_carry", "Main independent", "1 = carry/warrior-carry top, 0 = tank top."],
            ["top_gold_diff15_500", "Main independent", "Top gold difference at 15 minutes, per 500 gold."],
            ["is_carry × top_gold_diff15_500", "Interaction", "Tests whether carries convert top gold leads into win probability differently."],
            ["non_top_gold_diff15_500", "Control", "Team gold difference at 15 excluding top, per 500 gold."],
            ["non_top_kill_diff15", "Control", "Team kill difference at 15 excluding top."],
            ["side / league / patch_str", "Controls", "Controls for side, league, and patch."],
        ], columns=["Variable", "Type", "Meaning"])
    add_table(doc, variables)

    doc.add_heading(headings["why"], 2)
    doc.add_paragraph(
        "因变量result是赢/输二分类，因此逻辑回归适合估计获胜概率和优势比。"
        if zh else
        "Because result is binary, logistic regression is appropriate for estimating win probability and odds ratios."
    )

    doc.add_heading(headings["equation"], 2)
    add_formula(doc, eq)

    doc.add_heading(headings["results"], 2)
    doc.add_paragraph(
        "正文将核心Carry门槛变量与队友/资源控制变量分成两个相同格式的表格。"
        if zh else
        "The main results separate the carry-threshold variables from teammate 15-minute controls in two identically formatted tables."
    )
    doc.add_heading(headings["core"], 3)
    add_table(doc, core_table)
    doc.add_heading(headings["controls"], 3)
    add_table(doc, controls_table)

    doc.add_heading(headings["indicators"], 2)
    doc.add_paragraph(
        "系数表示log-odds影响，标准误衡量不确定性，z statistic为系数除以标准误，p-value检验效果是否异于零，置信区间给出优势比的合理范围。逻辑回归使用McFadden pseudo R-squared和似然比检验，而不是普通R²和F statistic。"
        if zh else
        "Coefficients are effects on log-odds, standard errors measure uncertainty, z statistics divide coefficients by standard errors, p-values test zero effects, and confidence intervals give plausible odds-ratio ranges. Logistic regression uses McFadden pseudo R-squared and likelihood-ratio tests rather than ordinary R-squared and F statistics."
    )
    add_table(doc, pd.DataFrame([fit]))
    add_table(doc, lr_table)

    doc.add_heading(headings["predictions"], 2)
    add_table(doc, pred_table)

    doc.add_heading(headings["conclusion"], 2)
    doc.add_paragraph(threshold_text)
    doc.add_paragraph(
        "游戏含义是：研究估计的是在控制队友与资源后，Carry上单需要多少经济领先才会比Tank明显更值得，而不是简单比较两类英雄的平均胜率。"
        if zh else
        "In gameplay terms, the study estimates how much gold advantage a carry top needs to become clearly preferable to a tank after controlling for teammates' 15-minute gold and kill advantage, rather than merely comparing average win rates."
    )

    doc.add_heading(headings["limits"], 2)
    doc.add_paragraph(
        "本研究为观察性分析，只能说明相关性。未来可加入英雄和队伍固定效应、按版本建模，并测试不同优势门槛。"
        if zh else
        "The study is observational and supports association rather than causation. Future work can add champion and team fixed effects, patch-specific models, and alternative dominance thresholds."
    )

    doc.add_heading(headings["appendix_a"], 2)
    doc.add_paragraph(
        "本附录列出包括蓝红方、赛区和版本dummy controls在内的全部逻辑回归系数。"
        if zh else
        "This appendix reports every logistic-regression coefficient, including side, league, and patch dummy controls."
    )
    add_table(doc, appendix_table)

    doc.add_heading(headings["ml"], 2)
    doc.add_paragraph(
        "补充预测分析使用按gameid分组的五折交叉验证，对比Logistic Regression、Random Forest和XGBoost，并只使用15分钟及以前变量。"
        if zh else
        "The predictive robustness analysis compares Logistic Regression, Random Forest, and XGBoost with five-fold cross-validation grouped by gameid, using only variables available by 15 minutes."
    )
    add_table(doc, ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    doc.add_paragraph(
        "非上路队友15分钟经济差主导预测；Carry身份及其与上路经济差的交互项几乎没有额外重要性。变量重要性不等于因果效应。"
        if zh else
        "The 15-minute non-top teammate gold difference dominates prediction; carry identity and its interaction with top gold difference add almost no importance. Predictive importance is not a causal effect."
    )
    add_table(doc, ml["focused_importance"].head(8))
    for image_name in ["主题三_专属变量_置换重要性.png", "主题三_专属变量_模型AUC.png"]:
        image_path = ML_FIG_DIR / image_name
        if image_path.exists():
            doc.add_picture(str(image_path), width=Inches(6.2))

    doc.add_heading(headings["appendix_b"], 2)
    doc.add_paragraph(
        "完整模型加入五路前期经济、经验、补刀和目标变量，以下展示模型表现与前五项置换重要性。"
        if zh else
        "The full model adds 10/15-minute gold, 15-minute experience, and top-lane CS variables across roles; the tables show model performance and the top five permutation importances."
    )
    add_table(doc, ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    add_table(doc, ml["full_importance"].head(5))


def build_mirrored_topic3_docx(
    model, core_table, controls_table, appendix_table, fit, lr_table,
    pred_table, threshold_sentence, threshold_cn, eq, ml
):
    doc = Document()
    style_doc(doc)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Topic 3: Carry Top Gold Threshold")
    run.bold = True
    run.font.size = Pt(18)
    run.font.color.rgb = RGBColor(31, 78, 121)
    doc.add_paragraph("English and Chinese mirrored bilingual report").alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading("Version B: English Report", 1)
    add_topic3_language(
        doc, "en", model, core_table, controls_table, appendix_table, fit,
        lr_table, pred_table, threshold_sentence, eq, ml
    )
    doc.add_section(WD_SECTION.NEW_PAGE)
    doc.add_heading("Version A: Chinese Report", 1)
    add_topic3_language(
        doc, "zh", model, core_table, controls_table, appendix_table, fit,
        lr_table, pred_table, threshold_cn, eq, ml
    )
    while doc.paragraphs and not doc.paragraphs[-1].text.strip():
        paragraph = doc.paragraphs[-1]
        paragraph._element.getparent().remove(paragraph._element)
    doc.save(DOCX_OUT)


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    _, model, champion_counts = prepare_dataset()
    model.to_csv(DATASET_OUT, index=False)
    desc = model.groupby("champion_class").agg(
        N=("result", "size"),
        win_rate=("result", "mean"),
        avg_top_gold_diff15=("golddiffat15", "mean"),
        avg_non_top_gold_diff15_500=("non_top_gold_diff15_500", "mean"),
    ).reset_index()

    cont = MODEL_CONTINUOUS_FEATURES
    cats = ["side", "league", "patch_str"]
    coef, x, fit = fit_logit(model, "result", cont, cats)
    focus_vars = cont
    coef_focus = coef[coef["variable"].isin(focus_vars)].copy()
    coef_focus["p_value"] = coef_focus["p_value"].map(lambda v: "<0.001" if v < 0.001 else f"{v:.3f}")
    coef_focus = coef_focus[["variable", "coef_log_odds", "std_error", "z_stat", "p_value", "odds_ratio", "or_ci_low", "or_ci_high"]]
    coef.to_csv(COEF_OUT, index=False)
    pd.DataFrame([fit]).to_csv(FIT_OUT, index=False)

    lr_table = pd.DataFrame([
        lr_test(model, cont, cats, drop_cont=["is_carry", "carry_x_top_gold_diff15_500"], label="Carry class terms"),
        lr_test(model, cont, cats, drop_cont=["top_gold_diff15_500", "carry_x_top_gold_diff15_500"], label="Top gold advantage terms"),
        lr_test(model, cont, cats, drop_cont=["non_top_gold_diff15_500"], label="Non-top teammate gold advantage"),
        lr_test(model, cont, cats, drop_cont=["non_top_kill_diff15"], label="Non-top teammate kill advantage"),
        lr_test(model, cont, cats, drop_cat=["league"], label="League controls"),
        lr_test(model, cont, cats, drop_cat=["patch_str"], label="Patch controls"),
    ])
    lr_table.to_csv(LR_OUT, index=False)

    grid = np.arange(-2000, 3001, 250)
    pred_rows = []
    for gold in grid:
        gold500 = gold / 500
        tank_p = average_prediction(model, coef, list(x.columns), 0, gold500)
        carry_p = average_prediction(model, coef, list(x.columns), 1, gold500)
        pred_rows.append({
            "top_gold_diff15": gold,
            "tank_pred_win_prob": tank_p,
            "carry_pred_win_prob": carry_p,
            "carry_minus_tank": carry_p - tank_p,
        })
    pred_table = pd.DataFrame(pred_rows)
    pred_table.to_csv(PRED_OUT, index=False)
    over = pred_table[pred_table["carry_minus_tank"] >= 0.10]
    threshold = None if over.empty else float(over.iloc[0]["top_gold_diff15"])

    build_reports(model, coef_focus, coef, fit, lr_table, pred_table, desc, threshold)
    print("dataset", DATASET_OUT)
    print("coefficients", COEF_OUT)
    print("fit", FIT_OUT)
    print("lr", LR_OUT)
    print("predictions", PRED_OUT)
    print("markdown", MD_OUT)
    print("docx", DOCX_OUT)
    print("threshold", threshold)
    print("sample rows", len(model), "champions", model["champion"].nunique())
    print(desc.to_string(index=False))
    print(coef_focus.to_string(index=False))
    print(pred_table.head().to_string(index=False))
    print(pred_table.tail().to_string(index=False))


if __name__ == "__main__":
    main()
