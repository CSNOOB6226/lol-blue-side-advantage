from pathlib import Path
import math

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


TOPICS_DIR = Path(__file__).resolve().parents[2]
DATA = TOPICS_DIR / "数据/原始数据/2026年非中国赛区比赛数据.csv"
OUT = TOPICS_DIR / "报告/主题一_弱势上单策略/主题一_弱势上单策略_中英文报告.docx"
ML_DATA_DIR = TOPICS_DIR / "数据/主题一_弱势上单策略"
ML_FIG_DIR = TOPICS_DIR / "报告/主题一_弱势上单策略/机器学习图表"


def load_ml_results():
    return {
        "focused_metrics": pd.read_csv(ML_DATA_DIR / "主题一_专属变量_模型表现.csv"),
        "focused_importance": pd.read_csv(ML_DATA_DIR / "主题一_专属变量_置换重要性.csv"),
        "full_metrics": pd.read_csv(ML_DATA_DIR / "主题一_完整15分钟变量_模型表现.csv"),
        "full_importance": pd.read_csv(ML_DATA_DIR / "主题一_完整15分钟变量_置换重要性.csv"),
    }


def sigmoid(z):
    z = np.clip(z, -35, 35)
    return 1 / (1 + np.exp(-z))


def norm_sf_abs(z):
    return math.erfc(abs(z) / math.sqrt(2))


def chi2_sf(x, df):
    if x <= 0:
        return 1.0
    if df == 1:
        return math.erfc(math.sqrt(x / 2))
    if df % 2 == 0:
        half = x / 2
        total = 0.0
        term = 1.0
        for j in range(df // 2):
            if j > 0:
                term *= half / j
            total += term
        return min(1.0, max(0.0, math.exp(-half) * total))
    # Wilson-Hilferty normal approximation for odd or larger df groups.
    z = ((x / df) ** (1 / 3) - (1 - 2 / (9 * df))) / math.sqrt(2 / (9 * df))
    return 0.5 * math.erfc(z / math.sqrt(2))


def fit_logit(data, ycol, cont_cols, cat_cols=None, max_iter=100, ridge=1e-6):
    cat_cols = cat_cols or []
    parts = [pd.Series(1.0, index=data.index, name="Intercept")]
    for col in cont_cols:
        parts.append(data[col].astype(float).rename(col))
    for col in cat_cols:
        parts.append(pd.get_dummies(data[col].astype(str), prefix=col, drop_first=True, dtype=float))
    x = pd.concat(parts, axis=1)
    y = data[ycol].astype(float).to_numpy()
    xn = x.to_numpy(float)
    beta = np.zeros(xn.shape[1])

    for _ in range(max_iter):
        pred = sigmoid(xn @ beta)
        w = np.clip(pred * (1 - pred), 1e-6, None)
        z = xn @ beta + (y - pred) / w
        xtw = xn.T * w
        h = xtw @ xn + ridge * np.eye(xn.shape[1])
        nb = np.linalg.solve(h, xtw @ z)
        if np.max(np.abs(nb - beta)) < 1e-7:
            beta = nb
            break
        beta = nb

    pred = sigmoid(xn @ beta)
    w = np.clip(pred * (1 - pred), 1e-6, None)
    h = (xn.T * w) @ xn + ridge * np.eye(xn.shape[1])
    cov = np.linalg.inv(h)
    se = np.sqrt(np.diag(cov))
    zstat = beta / se
    pvals = np.array([norm_sf_abs(z) for z in zstat])
    ll = float(np.sum(y * np.log(np.clip(pred, 1e-12, 1)) + (1 - y) * np.log(np.clip(1 - pred, 1e-12, 1))))
    ybar = np.clip(y.mean(), 1e-12, 1 - 1e-12)
    ll_null = float(np.sum(y * np.log(ybar) + (1 - y) * np.log(1 - ybar)))
    res = pd.DataFrame(
        {
            "term": x.columns,
            "coef": beta,
            "se": se,
            "z": zstat,
            "p": pvals,
            "or": np.exp(beta),
            "or_ci_low": np.exp(beta - 1.96 * se),
            "or_ci_high": np.exp(beta + 1.96 * se),
        }
    )
    metrics = {
        "n": len(y),
        "df_model": x.shape[1] - 1,
        "log_likelihood": ll,
        "null_log_likelihood": ll_null,
        "mcfadden_pseudo_r2": 1 - ll / ll_null,
    }
    return res, metrics


def lr_row(data, ycol, full_cont, full_cat, drop_cont=(), drop_cat=(), label=""):
    _, full = fit_logit(data, ycol, full_cont, full_cat)
    red_cont = [c for c in full_cont if c not in set(drop_cont)]
    red_cat = [c for c in full_cat if c not in set(drop_cat)]
    _, reduced = fit_logit(data, ycol, red_cont, red_cat)
    lr = 2 * (full["log_likelihood"] - reduced["log_likelihood"])
    df = full["df_model"] - reduced["df_model"]
    return {
        "Model": label,
        "Dropped variable/group": ", ".join(list(drop_cont) + list(drop_cat)),
        "LR Chi-square": lr,
        "df": df,
        "p-value": chi2_sf(lr, df),
    }


def fmt_p(p):
    if p < 0.001:
        return "<0.001"
    return f"{p:.3f}"


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_text(cell, text, bold=False):
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(str(text))
    run.bold = bold
    run.font.size = Pt(8.5)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc, df, widths=None):
    table = doc.add_table(rows=1, cols=len(df.columns))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for i, col in enumerate(df.columns):
        set_cell_text(table.rows[0].cells[i], col, bold=True)
        set_cell_shading(table.rows[0].cells[i], "D9EAF7")
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for i, value in enumerate(row):
            if isinstance(value, float):
                if "p-value" in df.columns[i] or df.columns[i] == "p":
                    text = fmt_p(value)
                else:
                    text = f"{value:.3f}"
            else:
                text = str(value)
            set_cell_text(cells[i], text)
    if widths:
        for row in table.rows:
            for idx, width in enumerate(widths):
                row.cells[idx].width = Inches(width)
    for row in table.rows:
        tr_pr = row._tr.get_or_add_trPr()
        cant_split = OxmlElement("w:cantSplit")
        tr_pr.append(cant_split)
    doc.add_paragraph()


def add_heading(doc, text, level=1):
    doc.add_heading(text, level=level)


def add_formula(doc, formula):
    p = doc.add_paragraph()
    p.style = doc.styles["Intense Quote"]
    run = p.add_run(formula)
    run.font.name = "Courier New"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Courier New")
    run.font.size = Pt(9)


def build_analysis():
    df = pd.read_csv(DATA, low_memory=False)
    players = df[df["position"].isin(["top", "jng", "mid", "bot", "sup"])].copy()
    keys = ["gameid", "side"]
    team_gold15 = players.groupby(keys, dropna=False)["goldat15"].sum(min_count=5).rename("team_goldat15_calc")
    top = players[players["position"] == "top"].merge(team_gold15, on=keys, how="left")
    top["top_gold_share15"] = top["goldat15"] / top["team_goldat15_calc"]
    top["win"] = top["result"].astype(float)
    model = top.dropna(subset=["win", "top_gold_share15", "golddiffat15", "side", "patch", "league", "gamelength"]).copy()
    model = model[np.isfinite(model["top_gold_share15"]) & (model["top_gold_share15"] > 0)]
    q25 = model["top_gold_share15"].quantile(0.25)
    q50 = model["top_gold_share15"].quantile(0.50)
    q75 = model["top_gold_share15"].quantile(0.75)
    model["weak_side_q1"] = (model["top_gold_share15"] <= q25).astype(int)
    model["stable_weak_side"] = ((model["weak_side_q1"] == 1) & (model["golddiffat15"] >= -500)).astype(int)
    model["game_minutes"] = model["gamelength"] / 60
    model["top_gold_share15_pp"] = model["top_gold_share15"] * 100
    model["golddiffat15_500"] = model["golddiffat15"] / 500
    model["game_length_5min"] = model["game_minutes"] / 5
    model["patch_str"] = model["patch"].astype(str)

    summaries = {}
    summaries["quartiles"] = (
        model.assign(TopGoldShareQuartile=pd.qcut(model["top_gold_share15"], 4, labels=["Q1 lowest", "Q2", "Q3", "Q4 highest"]))
        .groupby("TopGoldShareQuartile", observed=True)
        .agg(N=("win", "size"), WinRate=("win", "mean"), AvgTopShare=("top_gold_share15", "mean"), AvgTopGoldDiff15=("golddiffat15", "mean"))
        .reset_index()
    )
    summaries["stable"] = model.groupby("stable_weak_side").agg(N=("win", "size"), WinRate=("win", "mean"), AvgTopShare=("top_gold_share15", "mean"), AvgTopGoldDiff15=("golddiffat15", "mean")).reset_index()

    specs = {
        "M1 Continuous Top Gold Share": (["top_gold_share15_pp", "golddiffat15_500", "game_length_5min"], ["side", "league", "patch_str"]),
        "M2 Weak-Side Indicator": (["weak_side_q1", "golddiffat15_500", "game_length_5min"], ["side", "league", "patch_str"]),
        "M3 Stable Weak-Side Top": (["stable_weak_side", "game_length_5min"], ["side", "league", "patch_str"]),
    }
    results = []
    fits = []
    for name, (cont, cat) in specs.items():
        res, met = fit_logit(model, "win", cont, cat)
        focal = [c for c in cont if c != "game_length_5min"] + ["game_length_5min"]
        for term in focal:
            row = res[res["term"] == term].iloc[0]
            results.append(
                {
                    "Model": name,
                    "Variable": term,
                    "Coef": row["coef"],
                    "Odds Ratio": row["or"],
                    "95% CI Low": row["or_ci_low"],
                    "95% CI High": row["or_ci_high"],
                    "p": row["p"],
                }
            )
        fits.append(
            {
                "Model": name,
                "N": met["n"],
                "Log Likelihood": met["log_likelihood"],
                "Null LL": met["null_log_likelihood"],
                "McFadden R2": met["mcfadden_pseudo_r2"],
            }
        )

    lr_rows = []
    lr_rows.append(lr_row(model, "win", *specs["M1 Continuous Top Gold Share"], drop_cont=["top_gold_share15_pp"], label="M1"))
    lr_rows.append(lr_row(model, "win", *specs["M1 Continuous Top Gold Share"], drop_cont=["golddiffat15_500"], label="M1"))
    lr_rows.append(lr_row(model, "win", *specs["M1 Continuous Top Gold Share"], drop_cat=["side"], label="M1"))
    lr_rows.append(lr_row(model, "win", *specs["M1 Continuous Top Gold Share"], drop_cat=["league"], label="M1"))
    lr_rows.append(lr_row(model, "win", *specs["M1 Continuous Top Gold Share"], drop_cat=["patch_str"], label="M1"))
    lr_rows.append(lr_row(model, "win", *specs["M2 Weak-Side Indicator"], drop_cont=["weak_side_q1"], label="M2"))
    lr_rows.append(lr_row(model, "win", *specs["M2 Weak-Side Indicator"], drop_cont=["golddiffat15_500"], label="M2"))
    lr_rows.append(lr_row(model, "win", *specs["M3 Stable Weak-Side Top"], drop_cont=["stable_weak_side"], label="M3"))

    return {
        "model": model,
        "q25": q25,
        "q50": q50,
        "q75": q75,
        "summaries": summaries,
        "coef_table": pd.DataFrame(results),
        "fit_table": pd.DataFrame(fits),
        "lr_table": pd.DataFrame(lr_rows),
    }


def build_docx(a):
    ml = load_ml_results()
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.75)
    sec.bottom_margin = Inches(0.75)
    sec.left_margin = Inches(0.75)
    sec.right_margin = Inches(0.75)

    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    styles["Normal"].font.size = Pt(10)
    for style_name in ["Heading 1", "Heading 2", "Heading 3"]:
        styles[style_name].font.name = "Aptos Display"
        styles[style_name]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        styles[style_name].font.color.rgb = RGBColor(31, 78, 121)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Topic 1 Research Report: Weak-Side Top Strategy")
    run.bold = True
    run.font.size = Pt(20)
    run.font.color.rgb = RGBColor(31, 78, 121)
    doc.add_paragraph("English and Chinese bilingual report based on the 2026 Oracle's Elixir professional League of Legends dataset, excluding LPL and LPL-related games.").alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_heading(doc, "English Report", 1)
    add_heading(doc, "1. Research Question", 2)
    doc.add_paragraph("This study asks whether early-game resource allocation to top lane is associated with team win probability. A weak-side top strategy is defined as giving the top laner a relatively low share of team gold at 15 minutes.")
    doc.add_paragraph("The main hypothesis is that weak-side top is beneficial only when the top laner stays stable and does not fall far behind the opposing top laner.")

    add_heading(doc, "2. Data and Sample", 2)
    doc.add_paragraph("The original Oracle's Elixir dataset contained 65,448 rows and 5,454 games. I removed all LPL games and games involving teams observed in LPL. The filtered dataset contains 60,000 rows and 5,000 games. The analytic sample contains 10,000 top-lane team-game observations because each game has two top laners.")

    add_heading(doc, "3. Variables", 2)
    variable_rows = pd.DataFrame(
        [
            ["result", "Response variable", "1 if the team won, 0 if the team lost."],
            ["goldat15", "Input variable", "Top laner's gold at 15 minutes."],
            ["team_goldat15_calc", "Derived variable", "Total team gold at 15 minutes, summed across top, jungle, mid, bot, and support."],
            ["top_gold_share15", "Main explanatory variable", "Top gold at 15 divided by team gold at 15. Lower values mean lower top-lane resource share."],
            ["top_gold_share15_pp", "Scaled explanatory variable", "top_gold_share15 multiplied by 100, interpreted as percentage points."],
            ["weak_side_q1", "Indicator variable", f"1 if top_gold_share15 is in the bottom quartile; cutoff <= {a['q25']:.3f}."],
            ["stable_weak_side", "Indicator variable", "1 if weak_side_q1 = 1 and golddiffat15 >= -500."],
            ["golddiffat15_500", "Control variable", "Top lane gold difference at 15 divided by 500."],
            ["game_length_5min", "Control variable", "Game length measured in five-minute units."],
            ["side, league, patch_str", "Controls", "Controls for side selection, league environment, and game patch."],
        ],
        columns=["Variable", "Role", "Meaning"],
    )
    add_table(doc, variable_rows, [1.35, 1.5, 4.8])

    add_heading(doc, "4. Regression Models", 2)
    doc.add_paragraph("Because the dependent variable is win/loss, logistic regression is more appropriate than ordinary linear regression.")
    add_formula(doc, "General: logit(P(Win_i = 1)) = ln(P_i / (1 - P_i))")
    add_formula(doc, "M1: logit(P(Win_i=1)) = β0 + β1(top_gold_share15_pp_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i")
    add_formula(doc, "M2: logit(P(Win_i=1)) = β0 + β1(weak_side_q1_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i")
    add_formula(doc, "M3: logit(P(Win_i=1)) = β0 + β1(stable_weak_side_i) + β2(game_length_5min_i) + β3(side_i) + β4(league_i) + β5(patch_i) + ε_i")

    add_heading(doc, "5. Descriptive Results", 2)
    doc.add_paragraph("Top gold-share quartiles show that lower top share does not automatically imply lower win rate. The lowest top-share quartile has a win rate of about 54.6%, while the stable weak-side group has a win rate of about 77.8%.")
    add_table(doc, a["summaries"]["quartiles"], [1.55, 0.7, 0.9, 1.0, 1.25])
    add_table(doc, a["summaries"]["stable"], [1.3, 0.8, 0.9, 1.0, 1.3])

    add_heading(doc, "6. Regression Results", 2)
    doc.add_paragraph("The table reports log-odds coefficients, odds ratios, 95% confidence intervals for odds ratios, and p-values. Odds ratios above 1 indicate higher odds of winning; odds ratios below 1 indicate lower odds of winning.")
    add_table(doc, a["coef_table"], [1.45, 1.35, 0.65, 0.75, 0.75, 0.8, 0.55])

    add_heading(doc, "7. Model Fit and ANOVA-Style Tests", 2)
    doc.add_paragraph("Logistic regression does not have the same R-squared as linear regression. Therefore, McFadden pseudo R-squared is reported. The ANOVA-style table below uses likelihood-ratio chi-square tests, which compare the full model against a reduced model with one variable or group removed.")
    add_table(doc, a["fit_table"], [1.8, 0.7, 1.1, 1.1, 1.0])
    add_table(doc, a["lr_table"], [0.7, 1.8, 1.0, 0.45, 0.65])

    add_heading(doc, "8. Interpretation of Statistical Indicators", 2)
    doc.add_paragraph("p-value: The p-value measures how surprising the observed result would be if the true effect were zero. A small p-value, such as p < 0.001, means the evidence against the no-effect hypothesis is strong.")
    doc.add_paragraph("95% confidence interval: The confidence interval gives a plausible range for the odds ratio. If the interval is entirely above 1, the variable is associated with higher win odds. If it is entirely below 1, the variable is associated with lower win odds.")
    doc.add_paragraph("McFadden pseudo R-squared: This is a model-fit statistic for logistic regression. Model 1 has the highest pseudo R-squared, meaning it explains the win/loss log-likelihood better than the simpler weak-side indicator models.")
    doc.add_paragraph("Likelihood-ratio / ANOVA-style table: This table shows whether removing a variable or group makes the model significantly worse. A small p-value means that variable or group contributes meaningfully to the model.")

    add_heading(doc, "9. Preliminary Conclusion", 2)
    doc.add_paragraph("The preliminary conclusion is that weak-side top can be valuable, but only under a specific condition: the top laner must stay stable. Low resource share alone is not the full story. The strongest finding is that stable weak-side top, defined as low top gold share and not more than 500 gold behind at 15 minutes, is strongly associated with higher win odds.")
    doc.add_paragraph("In simple terms: weak-side top works when the top laner receives fewer resources but does not collapse.")

    add_heading(doc, "10. Machine-Learning Robustness and Variable Importance", 2)
    doc.add_paragraph("The logistic regressions remain the main inferential models. As a predictive robustness check, Logistic Regression, Random Forest, and XGBoost were evaluated with five-fold cross-validation grouped by gameid. This prevents the two opposing rows from the same match from entering different folds. Only information available by 15 minutes was used; final game length and end-of-game totals were excluded.")
    add_table(doc, ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    doc.add_paragraph("The focused model shows that team_golddiff15 is by far the most important predictor. Stable weak-side, the weak-side quartile indicator, and top gold share contribute almost no additional held-out AUC after total team state is included. This is predictive evidence, not a causal estimate, and it does not replace the regression p-values.")
    add_table(doc, ml["focused_importance"].head(9))
    if (ML_FIG_DIR / "主题一_专属变量_置换重要性.png").exists():
        doc.add_picture(str(ML_FIG_DIR / "主题一_专属变量_置换重要性.png"), width=Inches(6.4))
    add_heading(doc, "Appendix B. Full 15-Minute Feature Model", 2)
    doc.add_paragraph("The full model adds all five roles' 10/15-minute gold differences, 15-minute experience differences, top CS difference, and team gold difference. Team gold remains dominant; role-level experience and gold differences provide the next most useful signals, while top-lane variables remain secondary.")
    add_table(doc, ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    add_table(doc, ml["full_importance"].head(10))

    doc.add_section(WD_SECTION.NEW_PAGE)
    add_heading(doc, "中文报告", 1)
    add_heading(doc, "1. 研究问题", 2)
    doc.add_paragraph("本研究关注职业英雄联盟中的弱势路上单策略：队伍在前期给上路较少资源，是否会提高或降低队伍胜率。这里的“资源投入”主要用15分钟上单经济占全队经济比例来衡量。")
    doc.add_paragraph("核心假设是：弱势上单策略只有在上单保持稳定、不被对面上单打崩的情况下，才可能对胜率有正面作用。")

    add_heading(doc, "2. 数据与样本", 2)
    doc.add_paragraph("原始 Oracle's Elixir 数据包含 65,448 行、5,454 场比赛。分析前删除了所有 LPL 比赛，以及所有涉及 LPL 队伍的相关比赛。过滤后数据包含 60,000 行、5,000 场比赛。因为每场比赛有两个上单，所以 Topic 1 的分析样本是 10,000 条上单-队伍比赛记录。")

    add_heading(doc, "3. 变量解释", 2)
    add_table(doc, pd.DataFrame(
        [
            ["result", "因变量", "队伍是否获胜；1 = 赢，0 = 输。"],
            ["goldat15", "基础变量", "上单15分钟经济。"],
            ["team_goldat15_calc", "派生变量", "队伍15分钟总经济，由五个位置经济相加得到。"],
            ["top_gold_share15", "核心解释变量", "上单15分钟经济 / 队伍15分钟总经济；越低表示上路资源占比越少。"],
            ["top_gold_share15_pp", "缩放变量", "top_gold_share15 × 100，用百分比点解释。"],
            ["weak_side_q1", "弱势路变量", f"如果上单经济占比处于最低25%，则为1；阈值为 <= {a['q25']:.3f}。"],
            ["stable_weak_side", "稳定弱势路变量", "如果 weak_side_q1 = 1 且 golddiffat15 >= -500，则为1。"],
            ["golddiffat15_500", "控制变量", "上单15分钟相对敌方上单经济差 / 500。"],
            ["game_length_5min", "控制变量", "比赛时长，以5分钟为单位。"],
            ["side, league, patch_str", "控制变量", "控制蓝红方、赛区和版本差异。"],
        ],
        columns=["变量", "类型", "含义"],
    ), [1.35, 1.2, 5.1])

    add_heading(doc, "4. 回归模型", 2)
    doc.add_paragraph("由于因变量是赢/输二分类变量，因此使用逻辑回归，而不是普通线性回归。")
    add_formula(doc, "通用公式：logit(P(Win_i = 1)) = ln(P_i / (1 - P_i))")
    add_formula(doc, "模型1：logit(P(Win_i=1)) = β0 + β1(top_gold_share15_pp_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i")
    add_formula(doc, "模型2：logit(P(Win_i=1)) = β0 + β1(weak_side_q1_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i")
    add_formula(doc, "模型3：logit(P(Win_i=1)) = β0 + β1(stable_weak_side_i) + β2(game_length_5min_i) + β3(side_i) + β4(league_i) + β5(patch_i) + ε_i")

    add_heading(doc, "5. 主要结果与解释", 2)
    doc.add_paragraph("回归结果显示，weak_side_q1 和 stable_weak_side 的 odds ratio 都显著大于1，说明在控制部分因素后，弱势路上单，尤其是稳定弱势路上单，与更高的获胜 odds 相关。")
    doc.add_paragraph("其中 stable_weak_side 的 odds ratio 约为 3.93，95%置信区间约为 [3.32, 4.66]，p < 0.001。这说明低资源但不崩的上单，与更高胜率之间有很强的统计关联。")

    add_heading(doc, "6. 指标含义", 2)
    doc.add_paragraph("p-value：表示如果真实效果为0，观察到当前结果的意外程度。p值越小，说明结果越不太可能只是随机噪声。")
    doc.add_paragraph("95%置信区间：表示 odds ratio 的合理范围。如果整个区间都大于1，说明该变量与更高获胜 odds 显著相关。")
    doc.add_paragraph("McFadden pseudo R-squared：逻辑回归中类似R平方的模型拟合指标。它不是普通线性回归的R平方，但可以比较模型相对空模型的解释能力。")
    doc.add_paragraph("Likelihood-ratio / ANOVA-style table：通过比较完整模型和删去某个变量后的模型，判断该变量是否显著提升模型解释能力。")

    add_heading(doc, "7. 初步结论", 2)
    doc.add_paragraph("初步结论是：弱势路上单策略并不是简单地“不给上路资源就能赢”。真正有价值的是“低资源 + 稳定”。如果上单少吃资源，但没有在15分钟前严重落后，那么队伍可以把资源投入中野或下路，同时不牺牲上路稳定性。")
    doc.add_paragraph("一句话总结：弱势上单策略有效的关键，是上单在低资源条件下保持稳定。")

    add_heading(doc, "8. 机器学习稳健性与变量重要性", 2)
    doc.add_paragraph("原有逻辑回归继续作为主要统计推断模型。补充分析使用按 gameid 分组的五折交叉验证，对比 Logistic Regression、Random Forest 与 XGBoost，确保同一场比赛的蓝红双方不会进入不同折。预测变量严格限制在15分钟及以前，不使用最终局长或赛后总量。")
    add_table(doc, ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    doc.add_paragraph("主题专属模型中，team_golddiff15 的预测重要性远高于其他变量；在已知全队状态后，stable_weak_side、weak_side_q1 和 top_gs15 几乎不再增加测试集 AUC。这不否定逻辑回归中的相关性，而是说明它们相对于全队经济并不是强独立预测器。变量重要性不等于因果效应，也没有传统 p-value。")
    add_table(doc, ml["focused_importance"].head(9))
    if (ML_FIG_DIR / "主题一_专属变量_模型AUC.png").exists():
        doc.add_picture(str(ML_FIG_DIR / "主题一_专属变量_模型AUC.png"), width=Inches(6.4))
    add_heading(doc, "附录 B：完整15分钟变量模型", 2)
    doc.add_paragraph("完整模型加入五个位置的10/15分钟经济差、15分钟经验差、上路补刀差和团队经济差。全队15分钟经济差仍然排第一，其后主要是各位置经验差和经济差，上路变量整体处于次要位置。")
    add_table(doc, ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    add_table(doc, ml["full_importance"].head(8))

    doc.save(OUT)


def add_topic1_language(doc, a, ml, language):
    zh = language == "zh"
    headings = {
        "research": "1. 研究问题" if zh else "1. Research Question",
        "data": "2. 数据与样本" if zh else "2. Data and Sample",
        "variables": "3. 变量解释" if zh else "3. Variables",
        "models": "4. 回归模型" if zh else "4. Regression Models",
        "descriptive": "5. 描述性结果" if zh else "5. Descriptive Results",
        "regression": "6. 回归结果" if zh else "6. Regression Results",
        "fit": "7. 模型拟合与似然比检验" if zh else "7. Model Fit and ANOVA-Style Tests",
        "indicators": "8. 统计指标解释" if zh else "8. Interpretation of Statistical Indicators",
        "conclusion": "9. 初步结论" if zh else "9. Preliminary Conclusion",
        "ml": "10. 机器学习稳健性与变量重要性" if zh else "10. Machine-Learning Robustness and Variable Importance",
        "appendix": "附录 B：完整15分钟变量模型" if zh else "Appendix B. Full 15-Minute Feature Model",
    }

    add_heading(doc, headings["research"], 2)
    doc.add_paragraph(
        "本研究检验职业英雄联盟中，上路前期资源分配是否与队伍胜率相关。弱势上单定义为上单在15分钟时获得较低的全队经济占比。"
        if zh else
        "This study tests whether early-game resource allocation to top lane is associated with team win probability. Weak-side top is defined as a relatively low share of team gold at 15 minutes."
    )
    doc.add_paragraph(
        "核心假设是：弱势上单只有在上单保持稳定、没有相对敌方上单严重落后时才可能有效。"
        if zh else
        "The central hypothesis is that weak-side top is beneficial only when the top laner remains stable and does not fall far behind the opposing top laner."
    )

    add_heading(doc, headings["data"], 2)
    doc.add_paragraph(
        "原始 Oracle's Elixir 数据包含65,448行和5,454场比赛。删除所有LPL比赛及涉及LPL队伍的相关比赛后，样本为5,000场比赛、10,000条上单-队伍比赛记录。"
        if zh else
        "The original Oracle's Elixir dataset contained 65,448 rows and 5,454 games. After removing all LPL games and related games involving LPL teams, the sample contains 5,000 games and 10,000 top-lane team-game observations."
    )

    add_heading(doc, headings["variables"], 2)
    if zh:
        variable_rows = pd.DataFrame([
            ["result", "因变量", "1 = 赢，0 = 输。"],
            ["goldat15", "基础变量", "上单15分钟经济。"],
            ["team_goldat15_calc", "派生变量", "五个位置经济相加得到的队伍15分钟总经济。"],
            ["top_gold_share15", "核心解释变量", "上单15分钟经济除以队伍15分钟总经济。"],
            ["top_gold_share15_pp", "缩放变量", "上单经济占比乘以100，以百分点解释。"],
            ["weak_side_q1", "指标变量", f"上单经济占比处于最低四分位时为1；阈值 <= {a['q25']:.3f}。"],
            ["stable_weak_side", "指标变量", "weak_side_q1 = 1 且15分钟上路经济差不低于-500时为1。"],
            ["golddiffat15_500", "控制变量", "15分钟上路经济差除以500。"],
            ["game_length_5min", "控制变量", "比赛时长，以5分钟为单位。"],
            ["side, league, patch_str", "控制变量", "控制蓝红方、赛区与版本。"],
        ], columns=["变量", "类型", "含义"])
    else:
        variable_rows = pd.DataFrame([
            ["result", "Response variable", "1 = win, 0 = loss."],
            ["goldat15", "Input variable", "Top-lane gold at 15 minutes."],
            ["team_goldat15_calc", "Derived variable", "Team gold at 15, summed across all five roles."],
            ["top_gold_share15", "Main explanatory variable", "Top gold at 15 divided by team gold at 15."],
            ["top_gold_share15_pp", "Scaled variable", "Top gold share multiplied by 100, interpreted in percentage points."],
            ["weak_side_q1", "Indicator variable", f"1 when top gold share is in the bottom quartile; cutoff <= {a['q25']:.3f}."],
            ["stable_weak_side", "Indicator variable", "1 when weak_side_q1 = 1 and top gold difference at 15 is at least -500."],
            ["golddiffat15_500", "Control variable", "Top gold difference at 15 divided by 500."],
            ["game_length_5min", "Control variable", "Game duration measured in five-minute units."],
            ["side, league, patch_str", "Controls", "Controls for side, league, and patch."],
        ], columns=["Variable", "Role", "Meaning"])
    add_table(doc, variable_rows, [1.35, 1.5, 4.8])

    add_heading(doc, headings["models"], 2)
    doc.add_paragraph(
        "因变量为赢/输二分类，因此使用逻辑回归估计获胜概率和优势比。"
        if zh else
        "Because the outcome is binary, logistic regression is used to estimate win probability and odds ratios."
    )
    add_formula(doc, "General: logit(P(Win_i = 1)) = ln(P_i / (1 - P_i))")
    add_formula(doc, "M1: logit(P(Win_i=1)) = β0 + β1(top_gold_share15_pp_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i")
    add_formula(doc, "M2: logit(P(Win_i=1)) = β0 + β1(weak_side_q1_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i")
    add_formula(doc, "M3: logit(P(Win_i=1)) = β0 + β1(stable_weak_side_i) + β2(game_length_5min_i) + β3(side_i) + β4(league_i) + β5(patch_i) + ε_i")

    add_heading(doc, headings["descriptive"], 2)
    doc.add_paragraph(
        "最低上单经济占比四分位的胜率约为54.6%，稳定弱势上单组的胜率约为77.8%。以下两张表在中英文版本中使用完全相同的数据。"
        if zh else
        "The lowest top-share quartile has a win rate of about 54.6%, while the stable weak-side group has a win rate of about 77.8%. The same two data tables are used in both language versions."
    )
    add_table(doc, a["summaries"]["quartiles"], [1.55, 0.7, 0.9, 1.0, 1.25])
    add_table(doc, a["summaries"]["stable"], [1.3, 0.8, 0.9, 1.0, 1.3])

    add_heading(doc, headings["regression"], 2)
    doc.add_paragraph(
        "表格报告log-odds系数、优势比、优势比的95%置信区间与p-value。"
        if zh else
        "The table reports log-odds coefficients, odds ratios, 95% confidence intervals for odds ratios, and p-values."
    )
    add_table(doc, a["coef_table"], [1.45, 1.35, 0.65, 0.75, 0.75, 0.8, 0.55])

    add_heading(doc, headings["fit"], 2)
    doc.add_paragraph(
        "逻辑回归报告McFadden pseudo R-squared，并通过似然比卡方检验比较完整模型与删减模型。"
        if zh else
        "McFadden pseudo R-squared is reported for logistic model fit, and likelihood-ratio chi-square tests compare full and reduced models."
    )
    add_table(doc, a["fit_table"], [1.8, 0.7, 1.1, 1.1, 1.0])
    add_table(doc, a["lr_table"], [0.7, 1.8, 1.0, 0.45, 0.65])

    add_heading(doc, headings["indicators"], 2)
    indicator_texts = [
        ("p-value衡量在真实效果为零时观察到当前结果的意外程度；p越小，反对无效假设的证据越强。"
         if zh else "The p-value measures how surprising the result would be if the true effect were zero; smaller values provide stronger evidence against the null."),
        ("95%置信区间给出优势比的合理范围；区间完全高于1表示更高获胜odds，完全低于1表示更低获胜odds。"
         if zh else "A 95% confidence interval gives a plausible range for the odds ratio; intervals entirely above or below 1 indicate higher or lower win odds."),
        ("McFadden pseudo R-squared衡量逻辑回归相对空模型的拟合改善。"
         if zh else "McFadden pseudo R-squared measures improvement in logistic-model fit relative to the null model."),
        ("似然比检验判断删去变量或变量组后模型是否显著变差。"
         if zh else "Likelihood-ratio tests evaluate whether removing a variable or variable group significantly worsens model fit."),
    ]
    for text in indicator_texts:
        doc.add_paragraph(text)

    add_heading(doc, headings["conclusion"], 2)
    doc.add_paragraph(
        "初步结论是弱势上单只有在上单保持稳定时才可能有价值。低资源占比本身不是完整机制。"
        if zh else
        "The preliminary conclusion is that weak-side top can be valuable only when the top laner remains stable. Low resource share alone is not the complete mechanism."
    )
    doc.add_paragraph(
        "一句话总结：上单少吃资源但不崩，弱势上单策略才成立。"
        if zh else
        "In simple terms: weak-side top works when the top laner receives fewer resources without collapsing."
    )

    add_heading(doc, headings["ml"], 2)
    doc.add_paragraph(
        "补充分析使用按gameid分组的五折交叉验证，对比Logistic Regression、Random Forest和XGBoost；只使用15分钟及以前变量。"
        if zh else
        "The robustness analysis compares Logistic Regression, Random Forest, and XGBoost with five-fold cross-validation grouped by gameid, using only variables available by 15 minutes."
    )
    add_table(doc, ml["focused_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    doc.add_paragraph(
        "全队15分钟经济差主导预测；弱势上单指标在已知全队状态后几乎不增加测试集AUC。变量重要性不等于因果效应。"
        if zh else
        "Team gold difference at 15 dominates prediction; weak-side indicators add almost no held-out AUC once team state is known. Predictive importance is not a causal effect."
    )
    add_table(doc, ml["focused_importance"].head(9))
    for image_name in ["主题一_专属变量_置换重要性.png", "主题一_专属变量_模型AUC.png"]:
        image_path = ML_FIG_DIR / image_name
        if image_path.exists():
            doc.add_picture(str(image_path), width=Inches(6.4))

    add_heading(doc, headings["appendix"], 2)
    doc.add_paragraph(
        "完整模型加入五个位置的10/15分钟经济差、15分钟经验差、上路补刀差和团队经济差。"
        if zh else
        "The full model adds all five roles' 10/15-minute gold differences, 15-minute experience differences, top CS difference, and team gold difference."
    )
    add_table(doc, ml["full_metrics"][["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]])
    add_table(doc, ml["full_importance"].head(8))


def build_mirrored_docx(a):
    ml = load_ml_results()
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.75)
    sec.bottom_margin = Inches(0.75)
    sec.left_margin = Inches(0.75)
    sec.right_margin = Inches(0.75)
    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    styles["Normal"].font.size = Pt(10)
    for style_name in ["Heading 1", "Heading 2", "Heading 3"]:
        styles[style_name].font.name = "Aptos Display"
        styles[style_name]._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        styles[style_name].font.color.rgb = RGBColor(31, 78, 121)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Topic 1 Research Report: Weak-Side Top Strategy")
    run.bold = True
    run.font.size = Pt(20)
    run.font.color.rgb = RGBColor(31, 78, 121)
    doc.add_paragraph("English and Chinese mirrored bilingual report").alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_heading(doc, "English Report", 1)
    add_topic1_language(doc, a, ml, "en")
    doc.add_section(WD_SECTION.NEW_PAGE)
    add_heading(doc, "中文报告", 1)
    add_topic1_language(doc, a, ml, "zh")
    while doc.paragraphs and not doc.paragraphs[-1].text.strip():
        paragraph = doc.paragraphs[-1]
        paragraph._element.getparent().remove(paragraph._element)
    doc.save(OUT)


if __name__ == "__main__":
    analysis = build_analysis()
    build_mirrored_docx(analysis)
    print(OUT)
