from pathlib import Path
import math

import numpy as np
import pandas as pd


TOPICS_DIR = Path(__file__).resolve().parents[2]
SRC = TOPICS_DIR / "数据/原始数据/2026年英雄联盟职业比赛原始数据.csv"
DATA_DIR = TOPICS_DIR / "数据/原始数据"
REPORT_DIR = TOPICS_DIR / "报告/主题一_弱势上单策略"
FILTERED_CSV = DATA_DIR / "2026年非中国赛区比赛数据.csv"
REPORT = REPORT_DIR / "主题一_弱势上单策略_分析报告.md"
ML_FOCUSED_METRICS = TOPICS_DIR / "数据/主题一_弱势上单策略/主题一_专属变量_模型表现.csv"
ML_FOCUSED_IMPORTANCE = TOPICS_DIR / "数据/主题一_弱势上单策略/主题一_专属变量_置换重要性.csv"
ML_FULL_METRICS = TOPICS_DIR / "数据/主题一_弱势上单策略/主题一_完整15分钟变量_模型表现.csv"
ML_FULL_IMPORTANCE = TOPICS_DIR / "数据/主题一_弱势上单策略/主题一_完整15分钟变量_置换重要性.csv"


def sigmoid(z):
    z = np.clip(z, -35, 35)
    return 1 / (1 + np.exp(-z))


def markdown_table(df, floatfmt=".3f"):
    rows = []
    out = df.reset_index() if df.index.name else df.reset_index(drop=True)
    cols = list(out.columns)
    rows.append("| " + " | ".join(str(c) for c in cols) + " |")
    rows.append("| " + " | ".join("---" for _ in cols) + " |")
    for _, row in out.iterrows():
        vals = []
        for v in row:
            if isinstance(v, (float, np.floating)):
                vals.append(format(float(v), floatfmt))
            elif isinstance(v, (int, np.integer)):
                vals.append(str(int(v)))
            else:
                vals.append(str(v))
        rows.append("| " + " | ".join(vals) + " |")
    return "\n".join(rows)


def fit_logit(data, ycol, cont_cols, cat_cols=None, max_iter=100, ridge=1e-6):
    cat_cols = cat_cols or []
    x_parts = [pd.Series(1.0, index=data.index, name="Intercept")]
    for col in cont_cols:
        x_parts.append(data[col].astype(float).rename(col))
    for col in cat_cols:
        dummies = pd.get_dummies(data[col].astype(str), prefix=col, drop_first=True, dtype=float)
        x_parts.append(dummies)

    x = pd.concat(x_parts, axis=1)
    y = data[ycol].astype(float).to_numpy()
    xn = x.to_numpy(float)
    beta = np.zeros(xn.shape[1])

    for _ in range(max_iter):
        pred = sigmoid(xn @ beta)
        weights = np.clip(pred * (1 - pred), 1e-6, None)
        z = xn @ beta + (y - pred) / weights
        xtw = xn.T * weights
        hessian = xtw @ xn + ridge * np.eye(xn.shape[1])
        candidate = np.linalg.solve(hessian, xtw @ z)
        if np.max(np.abs(candidate - beta)) < 1e-7:
            beta = candidate
            break
        beta = candidate

    pred = sigmoid(xn @ beta)
    weights = np.clip(pred * (1 - pred), 1e-6, None)
    hessian = (xn.T * weights) @ xn + ridge * np.eye(xn.shape[1])
    cov = np.linalg.inv(hessian)
    se = np.sqrt(np.diag(cov))
    zstat = beta / se
    pvals = np.array([math.erfc(abs(z) / math.sqrt(2)) for z in zstat])
    ci_low = beta - 1.96 * se
    ci_high = beta + 1.96 * se

    result = pd.DataFrame(
        {
            "term": x.columns,
            "coef_log_odds": beta,
            "se": se,
            "z": zstat,
            "p": pvals,
            "ci_low": ci_low,
            "ci_high": ci_high,
        }
    )
    ybar = np.clip(y.mean(), 1e-12, 1 - 1e-12)
    ll_model = float(np.sum(y * np.log(np.clip(pred, 1e-12, 1)) + (1 - y) * np.log(np.clip(1 - pred, 1e-12, 1))))
    ll_null = float(np.sum(y * np.log(ybar) + (1 - y) * np.log(1 - ybar)))
    metrics = {
        "n": int(len(y)),
        "log_likelihood": ll_model,
        "null_log_likelihood": ll_null,
        "mcfadden_pseudo_r2": 1 - (ll_model / ll_null),
    }

    return result, x, metrics


def avg_pred_contrast(res, x, term, low_val, high_val):
    beta = res["coef_log_odds"].to_numpy()
    xa = x.copy()
    xb = x.copy()
    xa[term] = low_val
    xb[term] = high_val
    pa = sigmoid(xa.to_numpy(float) @ beta).mean()
    pb = sigmoid(xb.to_numpy(float) @ beta).mean()
    return pa, pb, pb - pa


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    if SRC.exists():
        df = pd.read_csv(SRC, low_memory=False)
        team_rows = df[df["position"] == "team"].copy()
        lpl_teams = set(team_rows.loc[team_rows["league"].eq("LPL"), "teamname"].dropna())
        lpl_related_games = set(df.loc[df["league"].eq("LPL"), "gameid"].dropna())
        lpl_related_games |= set(team_rows.loc[team_rows["teamname"].isin(lpl_teams), "gameid"].dropna())
        filtered = df[~df["gameid"].isin(lpl_related_games)].copy()
        filtered.to_csv(FILTERED_CSV, index=False)
        orig_rows = len(df)
        orig_games = df["gameid"].nunique()
        filtered_games = filtered["gameid"].nunique()
        removed_games = orig_games - filtered_games
        removed_rows = len(df) - len(filtered)
        outside_removed = team_rows.loc[
            (team_rows["teamname"].isin(lpl_teams)) & (team_rows["league"] != "LPL"), "gameid"
        ].nunique()
    else:
        filtered = pd.read_csv(FILTERED_CSV, low_memory=False)
        # The original source was already filtered in the earlier run; keep those audit numbers in the report.
        orig_rows = 65448
        orig_games = 5454
        removed_rows = 5448
        removed_games = 454
        outside_removed = 25

    players = filtered[filtered["position"].isin(["top", "jng", "mid", "bot", "sup"])].copy()
    keys = ["gameid", "side"]
    team_gold15 = players.groupby(keys, dropna=False)["goldat15"].sum(min_count=5).rename("team_goldat15_calc")
    team_xp15 = players.groupby(keys, dropna=False)["xpat15"].sum(min_count=5).rename("team_xpat15_calc")

    top = (
        players[players["position"] == "top"]
        .merge(team_gold15, on=keys, how="left")
        .merge(team_xp15, on=keys, how="left")
    )
    top["top_gold_share15"] = top["goldat15"] / top["team_goldat15_calc"]
    top["top_xp_share15"] = top["xpat15"] / top["team_xpat15_calc"]
    top["win"] = top["result"].astype(float)

    vars_needed = [
        "win",
        "top_gold_share15",
        "golddiffat15",
        "xpdiffat15",
        "csdiffat15",
        "goldat15",
        "team_goldat15_calc",
        "side",
        "patch",
        "league",
        "champion",
        "gamelength",
    ]
    missing_counts = top[vars_needed].isna().sum()

    model_df = top.dropna(
        subset=["win", "top_gold_share15", "golddiffat15", "side", "patch", "league", "gamelength"]
    ).copy()
    model_df = model_df[np.isfinite(model_df["top_gold_share15"]) & (model_df["top_gold_share15"] > 0)]

    q25 = model_df["top_gold_share15"].quantile(0.25)
    q50 = model_df["top_gold_share15"].quantile(0.50)
    q75 = model_df["top_gold_share15"].quantile(0.75)
    model_df["weak_side_q1"] = (model_df["top_gold_share15"] <= q25).astype(int)
    model_df["stable_weak_side"] = ((model_df["weak_side_q1"] == 1) & (model_df["golddiffat15"] >= -500)).astype(int)
    model_df["strong_side_q4"] = (model_df["top_gold_share15"] >= q75).astype(int)
    model_df["game_minutes"] = model_df["gamelength"] / 60

    summary_by_q = (
        model_df.assign(
            share_quartile=pd.qcut(
                model_df["top_gold_share15"],
                4,
                labels=["Q1 lowest top share", "Q2", "Q3", "Q4 highest top share"],
            )
        )
        .groupby("share_quartile", observed=True)
        .agg(
            n=("win", "size"),
            winrate=("win", "mean"),
            avg_top_share=("top_gold_share15", "mean"),
            avg_top_golddiff15=("golddiffat15", "mean"),
            avg_game_minutes=("game_minutes", "mean"),
        )
    )
    summary_stable = model_df.groupby("stable_weak_side").agg(
        n=("win", "size"),
        winrate=("win", "mean"),
        avg_top_share=("top_gold_share15", "mean"),
        avg_top_golddiff15=("golddiffat15", "mean"),
    )

    model_df["top_gold_share15_pp"] = model_df["top_gold_share15"] * 100
    model_df["golddiffat15_500"] = model_df["golddiffat15"] / 500
    model_df["game_length_5min"] = model_df["game_minutes"] / 5
    model_df["patch_str"] = model_df["patch"].astype(str)

    res1, x1, metrics1 = fit_logit(
        model_df,
        "win",
        ["top_gold_share15_pp", "golddiffat15_500", "game_length_5min"],
        ["side", "league", "patch_str"],
    )
    res2, x2, metrics2 = fit_logit(
        model_df,
        "win",
        ["weak_side_q1", "golddiffat15_500", "game_length_5min"],
        ["side", "league", "patch_str"],
    )
    res3, x3, metrics3 = fit_logit(
        model_df,
        "win",
        ["stable_weak_side", "game_length_5min"],
        ["side", "league", "patch_str"],
    )

    focus_terms = ["top_gold_share15_pp", "golddiffat15_500", "weak_side_q1", "stable_weak_side", "game_length_5min"]
    focus = pd.concat(
        [
            res1.assign(model="M1 continuous top share + lane gold diff"),
            res2.assign(model="M2 weak-side Q1 + lane gold diff"),
            res3.assign(model="M3 stable weak-side"),
        ]
    )
    focus = focus[focus["term"].isin(focus_terms)].copy()
    focus["odds_ratio"] = np.exp(focus["coef_log_odds"])
    focus["or_ci_low"] = np.exp(focus["ci_low"])
    focus["or_ci_high"] = np.exp(focus["ci_high"])
    focus["significance"] = np.where(focus["p"] < 0.001, "***", np.where(focus["p"] < 0.01, "**", np.where(focus["p"] < 0.05, "*", "")))

    share_contrast = avg_pred_contrast(res1, x1, "top_gold_share15_pp", q25 * 100, q75 * 100)
    weak_contrast = avg_pred_contrast(res2, x2, "weak_side_q1", 0, 1)
    stable_contrast = avg_pred_contrast(res3, x3, "stable_weak_side", 0, 1)

    show = focus[["model", "term", "coef_log_odds", "odds_ratio", "or_ci_low", "or_ci_high", "p", "significance"]].reset_index(drop=True)
    fit_show = pd.DataFrame(
        [
            {"model": "M1 continuous top share + lane gold diff", **metrics1},
            {"model": "M2 weak-side Q1 + lane gold diff", **metrics2},
            {"model": "M3 stable weak-side", **metrics3},
        ]
    )
    weak_row = focus[(focus.model.str.startswith("M2")) & (focus.term == "weak_side_q1")].iloc[0]

    if weak_row["p"] < 0.05 and weak_row["odds_ratio"] < 1:
        main_finding = (
            "Low top gold share by itself is associated with lower win odds, even after controlling for top lane gold "
            "difference. This suggests many low-resource top games are not clean strategic weak-side games; they may "
            "include games where top lane fell behind or the team lacked top-side pressure."
        )
    elif weak_row["p"] < 0.05 and weak_row["odds_ratio"] > 1:
        main_finding = (
            "Low top gold share is associated with higher win odds after controlling for top lane gold difference. "
            "This supports the idea that successful teams can win by allocating fewer resources to top when the top "
            "laner remains stable."
        )
    else:
        main_finding = (
            "Low top gold share is not statistically distinguishable from normal top allocation after controlling for "
            "top lane gold difference. The practical story is that weak-side top is not automatically good or bad; "
            "the key is whether top can stay stable while resources go elsewhere."
        )

    md = [
        "# Formal Report: Weak-Side Top Strategy in Professional League of Legends\n\n",
        "## 1. Research Question\n\n",
        "This study examines whether a weak-side top lane strategy is associated with winning in professional League of Legends. In this report, weak-side top means that the top laner receives a relatively small share of the team's total gold at 15 minutes. The central question is whether low early top-lane resource allocation hurts a team, or whether it can be valuable when the top laner remains stable.\n\n",
        "The main hypothesis is that weak-side top is beneficial only when the top laner absorbs low resources without falling far behind the opposing top laner.\n\n",
        "## 2. Data and Filtering\n\n",
        f"- Original data: {orig_rows:,} rows, {orig_games:,} games.\n",
        f"- Removed all `LPL` league games and any games involving teams observed in `LPL`. This removed {removed_rows:,} rows and {removed_games:,} games.\n",
        f"- Off-league LPL-related games removed: {outside_removed:,} games involving LPL teams outside the LPL league code.\n",
        f"- Filtered output CSV: `{FILTERED_CSV}`.\n",
        f"- Final analytic sample for Topic 1: {len(model_df):,} top-lane team-game rows across {model_df.gameid.nunique():,} games.\n\n",
        "The Oracle's Elixir data is player-level data. Each game has two teams, and each team has five player rows plus one team row. The analysis uses one observation per top laner per team-game, so 5,000 games become 10,000 top-lane observations.\n\n",
        "## 3. Variables\n\n",
        "### Response Variable\n\n",
        "- `result`: the dependent variable. It equals 1 if the team won and 0 if the team lost.\n\n",
        "### Main Explanatory Variables\n\n",
        "- `goldat15`: the top laner's gold at 15 minutes.\n",
        "- `team_goldat15_calc`: the team's total gold at 15 minutes, calculated by summing the five player roles: top, jungle, mid, bot, and support.\n",
        "- `top_gold_share15`: the top laner's share of team gold at 15 minutes. Formula: `top_gold_share15 = top goldat15 / team goldat15`. A lower value means the team allocated a smaller share of early gold to top lane.\n",
        "- `top_gold_share15_pp`: top gold share measured in percentage points. Formula: `top_gold_share15_pp = top_gold_share15 * 100`.\n",
        "- `weak_side_q1`: an indicator variable equal to 1 if `top_gold_share15` is in the bottom 25 percent of the sample, and 0 otherwise. The cutoff is `top_gold_share15 <= 0.188`.\n",
        "- `stable_weak_side`: an indicator variable equal to 1 if the top laner is weak-side and also has `golddiffat15 >= -500`. This means the top laner received low resources but was not losing lane by more than 500 gold at 15 minutes.\n\n",
        "### Control Variables\n\n",
        "- `golddiffat15`: the top laner's gold difference against the enemy top laner at 15 minutes. This controls for lane performance.\n",
        "- `golddiffat15_500`: top gold difference divided by 500. This makes the coefficient easier to interpret as the effect of a 500-gold difference.\n",
        "- `game_length_5min`: game length measured in five-minute units.\n",
        "- `side`: blue side or red side.\n",
        "- `league`: league fixed controls after removing LPL-related games.\n",
        "- `patch_str`: patch/version controls.\n\n",
        "## 4. Data Quality Notes\n\n",
        f"- Missing values among top rows before complete-case filtering: {missing_counts[missing_counts > 0].to_dict()}\n",
        "- Oracle's Elixir rows are nested: five player rows plus one team row per side, two sides per game. Treating every player row as independent would be wrong; Topic 1 uses one top-lane row per team-game.\n",
        "- `top_gold_share15` is measured after 15 minutes, so it is not pure pre-game strategy. It mixes planned weak-side allocation, lane outcome, kills, CS, and map movement. That is why `golddiffat15` is controlled.\n\n",
        "## 5. Descriptive Results\n\n",
        "Top gold-share quartiles:\n\n",
        markdown_table(summary_by_q),
        "\n\nStable weak-side definition: bottom quartile of top gold share, but top gold difference at 15 is not worse than -500 gold.\n\n",
        markdown_table(summary_stable),
        "\n\n## 6. Regression Method\n\n",
        "Because the response variable is binary, the report uses logistic regression. The model estimates the log-odds that a team wins the game.\n\n",
        "General formula:\n\n",
        "```text\nlogit(P(Win_i = 1)) = ln(P(Win_i = 1) / (1 - P(Win_i = 1)))\n```\n\n",
        "A positive coefficient means the variable is associated with higher win odds. A negative coefficient means the variable is associated with lower win odds. Odds ratios are reported because they are easier to interpret: an odds ratio above 1 means higher odds of winning, while an odds ratio below 1 means lower odds of winning.\n\n",
        "### Model 1: Continuous Top Gold Share\n\n",
        "```text\nlogit(P(Win_i = 1)) = β0\n+ β1(top_gold_share15_pp_i)\n+ β2(golddiffat15_500_i)\n+ β3(game_length_5min_i)\n+ β4(side_i)\n+ β5(league_i)\n+ β6(patch_i)\n+ ε_i\n```\n\n",
        "This model tests whether higher or lower top gold share is associated with winning after controlling for the top laner's direct gold difference against the opposing top laner.\n\n",
        "### Model 2: Weak-Side Indicator\n\n",
        "```text\nlogit(P(Win_i = 1)) = β0\n+ β1(weak_side_q1_i)\n+ β2(golddiffat15_500_i)\n+ β3(game_length_5min_i)\n+ β4(side_i)\n+ β5(league_i)\n+ β6(patch_i)\n+ ε_i\n```\n\n",
        "This model tests whether being in the lowest quartile of top gold share is associated with winning, again controlling for whether the top laner was winning or losing lane economically.\n\n",
        "### Model 3: Stable Weak-Side Top\n\n",
        "```text\nlogit(P(Win_i = 1)) = β0\n+ β1(stable_weak_side_i)\n+ β2(game_length_5min_i)\n+ β3(side_i)\n+ β4(league_i)\n+ β5(patch_i)\n+ ε_i\n```\n\n",
        "This model tests a stricter concept: low top resource share plus lane stability.\n\n",
        "## 7. Regression Results\n\n",
        "Main coefficient results:\n\n",
        markdown_table(show, floatfmt=".4f"),
        "\n\nModel fit statistics:\n\n",
        markdown_table(fit_show, floatfmt=".4f"),
        "\n\nMcFadden pseudo R-squared is reported instead of ordinary R-squared because logistic regression does not use the same least-squares framework as linear regression. It compares the fitted model to a null model with no predictors. Higher values mean the model explains more of the win/loss log-likelihood relative to the null model.\n\n",
        "## 8. Practical Interpretation\n\n",
        f"- The bottom quartile threshold for top gold share at 15 is {q25:.3f}; the median is {q50:.3f}; the top quartile starts at {q75:.3f}.\n",
        f"- Moving from Q1-level top share ({q25:.3f}) to Q4-level top share ({q75:.3f}), while keeping the same observed controls, changes average predicted win probability from {share_contrast[0]:.3f} to {share_contrast[1]:.3f} ({share_contrast[2]:+.3f}).\n",
        f"- Being in the weak-side Q1 group changes average predicted win probability from {weak_contrast[0]:.3f} to {weak_contrast[1]:.3f} ({weak_contrast[2]:+.3f}) after controlling for top lane gold difference at 15.\n",
        f"- Being a stable weak-side top changes average predicted win probability from {stable_contrast[0]:.3f} to {stable_contrast[1]:.3f} ({stable_contrast[2]:+.3f}) with side/league/patch/game-length controls.\n\n",
        "## 9. Main Finding\n\n",
        main_finding,
        "\n\nThe most important interpretation is not simply that teams should ignore top lane. The stronger interpretation is that a weak-side top strategy can be valuable when the top laner remains stable. In other words, low top gold share is useful only when the top laner avoids a severe lane deficit and allows the team to allocate resources elsewhere.\n\n",
        "## 10. Confidence Intervals and Statistical Significance\n\n",
        "The 95 percent confidence intervals in the regression table show plausible ranges for each odds ratio. For example, in Model 2, `weak_side_q1` has an odds ratio of about 3.56 with a 95 percent confidence interval from about 3.17 to 3.99. Since the interval is entirely above 1, the result is statistically significant and suggests that weak-side top is associated with higher win odds after controlling for lane gold difference.\n\n",
        "The p-values are very small for the main top-side variables, meaning the observed relationships would be very unlikely if there were truly no association in the population represented by the data. However, statistical significance does not prove causality, because teams do not randomly assign weak-side strategies.\n\n",
        "## 11. Why This Is Research-Worthy\n\n",
        "- It challenges the simple claim that top lane needs resources to matter. The better question is whether a top laner can absorb low resources without creating a losing lane state.\n",
        "- It separates resource allocation from lane dominance. That distinction is important because raw top gold share can punish both intentional weak-side play and accidental top-side failure.\n",
        "- The stable weak-side version is closer to how coaches talk about the role: low investment, acceptable deficit, and team resources redirected elsewhere.\n\n",
        "## 12. Limitations\n\n",
        "- The analysis is observational, so the results should be interpreted as associations rather than causal effects.\n",
        "- `top_gold_share15` is measured at 15 minutes, so it reflects both strategy and what happened in the game before 15 minutes.\n",
        "- The model controls for league and patch, but it does not yet include team, player, or champion fixed effects.\n",
        "- Stable weak-side top may partly capture strong teams, strong players, or favorable champion matchups.\n\n",
        "## 13. Recommended Robustness Checks\n\n",
        "- Re-run by major regions only, then by minor regions only.\n",
        "- Add team fixed effects if focusing on repeated teams, because some teams systematically play through bot/mid.\n",
        "- Add champion or champion-class controls to separate weak-side strategy from tank/carry champion selection.\n",
        "- Replace `top_gold_share15` with top XP share, CS share, or jungle proximity if available.\n",
        "- Test thresholds other than bottom quartile, such as bottom third or below 19 percent top share.\n",
        "- Exclude very short or very long games because game length can distort 15-minute resource interpretation.\n\n",
        "## 14. Suggested Figures\n\n",
        "- Bar chart: win rate by top gold-share quartile.\n",
        "- Scatterplot: top gold share at 15 versus win probability, colored by `golddiffat15`.\n",
        "- Coefficient plot: odds ratios for weak-side indicator and top gold difference.\n",
        "- Two-by-two table: weak-side/non-weak-side by stable/unstable top lane.\n",
        "\n## 15. Conclusion\n\n",
        "The evidence supports a nuanced version of the weak-side top theory. Weak-side top is not valuable simply because the top laner receives less gold. It becomes valuable when the top laner receives fewer resources and still remains economically stable. This allows the team to redirect resources to other parts of the map without suffering a major top-lane collapse.\n\n",
        "A concise conclusion is: weak-side top works when the top laner stays stable.\n",
    ]
    if all(path.exists() for path in [
        ML_FOCUSED_METRICS, ML_FOCUSED_IMPORTANCE, ML_FULL_METRICS, ML_FULL_IMPORTANCE
    ]):
        focused_metrics = pd.read_csv(ML_FOCUSED_METRICS)
        focused_importance = pd.read_csv(ML_FOCUSED_IMPORTANCE)
        full_metrics = pd.read_csv(ML_FULL_METRICS)
        full_importance = pd.read_csv(ML_FULL_IMPORTANCE)
        md.extend([
            "\n\n## 16. Machine-Learning Robustness and Variable Importance\n\n",
            "The original logistic regressions remain the main inferential models. As a robustness check, Logistic Regression, Random Forest, and XGBoost were compared using grouped five-fold cross-validation. Splits were grouped by `gameid`, so the blue-side and red-side rows from the same match could not appear in different folds. Only variables observed by 15 minutes were used; final game length and end-of-game totals were excluded.\n\n",
            "Focused Topic 1 model performance:\n\n",
            markdown_table(focused_metrics[["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]], ".4f"),
            "\n\nXGBoost held-out permutation importance for the focused model:\n\n",
            markdown_table(focused_importance.head(9), ".4f"),
            "\n\nThe focused results show that `team_golddiff15` dominates predictive importance. The weak-side indicators and `top_gs15` add almost no held-out AUC once overall team state is known. This does not invalidate the logistic association; it shows that the weak-side variables are not strong standalone predictors compared with total team advantage.\n\n",
            "### Full 15-Minute Feature Appendix\n\n",
            markdown_table(full_metrics[["model", "cv_auc_mean", "cv_auc_sd", "heldout_auc"]], ".4f"),
            "\n\n",
            markdown_table(full_importance.head(15), ".4f"),
            "\n\nAcross the broader 10/15-minute checkpoint feature set, team gold difference remains first, followed by role-level experience and gold differences. Top-lane variables remain secondary. Permutation importance and SHAP measure predictive contribution, not causality, and they do not provide regression p-values.\n",
        ])
    REPORT.write_text("".join(md))

    print(f"filtered_csv={FILTERED_CSV}")
    print(f"report={REPORT}")
    print(f"removed_rows={removed_rows}")
    print(f"removed_games={removed_games}")
    print(f"analytic_rows={len(model_df)}")
    print(f"analytic_games={model_df.gameid.nunique()}")
    print("\nTop gold-share quartiles")
    print(summary_by_q.to_string())
    print("\nFocus regression terms")
    print(show.to_string(index=False))


if __name__ == "__main__":
    main()
