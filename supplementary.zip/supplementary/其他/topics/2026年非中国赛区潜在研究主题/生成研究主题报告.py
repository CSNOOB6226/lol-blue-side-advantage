from pathlib import Path
import math

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[2]
PROJECT_DIR = Path(__file__).resolve().parent
DATA_FILE = ROOT / "topics/数据/原始数据/2026年非中国赛区比赛数据.csv"
CHART_DIR = PROJECT_DIR / "图表"
REPORT_FILE = PROJECT_DIR / "2026年非中国赛区潜在研究主题评估报告.docx"

ROLES = ["top", "jng", "mid", "bot", "sup"]
FOCUS_LEAGUES = {"LCK", "LEC", "LCS", "LCP", "CBLOL"}

BLUE = "2E74B5"
DARK_BLUE = "17365D"
INK = "1F2937"
MUTED = "667085"
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F4F6F9"
PALE_GOLD = "FFF4D6"
GOLD = "9A6B00"
RED = "9B1C1C"
WHITE = "FFFFFF"

PAGE_WIDTH_DXA = 12240
CONTENT_WIDTH_DXA = 9360
TABLE_INDENT_DXA = 120


def sigmoid(z):
    return 1 / (1 + np.exp(-np.clip(z, -35, 35)))


def normal_p(z):
    return math.erfc(abs(float(z)) / math.sqrt(2))


def fit_logit(data, outcome, numeric, categorical):
    parts = [pd.Series(1.0, index=data.index, name="Intercept")]
    for col in numeric:
        parts.append(data[col].astype(float).rename(col))
    for col in categorical:
        parts.append(
            pd.get_dummies(
                data[col].astype(str),
                prefix=col,
                drop_first=True,
                dtype=float,
            )
        )

    x = pd.concat(parts, axis=1)
    y = data[outcome].astype(float).to_numpy()
    a = x.to_numpy(float)
    beta = np.zeros(a.shape[1])

    for _ in range(120):
        pred = sigmoid(a @ beta)
        weights = np.clip(pred * (1 - pred), 1e-6, None)
        z = a @ beta + (y - pred) / weights
        hessian = (a.T * weights) @ a + 1e-7 * np.eye(a.shape[1])
        candidate = np.linalg.solve(hessian, (a.T * weights) @ z)
        if np.max(np.abs(candidate - beta)) < 1e-8:
            beta = candidate
            break
        beta = candidate

    pred = sigmoid(a @ beta)
    weights = np.clip(pred * (1 - pred), 1e-6, None)
    hessian = (a.T * weights) @ a + 1e-7 * np.eye(a.shape[1])
    covariance = np.linalg.inv(hessian)
    se = np.sqrt(np.diag(covariance))
    z_stat = beta / se
    p_value = np.array([normal_p(z) for z in z_stat])
    ll = float(
        np.sum(
            y * np.log(np.clip(pred, 1e-12, 1))
            + (1 - y) * np.log(np.clip(1 - pred, 1e-12, 1))
        )
    )
    ybar = np.clip(y.mean(), 1e-12, 1 - 1e-12)
    ll_null = float(np.sum(y * np.log(ybar) + (1 - y) * np.log(1 - ybar)))

    result = pd.DataFrame(
        {
            "term": x.columns,
            "coef": beta,
            "se": se,
            "p": p_value,
            "odds_ratio": np.exp(beta),
            "or_low": np.exp(beta - 1.96 * se),
            "or_high": np.exp(beta + 1.96 * se),
        }
    )
    metrics = {
        "n": len(y),
        "log_likelihood": ll,
        "mcfadden_r2": 1 - ll / ll_null,
    }
    return result, covariance, list(x.columns), metrics


def coefficient_contrast(result, covariance, names, weights):
    index = {name: i for i, name in enumerate(names)}
    w = np.zeros(len(names))
    for name, value in weights.items():
        w[index[name]] = value
    beta = result["coef"].to_numpy()
    estimate = float(w @ beta)
    se = float(math.sqrt(w @ covariance @ w))
    p = normal_p(estimate / se)
    return {
        "estimate": estimate,
        "se": se,
        "p": p,
        "ratio_of_odds_ratios": math.exp(estimate),
    }


def prepare_data():
    df = pd.read_csv(DATA_FILE, low_memory=False)
    team_rows = df[df["position"].eq("team")].copy()
    blue = team_rows[team_rows["side"].eq("Blue")].copy()
    blue["patch_str"] = blue["patch"].astype(str)
    blue["blue_win"] = blue["result"].astype(int)
    blue["gold_diff15_k"] = blue["golddiffat15"] / 1000
    blue["xp_diff15_k"] = blue["xpdiffat15"] / 1000
    blue["cs_diff15_10"] = blue["csdiffat15"] / 10
    blue["kill_diff15"] = blue["killsat15"] - blue["opp_killsat15"]
    blue["grub_diff"] = blue["void_grubs"] - blue["opp_void_grubs"]

    players = df[
        df["position"].isin(ROLES) & df["side"].eq("Blue")
    ].copy()
    role_gold = players.pivot(
        index="gameid",
        columns="position",
        values="golddiffat15",
    )
    for role in ROLES:
        blue[f"{role}_gold_diff15_k"] = (
            blue["gameid"].map(role_gold[role]) / 1000
        )

    blue["non_top_gold_diff15_k"] = (
        blue["gold_diff15_k"] - blue["top_gold_diff15_k"]
    )
    blue["focus_league"] = blue["league"].isin(FOCUS_LEAGUES).astype(int)
    blue["focus_x_top"] = (
        blue["focus_league"] * blue["top_gold_diff15_k"]
    )
    blue["focus_x_non_top"] = (
        blue["focus_league"] * blue["non_top_gold_diff15_k"]
    )

    quality_cols = [
        "blue_win",
        "league",
        "patch_str",
        "gold_diff15_k",
        "xp_diff15_k",
        "cs_diff15_10",
        "kill_diff15",
    ]
    topic1_cols = [
        "blue_win",
        "league",
        "patch_str",
        "top_gold_diff15_k",
        "non_top_gold_diff15_k",
        "focus_x_top",
        "focus_x_non_top",
    ]
    objective_cols = [
        "blue_win",
        "league",
        "patch_str",
        "gold_diff15_k",
        "firstdragon",
        "firstherald",
        "grub_diff",
    ]

    topic1 = blue[topic1_cols].dropna().copy()
    quality = blue[quality_cols].dropna().copy()
    objective = blue[objective_cols].dropna().copy()

    topic1_result, topic1_cov, topic1_names, topic1_metrics = fit_logit(
        topic1,
        "blue_win",
        [
            "top_gold_diff15_k",
            "non_top_gold_diff15_k",
            "focus_x_top",
            "focus_x_non_top",
        ],
        ["league", "patch_str"],
    )
    quality_result, _, _, quality_metrics = fit_logit(
        quality,
        "blue_win",
        [
            "gold_diff15_k",
            "xp_diff15_k",
            "cs_diff15_10",
            "kill_diff15",
        ],
        ["league", "patch_str"],
    )
    objective_result, _, _, objective_metrics = fit_logit(
        objective,
        "blue_win",
        [
            "gold_diff15_k",
            "firstdragon",
            "firstherald",
            "grub_diff",
        ],
        ["league", "patch_str"],
    )

    contrast = coefficient_contrast(
        topic1_result,
        topic1_cov,
        topic1_names,
        {
            "top_gold_diff15_k": 1,
            "focus_x_top": 1,
            "non_top_gold_diff15_k": -1,
            "focus_x_non_top": -1,
        },
    )

    topic1_focus = []
    for label, base, interaction in [
        (
            "上路每领先1,000金币",
            "top_gold_diff15_k",
            "focus_x_top",
        ),
        (
            "其余四个位置合计每领先1,000金币",
            "non_top_gold_diff15_k",
            "focus_x_non_top",
        ),
    ]:
        weights = {base: 1, interaction: 1}
        c = coefficient_contrast(
            topic1_result,
            topic1_cov,
            topic1_names,
            weights,
        )
        topic1_focus.append(
            {
                "指标": label,
                "胜算比": math.exp(c["estimate"]),
                "下限": math.exp(c["estimate"] - 1.96 * c["se"]),
                "上限": math.exp(c["estimate"] + 1.96 * c["se"]),
                "p值": c["p"],
            }
        )

    topic1_other = topic1_result[
        topic1_result["term"].isin(
            ["top_gold_diff15_k", "non_top_gold_diff15_k"]
        )
    ].copy()
    topic1_other["指标"] = topic1_other["term"].map(
        {
            "top_gold_diff15_k": "其他联赛：上路每领先1,000金币",
            "non_top_gold_diff15_k": "其他联赛：其余四个位置合计",
        }
    )

    data_quality = {
        "rows": len(df),
        "games": df["gameid"].nunique(),
        "start_date": str(df["date"].min())[:10],
        "end_date": str(df["date"].max())[:10],
        "leagues": team_rows["league"].nunique(),
        "teams": team_rows["teamname"].nunique(),
        "players": df.loc[
            ~df["position"].eq("team"), "playername"
        ].nunique(),
        "duplicate_rows": int(df.duplicated().sum()),
        "early_missing": int(
            df[
                [
                    "goldat10",
                    "goldat15",
                    "xpat10",
                    "xpat15",
                    "csat10",
                    "csat15",
                    "result",
                ]
            ]
            .isna()
            .sum()
            .sum()
        ),
        "patch_min": float(df["patch"].min()),
        "patch_max": float(df["patch"].max()),
    }

    return {
        "df": df,
        "blue": blue,
        "data_quality": data_quality,
        "topic1_result": topic1_result,
        "topic1_focus": pd.DataFrame(topic1_focus),
        "topic1_other": topic1_other,
        "topic1_metrics": topic1_metrics,
        "topic1_contrast": contrast,
        "quality_result": quality_result,
        "quality_metrics": quality_metrics,
        "objective_result": objective_result,
        "objective_metrics": objective_metrics,
    }


def font(size, bold=False):
    path = (
        "/System/Library/Fonts/STHeiti Medium.ttc"
        if bold
        else "/System/Library/Fonts/STHeiti Light.ttc"
    )
    return ImageFont.truetype(path, size=size)


def create_coefficient_chart(
    rows,
    output,
    title,
    subtitle,
    x_min,
    x_max,
    ticks,
):
    width, height = 1500, 820
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((95, 55), title, fill="#" + DARK_BLUE, font=font(44, True))
    draw.text((95, 118), subtitle, fill="#" + MUTED, font=font(25))

    left, right = 570, 1380
    top, bottom = 220, 670

    def x_pos(value):
        return left + (value - x_min) / (x_max - x_min) * (right - left)

    for tick in ticks:
        x = x_pos(tick)
        draw.line((x, top, x, bottom), fill="#E4E7EC", width=2)
        text = f"{tick:.1f}"
        bbox = draw.textbbox((0, 0), text, font=font(22))
        draw.text(
            (x - (bbox[2] - bbox[0]) / 2, bottom + 18),
            text,
            fill="#" + MUTED,
            font=font(22),
        )

    reference = x_pos(1.0)
    draw.line((reference, top - 15, reference, bottom), fill="#98A2B3", width=4)

    spacing = (bottom - top) / max(1, len(rows))
    for i, row in enumerate(rows):
        y = top + spacing * (i + 0.5)
        draw.text((95, y - 19), row["label"], fill="#" + INK, font=font(25))
        low = x_pos(max(x_min, row["low"]))
        high = x_pos(min(x_max, row["high"]))
        center = x_pos(row["value"])
        draw.line((low, y, high, y), fill=row["color"], width=8)
        draw.ellipse(
            (center - 11, y - 11, center + 11, y + 11),
            fill=row["color"],
        )
        value_text = f"{row['value']:.2f}"
        draw.text(
            (min(right - 10, high + 18), y - 17),
            value_text,
            fill=row["color"],
            font=font(23, True),
        )

    draw.text(
        (left + 220, 745),
        "胜算比（Odds Ratio）",
        fill="#" + MUTED,
        font=font(24),
    )
    image.save(output, quality=95)


def build_charts(analysis):
    CHART_DIR.mkdir(parents=True, exist_ok=True)

    focus_rows = []
    for _, row in analysis["topic1_focus"].iterrows():
        focus_rows.append(
            {
                "label": "重点联赛：" + row["指标"],
                "value": row["胜算比"],
                "low": row["下限"],
                "high": row["上限"],
                "color": "#2E74B5",
            }
        )
    for _, row in analysis["topic1_other"].iterrows():
        focus_rows.append(
            {
                "label": row["指标"],
                "value": row["odds_ratio"],
                "low": row["or_low"],
                "high": row["or_high"],
                "color": "#7A5A00",
            }
        )
    create_coefficient_chart(
        focus_rows,
        CHART_DIR / "图1_上路与非上路经济领先的胜算比.png",
        "同样领先1,000金币，价值取决于领先发生在哪里",
        "模型控制联赛与版本；重点联赛为 LCK、LEC、LCS、LCP、CBLOL",
        0.5,
        2.2,
        [0.5, 1.0, 1.5, 2.0],
    )

    quality_map = {
        "gold_diff15_k": ("15分钟经济差（每1,000）", "#2E74B5"),
        "xp_diff15_k": ("15分钟经验差（每1,000）", "#344054"),
        "cs_diff15_10": ("15分钟补刀差（每10）", "#7A5A00"),
        "kill_diff15": ("15分钟击杀差（每1）", "#9B1C1C"),
    }
    quality_rows = []
    for term, (label, color) in quality_map.items():
        row = analysis["quality_result"].set_index("term").loc[term]
        quality_rows.append(
            {
                "label": label,
                "value": row["odds_ratio"],
                "low": row["or_low"],
                "high": row["or_high"],
                "color": color,
            }
        )
    create_coefficient_chart(
        quality_rows,
        CHART_DIR / "图2_经济领先质量模型.png",
        "总经济相同后，经验与补刀仍提供额外信息",
        "击杀差的额外系数接近于零；模型控制联赛与版本",
        0.85,
        1.55,
        [0.9, 1.0, 1.2, 1.4],
    )

    objective_map = {
        "gold_diff15_k": ("15分钟经济差（每1,000）", "#344054"),
        "firstdragon": ("获得第一条小龙", "#2E74B5"),
        "firstherald": ("获得第一只先锋", "#7A5A00"),
        "grub_diff": ("巢虫净优势（每1只）", "#9B1C1C"),
    }
    objective_rows = []
    for term, (label, color) in objective_map.items():
        row = analysis["objective_result"].set_index("term").loc[term]
        objective_rows.append(
            {
                "label": label,
                "value": row["odds_ratio"],
                "low": row["or_low"],
                "high": row["or_high"],
                "color": color,
            }
        )
    create_coefficient_chart(
        objective_rows,
        CHART_DIR / "图3_中立资源剩余预测价值.png",
        "控制15分钟经济后，小龙仍保留较强的预测价值",
        "先锋仍有额外关联；巢虫净优势不再显著",
        0.85,
        2.25,
        [0.9, 1.0, 1.5, 2.0],
    )


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in [
        ("top", top),
        ("start", start),
        ("bottom", bottom),
        ("end", end),
    ]:
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    table.autofit = False
    tbl_pr = table._tbl.tblPr

    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths)))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(TABLE_INDENT_DXA))
    tbl_ind.set(qn("w:type"), "dxa")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        for i, cell in enumerate(row.cells):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.first_child_found_in("w:tcW")
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(widths[i]))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_run_font(run, size=None, color=None, bold=None, italic=None):
    run.font.name = "Calibri"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Calibri")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Calibri")
    run._element.get_or_add_rPr().rFonts.set(
        qn("w:eastAsia"), "STHeiti"
    )
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def apply_style_font(style, size, color=INK, bold=False):
    style.font.name = "Calibri"
    style._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Calibri")
    style._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Calibri")
    style._element.get_or_add_rPr().rFonts.set(
        qn("w:eastAsia"), "STHeiti"
    )
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string(color)
    style.font.bold = bold


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("第 ")
    set_run_font(run, size=9, color=MUTED)
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)
    end = paragraph.add_run(" 页")
    set_run_font(end, size=9, color=MUTED)


def add_custom_numbering(doc):
    numbering = doc.part.numbering_part.element
    existing_ids = [
        int(x.get(qn("w:abstractNumId")))
        for x in numbering.findall(qn("w:abstractNum"))
    ]
    abstract_id = max(existing_ids or [0]) + 1

    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    multi = OxmlElement("w:multiLevelType")
    multi.set(qn("w:val"), "singleLevel")
    abstract.append(multi)

    level = OxmlElement("w:lvl")
    level.set(qn("w:ilvl"), "0")
    start = OxmlElement("w:start")
    start.set(qn("w:val"), "1")
    num_fmt = OxmlElement("w:numFmt")
    num_fmt.set(qn("w:val"), "bullet")
    lvl_text = OxmlElement("w:lvlText")
    lvl_text.set(qn("w:val"), "•")
    lvl_jc = OxmlElement("w:lvlJc")
    lvl_jc.set(qn("w:val"), "left")
    p_pr = OxmlElement("w:pPr")
    tabs = OxmlElement("w:tabs")
    tab = OxmlElement("w:tab")
    tab.set(qn("w:val"), "num")
    tab.set(qn("w:pos"), "540")
    tabs.append(tab)
    ind = OxmlElement("w:ind")
    ind.set(qn("w:left"), "540")
    ind.set(qn("w:hanging"), "280")
    spacing = OxmlElement("w:spacing")
    spacing.set(qn("w:after"), "80")
    spacing.set(qn("w:line"), "290")
    spacing.set(qn("w:lineRule"), "auto")
    p_pr.append(tabs)
    p_pr.append(ind)
    p_pr.append(spacing)
    level.extend([start, num_fmt, lvl_text, lvl_jc, p_pr])
    abstract.append(level)
    numbering.append(abstract)

    num_ids = [
        int(x.get(qn("w:numId"))) for x in numbering.findall(qn("w:num"))
    ]
    num_id = max(num_ids or [0]) + 1
    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))
    abstract_ref = OxmlElement("w:abstractNumId")
    abstract_ref.set(qn("w:val"), str(abstract_id))
    num.append(abstract_ref)
    numbering.append(num)
    return num_id


def set_numbering(paragraph, num_id):
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = p_pr.find(qn("w:numPr"))
    if num_pr is None:
        num_pr = OxmlElement("w:numPr")
        p_pr.append(num_pr)
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num_id_node = OxmlElement("w:numId")
    num_id_node.set(qn("w:val"), str(num_id))
    num_pr.extend([ilvl, num_id_node])


def configure_document(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    normal = doc.styles["Normal"]
    apply_style_font(normal, 11, INK)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.line_spacing = 1.333
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    heading_tokens = {
        "Heading 1": (16, BLUE, 18, 10),
        "Heading 2": (13, BLUE, 12, 6),
        "Heading 3": (12, DARK_BLUE, 8, 4),
    }
    for name, (size, color, before, after) in heading_tokens.items():
        style = doc.styles[name]
        apply_style_font(style, size, color, True)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    caption = doc.styles["Caption"]
    apply_style_font(caption, 9.5, MUTED)
    caption.font.italic = True
    caption.paragraph_format.space_before = Pt(4)
    caption.paragraph_format.space_after = Pt(6)
    caption.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER

    if "Callout" not in doc.styles:
        callout = doc.styles.add_style("Callout", WD_STYLE_TYPE.PARAGRAPH)
    else:
        callout = doc.styles["Callout"]
    apply_style_font(callout, 11, DARK_BLUE, True)
    callout.paragraph_format.space_before = Pt(6)
    callout.paragraph_format.space_after = Pt(8)
    callout.paragraph_format.line_spacing = 1.25

    header = section.header
    hp = header.paragraphs[0]
    hp.text = ""
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hr = hp.add_run("2026年非中国赛区潜在研究主题")
    set_run_font(hr, size=9, color=MUTED, bold=True)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.text = ""
    add_page_number(fp)


def add_cover(doc):
    for _ in range(4):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    r = p.add_run("研究选题评估报告")
    set_run_font(r, size=12, color=GOLD, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(10)
    r = p.add_run("2026年非中国赛区\n潜在研究主题")
    set_run_font(r, size=29, color=DARK_BLUE, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(32)
    r = p.add_run("从早期优势的位置、质量与兑现方式出发")
    set_run_font(r, size=15, color=BLUE)

    table = doc.add_table(rows=3, cols=2)
    set_repeat_table_header(table.rows[0])
    values = [
        ("数据范围", "2026年1月8日—6月2日"),
        ("分析样本", "剔除LPL及LPL队伍跨赛事比赛后的5,000场"),
        ("报告性质", "探索性选题评估与研究推进方案"),
    ]
    for row, (label, value) in zip(table.rows, values):
        label_cell, value_cell = row.cells
        shade_cell(label_cell, LIGHT_BLUE)
        shade_cell(value_cell, LIGHT_GRAY)
        label_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        value_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p1 = label_cell.paragraphs[0]
        p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p1.paragraph_format.space_after = Pt(0)
        r1 = p1.add_run(label)
        set_run_font(r1, size=10, color=DARK_BLUE, bold=True)
        p2 = value_cell.paragraphs[0]
        p2.paragraph_format.space_after = Pt(0)
        r2 = p2.add_run(value)
        set_run_font(r2, size=10, color=INK)
    set_table_geometry(table, [2160, 7200])

    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(28)
    r = p.add_run("生成日期：2026年6月7日")
    set_run_font(r, size=10, color=MUTED)
    doc.add_page_break()


def add_bullet(doc, text, num_id):
    p = doc.add_paragraph()
    set_numbering(p, num_id)
    r = p.add_run(text)
    set_run_font(r, size=11, color=INK)
    return p


def add_callout(doc, label, text, fill=LIGHT_BLUE):
    table = doc.add_table(rows=1, cols=1)
    set_repeat_table_header(table.rows[0])
    cell = table.cell(0, 0)
    shade_cell(cell, fill)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(label + " ")
    set_run_font(r, size=11, color=DARK_BLUE, bold=True)
    r = p.add_run(text)
    set_run_font(r, size=11, color=INK)
    set_table_geometry(table, [CONTENT_WIDTH_DXA])
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_table(doc, headers, rows, widths, numeric_cols=()):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    set_repeat_table_header(table.rows[0])
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        shade_cell(cell, LIGHT_BLUE)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(str(header))
        set_run_font(r, size=9.2, color=DARK_BLUE, bold=True)
    for row_data in rows:
        row = table.add_row()
        for i, value in enumerate(row_data):
            cell = row.cells[i]
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            p.alignment = (
                WD_ALIGN_PARAGRAPH.CENTER
                if i in numeric_cols
                else WD_ALIGN_PARAGRAPH.LEFT
            )
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(str(value))
            set_run_font(r, size=9.2, color=INK)
    set_table_geometry(table, widths)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def fmt_p(value):
    if value < 0.001:
        return "<0.001"
    return f"{value:.3f}"


def add_figure(doc, path, caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(2)
    picture = p.add_run().add_picture(str(path), width=Inches(6.25))
    picture._inline.docPr.set("descr", caption)
    picture._inline.docPr.set("title", path.stem)
    c = doc.add_paragraph(caption, style="Caption")
    c.paragraph_format.keep_with_next = False


def add_research_outline(doc, num_id, steps):
    for step in steps:
        add_bullet(doc, step, num_id)


def build_report(analysis):
    doc = Document()
    configure_document(doc)
    bullet_num_id = add_custom_numbering(doc)
    add_cover(doc)

    quality = analysis["data_quality"]
    q = analysis["quality_result"].set_index("term")
    obj = analysis["objective_result"].set_index("term")
    t1 = analysis["topic1_focus"].set_index("指标")
    contrast = analysis["topic1_contrast"]

    doc.add_heading("执行摘要", level=1)
    add_callout(
        doc,
        "共同主线：",
        "早期优势的价值不只取决于“领先多少”，还取决于领先发生在哪里、由什么形成，以及资源价值是否已经兑现。",
    )
    doc.add_paragraph(
        "本报告从2026年职业比赛数据中排除中国赛区及相关中国队伍比赛，"
        "使用一场比赛一条蓝方记录进行探索性逻辑回归，筛选出三个具有反直觉特征、"
        "可解释性较强且能够发展为正式课程研究或数据项目的主题。"
    )
    add_table(
        doc,
        ["优先级", "研究主题", "核心反直觉点", "推荐用途"],
        [
            (
                "1",
                "重点联赛的上路领先悖论",
                "上路经济领先的胜负转化弱于其余位置",
                "最适合作为上单主线研究",
            ),
            (
                "2",
                "经济领先的质量",
                "控制总经济后，击杀数不再提供额外信息",
                "统计设计最干净",
            ),
            (
                "3",
                "中立资源的剩余价值",
                "小龙比更直接产出经济的上半区资源保留更多信息",
                "最适合演讲与可视化",
            ),
        ],
        [820, 2400, 3600, 2540],
        numeric_cols=(0,),
    )

    doc.add_heading("1. 数据范围与质量", level=1)
    doc.add_paragraph(
        f"数据文件覆盖{quality['start_date']}至{quality['end_date']}，"
        f"版本范围为{quality['patch_min']:.2f}至{quality['patch_max']:.2f}。"
        "因此，本报告分析的是截至2026年6月2日的数据期，而不是完整的2026自然年。"
    )
    add_table(
        doc,
        ["项目", "结果", "解释"],
        [
            ("最终样本", f"{quality['games']:,}场；{quality['rows']:,}行", "每场12行"),
            ("赛事覆盖", f"{quality['leagues']}个联赛", "排除中国相关比赛后"),
            ("参与对象", f"{quality['teams']}支队伍；{quality['players']}名选手", "按数据中的名称统计"),
            ("重复记录", str(quality["duplicate_rows"]), "未发现完全重复行"),
            ("核心早期变量缺失", str(quality["early_missing"]), "10/15分钟经济、经验、补刀及赛果"),
        ],
        [1900, 2300, 5160],
        numeric_cols=(1,),
    )

    doc.add_heading("1.1 中国相关数据的剔除口径", level=2)
    doc.add_paragraph(
        "原始文件包含5,454场、65,448行。筛选规则不仅删除联赛代码为LPL的比赛，"
        "还识别曾出现在LPL中的队伍，并删除这些队伍参加其他赛事的比赛。"
        "最终删除454场、5,448行，其中25场属于LPL队伍参加非LPL赛事的跨赛事记录。"
        "这一口径比只删除“league = LPL”更严格。"
    )

    doc.add_heading("1.2 分析对象、单位与变量", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "原始观测结构：每场比赛包含两队，每队五个选手行和一个队伍行，共12行。",
            "主模型单位：每场比赛只保留蓝方一条记录，因变量为蓝方是否获胜，避免把同一比赛的胜负镜像当作两条独立样本。",
            "位置经济差：使用蓝方各位置与红方对应位置的15分钟经济差；其余四位置经济差等于队伍总经济差减去上路经济差。",
            "所有正式题目均以15分钟及以前变量为核心，避免使用终局伤害、最终经济等赛后结果变量预测胜负。",
        ],
    )

    doc.add_heading("1.3 统计方法与解释边界", level=2)
    doc.add_paragraph(
        "三个预实验均使用逻辑回归，并控制联赛与版本。胜算比大于1表示该变量增加时，"
        "获胜胜算与更高值相关；p值用于衡量数据与“无关联”假设之间的相容程度。"
        "本报告用于选题筛选，结果属于探索性关联证据，不应解释为策略的因果效果。"
    )

    doc.add_page_break()
    doc.add_heading("2. 主题一：重点联赛的上路领先悖论", level=1)
    add_callout(
        doc,
        "研究问题：",
        "在15分钟总领先结构相同的比较中，上路领先1,000金币与其余四个位置合计领先1,000金币，是否具有相同的胜负转化价值？",
        PALE_GOLD,
    )

    doc.add_heading("2.1 为什么它反直觉", level=2)
    doc.add_paragraph(
        "上路领先通常意味着单带压力、先锋控制、边线优先级和更强的团战前排或侧翼。"
        "直觉上，这种领先至少应该和其他位置的等额领先同样重要。"
        "但预实验显示，在重点联赛组中，上路领先的独立转化明显弱于其余位置；"
        "在其他联赛中，两者则更加接近。"
    )

    doc.add_heading("2.2 初步模型与结果", level=2)
    doc.add_paragraph(
        "重点联赛在本报告中被操作性定义为LCK、LEC、LCS、LCP和CBLOL。"
        "该分组不是永久结论，正式研究中应使用不同赛区集合进行稳健性检验。"
    )
    add_table(
        doc,
        ["重点联赛指标", "胜算比", "95%区间", "p值"],
        [
            (
                "上路每领先1,000金币",
                f"{t1.loc['上路每领先1,000金币', '胜算比']:.2f}",
                f"{t1.loc['上路每领先1,000金币', '下限']:.2f}–{t1.loc['上路每领先1,000金币', '上限']:.2f}",
                fmt_p(t1.loc["上路每领先1,000金币", "p值"]),
            ),
            (
                "其余四位置合计每领先1,000金币",
                f"{t1.loc['其余四个位置合计每领先1,000金币', '胜算比']:.2f}",
                f"{t1.loc['其余四个位置合计每领先1,000金币', '下限']:.2f}–{t1.loc['其余四个位置合计每领先1,000金币', '上限']:.2f}",
                fmt_p(t1.loc["其余四个位置合计每领先1,000金币", "p值"]),
            ),
        ],
        [4080, 1320, 2240, 1720],
        numeric_cols=(1, 2, 3),
    )
    add_figure(
        doc,
        CHART_DIR / "图1_上路与非上路经济领先的胜算比.png",
        "图1　不同位置经济领先与胜负的关联。横线为95%置信区间，虚线位置1表示无额外关联。",
    )
    doc.add_paragraph(
        f"在重点联赛组内，“上路领先”相对于“其余位置领先”的胜算比之比约为"
        f"{contrast['ratio_of_odds_ratios']:.2f}（p{('=' + format(contrast['p'], '.3f')) if contrast['p'] >= 0.001 else '<0.001'}）。"
        "换言之，等额早期经济优势如果集中在上路，其胜负转化率可能更低。"
    )

    doc.add_heading("2.3 可检验的研究假设", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "H1：在重点联赛中，上路15分钟经济差的胜负关联弱于其余四个位置的合计经济差。",
            "H2：这种差异在坦克、弱侧或低单带压力英雄中更明显。",
            "H3：先锋、巢虫和上路镀层只能解释部分上路经济领先，不能完全解释其较低的转化效率。",
            "H4：强队更擅长通过换资源、避战和下半区扩张来中和敌方上路领先。",
        ],
    )

    doc.add_heading("2.4 正式研究推进路线", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "数据构建：建立一场比赛一行的数据集，分别计算五个位置的10分钟和15分钟经济差。",
            "基础模型：BlueWin ~ TopGoldDiff15 + NonTopGoldDiff15 + Side/League/Patch controls。",
            "核心检验：加入重点联赛交互项，并直接检验上路系数与非上路系数之差。",
            "机制分析：加入英雄类型、先锋、巢虫、第一座塔和上路补刀/经验差，判断上路领先通过何种渠道产生。",
            "稳健性：改变重点联赛定义；按季后赛、常规赛和版本分组；使用2025数据做跨年度验证。",
            "输出形式：赛区系数图、位置边际效应图，以及“同样领先1,000金币”情境预测图。",
        ],
    )

    doc.add_heading("2.5 风险与限制", level=2)
    doc.add_paragraph(
        "上路经济差并不等于队伍主动投资，它也可能来自对线能力、英雄克制、击杀或对手失误。"
        "此外，重点联赛组的定义带有研究者选择，需要替代分组和逐赛区结果共同支持结论。"
    )

    doc.add_page_break()
    doc.add_heading("3. 主题二：经济领先的质量", level=1)
    add_callout(
        doc,
        "研究问题：",
        "当15分钟总经济差相同时，由经验和补刀形成的领先，是否比由击杀形成的领先更能预测最终胜负？",
        PALE_GOLD,
    )

    doc.add_heading("3.1 为什么它反直觉", level=2)
    doc.add_paragraph(
        "比赛叙事通常首先围绕击杀展开，因为击杀最显眼，也会直接产生金币。"
        "然而，击杀带来的大部分信息可能已经被总经济差吸收。相比之下，经验和补刀差还可能反映兵线控制、"
        "地图占有、转线效率和可持续发育，因此在总经济相同后仍保留额外预测信息。"
    )

    doc.add_heading("3.2 初步模型与结果", level=2)
    add_table(
        doc,
        ["变量", "单位", "胜算比", "95%区间", "p值"],
        [
            (
                "总经济差",
                "每1,000金币",
                f"{q.loc['gold_diff15_k', 'odds_ratio']:.2f}",
                f"{q.loc['gold_diff15_k', 'or_low']:.2f}–{q.loc['gold_diff15_k', 'or_high']:.2f}",
                fmt_p(q.loc["gold_diff15_k", "p"]),
            ),
            (
                "经验差",
                "每1,000经验",
                f"{q.loc['xp_diff15_k', 'odds_ratio']:.2f}",
                f"{q.loc['xp_diff15_k', 'or_low']:.2f}–{q.loc['xp_diff15_k', 'or_high']:.2f}",
                fmt_p(q.loc["xp_diff15_k", "p"]),
            ),
            (
                "补刀差",
                "每10补刀",
                f"{q.loc['cs_diff15_10', 'odds_ratio']:.2f}",
                f"{q.loc['cs_diff15_10', 'or_low']:.2f}–{q.loc['cs_diff15_10', 'or_high']:.2f}",
                fmt_p(q.loc["cs_diff15_10", "p"]),
            ),
            (
                "击杀差",
                "每1击杀",
                f"{q.loc['kill_diff15', 'odds_ratio']:.2f}",
                f"{q.loc['kill_diff15', 'or_low']:.2f}–{q.loc['kill_diff15', 'or_high']:.2f}",
                fmt_p(q.loc["kill_diff15", "p"]),
            ),
        ],
        [1900, 1820, 1360, 2380, 1900],
        numeric_cols=(2, 3, 4),
    )
    add_figure(
        doc,
        CHART_DIR / "图2_经济领先质量模型.png",
        "图2　控制15分钟总经济差、联赛和版本后的领先构成系数。",
    )
    doc.add_paragraph(
        "结果不表示击杀没有价值。更准确的解释是：击杀产生的即时经济价值大多已经包含在总经济差中，"
        "而经验和补刀仍补充了总经济无法完全描述的结构信息。"
    )

    doc.add_heading("3.3 可检验的研究假设", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "H1：控制15分钟总经济差后，经验差和补刀差仍与胜率正相关。",
            "H2：控制总经济后，击杀差的额外关联较弱，且可能因位置而异。",
            "H3：发育型领先在经济接近的比赛中比击杀型领先更稳定。",
            "H4：击杀型领先只有在同时转化为塔、兵线或中立资源时，才显著改善胜负预测。",
        ],
    )

    doc.add_heading("3.4 正式研究推进路线", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "定义领先类型：依据击杀、经验、补刀和经济差，将比赛划分为击杀型、发育型、混合型和无明显领先。",
            "模型比较：先估计仅含经济差的基线模型，再加入经验、补刀和击杀差，比较似然、AUC和校准表现。",
            "位置分解：分别计算上、野、中、下、辅的领先来源，检验“谁通过何种方式领先”最重要。",
            "非线性检验：加入平方项或分段函数，判断补刀/经验的边际价值是否递减。",
            "稳健性：限制在经济差±500或±1,000金币的接近比赛；按版本、联赛和比赛阶段复算。",
            "输出形式：相同经济差下不同领先构成的预测胜率图，以及模型增量预测能力表。",
        ],
    )

    doc.add_heading("3.5 风险与限制", level=2)
    doc.add_paragraph(
        "经济、经验、补刀和击杀之间高度相关，正式模型必须检查多重共线性。"
        "此外，“领先类型”是对比赛状态的总结，并非随机分配的策略，因此适合进行预测和关联解释，"
        "不适合直接声称某种领先方式导致胜利。"
    )

    doc.add_page_break()
    doc.add_heading("4. 主题三：中立资源的剩余价值", level=1)
    add_callout(
        doc,
        "研究问题：",
        "在已经知道15分钟经济差后，第一条小龙、第一只先锋和巢虫净优势还分别保留多少额外胜负信息？",
        PALE_GOLD,
    )

    doc.add_heading("4.1 为什么它反直觉", level=2)
    doc.add_paragraph(
        "先锋和巢虫能够更直接地转化为镀层、塔和即时经济，看起来应该比第一条小龙更重要。"
        "但也正因为其价值较快进入当前经济，它们在控制15分钟经济后可能不再提供大量新增信息。"
        "第一条小龙的部分价值来自未来龙魂进度，这是一种尚未完全兑现的“期权价值”。"
    )

    doc.add_heading("4.2 初步模型与结果", level=2)
    add_table(
        doc,
        ["变量", "胜算比", "95%区间", "p值", "初步解释"],
        [
            (
                "15分钟经济差（每1,000）",
                f"{obj.loc['gold_diff15_k', 'odds_ratio']:.2f}",
                f"{obj.loc['gold_diff15_k', 'or_low']:.2f}–{obj.loc['gold_diff15_k', 'or_high']:.2f}",
                fmt_p(obj.loc["gold_diff15_k", "p"]),
                "当前已兑现优势",
            ),
            (
                "第一条小龙",
                f"{obj.loc['firstdragon', 'odds_ratio']:.2f}",
                f"{obj.loc['firstdragon', 'or_low']:.2f}–{obj.loc['firstdragon', 'or_high']:.2f}",
                fmt_p(obj.loc["firstdragon", "p"]),
                "仍有较强剩余价值",
            ),
            (
                "第一只先锋",
                f"{obj.loc['firstherald', 'odds_ratio']:.2f}",
                f"{obj.loc['firstherald', 'or_low']:.2f}–{obj.loc['firstherald', 'or_high']:.2f}",
                fmt_p(obj.loc["firstherald", "p"]),
                "仍有中等额外关联",
            ),
            (
                "巢虫净优势（每1只）",
                f"{obj.loc['grub_diff', 'odds_ratio']:.2f}",
                f"{obj.loc['grub_diff', 'or_low']:.2f}–{obj.loc['grub_diff', 'or_high']:.2f}",
                fmt_p(obj.loc["grub_diff", "p"]),
                "控制经济后不显著",
            ),
        ],
        [2280, 1120, 1820, 1220, 2920],
        numeric_cols=(1, 2, 3),
    )
    add_figure(
        doc,
        CHART_DIR / "图3_中立资源剩余预测价值.png",
        "图3　控制15分钟经济、联赛和版本后，各类早期资源保留的胜负关联。",
    )

    doc.add_heading("4.3 可检验的研究假设", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "H1：控制15分钟经济后，第一条小龙仍保留显著的额外胜负关联。",
            "H2：先锋的总价值较高，但其部分作用通过即时经济和塔资源体现。",
            "H3：巢虫优势的额外价值取决于是否真正转化为镀层、第一塔或边线压力。",
            "H4：小龙的剩余价值在重视龙魂节奏的赛区或版本中更强。",
        ],
    )

    doc.add_heading("4.4 正式研究推进路线", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "双阶段模型：先估计不控制经济时的资源总关联，再加入15分钟经济，比较系数衰减幅度。",
            "资源交换分类：构建“龙+先锋、只拿龙、只拿先锋、两者均无”四种早期资源组合。",
            "转化机制：加入15分钟塔数、镀层、补刀和经济差，检验先锋/巢虫如何被兑现。",
            "异质性：加入红蓝方、赛区和版本交互，观察地图结构与版本变化。",
            "预测验证：使用留出赛区或后续月份数据检验资源价值是否稳定。",
            "输出形式：资源组合胜率图、系数衰减图，以及“已兑现价值—未来期权价值”概念图。",
        ],
    )

    doc.add_heading("4.5 风险与限制", level=2)
    doc.add_paragraph(
        "取得第一条龙或先锋往往是团队强度、线权和视野控制共同作用的结果。"
        "因此，小龙系数可能同时包含未观测的队伍质量。正式研究应加入队伍固定效应，"
        "并避免把资源系数解释为拿到该资源本身的纯因果收益。"
    )

    doc.add_page_break()
    doc.add_heading("5. 三个主题的比较与项目建议", level=1)
    add_table(
        doc,
        ["评价维度", "主题一：上路悖论", "主题二：领先质量", "主题三：资源剩余价值"],
        [
            ("反直觉程度", "高", "中高", "高"),
            ("与既有上单项目衔接", "非常强", "中等", "中等"),
            ("统计实施难度", "中等", "较低", "中等"),
            ("手工分类需求", "英雄类型扩展时需要", "较少", "较少"),
            ("展示与叙事能力", "强", "清晰稳健", "非常强"),
            ("主要方法风险", "赛区定义与英雄混杂", "共线性", "队伍强度混杂"),
        ],
        [1800, 2520, 2520, 2520],
    )

    doc.add_heading("5.1 推荐主项目", level=2)
    add_callout(
        doc,
        "首选：",
        "将主题一发展为主研究。它直接连接既有的弱势上单与Carry上单项目，又把问题从“上路是否需要资源”推进为“上路优势为何在高水平比赛中更难兑现”。",
    )
    doc.add_paragraph(
        "主题二可以作为方法章节或独立的稳健短项目，用来证明“优势结构”比单一总经济更丰富。"
        "主题三适合作为第二篇独立报告或演示文稿，因为它拥有最清楚的策略叙事与可视化结构。"
    )

    doc.add_heading("5.2 组合成统一研究计划", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "第一部分回答“优势在哪里”：比较上路和其他位置的经济领先转化。",
            "第二部分回答“优势如何形成”：区分经验、补刀和击杀型领先。",
            "第三部分回答“价值是否已兑现”：比较小龙、先锋和巢虫在控制经济后的剩余信息。",
        ],
    )
    add_callout(
        doc,
        "统一标题建议：",
        "《早期优势的结构：2026年职业英雄联盟中领先位置、形成方式与资源兑现的胜负关联》",
        PALE_GOLD,
    )

    doc.add_heading("5.3 建议执行时间表", level=2)
    add_table(
        doc,
        ["阶段", "建议用时", "核心任务", "交付物"],
        [
            ("数据冻结", "1周", "固定日期、联赛及排除口径；建立数据字典", "可复现分析表"),
            ("描述分析", "1–2周", "分布、相关性、赛区和版本对比", "图表与异常清单"),
            ("主模型", "2周", "逻辑回归、交互项和系数对比", "核心结果表"),
            ("稳健性", "2周", "替代定义、队伍效应、2025验证", "稳健性附录"),
            ("写作展示", "2周", "报告、图表和演示叙事", "最终报告与PPT"),
        ],
        [1400, 1400, 3600, 2960],
        numeric_cols=(1,),
    )

    doc.add_heading("6. 结论", level=1)
    doc.add_paragraph(
        "本次探索最重要的发现不是某一个变量的显著性，而是三个题目共同指向同一件事："
        "职业比赛中的早期优势具有结构。相同数量的金币，如果出现在不同位置、由不同方式形成，"
        "或绑定不同类型的地图资源，其最终胜负含义可能明显不同。"
    )
    doc.add_paragraph(
        "其中，重点联赛的上路领先悖论最符合现有项目积累；经济领先质量最适合严谨的统计训练；"
        "中立资源剩余价值最适合面向观众讲述。三者均具备发展为正式研究的条件，"
        "但在进入因果解释前，都需要队伍、英雄、版本及赛区层面的进一步控制和跨年度验证。"
    )

    doc.add_heading("附录A：核心模型公式", level=1)
    formulas = [
        (
            "主题一",
            "logit(P(BlueWin)) = β0 + β1 TopGoldDiff15 + β2 NonTopGoldDiff15 + β3 FocusLeague×TopGoldDiff15 + β4 FocusLeague×NonTopGoldDiff15 + League FE + Patch FE",
        ),
        (
            "主题二",
            "logit(P(BlueWin)) = β0 + β1 GoldDiff15 + β2 XPDiff15 + β3 CSDiff15 + β4 KillDiff15 + League FE + Patch FE",
        ),
        (
            "主题三",
            "logit(P(BlueWin)) = β0 + β1 GoldDiff15 + β2 FirstDragon + β3 FirstHerald + β4 GrubDiff + League FE + Patch FE",
        ),
    ]
    for label, formula in formulas:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(label + "：")
        set_run_font(r, size=10, color=DARK_BLUE, bold=True)
        r = p.add_run(formula)
        set_run_font(r, size=9.5, color=INK)

    doc.add_heading("附录B：复现说明", level=1)
    doc.add_paragraph(
        "报告数字与图表由同文件夹中的《生成研究主题报告.py》读取"
        "《topics/数据/原始数据/2026年非中国赛区比赛数据.csv》后自动计算生成。"
        "后续数据更新时，应先重新执行中国相关比赛筛选，再运行该脚本，"
        "并记录新的数据截止日期，避免把不同时间点的结果混合。"
    )

    doc.save(REPORT_FILE)


def main():
    analysis = prepare_data()
    build_charts(analysis)
    build_report(analysis)
    print(REPORT_FILE)


if __name__ == "__main__":
    main()
