#!/usr/bin/env python3
"""Build the 43,037-match enhanced final report without deleting legacy content."""
from __future__ import annotations

import re
import textwrap
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "蓝方优势完整分析报告_最终版.md"
OUTPUT = HERE / "蓝方优势完整分析报告_最终增强版_含Elo详解.docx"

FONT = "Noto Sans CJK SC"
NAVY = "17365D"
BLUE = "2F5597"
TEXT = "202938"
MID_GREY = "667085"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREY = "F2F4F7"
PALE_BLUE = "EEF5FB"
BORDER = "98A2B3"
TABLE_DXA = 10150


def set_run_font(run, size=None, bold=None, italic=None, color=None, mono=False, strike=None):
    name = "Courier New" if mono else FONT
    run.font.name = name
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if strike is not None:
        run.font.strike = strike
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    fonts.set(qn("w:ascii"), name)
    fonts.set(qn("w:hAnsi"), name)
    fonts.set(qn("w:eastAsia"), FONT)
    fonts.set(qn("w:cs"), name)


def set_style_font(style, size, bold=False, color=None, italic=False):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.italic = italic
    if color:
        style.font.color.rgb = RGBColor.from_string(color)
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)


def set_cell_margins(cell, top=78, start=92, bottom=78, end=92):
    tcpr = cell._tc.get_or_add_tcPr()
    tcm = tcpr.first_child_found_in("w:tcMar")
    if tcm is None:
        tcm = OxmlElement("w:tcMar")
        tcpr.append(tcm)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcm.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tcm.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcpr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_borders(cell, color=BORDER, size=5):
    tcpr = cell._tc.get_or_add_tcPr()
    borders = tcpr.find(qn("w:tcBorders"))
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tcpr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = borders.find(qn(f"w:{edge}"))
        if tag is None:
            tag = OxmlElement(f"w:{edge}")
            borders.append(tag)
        tag.set(qn("w:val"), "single")
        tag.set(qn("w:sz"), str(size))
        tag.set(qn("w:color"), color)


def set_keep(paragraph, together=False):
    ppr = paragraph._p.get_or_add_pPr()
    if ppr.find(qn("w:keepNext")) is None:
        ppr.append(OxmlElement("w:keepNext"))
    if together and ppr.find(qn("w:keepLines")) is None:
        ppr.append(OxmlElement("w:keepLines"))


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    set_run_font(run, 8, color=MID_GREY)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    paragraph._p.append(fld)


def clean_markdown_escapes(text):
    return (text.replace("\\<", "<").replace("\\>", ">")
                .replace("\\[", "[").replace("\\]", "]")
                .replace("\\_", "_"))


def add_inline(paragraph, text, default_size=9.5, color=TEXT):
    text = clean_markdown_escapes(text.replace("  ", " "))
    pattern = r"(\*\*.*?\*\*|~~.*?~~|`.*?`|(?<!\*)\*[^*]+?\*(?!\*))"
    for token in re.split(pattern, text):
        if not token:
            continue
        if token.startswith("**") and token.endswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, default_size, bold=True, color=color)
        elif token.startswith("~~") and token.endswith("~~"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, default_size, color=MID_GREY, strike=True)
        elif token.startswith("`") and token.endswith("`"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, max(8, default_size - 0.5), mono=True, color="344054")
        elif token.startswith("*") and token.endswith("*"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, default_size, italic=True, color=color)
        else:
            run = paragraph.add_run(token)
            set_run_font(run, default_size, color=color)


def add_body_paragraph(doc, text, first_line=True):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.18
    if first_line:
        p.paragraph_format.first_line_indent = Pt(18)
    add_inline(p, text)
    return p


def add_callout(doc, lines, fill=LIGHT_BLUE):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    shade_cell(cell, fill)
    set_cell_margins(cell, top=110, start=150, bottom=110, end=150)
    cell.paragraphs[0]._element.getparent().remove(cell.paragraphs[0]._element)
    for line in lines:
        p = cell.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.line_spacing = 1.08
        add_inline(p, line, 9.1)
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)


def display_len(text):
    return sum(2 if ord(ch) > 127 else 1 for ch in text)


def compute_widths(rows, total=TABLE_DXA):
    ncols = len(rows[0])
    raw = []
    for j in range(ncols):
        longest = max(display_len(str(row[j])) for row in rows)
        raw.append(max(8, min(36, longest + 2)))
    if ncols >= 6:
        raw = [min(v, 19) for v in raw]
    denom = sum(raw)
    widths = [max(720, round(total * v / denom)) for v in raw]
    widths[-1] += total - sum(widths)
    return widths


def set_table_geometry(table, widths):
    tblpr = table._tbl.tblPr
    for node in list(tblpr.findall(qn("w:tblW"))):
        tblpr.remove(node)
    tw = OxmlElement("w:tblW")
    tw.set(qn("w:w"), str(sum(widths)))
    tw.set(qn("w:type"), "dxa")
    tblpr.append(tw)
    ind = tblpr.find(qn("w:tblInd"))
    if ind is None:
        ind = OxmlElement("w:tblInd")
        tblpr.append(ind)
    ind.set(qn("w:w"), "120")
    ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        for j, cell in enumerate(row.cells):
            tcw = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            if tcw is None:
                tcw = OxmlElement("w:tcW")
                cell._tc.get_or_add_tcPr().append(tcw)
            tcw.set(qn("w:w"), str(widths[min(j, len(widths) - 1)]))
            tcw.set(qn("w:type"), "dxa")


def add_table(doc, rows):
    ncols = len(rows[0])
    if any(len(row) != ncols for row in rows):
        raise ValueError(f"Inconsistent Markdown table width: {rows}")
    table = doc.add_table(rows=len(rows), cols=ncols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.style = "Table Grid"
    set_table_geometry(table, compute_widths(rows))
    font_size = 7.2 if ncols >= 7 else 7.7 if ncols >= 5 else 8.2
    for i, row in enumerate(rows):
        trpr = table.rows[i]._tr.get_or_add_trPr()
        trpr.append(OxmlElement("w:cantSplit"))
        if i == 0:
            repeat = OxmlElement("w:tblHeader")
            repeat.set(qn("w:val"), "true")
            trpr.append(repeat)
        for j, value in enumerate(row):
            cell = table.cell(i, j)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            set_cell_borders(cell)
            if i == 0:
                shade_cell(cell, NAVY)
            elif i % 2 == 0:
                shade_cell(cell, LIGHT_GREY)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if (j == 0 or ncols <= 3) else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            value = re.sub(r"\*\*(.*?)\*\*", r"\1", value.strip())
            value = re.sub(r"`(.*?)`", r"\1", value)
            value = clean_markdown_escapes(value)
            run = p.add_run(value)
            set_run_font(run, font_size, bold=(i == 0), color="FFFFFF" if i == 0 else TEXT)
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)


def add_code(doc, lines):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_geometry(table, [TABLE_DXA])
    cell = table.cell(0, 0)
    shade_cell(cell, "F6F8FA")
    set_cell_margins(cell, top=100, start=130, bottom=100, end=130)
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(0)
    wrapped = []
    for line in lines:
        wrapped.extend(textwrap.wrap(clean_markdown_escapes(line), width=92,
                                     break_long_words=False, break_on_hyphens=False) or [""])
    for idx, line in enumerate(wrapped):
        run = p.add_run(line)
        set_run_font(run, 7.7, mono=True, color="24292F")
        if idx != len(wrapped) - 1:
            run.add_break()
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)


def add_figure(doc, alt, src):
    path = (HERE / src).resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_together = True
    run = p.add_run()
    shape = run.add_picture(str(path), width=Inches(6.55))
    shape._inline.docPr.set("descr", alt)
    shape._inline.docPr.set("title", alt)
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(6)
    cap.paragraph_format.keep_with_next = False
    r = cap.add_run(alt)
    set_run_font(r, 8.2, italic=True, color=MID_GREY)


def configure_document(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)
    section.header_distance = Inches(0.30)
    section.footer_distance = Inches(0.30)

    normal = doc.styles["Normal"]
    set_style_font(normal, 9.5, color=TEXT)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.18
    set_style_font(doc.styles["Heading 1"], 14.5, True, NAVY)
    set_style_font(doc.styles["Heading 2"], 11.5, True, BLUE)
    for name in ("Heading 1", "Heading 2"):
        style = doc.styles[name]
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(10 if name == "Heading 1" else 7)
        style.paragraph_format.space_after = Pt(4)
    set_style_font(doc.styles["List Bullet"], 9.5, color=TEXT)
    set_style_font(doc.styles["List Number"], 9.5, color=TEXT)

    styles = doc.styles.element
    defaults = styles.find(qn("w:docDefaults"))
    rpr_default = defaults.find(qn("w:rPrDefault"))
    rpr = rpr_default.find(qn("w:rPr"))
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = header.add_run("Map Side vs Draft Timing · 43,037-Match Enhanced Final Report")
    set_run_font(r, 7.6, color=MID_GREY)
    add_page_number(section.footer.paragraphs[0])


def add_cover(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(78)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("《 》")
    set_run_font(r, 19, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("职业《英雄联盟》\n蓝方优势完整分析报告")
    set_run_font(r, 25, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(16)
    r = p.add_run("Map Side, Draft Timing, Team Strength, and Early-Game Pathways")
    set_run_font(r, 11.5, italic=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(34)
    r = p.add_run("43,037 场比赛 · 86,074 个 team-game\n2022-01-10 — 2026-06-02")
    set_run_font(r, 13, bold=True, color="344054")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(42)
    r = p.add_run("最终增强版 · 2026-07-15\n项目全过程、统计方法与识别边界")
    set_run_font(r, 10, color=MID_GREY)
    p.add_run().add_break(WD_BREAK.PAGE)


def is_special(line):
    stripped = line.strip()
    return (not stripped or stripped == "---" or line.startswith(("## ", "### ", ">", "```", "|", "!["))
            or re.match(r"^-\s+", line) or re.match(r"^\d+\.\s+", line)
            or stripped.startswith(("<figure", "</figure", "<figcaption", "</figcaption", "aria-hidden")))


def split_markdown_row(line):
    """Split table cells while preserving literal pipes inside inline code."""
    text = line.strip().strip("|")
    cells, current, in_code = [], [], False
    for char in text:
        if char == "`":
            in_code = not in_code
            current.append(char)
        elif char == "|" and not in_code:
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(char)
    cells.append("".join(current).strip())
    return cells


def parse_markdown(doc, text):
    lines = text.splitlines()
    i = 1  # cover replaces Markdown H1 title
    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if not stripped or stripped == "---":
            i += 1
            continue
        if stripped.startswith(("<figure", "</figure", "<figcaption", "</figcaption", "aria-hidden")):
            i += 1
            continue
        if line.startswith(">"):
            block = []
            while i < len(lines) and lines[i].startswith(">"):
                block.append(lines[i][1:].strip().rstrip("  "))
                i += 1
            add_callout(doc, [" ".join(block)])
            continue
        if line.startswith("## "):
            p = doc.add_paragraph(line[3:].strip(), style="Heading 1")
            set_keep(p)
            i += 1
            continue
        if line.startswith("### "):
            p = doc.add_paragraph(line[4:].strip(), style="Heading 2")
            set_keep(p)
            i += 1
            continue
        if line.startswith("```"):
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            i += 1
            add_code(doc, code)
            continue
        image_match = re.match(r"!\[(.*?)\]\((.*?)\)", line)
        if image_match:
            add_figure(doc, image_match.group(1), image_match.group(2))
            i += 1
            continue
        if line.startswith("|"):
            raw = []
            while i < len(lines) and lines[i].startswith("|"):
                raw.append(lines[i])
                i += 1
            rows = []
            for idx, row in enumerate(raw):
                cells = split_markdown_row(row)
                if idx == 1 and all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                    continue
                rows.append(cells)
            add_table(doc, rows)
            continue
        if re.match(r"^-\s+", line):
            while i < len(lines) and re.match(r"^-\s+", lines[i]):
                content = re.sub(r"^-\s+", "", lines[i]).strip()
                i += 1
                while i < len(lines) and lines[i].startswith("  ") and not re.match(r"^-\s+", lines[i]):
                    content += " " + lines[i].strip()
                    i += 1
                p = doc.add_paragraph(style="List Bullet")
                p.paragraph_format.space_after = Pt(2)
                add_inline(p, content)
            continue
        if re.match(r"^\d+\.\s+", line):
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i]):
                match = re.match(r"^(\d+)\.\s+(.*)", lines[i])
                number, content = match.group(1), match.group(2).strip()
                i += 1
                while i < len(lines) and (lines[i].startswith("    ") or lines[i].startswith("  ")):
                    content += " " + lines[i].strip()
                    i += 1
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(2)
                p.paragraph_format.left_indent = Pt(18)
                p.paragraph_format.first_line_indent = Pt(-18)
                add_inline(p, f"{number}.  {content}")
            continue

        para = [stripped.rstrip("  ")]
        i += 1
        while i < len(lines) and not is_special(lines[i]):
            para.append(lines[i].strip().rstrip("  "))
            i += 1
        add_body_paragraph(doc, " ".join(para))


def replace_paragraph(paragraph, new_text, size=9.5):
    for run in list(paragraph.runs):
        paragraph._p.remove(run._r)
    add_inline(paragraph, new_text, size)


def apply_identification_edits(doc):
    """Surgical wording changes: retain analyses and numbers, lower unsupported causal force."""
    edits = [
        ("4. 第二步：排除强队假象", "4. 第二步：控制队伍强度与强队选择"),
        ("这一步说明，蓝方优势不能简单解释为”强队更多站蓝方”。", "这一步说明，蓝方优势不能简单解释为“强队更多站蓝方”。控制强队因素后，蓝方与更高胜率之间仍存在稳定的条件关联；固定效应不能排除所有随时间变化的混杂。"),
        ("2026 年是唯一控制实力后蓝方 OR 明显缩小的年份", "2026 年是唯一控制实力后蓝方 OR 明显缩小的年份——这提示 First Selection 解耦后，“谁在蓝方”从分配转为队伍选择，原始蓝方胜率可能混入部分强队选择效应。控制 Elo 后仍留下方向为正、但更小的地图侧估计；职业队更常选择蓝方可视为偏好证据，但不能证明蓝方地图侧相对于先选权的因果价值。"),
        ("这一步把研究方向进一步缩小：蓝方优势的核心不在", "这一步把研究方向进一步缩小：在 2026 年联合模型中，地图侧的条件关联明显强于 firstPick；但选边由规则和队伍策略共同产生，因此不能把该系数解释为纯地图因果效应。"),
        ("6. 第四步：寻找地图侧带来的早期结构差异", "6. 第四步：寻找与地图侧相关的早期结构差异"),
        ("结果显示，蓝方最明显的结构优势集中在上半区", "结果显示，蓝方最明显的结构差异集中在上半区：蓝方拿首先锋的概率高约 19.2 个百分点，拿首塔的概率高约 8.5 个百分点，15 分钟经济也平均领先数百金币；与此同时，蓝方拿首龙的概率反而低约 19.7 个百分点。这说明蓝方并非与所有资源都同向相关，而是呈现偏上半区资源及后续经济转化的模式。"),
        ("早期结构差异本身还不是最终答案", "早期结构差异本身还不是最终答案，因为比赛胜负仍然取决于这些差异如何与后续状态共同变化。描述性中介分解逐步把早期目标、15 分钟经济和首塔加入胜负模型，观察 blue 系数被这些变量吸收多少。"),
        ("这个分解的含义是：蓝方优势中相当一部分可以通过", "这个分解表明，蓝方胜率差中相当一部分可由早期目标和 15 分钟经济的联合关联吸收，其中 15 分钟经济是最主要的可量化路径。换句话说，蓝方更容易在前 15 分钟形成经济领先，而经济领先与更高获胜概率显著相关；这仍不是严格的因果中介识别。"),
        ("2026-07 升级：路径分析＋自助法置信区间。", "2026-07 升级：描述性路径分析＋自助法置信区间。 上面的分解只有点估计，无法回答这些估计会不会只是抽样噪音。我们把分解表达为多中介路径分析（每条渠道的路径项 = 蓝方→渠道的条件关联 × 渠道→胜率的条件关联，在线性概率模型下可加），并对整局比赛重采样 600 次（蓝红两行始终一起抽，尊重镜像结构）得到 95% 置信区间。该方法量化抽样不确定性，但不自动满足顺序可忽略性等因果中介假设。以 2026 年为例："),
        ("2025 年结论相同", "2025 年结论相同（先锋 +2.5 [2.0, 2.9]，首龙 −2.8 [−3.3, −2.4]，残差 +2.0 [0.3, 3.6]）。核心渠道的 bootstrap 区间不含 0，说明这些路径项在当前样本和模型下较稳定；但区间不含 0 不等于已经识别因果中介效应。顺序分解与联合分解在 2025–2026 年的方向和相对大小接近，但渠道归属会随模型设定变化。"),
        ("先看 15 分钟经济差的组成。", "先看 15 分钟经济差的组成。首塔、一血、首先锋、首龙和虚空巢虫均与 15 分钟经济差显著相关，其中首塔和一血的条件关联尤其大，首先锋也呈稳定正向关联。"),
        ("这一步把前面的机制串起来", "这一步把前面的描述性路径串起来：地图侧与早期目标分配相关，早期目标和对线状态与 15 分钟经济差相关，15 分钟经济差又与最终胜负高度相关。"),
        ("进一步的反事实检查用来确认", "进一步的压力检查用来判断这条解释是否只是模型设定造成的自我循环。我们不仅观察蓝方胜率和领先状态，还检查控制部分早期局面后，蓝方与特定结构资源的关联是否仍存在，以及在关键经济差接近持平的样本中，蓝方估计是否衰减。"),
        ("2026-07 补充：满早期状态残差压力测试。", "2026-07 补充：满早期状态残差压力测试。 为检验可观测早期状态能吸收多少蓝方差异，我们把 Oracle’s Elixir 中可用的 15 分钟前状态一次性放入模型——首血、虚空巢虫、10 分钟经济差、10/15 分钟经验差，连同先锋、首龙、首塔和 15 分钟经济，共九条渠道。2024–2026 年仍留下总差异的 21%–37%。该剩余与未观测地图机制相容，但也可能来自策略选择、测量误差、函数形式和遗漏变量，不能直接命名为地图几何根因；Riot timeline 坐标数据是区分这些解释的重要下一步。"),
        ("11. 第九步：政策评估——First Selection 新规削弱蓝方优势了吗（DiD）", "11. 第九步：政策评估尝试——First Selection 新规削弱蓝方优势了吗（探索性 DiD）"),
        ("本报告 6 月版把 Difference-in-Differences", "本报告 6 月版把 Difference-in-Differences 列为下一步；这里保留一项探索性政策面板评估，检验新规后的赛区异质性是否与蓝方优势变化同向。由于所有赛区同时实施新规，且所谓“解耦度”来自政策实施后的队伍选择，本设计没有标准的未处理对照组。"),
        ("设计思路。 新规在 2026 年落地", "设计思路。 新规在 2026 年落地，各赛区观察到的解耦程度不同。我们构建赛区×赛季面板（2022–2026，23 个赛区），以各赛区蓝方胜率优势为结果变量，加入赛区与年份固定效应并按赛区聚类标准误。解耦度 D 只能视为政策后的行为指标，不是外生处理强度，因此交互系数描述异质性，不能直接解释为政策因果效果。"),
        ("结果：没有削弱的证据。", "结果：未检测到新规削弱蓝方优势的统计证据。"),
        ("主效应不显著，而且点估计是正的", "主交互项不显著，点估计为正；这表示当前面板没有显示“解耦越彻底、蓝方优势下降越多”的模式。首先锋率的次要结果同样不显著，但该结果不能验证设计，也不能证明新规有效或无效。"),
        ("诚实的限定。 事件研究显示", "诚实的限定。 事件研究显示 2024 年的政策前交互已经偏高（约 +3.7 pp，与 2026 年约 +4.8 pp 接近），平行趋势并不理想；加上面板只有 23 个赛区，这个 DiD 只能作为探索性关联，不能当作政策因果识别。更直接的描述性证据是：蓝方 OR 五年稳定，2026 年仍落在历史区间内；这说明样本中没有观察到明显断点，但不能证明反事实下新规完全没有作用。"),
        ("政策含义。 结合 §6–§8", "政策含义。 结果与一种解释相容：First Selection 主要改变谁获得地图侧或先选权，而未直接改变地图本身。若地图侧机制确实重要，仅重新分配选择权未必改变地图侧价值。但现有数据不能据此断言 Riot“拧错了旋钮”，也不能确定应修改目标刷新、地形或选秀流程；这些属于需要更强识别或规则实验检验的政策假设。"),
        ("第三，蓝方优势的主要机制是", "第三，蓝方胜率差中最清晰的描述性路径是早期地图结构、资源分配和经济转化。蓝方更容易拿首先锋、首塔，并在 15 分钟形成经济领先；15 分钟经济差也是胜负预测中信息量最大的变量之一。当 15 分钟经济接近持平时，蓝方估计基本消失。"),
        ("因此，这项研究最合理的解释不是", "因此，本研究支持的谨慎解释不是“蓝方天然必赢”，也不是“先选权决定胜负”，而是：蓝方地图侧与上半区早期资源及 15 分钟经济领先稳定相关，这条路径吸收了蓝方胜率差的大部分。它是当前数据下最有解释力的机制假设，但不是已经完成的严格因果证明。"),
        ("2026-07 版补充第四层结论", "2026-07 版补充第四层结论：先锋和首龙路径项的 bootstrap 区间不含 0，说明在当前模型下估计稳定；满早期状态模型仍留下 21%–37% 的差异。该剩余与地图几何解释相容，也可能包含选择、测量误差和遗漏状态。探索性 DiD 没有检测到 First Selection 后的明显削弱模式，但不能用于断言政策因果效果。"),
    ]

    matched = {old: 0 for old, _ in edits}
    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        for old, new in edits:
            if text == old or text.startswith(old):
                replace_paragraph(paragraph, new, 14.5 if paragraph.style.name == "Heading 1" else 9.5)
                matched[old] += 1
                break

    missing = [key for key, count in matched.items() if count == 0]
    if missing:
        raise RuntimeError("Identification edit targets not found: " + " | ".join(missing))

    # Future-work numbered items are intentionally retained, but their status is corrected.
    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        if re.match(r"1\.\s+把 2026", text):
            replace_paragraph(paragraph, "1.  探索性 DiD 面板与事件研究已完成（§11），但因缺少未处理组、解耦度属于政策后选择且预趋势不平坦，不能作为政策因果结论。")
        elif re.match(r"2\.\s+更正式的因果中介", text):
            replace_paragraph(paragraph, "2.  描述性路径分析与整簇 bootstrap 已完成（§7）；严格因果中介分析尚未完成，需要更强的时序、混杂控制与敏感性分析。经典潜变量 SEM 因无潜构念且多数变量为二元结果，不是首选。")
        elif re.match(r"3\.\s+引入 Riot API", text):
            replace_paragraph(paragraph, "3.  引入 Riot API 的 timeline、坐标、视野和事件级数据，区分打野路径、线权、河道视野和目标前站位，是解释 21%–37% 模型剩余的关键下一步；仍需处理路人局向职业比赛外推的问题。")
        elif re.match(r"5\.\s+counterpick", text):
            replace_paragraph(paragraph, "5.  counterpick、R5 价值支线已完成：十个估计与预设 ±10% odds 等效边界相容，但这不等于证明真实效应为零，也不能单独识别蓝方优势的地图根因。材料保存在其他/选秀迷思_已搁置/。")
        elif re.match(r"6\.\s+新增", text):
            replace_paragraph(paragraph, "6.  新增：正式论文写作时，将本报告的路径分析、探索性 DiD 和识别边界整理为投稿格式，并补充系统的 Related Work 与精确文献查重。")


def inject_boundary_callout(text):
    marker = "\n## 1. 研究目的"
    note = ("\n> **识别边界提示**：本报告完整保留固定效应、dummy variables、LPM、Logistic、机器学习、路径分析、bootstrap 与 DiD 等项目过程。"
            "路径分解用于描述拟合差异，不能自动识别因果中介；DiD 因没有未处理组、处理强度是政策后选择且预趋势不平坦，只作为探索性政策面板分析。\n")
    if marker not in text:
        raise RuntimeError("Cannot locate section 1 marker")
    return text.replace(marker, note + marker, 1)


def inject_elo_detail(text):
    """Add a reproducible explanation of the Elo control without deleting legacy text."""
    marker = (
        "Elo\n本身预测力很强（实力差每一个标准差，胜算比约\n"
        "2.15），说明这是一个有意义的控制变量。"
    )
    detail = r'''

### Elo 控制的具体构造

1.  **分组与起点。** 每支队伍在每一个“赛区 × 赛季”内从 1500 分开始。1500 只是共同锚点，不是测量出来的真实实力；Elo 是相对评分，因此真正进入计算的是双方分差，而不是绝对分数。
2.  **按时间顺序处理。** 同一个赛区、同一个赛季内，比赛按日期和 gameid 排序。每场比赛开始前，先保存蓝红双方当时的 Elo；本场赛果只用于赛后更新，绝不会反过来进入本场的赛前评分。
3.  **计算预期胜率。** 若本队赛前评分为 R_i、对手为 R_j，则本队的 Elo 预期胜率为：

```
E_i = 1 / (1 + 10^((R_j - R_i) / 400))
```

4.  **赛后更新。** 本项目取 K=24；S_i=1 表示获胜、S_i=0 表示失利。更新公式为：

```
R_i(new) = R_i(old) + 24 × (S_i - E_i)
```

因此，强队按预期战胜弱队时分数变化较小，弱队爆冷击败强队时变化较大。双方的更新量一正一负，保持相对评分体系。

5.  **生成回归变量。** 对每一条 team-game 记录构造 `rating_diff = 本队赛前 Elo - 对手赛前 Elo`，再在全样本中标准化为 `z(rating_diff)`。胜负模型为：

```
logit[P(win=1)] = α + β_blue × blue + β_Elo × z(rating_diff)
```

标准误按 gameid 聚类，使同一场比赛的蓝、红两条镜像记录被视为同一簇。于是 β_blue 的含义是：在赛前 Elo 实力差相同的条件下，蓝方相对于红方的条件胜算差异。模型中 Elo 实力差每增加 1 个标准差（本样本约 90 Elo 分），获胜 OR 约为 2.15，说明该控制变量确实携带了明显的赛前实力信息。

### Elo 与 team-season fixed effects 的本质区别

| 比较维度 | Team-season fixed effects | Elo 控制 |
|---|---|---|
| 实力表示 | 每支队伍每赛季一个固定标签，由一组 dummy variables 吸收 | 每场比赛前都有一个动态评分 |
| 时间变化 | 默认同队在同一赛季内的未观测基准实力不变 | 随比赛结果逐场更新，可反映赛季中途变化 |
| 对手处理 | 若要显式控制对手，还需加入 opponent fixed effects | `rating_diff` 天然同时包含本队与当日对手的评分 |
| 函数假设 | 对队伍-赛季身份较灵活，但需要大量 dummy | 假设实力可压缩为单一分数，并按 Elo 公式演化 |
| 识别来源 | 同一队伍同一赛季内部的蓝方场与红方场比较 | 在赛前评分差相近的对局之间比较蓝方与红方 |
| 主要代价 | 参数多，且把赛季内实力近似为静态 | 参数少但存在冷启动、K 值选择和评分误差 |

一句话概括：固定效应控制的是“这支队伍在这个赛季是谁”，Elo 控制的是“它在这一天面对这个对手时有多强”。两种方法的假设和弱点互补：team-season FE、队伍加对手 FE 和赛前 Elo 控制都没有使蓝方估计整体消失，因此“强队更常处在蓝方”不足以解释全部结果。不过，这些模型只能减少队伍实力混杂，不能保证所有随时间变化的实力、阵容、版本和选边策略都已被完全控制，也不能单独证明地图侧的因果效应。

### 初始 Elo、冷启动与稳健性边界

所有队伍从 1500 开始，并不意味着研究者知道它们开季时一样强。因为模型只使用分差，所以把所有初始分统一改成 1000 或 2000，不会改变任何预期胜率、更新量或 `rating_diff`。真正的局限是开季前几场：系统尚未从历史结果中学到强弱，双方评分常接近 1500，Elo 控制在这一阶段较弱。具体需要多少场才能稳定取决于 K 值、对手强度和赛程，不能机械地认定固定为 10 或 15 场。

冷启动造成的是赛前实力代理变量的测量误差，通常会削弱 Elo 的控制能力，但其对 blue 系数的偏差方向不能在没有额外假设时预先确定。因此，不能把“冷启动下仍然显著”本身当作因果证明。更可靠的判断来自多种控制的共同证据：没有 Elo 冷启动形式的 team-season FE 给出相近方向；Elo 对胜负有较强预测力；并且逐年结果能显示 2026 年选边机制变化带来的选择效应。

可追加的稳健性检验包括：用上赛季末评分热启动；删除每队或每个赛区-赛季最初若干场作为 burn-in；检验不同 K 值；或者使用带评分不确定度的 Glicko。热启动可能把换人和版本变化后的旧实力带入新赛季，因此这些做法应作为敏感性分析，而不是自动更正确的替代方案。
'''.strip()
    if marker not in text:
        raise RuntimeError("Cannot locate Elo introduction marker")
    return text.replace(marker, marker + "\n\n" + detail, 1)


def correct_source_version_note(text):
    text = text.replace("因果推断扩展", "机制路径与政策识别扩展")
    text = text.replace("First Selection 新规的 DiD 政策评估", "First Selection 新规的探索性 DiD 政策评估尝试")
    text = text.replace("导致 §4/§7/§10/§11 因果扩展当时基于 84,548 个 team-game 的样本。", "导致后来追加章节一度误用较小样本。")
    text = text.replace("（2026-07-14 曾出现一版基于 42,274 局的外部改写版，已存档于 `../归档/历史改写版_20260714/`，不作为结论来源。）", "（2026-07-14 的错误外部改写版已单独归档，不作为结论来源。）")
    return text


def main():
    source_text = correct_source_version_note(SOURCE.read_text(encoding="utf-8"))
    doc = Document()
    configure_document(doc)
    add_cover(doc)
    parse_markdown(doc, inject_elo_detail(inject_boundary_callout(source_text)))
    apply_identification_edits(doc)

    props = doc.core_properties
    props.title = "职业《英雄联盟》蓝方优势完整分析报告——最终增强版"
    props.subject = "43,037-match project-process report with statistical methods and identification boundaries"
    props.author = "Vincent"
    props.keywords = "League of Legends; map side; team-season fixed effects; LPM; Logistic; bootstrap; DiD"
    props.comments = "43,037 games; LPLOL retained; LPL/LDL excluded by exact match."

    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
