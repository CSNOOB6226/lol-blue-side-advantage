#!/usr/bin/env python3
"""Build a standalone companion manual for interpreting the blue-side report."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from build_teaching_final_report import (
    FIGURE_EXPLANATIONS,
    GLOSSARY,
    TABLE_EXPLANATIONS,
)


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "蓝方优势报告_统计知识与表格解读手册_2026-07-15.docx"
FONT = "Noto Sans CJK SC"
NAVY = "0B2545"
BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
TEXT = "202938"
MUTED = "667085"
LIGHT = "F4F6F9"
TABLE_FILL = "E8EEF5"
BORDER = "B8C2CC"
GOLD = "7A5A00"
WIDTH_DXA = 9360
INDENT_DXA = 120


TABLE_GROUPS = [
    ("A. 数据基础与研究设计", [1, 2]),
    ("B. 第一步：确认蓝方优势是否存在", [3]),
    ("C. 第二步：控制队伍强度与强队选择", [4, 5]),
    ("D. 第三步：拆开先选权和地图侧", [6, 7, 8]),
    ("E. 第四步：寻找早期结构差异", [9]),
    ("F. 第五步：资源与经济路径", [10, 11, 12]),
    ("G. 第六步：经济链条检查", [13, 14]),
    ("H. 第七步：机器学习验证", [15, 16, 17]),
    ("I. 第八步：稳健性与机制边界", [18, 19, 20]),
    ("J. 第九步：探索性政策评估", [21]),
    ("K. 附表与方法索引", [22, 23]),
]


def set_run_font(run, size=None, bold=None, italic=None, color=None, mono=False):
    name = "Courier New" if mono else FONT
    run.font.name = name
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    fonts.set(qn("w:ascii"), name)
    fonts.set(qn("w:hAnsi"), name)
    fonts.set(qn("w:eastAsia"), FONT)
    fonts.set(qn("w:cs"), name)


def set_style_font(style, size, color=TEXT, bold=False):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string(color)
    style.font.bold = bold
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)


def set_keep(paragraph, next_paragraph=True, lines=True):
    ppr = paragraph._p.get_or_add_pPr()
    if next_paragraph and ppr.find(qn("w:keepNext")) is None:
        ppr.append(OxmlElement("w:keepNext"))
    if lines and ppr.find(qn("w:keepLines")) is None:
        ppr.append(OxmlElement("w:keepLines"))


def shade_paragraph(paragraph, fill):
    ppr = paragraph._p.get_or_add_pPr()
    shd = ppr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        ppr.append(shd)
    shd.set(qn("w:fill"), fill)


def left_border(paragraph, color=BLUE, size=16, space=7):
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    node = pbdr.find(qn("w:left"))
    if node is None:
        node = OxmlElement("w:left")
        pbdr.append(node)
    node.set(qn("w:val"), "single")
    node.set(qn("w:sz"), str(size))
    node.set(qn("w:space"), str(space))
    node.set(qn("w:color"), color)


def add_page_field(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    paragraph._p.append(field)


def mark_repeat_header(row):
    trpr = row._tr.get_or_add_trPr()
    header = trpr.find(qn("w:tblHeader"))
    if header is None:
        header = OxmlElement("w:tblHeader")
        trpr.append(header)
    header.set(qn("w:val"), "true")


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tcpr = cell._tc.get_or_add_tcPr()
    tcm = tcpr.find(qn("w:tcMar"))
    if tcm is None:
        tcm = OxmlElement("w:tcMar")
        tcpr.append(tcm)
    for side, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcm.find(qn(f"w:{side}"))
        if node is None:
            node = OxmlElement(f"w:{side}")
            tcm.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcpr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_borders(cell, color=BORDER, size=5):
    tcpr = cell._tc.get_or_add_tcPr()
    borders = tcpr.find(qn("w:tcBorders"))
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tcpr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        node = borders.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            borders.append(node)
        node.set(qn("w:val"), "single")
        node.set(qn("w:sz"), str(size))
        node.set(qn("w:color"), color)


def set_table_geometry(table, widths):
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    tblpr = table._tbl.tblPr
    tblw = tblpr.find(qn("w:tblW"))
    if tblw is None:
        tblw = OxmlElement("w:tblW")
        tblpr.append(tblw)
    tblw.set(qn("w:w"), str(sum(widths)))
    tblw.set(qn("w:type"), "dxa")
    tblind = tblpr.find(qn("w:tblInd"))
    if tblind is None:
        tblind = OxmlElement("w:tblInd")
        tblpr.append(tblind)
    tblind.set(qn("w:w"), str(INDENT_DXA))
    tblind.set(qn("w:type"), "dxa")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        trpr = row._tr.get_or_add_trPr()
        cant_split = trpr.find(qn("w:cantSplit"))
        if cant_split is None:
            trpr.append(OxmlElement("w:cantSplit"))
        for cell, width in zip(row.cells, widths):
            tcpr = cell._tc.get_or_add_tcPr()
            tcw = tcpr.find(qn("w:tcW"))
            if tcw is None:
                tcw = OxmlElement("w:tcW")
                tcpr.append(tcw)
            tcw.set(qn("w:w"), str(width))
            tcw.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            set_cell_borders(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def configure_document(doc):
    section = doc.sections[0]
    doc.settings.odd_and_even_pages_header_footer = True
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    normal = doc.styles["Normal"]
    set_style_font(normal, 11, TEXT)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    h1 = doc.styles["Heading 1"]
    set_style_font(h1, 16, BLUE, True)
    h1.paragraph_format.space_before = Pt(18)
    h1.paragraph_format.space_after = Pt(10)
    h1.paragraph_format.keep_with_next = True

    h2 = doc.styles["Heading 2"]
    set_style_font(h2, 13, BLUE, True)
    h2.paragraph_format.space_before = Pt(14)
    h2.paragraph_format.space_after = Pt(7)
    h2.paragraph_format.keep_with_next = True

    h3 = doc.styles["Heading 3"]
    set_style_font(h3, 12, DARK_BLUE, True)
    h3.paragraph_format.space_before = Pt(10)
    h3.paragraph_format.space_after = Pt(5)
    h3.paragraph_format.keep_with_next = True

    if "Manual Label" not in doc.styles:
        label = doc.styles.add_style("Manual Label", WD_STYLE_TYPE.PARAGRAPH)
    else:
        label = doc.styles["Manual Label"]
    set_style_font(label, 10.5, DARK_BLUE, True)
    label.paragraph_format.space_before = Pt(3)
    label.paragraph_format.space_after = Pt(2)
    label.paragraph_format.keep_with_next = True

    if "Manual Detail" not in doc.styles:
        detail = doc.styles.add_style("Manual Detail", WD_STYLE_TYPE.PARAGRAPH)
    else:
        detail = doc.styles["Manual Detail"]
    set_style_font(detail, 10.5, TEXT)
    detail.paragraph_format.space_before = Pt(0)
    detail.paragraph_format.space_after = Pt(5)
    detail.paragraph_format.line_spacing = 1.25
    detail.paragraph_format.left_indent = Inches(0.12)

    for header in (section.header.paragraphs[0], section.even_page_header.paragraphs[0]):
        header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run = header.add_run("蓝方优势报告 · 统计知识与表格解读手册")
        set_run_font(run, 8.3, color=MUTED)
    add_page_field(section.footer.paragraphs[0])
    add_page_field(section.even_page_footer.paragraphs[0])

    defaults = doc.styles.element.find(qn("w:docDefaults"))
    rpr_default = defaults.find(qn("w:rPrDefault"))
    rpr = rpr_default.find(qn("w:rPr"))
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)


def add_cover(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(108)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("COMPANION HANDBOOK")
    set_run_font(run, 10, bold=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(20)
    p.paragraph_format.space_after = Pt(10)
    run = p.add_run("蓝方优势报告\n统计知识与表格解读手册")
    set_run_font(run, 29, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(44)
    run = p.add_run("逐表理解 · 统计概念 · 结果解读")
    set_run_font(run, 14, italic=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("配套主报告：43,037 场比赛 / 86,074 个 team-game")
    set_run_font(run, 11.5, bold=True, color=DARK_BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(54)
    run = p.add_run("2026 年 7 月 15 日")
    set_run_font(run, 12, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(24)
    p.paragraph_format.left_indent = Inches(0.45)
    p.paragraph_format.right_indent = Inches(0.45)
    shade_paragraph(p, LIGHT)
    left_border(p)
    run = p.add_run(
        "定位说明｜本手册只解释主报告中的统计知识、23 张数据表和 9 张图，不替代、不覆盖主报告。"
    )
    set_run_font(run, 10.5, color=TEXT)
    p.add_run().add_break(WD_BREAK.PAGE)


def add_labeled(doc, label, text, fill=None, caution=False):
    p = doc.add_paragraph(style="Manual Label")
    if fill:
        shade_paragraph(p, fill)
        left_border(p, color=GOLD if caution else BLUE)
    run = p.add_run(label)
    set_run_font(run, 10.5, bold=True, color=GOLD if caution else DARK_BLUE)
    set_keep(p)
    p = doc.add_paragraph(style="Manual Detail")
    if fill:
        shade_paragraph(p, fill)
    run = p.add_run(text)
    set_run_font(run, 10.5, color=TEXT)
    return p


def add_intro(doc):
    doc.add_paragraph("1. 这本手册怎么用", style="Heading 1")
    p = doc.add_paragraph(
        "打开主报告看到某张表时，先按表号在本手册中找到对应条目。每个条目固定回答六个问题："
        "这张表在回答什么、用了什么统计知识、应该怎么看、关键结论是什么、哪些话不能说、汇报时怎么表达。"
    )
    set_keep(p, next_paragraph=False)

    add_labeled(
        doc,
        "统计结果的通用解读结构",
        "先说研究问题；再说为什么使用该方法；随后报告效应大小、95% CI 与 p 值；"
        "最后说明《英雄联盟》中的实际含义和识别边界。",
        LIGHT,
    )
    add_labeled(
        doc,
        "三种结论要分开",
        "描述性结论回答“样本里发生了什么”；预测结论回答“新比赛里能否排序胜负”；"
        "因果结论回答“如果人为改变某因素，结果会怎样”。显著 p 值、固定效应或机器学习都不能单独把描述升级为因果。",
        LIGHT,
    )


def add_or_worked_example(doc):
    doc.add_paragraph("2. 完整示范：胜率 95% CI 与 OR 怎么算", style="Heading 1")
    p = doc.add_paragraph(
        "以主报告表 3 的 2022 年为例：局数 n=10,641，蓝方胜率 p̂=0.523。"
        "这一页示范四个常用统计概念。"
    )
    set_keep(p, next_paragraph=False)

    add_labeled(
        doc,
        "第一步｜胜率标准误",
        "SE(p̂)=√[p̂(1-p̂)/n]≈√[0.523×0.477/10,641]≈0.00484。"
        "它衡量蓝方胜率估计在重复抽样中的波动，不是比赛胜负本身的标准差。",
        LIGHT,
    )
    add_labeled(
        doc,
        "第二步｜胜率 95% CI",
        "p̂±1.96×SE≈0.523±1.96×0.00484≈[0.5135, 0.5325]，"
        "按表格精度显示为约 51.3%–53.2%。整个区间高于 50%，支持蓝方胜率高于无差异基准。",
        LIGHT,
    )
    add_labeled(
        doc,
        "第三步｜胜算与 OR",
        "蓝方胜算=0.523/0.477≈1.096；红方胜算=0.477/0.523≈0.912；"
        "OR=1.096/0.912≈1.202。它表示蓝方胜算约比红方高 20.2%，不是胜率高 20.2 个百分点。",
        LIGHT,
    )
    add_labeled(
        doc,
        "第四步｜OR 的 95% CI",
        "Logistic 回归中 OR=e^β，区间为 e^(β±1.96×SEβ)。本报告按 gameid 聚类标准误，"
        "得到 2022 年 OR 95% CI 为 1.114–1.297。整个区间高于 1，因此胜算差异显著。",
        LIGHT,
    )
    add_labeled(
        doc,
        "最容易说错的地方",
        "95% CI 不是“真实参数有 95% 概率在区间里”；p<0.001 也不是“结论有 99.9% 概率为真”。",
        "FFF8E8",
        caution=True,
    )


def add_table_index(doc):
    doc.add_paragraph("3. 原报告表格索引", style="Heading 1")
    p = doc.add_paragraph(
        "索引只列出表号和用途；完整数字仍以主报告为准。LPLOL 的 763 场比赛保留在主报告表 22 中。"
    )
    set_keep(p, next_paragraph=False)

    rows = [["表号", "所属步骤", "表格主题"]]
    group_name_by_table = {}
    for group, numbers in TABLE_GROUPS:
        for number in numbers:
            group_name_by_table[number] = group
    for number, info in enumerate(TABLE_EXPLANATIONS, start=1):
        rows.append([str(number), group_name_by_table[number], info["title"]])

    table = doc.add_table(rows=len(rows), cols=3)
    set_table_geometry(table, [720, 3240, 5400])
    mark_repeat_header(table.rows[0])
    for row_index, row in enumerate(rows):
        for col_index, value in enumerate(row):
            cell = table.cell(row_index, col_index)
            if row_index == 0:
                shade_cell(cell, TABLE_FILL)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if col_index == 0 else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(0)
            run = p.add_run(value)
            set_run_font(run, 9.2, bold=row_index == 0, color=NAVY if row_index == 0 else TEXT)


def add_table_manual(doc):
    doc.add_paragraph("4. 逐表解读", style="Heading 1")
    p = doc.add_paragraph(
        "下面按主报告顺序解释 23 张表。这里只保留理解和汇报所需的关键数字，不复制主报告全文。"
    )
    set_keep(p, next_paragraph=False)

    for group_name, numbers in TABLE_GROUPS:
        doc.add_paragraph(group_name, style="Heading 2")
        for number in numbers:
            info = TABLE_EXPLANATIONS[number - 1]
            doc.add_paragraph(f"表 {number}｜{info['title']}", style="Heading 3")
            add_labeled(doc, "这张表回答什么", info["purpose"])
            add_labeled(doc, "统计知识", info["knowledge"])
            add_labeled(doc, "怎么读", info["read"])
            add_labeled(doc, "关键结论", info["result"], LIGHT)
            add_labeled(
                doc,
                "不能过度解释",
                info["caution"],
                "FFF8E8",
                caution=True,
            )
            add_labeled(doc, "汇报时可以说", info["script"], LIGHT)


def add_figure_manual(doc):
    doc.add_paragraph("5. 逐图解读", style="Heading 1")
    p = doc.add_paragraph(
        "图形主要帮助识别方向、变化趋势和不确定性。读图时先找横轴、纵轴、基准线和误差线，再看点估计。"
    )
    set_keep(p, next_paragraph=False)

    for index, info in enumerate(FIGURE_EXPLANATIONS, start=1):
        heading = doc.add_paragraph(f"图 {index}｜{info['title']}", style="Heading 2")
        if index == 6:
            heading.paragraph_format.page_break_before = True
        add_labeled(doc, "怎么看图", info["read"])
        add_labeled(doc, "图中结论", info["result"], LIGHT)
        add_labeled(
            doc,
            "不能过度解释",
            info["caution"],
            "FFF8E8",
            caution=True,
        )


def add_glossary(doc):
    doc.add_paragraph("6. 统计知识速查", style="Heading 1")
    p = doc.add_paragraph(
        "汇报时不必背诵全部公式，但必须能说清楚：指标测量什么、无差异基准是什么、什么结论可以说、什么结论不能说。"
    )
    set_keep(p, next_paragraph=False)

    for term, explanation in GLOSSARY:
        heading = doc.add_paragraph(style="Heading 2")
        heading.paragraph_format.space_before = Pt(6)
        heading.paragraph_format.space_after = Pt(2)
        heading.paragraph_format.line_spacing = 1.0
        run = heading.add_run(term)
        set_run_font(run, 11.5, bold=True, color=BLUE)
        p = doc.add_paragraph(explanation)
        p.paragraph_format.left_indent = Inches(0.1)
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(4)


def add_final_checklist(doc):
    doc.add_paragraph("7. 汇报前一分钟检查", style="Heading 1")
    checks = [
        ("样本", "43,037 场比赛；86,074 个 team-game；LPLOL 保留；LPL/LDL 精确排除。"),
        ("效应大小", "先说胜率差或 pp，再说 OR；不要只报 p 值。"),
        ("不确定性", "CI 看是否跨无差异基准：胜率看 50%，OR 看 1，路径项看 0。"),
        ("统计与实战", "统计显著不等于实战一定重要；要把金币、目标和胜率差联系到游戏情境。"),
        ("因果边界", "固定效应、路径分析、SHAP、bootstrap 和探索性 DiD 都不能自动证明因果。"),
        ("回答顺序", "问题 → 方法 → 数字 → 游戏含义 → 限制。"),
    ]
    for label, text in checks:
        add_labeled(doc, label, text, LIGHT)


def set_properties(doc):
    props = doc.core_properties
    props.title = "蓝方优势报告统计知识与表格解读手册"
    props.subject = "43,037 场职业英雄联盟蓝方优势报告的独立伴随手册"
    props.author = "Vincent"
    props.keywords = "蓝方优势; 统计手册; 95% CI; OR; LPM; Logistic; fixed effects; bootstrap; DiD"
    props.comments = "独立伴随手册；不覆盖主报告；日期 2026年7月15日。"
    props.modified = datetime(2026, 7, 15, 16, 0, 0)


def main():
    doc = Document()
    configure_document(doc)
    add_cover(doc)
    add_intro(doc)
    add_or_worked_example(doc)
    add_table_index(doc)
    add_table_manual(doc)
    add_figure_manual(doc)
    add_glossary(doc)
    add_final_checklist(doc)
    set_properties(doc)
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
