#!/usr/bin/env python3
"""Create the pedagogical final report from the retained 43,037-match DOCX."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from docx.text.paragraph import Paragraph

import build_enhanced_final_report as base


HERE = Path(__file__).resolve().parent
REFERENCE = HERE / "蓝方优势完整分析报告_最终增强版.docx"
OUTPUT = HERE / "蓝方优势完整分析报告最终版.docx"


STEP_GUIDES = {
    "1. 研究目的": [
        ("研究路线", "整份报告按“优势是否存在 → 是否由强队选择造成 → 地图侧与先选权能否拆开 → 早期资源和经济路径 → 预测验证 → 稳健性 → 政策评估”的顺序推进。"),
        ("最重要的区分", "描述性结果回答“数据里发生了什么”；预测模型回答“哪些变量能预测胜负”；只有满足更强识别条件的设计才能回答“某因素是否造成了结果”。本报告会明确区分这三层。"),
    ],
    "2. 数据从哪里开始": [
        ("本步问题", "先确认样本是谁、每一行代表什么，以及哪些观测并不独立。统计方法是否正确，首先取决于分析单位是否定义正确。"),
        ("核心知识", "43,037 场比赛被展开为 86,074 个 team-game；同一场的蓝红两行互为镜像，因此回归标准误按 gameid 聚类。样本量 N 是进入某项分析的有效观测数，缺失值会使不同表格的 N 略有不同。"),
    ],
    "3. 第一步：确认蓝方优势是否存在": [
        ("本步问题", "不加入复杂控制变量，先检验蓝方总体胜率是否稳定高于无优势基准 50%。"),
        ("核心知识", "这里使用样本比例、标准误、95% 置信区间、胜算 odds、胜算比 OR、Logistic 回归和 p 值。胜率区间是否跨过 50%，对应 OR 区间是否跨过 1。"),
        ("汇报重点", "先报告效应大小，再报告不确定性：蓝方胜率高约 5.8 个百分点；五个赛季的置信区间都在 50% 以上，OR 区间也都在 1 以上。"),
    ],
    "4. 第二步：控制队伍强度与强队选择": [
        ("本步问题", "蓝方优势是否只是因为强队更常出现在蓝方，或者蓝方样本中强队比例更高？"),
        ("核心知识", "LPM 直接估计胜率百分点差；team-season dummy variables 和固定效应比较同一队伍同一赛季内的蓝红表现；对手固定效应和赛前 Elo 进一步控制对手与实力差。"),
        ("识别边界", "控制后系数仍为正，说明“强队构成”不能完全解释结果；但固定效应无法消除所有随比赛变化的策略、阵容和状态混杂，因此仍应称为条件关联。"),
    ],
    "5. 第三步：拆开先选权和地图侧": [
        ("本步问题", "蓝方通常同时拥有先选权。2026 年 First Selection 解耦后，可以把地图侧 blue 与 firstPick 同时放进模型，观察谁提供独立信息。"),
        ("核心知识", "四格交叉表展示两个二元变量的联合分布；多变量 Logistic 回归给出“控制另一个变量后”的 OR；嵌套模型似然比检验比较新增变量是否显著改善拟合。"),
        ("汇报重点", "在 2026 年联合模型中，blue 的 OR 显著大于 1，而 firstPick 的区间跨过 1；加入 blue 明显改善模型，加入 firstPick 则没有。"),
    ],
    "6. 第四步：寻找与地图侧相关的早期结构差异": [
        ("本步问题", "如果地图侧与胜率有关，它首先体现在哪些可观测的早期事件上？"),
        ("核心知识", "二元结果用 LPM 表示概率差，连续结果用 OLS 表示平均单位差；标准化效应用标准差 SD 统一不同量纲，便于比较“金币、经验、概率”等不同指标。"),
        ("汇报重点", "蓝方更偏向首先锋、首塔和前 15 分钟经济领先，但首龙概率更低，说明不是所有资源都单向有利，而是存在上半区与下半区的结构分化。"),
    ],
    "7. 第五步：资源优势如何转化为胜率优势": [
        ("本步问题", "蓝方与更高胜率之间的差异，有多少能被首先锋、首龙、15 分钟经济和首塔这些路径吸收？"),
        ("核心知识", "顺序分解观察逐步加入变量后 blue 系数下降多少；路径项可写为“blue→渠道”的关联乘以“渠道→胜率”的关联；整场 cluster bootstrap 用重复重采样衡量这些估计的抽样不确定性。"),
        ("识别边界", "这是描述性路径分析。渠道可能受未观测策略共同影响，加入顺序也会改变归属，因此不能把“被解释比例”直接叫作严格因果中介比例。"),
    ],
    "8. 第六步：用经济链条重新检查这个故事": [
        ("本步问题", "早期目标是否确实对应 15 分钟经济优势，而经济优势是否又对应更高胜率？"),
        ("核心知识", "OLS 系数衡量控制其他模型变量时的平均金币差；分箱胜率把连续经济差切成区间，用来展示可能的非线性关系。"),
        ("汇报重点", "首塔、一血和首先锋与更大的 15 分钟经济领先相关；随着 15 分钟经济差从大幅落后变成大幅领先，胜率从约 8% 单调上升到约 92%。"),
    ],
    "9. 第七步：机器学习验证是否改写结论": [
        ("本步问题", "允许模型学习非线性和变量交互后，关键预测变量是否仍然是早期经济，而不是 blue 标签本身？"),
        ("核心知识", "GroupKFold 按比赛分组切分训练集和测试集，防止同一局蓝红两行泄漏；AUC 衡量排序能力；Permutation importance 和 SHAP 从不同角度衡量预测贡献。"),
        ("识别边界", "变量对预测重要不代表它是因果变量；高度相关的经济、经验和目标变量还会彼此分摊重要性。"),
    ],
    "10. 第八步：稳健性检查与机制边界": [
        ("本步问题", "结论是否只在某个联赛、赛段、模型写法或控制变量组合中成立？"),
        ("核心知识", "子样本检验、交互项、固定效应和逐步控制用于检查结论稳定性；残差衰减展示可观测早期状态吸收了多少 blue 系数。"),
        ("识别边界", "稳健性检查能发现脆弱性，但不能自动创造因果识别。把比赛中途变量加入模型还可能属于过度控制，因此残余和被吸收部分都要谨慎命名。"),
    ],
    "11. 第九步：政策评估尝试——First Selection 新规削弱蓝方优势了吗（探索性 DiD）": [
        ("本步问题", "2026 年 First Selection 新规实施后，解耦程度不同的赛区是否出现不同幅度的蓝方优势变化？"),
        ("核心知识", "探索性 DiD 使用赛区固定效应、年份固定效应和“解耦度×2026”交互项；事件研究检查政策前趋势，安慰剂结果检查模型是否出现类似的虚假政策模式。"),
        ("识别边界", "所有赛区同时实施新规，没有标准未处理组；解耦度还是政策后的队伍选择，且预趋势不平坦。因此该部分只能描述异质性，不能作为政策因果效果。"),
    ],
    "12. 分联赛结果附表": [
        ("本步问题", "蓝方优势在不同联赛中的方向是否大体一致，哪些联赛估计更精确？"),
        ("核心知识", "每个联赛分别计算二项比例与 95% CI。样本越大，标准误通常越小，区间越窄；小联赛区间较宽不等于没有效应。"),
        ("读表提醒", "不要只按点估计给联赛排名，也不要把“区间跨 50%”误解为胜率恰好等于 50%；它只是当前样本精度不足以排除 50%。"),
    ],
    "13. 方法说明": [
        ("本步用途", "把报告中反复出现的方法放在同一张速查表中，方便汇报时快速说明“为什么用这个模型、结果单位是什么”。"),
        ("选择原则", "胜负是二元结果时优先使用 Logistic 或 LPM；经济、经验等连续结果使用 OLS；重复队伍和同局镜像结构分别用固定效应与聚类标准误处理。"),
    ],
}


TABLE_EXPLANATIONS = [
    {
        "title": "样本范围与分析单位",
        "purpose": "说明研究使用什么数据、排除了什么，以及一行数据代表什么。",
        "knowledge": "“比赛”与“team-game”是两种不同分析单位。每场比赛产生蓝方和红方两行，所以 43,037 场对应 86,074 行；两行结果互为镜像，不能当作完全独立样本。",
        "read": "赛季范围和联赛范围决定结论能推广到哪里；“按 gameid 聚类”表示允许同一场的两行误差相关，再据此计算标准误、CI 和 p 值。",
        "result": "正确口径是 80 个非中国联赛、43,037 场比赛，LPLOL 保留；LPL/LDL 由于关键早期数据缺失而精确排除。",
        "caution": "86,074 是数据行数，不是 86,074 场独立比赛。若忽视配对结构，标准误可能过小。",
        "script": "我们以 team-game 为建模单位，但统计推断按比赛聚类，因此没有把同一场蓝红两行误当成两场独立比赛。",
    },
    {
        "title": "变量字典",
        "purpose": "说明因变量、核心解释变量、机制变量和控制变量各自承担什么角色。",
        "knowledge": "win 是二元因变量；blue 是核心解释变量；firstPick、早期目标和经济差用于拆解可能路径；team-season 与对手变量用于控制长期实力差。",
        "read": "先问变量是在比赛前、比赛中还是比赛后产生。越靠后的变量越接近胜负，但把它加入模型可能是在解释路径，而不是估计地图侧的总关联。",
        "result": "变量体系覆盖地图侧、选秀时序、早期资源、经济状态、视野以及队伍和对手强度。",
        "caution": "15 分钟经济和目标属于 blue 之后可能发生的中间状态。控制它们会吸收 blue 的一部分关联，不能与赛前混杂控制混为一谈。",
        "script": "这张表不是结果表，而是研究设计地图：win 是结果，blue 是核心变量，其他变量分别用于控制混杂或解释路径。",
    },
    {
        "title": "分赛季蓝方胜率、95% CI 与 OR",
        "purpose": "检验每个赛季蓝方胜率是否高于 50%，并用 OR 表达蓝方相对红方的胜算差异。",
        "knowledge": "胜率估计为 p̂=x/n；标准误约为 SE=√[p̂(1-p̂)/n]；95% CI 约为 p̂±1.96×SE。odds=p/(1-p)，OR=odds蓝/odds红。Logistic 中 OR=e^β，OR 区间为 e^(β±1.96SEβ)。",
        "read": "胜率 CI 不跨 50% 或 OR CI 不跨 1，表示在 5% 显著性水平下拒绝“蓝红无差异”。p<0.001 表示在零假设成立时，观察到当前或更极端结果的概率很小。",
        "result": "五个赛季蓝方胜率均为 52%–53% 左右，所有胜率区间高于 50%，所有 OR 区间高于 1。",
        "caution": "2022 年 OR=1.202 表示蓝方获胜胜算约比红方高 20.2%，不是胜率高 20.2 个百分点，也不是蓝方有 120.2% 的胜率。",
        "script": "以 2022 年为例，蓝方胜率为 52.3%，95% CI 为 51.3%–53.2%；OR 为 1.202，区间 1.114–1.297，两个区间都排除了无差异基准。",
    },
    {
        "title": "LPM、固定效应与 Elo 控制的蓝方估计",
        "purpose": "检查蓝方优势在控制队伍长期实力和对手强度后是否仍然存在。",
        "knowledge": "LPM 把 win 的 0/1 值直接做线性回归，blue 系数的单位是百分点 pp。队伍-赛季固定效应等价于加入大量 team-season dummy variables，利用同一队伍同一赛季内的蓝红变化识别系数。",
        "read": "比较原始 +5.79 pp 与固定效应后的 +5.49、+4.54 pp：若系数只小幅下降，说明可观测的队伍构成不能解释全部差异。",
        "result": "控制队伍-赛季、对手或赛前 Elo 后，蓝方估计仍为正且大小接近原始结果。",
        "caution": "固定效应控制的是组内不随比赛变化的因素，不会自动控制临场状态、阵容克制、版本策略或选边动机。",
        "script": "加入队伍-赛季和对手固定效应后，蓝方优势仍有约 4.5–5.5 个百分点，所以它不只是强队样本构成造成的。",
    },
    {
        "title": "分赛季原始 OR 与 Elo 调整 OR",
        "purpose": "观察赛前实力差控制前后，蓝方 OR 在各赛季如何变化。",
        "knowledge": "Elo 是比赛前的队伍强度指标。调整 OR 来自同时放入 blue 与 Elo 差的 Logistic 回归，表示在相同赛前实力条件下 blue 的条件胜算比。",
        "read": "先比较同一行的原始 OR 与调整 OR，再检查调整后的 CI 是否跨 1。2026 年调整 OR=1.114，但 CI 约 0.99–1.25 且 p=0.072，只达到弱证据而非通常的 5% 显著。",
        "result": "2022–2025 年调整后结论稳定；2026 年调整后明显缩小，符合新规下强队更可能主动选择蓝方的现象。",
        "caution": "Elo 不是完美实力真值，2026 年的变化也可能涉及规则、策略和样本期较短，不能把差异全部归因于强队选择。",
        "script": "2026 年是唯一在控制 Elo 后蓝方估计明显缩小的年份，这提示新规下选边行为开始混入原始胜率，但方向仍为正。",
    },
    {
        "title": "2026 年地图侧 × 先选权四格表",
        "purpose": "直接展示 blue 与 firstPick 解耦后四种组合的胜率和样本量。",
        "knowledge": "这是两个二元变量的 2×2 联合分布。四个格子可以发现边际平均值隐藏的结构，也能检查是否有某种组合样本过少。",
        "read": "比较蓝方先选与蓝方后选，可以在同一地图侧内看先选差异；比较蓝方先选与红方先选，可以在同为先选时看地图侧差异。",
        "result": "蓝方后选 53.8%、蓝方先选 52.2%；红方后选 47.8%、红方先选 46.2%。样本中地图侧差异比先选差异更突出。",
        "caution": "这不是随机四格实验。队伍会根据规则和策略选择组合，原始格子差异可能包含选择效应。",
        "script": "四格表的直观结果是：无论先选还是后选，蓝方胜率都更高；但要控制联赛、版本等因素仍需看下一张回归表。",
    },
    {
        "title": "先选权与地图侧的联合 Logistic 模型",
        "purpose": "估计控制 firstPick 后 blue 是否仍与胜率相关，以及控制 blue 后 firstPick 是否仍提供独立信息。",
        "knowledge": "多变量 Logistic 的 OR 是“其他进入模型的变量保持不变时”的条件胜算比。CI 跨 1 通常表示证据不足，CI 不跨 1 表示该方向在常用阈值下显著。",
        "read": "M0 只放 firstPick；M1 同时放 firstPick 与 blue；M2 再加入 league 和 patch 固定效应。观察系数方向、区间和 p 值是否稳定。",
        "result": "firstPick 的 OR 约 0.94，CI 跨 1；blue 的 OR 约 1.269，CI 不跨 1，加入联赛和版本控制后几乎不变。",
        "caution": "OR 是条件关联，不等于随机分配地图侧的因果效果。若存在未测量的选边动机，blue 系数仍可能带有选择偏差。",
        "script": "在同一个模型中控制先选权后，blue 的 OR 仍为 1.269 且显著；firstPick 则没有显著独立关联。",
    },
    {
        "title": "嵌套模型似然比比较",
        "purpose": "检验在已有变量基础上加入 blue 或 firstPick，是否显著改善模型拟合。",
        "knowledge": "两个嵌套 Logistic 模型的似然比统计量近似服从卡方分布。较大的 chi-square 和较小的 p 值表示新增变量提供了模型原先没有的信息。",
        "read": "“firstPick 模型 + blue”问的是 blue 的增量价值；“blue 模型 + firstPick”问的是 firstPick 的增量价值，两个问题方向不同。",
        "result": "加入 blue：chi-square=26.2，p≈3×10⁻⁷；加入 firstPick：chi-square=1.8，p≈0.18。只有 blue 明显改善拟合。",
        "caution": "拟合改善不等于因果重要性，也不代表模型已经包含所有混杂变量。",
        "script": "模型比较给出同一结论：在 firstPick 之外加入地图侧能显著提升解释力，反过来加入 firstPick 则没有明显提升。",
    },
    {
        "title": "蓝方与早期结果的关联",
        "purpose": "系统比较 blue 与首先锋、首龙、首塔、经济、经验、补刀和视野等早期指标的关系。",
        "knowledge": "二元结果的 LPM 系数用 pp 表示概率差；连续结果的 OLS 系数保留原始单位；标准化效应把系数除以结果变量标准差，以 SD 为单位进行跨指标比较。",
        "read": "正号表示蓝方平均更高，负号表示蓝方平均更低。N 不同通常来自变量只在特定年份存在或少量缺失；p 值很小不代表效应在实战中一定很大。",
        "result": "最大标准化差异集中在首先锋 +0.387 SD 与首龙 −0.390 SD；15 分钟经济约 +516 金，说明资源分配存在明显上下半区分化。",
        "caution": "这里同时检验多个结果，且结果彼此相关。表中系数主要描述结构差异，不能逐项都当成独立因果效应。",
        "script": "蓝方并非所有目标都更强：它更容易拿先锋和首塔，却更不容易拿首龙，同时在 15 分钟平均多约 516 金。",
    },
    {
        "title": "顺序分解：哪些渠道吸收蓝方胜率差",
        "purpose": "把总蓝方胜率差分成早期目标、15 分钟经济、首塔和剩余部分。",
        "knowledge": "顺序分解通过逐步加入中间变量，观察 blue 系数减少多少。解释比例=某一步吸收的 pp÷原始蓝方 pp；各部分加总回到总差异。",
        "read": "先看“解释的蓝方胜率差”，再看占比。15 分钟经济在目标变量之后仍新增解释 2.27 pp，是最大的可量化部分；剩余 2.56 pp 不等于纯地图几何效应。",
        "result": "目标分配解释 13.1%，15 分钟经济新增解释 39.1%，首塔新增解释 3.6%，模型剩余 44.1%。",
        "caution": "解释份额依赖变量加入顺序；中间变量可能同时受未观测策略影响，所以不能直接称为严格因果中介比例。",
        "script": "可观测渠道大约吸收一半以上的蓝方差异，其中 15 分钟经济是最大的单一解释路径。",
    },
    {
        "title": "分赛季首先锋与首龙路径贡献",
        "purpose": "检查先锋正向路径和首龙负向路径是否跨赛季稳定。",
        "knowledge": "路径贡献的正负号表示该渠道放大还是抑制总蓝方差异。正贡献表示 blue 与该渠道的关系和渠道与胜率的关系同向；负贡献表示该渠道抵消部分蓝方优势。",
        "read": "同一行内把先锋贡献、首龙贡献与总差异比较；贡献可以超过总差异，因为正负路径会相互抵消。",
        "result": "2024–2026 年首先锋正贡献明显增强，首龙始终为负，符合“上半区引擎、下半区抑制器”的描述性结构。",
        "caution": "贡献值不是资源单独造成的胜率百分点，也不能脱离模型和其他渠道独立解释。",
        "script": "首先锋路径持续为正、首龙路径持续为负；两条路径相互抵消后，形成最终观察到的蓝方差异。",
    },
    {
        "title": "2026 路径项与 600 次 cluster bootstrap",
        "purpose": "在给出路径点估计的同时，用重采样区间展示估计的不确定性。",
        "knowledge": "cluster bootstrap 每次按整场比赛重采样，蓝红两行一起进入样本；重复 600 次后用估计分布的 2.5% 和 97.5% 分位数形成 95% CI。",
        "read": "区间不含 0 表示该路径项在当前样本和模型下较稳定；负值表示抑制路径。直接残差区间跨 0，说明其方向和大小不够精确。",
        "result": "先锋约 +2.0 pp、首龙约 −1.9 pp、15 分钟经济约 +2.6 pp、首塔约 +1.3 pp；前三类核心路径区间均未跨 0。",
        "caution": "bootstrap 处理抽样不确定性，但不会修复遗漏混杂、测量误差或错误的因果顺序，因此“稳定”不等于“已识别因果”。",
        "script": "我们按整局比赛做 600 次 bootstrap；先锋和经济为稳定正路径，首龙为稳定负路径，而直接残差的区间跨过 0。",
    },
    {
        "title": "早期事件与 15 分钟经济差",
        "purpose": "量化首先锋、一血、首龙、首塔和巢虫与 15 分钟经济领先的条件关联。",
        "knowledge": "OLS 系数以金币为单位。例如首塔系数 +2773 表示在模型其他变量相同的条件下，拿到首塔的队伍平均 15 分钟经济差更高约 2773 金。",
        "read": "比较系数大小时要注意事件本身含义和发生顺序；同一模型中的系数是条件差异，不能把所有系数直接相加当作一场比赛的总金币。",
        "result": "首塔和一血对应最大的经济差，首先锋和首龙也与正经济差相关，单只虚空巢虫对应约 +235 金。",
        "caution": "强队和领先队更容易拿目标，目标与经济之间存在双向强化。表格说明关联链条合理，但不是随机目标实验。",
        "script": "早期目标确实与 15 分钟经济相关，其中首塔、一血和首先锋的经济关联最大，这为经济转化路径提供了支持。",
    },
    {
        "title": "15 分钟经济差分箱与最终胜率",
        "purpose": "用直观区间展示经济领先与胜率之间的单调、非线性关系。",
        "knowledge": "分箱把连续变量划入若干区间，再计算每组平均胜率。它适合可视化非线性，但会丢失箱内细节，分界点也具有一定人为性。",
        "read": "0 附近两侧最适合观察小幅经济差的变化；极端区间显示大幅领先和落后的胜率上限与下限。样本数说明每个区间估计的支撑程度。",
        "result": "从落后超过 3000 金到领先超过 3000 金，胜率由 8.1% 上升到 91.9%；经济接近持平时胜率接近 50%。",
        "caution": "经济差是比赛过程结果，与胜负共同受到队伍实力和局势影响。这张表不能解释为“人为增加 1000 金必然造成某个固定胜率变化”。",
        "script": "15 分钟经济差与最终胜率呈非常清晰的单调关系，这也是后续模型中经济变量预测力最强的原因。",
    },
    {
        "title": "机器学习特征组",
        "purpose": "明确 Logistic、随机森林和 XGBoost 看到了哪些输入变量，防止模型成为无法解释的黑箱。",
        "knowledge": "特征是模型用于预测的输入。将变量按地图侧、经济、发育和早期目标分组，有助于判断是否存在结果泄漏以及变量重要性应如何解释。",
        "read": "这些变量均来自地图侧或前 15 分钟状态，预测目标是最终 win。blue 单独作为一个标签进入，便于检查模型看到早期状态后它还剩多少增量信息。",
        "result": "模型同时使用线性和非线性算法，但输入信息保持一致，因此模型间 AUC 和重要性结果可比较。",
        "caution": "“前 15 分钟变量预测最终胜负”不是赛前预测；它回答的是比赛进行到 15 分钟时，哪些状态最能排序胜负。",
        "script": "三类模型使用同一套早期变量，既比较算法，也保证结果差异不是由输入变量不同造成的。",
    },
    {
        "title": "三类模型的 GroupKFold AUC",
        "purpose": "比较可解释 Logistic 与非线性模型的样本外排序能力。",
        "knowledge": "GroupKFold 按 gameid 分组切分，保证同一局的蓝红两行不会分到训练集和测试集两侧。AUC 是随机抽取一支胜队和一支败队时，模型把胜队预测分数排得更高的概率。",
        "read": "AUC=0.5 接近随机排序，1 为完美排序。平均 AUC 是多折结果均值，标准差反映不同折之间波动，不是系数标准误。",
        "result": "三类模型 AUC 都约 0.834–0.835，差异只有 0.001，说明复杂非线性模型没有明显改写整体预测表现。",
        "caution": "AUC 不是准确率，也不直接反映概率校准；0.835 更不代表模型有 83.5% 的比赛预测正确。",
        "script": "Logistic、随机森林和 XGBoost 的 AUC 几乎相同，说明简单可解释模型已经捕捉到主要预测结构。",
    },
    {
        "title": "Permutation 与 SHAP 变量重要性",
        "purpose": "用两种互补指标判断哪些变量最支持样本外预测。",
        "knowledge": "Permutation importance 随机打乱一个变量，看 AUC 下降多少；SHAP importance 汇总该变量对单场模型输出的平均绝对贡献。两列量纲不同，只比较各自列内排序。",
        "read": "若变量打乱后 AUC 大幅下降，说明模型依赖它；SHAP 较大说明该变量经常明显推动预测。相关变量会共享或替代信息，因此单个值可能被稀释。",
        "result": "15 分钟经济差在两种指标中均排名第一；blue 的 permutation importance 仅 0.0002，说明在早期状态已知后，地图侧标签几乎没有额外预测增益。",
        "caution": "重要性不是因果效应，也不能把不同算法、不同量纲的数值直接相减或解释为百分比贡献。",
        "script": "两种重要性方法都把 15 分钟经济排在第一，而 blue 接近末位，说明地图侧的信息主要已经体现在早期局势中。",
    },
    {
        "title": "子样本、趋势与固定效应稳健性",
        "purpose": "检查蓝方结果是否依赖某一种比赛类型、赛段或模型设定。",
        "knowledge": "子样本检验把模型分别用于主要联赛、季后赛和常规赛；blue×year 交互项检验蓝方关联是否呈线性年度趋势；固定效应使用组内比较。",
        "read": "先看方向是否一致，再看 CI/p 值和效应大小是否接近。交互 OR=1.010、p=0.500 表示没有检测到稳定的逐年线性变化。",
        "result": "主要联赛、季后赛、常规赛和队伍-赛季固定效应结果均为正且显著，方向具有稳定性。",
        "caution": "多项稳健性结果一致提高可信度，但它们使用同一基础数据，不能被当成完全独立的重复实验。",
        "script": "无论限制到主要联赛、季后赛还是常规赛，蓝方估计都保持为正；年度交互项没有显示明显增强或衰减趋势。",
    },
    {
        "title": "逐步加入早期状态后的 blue 剩余效应",
        "purpose": "观察目标和经济变量依次加入后，blue 系数如何衰减。",
        "knowledge": "每一行是一个更丰富的模型。“相对原始效应”=当前 blue 系数÷只放 blue 时的系数，用来描述可观测状态吸收比例。",
        "read": "从 5.05 pp 降到 1.38 pp，表示模型看见更多早期局势后，blue 标签的条件关联逐步减少；曲线下降最快的位置提示信息最集中的变量阶段。",
        "result": "加入 15 分钟经济后剩余 57%，加入 20/25 分钟经济与首大龙后降到 27%。",
        "caution": "这些变量是比赛中途结果，控制它们会阻断可能路径；因此衰减可以支持机制叙事，但不能把被吸收比例直接叫作因果中介效应。",
        "script": "随着模型看到更多经济状态，blue 剩余效应从 100% 降到 27%，说明地图侧标签的信息逐渐被实际比赛局势替代。",
    },
    {
        "title": "机制压力测试",
        "purpose": "从多个条件和受限样本角度检查“上半区资源→经济→胜率”故事是否合理。",
        "knowledge": "前三行是加入 goldDiff@10 后的条件回归；最后一行限制 |goldDiff@15|<250，构造经济几乎持平的子样本，再估计 blue 与胜负的关系。",
        "read": "控制 10 分钟经济后，blue 与首先锋仍约 +16.7 pp、与首龙仍约 −20.7 pp；在 15 分钟经济近乎持平时，OR=1.015 且 p=0.83。",
        "result": "结构目标差异不是完全由 10 分钟经济领先解释；而当 15 分钟经济被近似抹平，蓝方胜率差基本消失。",
        "caution": "限制在经济持平的比赛会改变样本组成，还可能产生选择或碰撞偏差；该结果是压力测试，不是随机控制经济的实验。",
        "script": "即使 10 分钟经济相同，先锋和首龙的地图侧差异仍在；但 15 分钟经济接近持平时，蓝方胜率优势几乎为零。",
    },
    {
        "title": "探索性 DiD 与安慰剂结果",
        "purpose": "检验新规后解耦程度更高的赛区是否出现不同的蓝方优势变化。",
        "knowledge": "主交互项“解耦度×2026”以 pp 为单位；95% CI 展示估计精度。安慰剂把结果换成蓝方首先锋率，用来观察模型是否同样产生一项非预期政策模式。",
        "read": "主估计 +4.0 pp，但 CI 为 −4.1 到 +12.2 且 p=0.33；区间同时容纳负效应、零效应和正效应，所以结果不精确。安慰剂同样不显著。",
        "result": "没有检测到“解耦越高、蓝方优势下降越多”的模式，但也不能证明新规完全没有效果。",
        "caution": "没有未处理组、处理强度来自政策后选择，事件研究预趋势也不理想，所以这不是标准可识别 DiD。",
        "script": "探索性 DiD 的区间很宽且跨 0，只能说当前数据没有检测到削弱模式，不能把不显著解释成政策无效。",
    },
    {
        "title": "分联赛蓝方胜率与区间",
        "purpose": "展示不同联赛的样本量、蓝方点估计与估计精度，并确认 LPLOL 被正确保留。",
        "knowledge": "每个联赛的 95% CI 主要由样本量和胜率决定。标准误约为 √[p̂(1-p̂)/n]，因此 n 大的联赛通常区间更窄。",
        "read": "点估计用于看方向，区间用于看不确定性。LPLOL 有 763 场、蓝方胜率 51.8%、CI 48.2%–55.3%，说明方向为正但单独联赛精度有限。",
        "result": "多数列出的联赛蓝方点估计高于 50%，较大联赛如 LEC、LCKC、NACL 的区间相对更有信息。",
        "caution": "同时观察很多联赛会增加偶然极端值；不要仅凭点估计给联赛做显著性排名，也不要忽略联赛风格和赛程差异。",
        "script": "附表主要展示异质性和精度；LPLOL 的 763 场完整保留，单联赛区间较宽，因此总体模型比单独排名更可靠。",
    },
    {
        "title": "方法总览速查表",
        "purpose": "把每种方法的研究任务和结果单位放在一起，帮助读者快速选择正确的解释方式。",
        "knowledge": "Logistic 输出 OR；LPM 输出胜率百分点；OLS 输出连续单位差；固定效应控制组内不变因素；GroupKFold/AUC 评估样本外预测；Permutation/SHAP 解释预测模型。",
        "read": "不要把不同模型的指标混用：Logistic 不以普通 R² 和 F 检验为主要指标；AUC 不能替代因果系数；路径分解也不是单纯预测指标。",
        "result": "报告从描述、控制、路径、预测、稳健性到探索性政策分析使用了相互补充的方法。",
        "caution": "方法越多不等于因果证据自动更强。真正的可信度来自方法与问题匹配、假设透明以及结果在合理设定下稳定。",
        "script": "这张表是汇报时的方法索引：先说结果变量类型，再说明为什么选择 Logistic、LPM、OLS、固定效应或机器学习。",
    },
]


FIGURE_EXPLANATIONS = [
    {
        "title": "蓝方胜率跨赛季",
        "read": "横轴是赛季，纵轴是蓝方胜率；点表示各赛季点估计，误差线表示 95% CI，50% 水平线是蓝红无优势基准。",
        "result": "五个点都在 50% 以上，误差线也没有跨过 50%，说明蓝方优势跨赛季稳定存在。",
        "caution": "误差线只表达抽样不确定性，不包含所有测量误差、赛制差异或遗漏变量。",
    },
    {
        "title": "蓝方对早期结构变量的影响",
        "read": "每根条形表示 blue 与某个早期结果的估计差；向右为蓝方更高，向左为蓝方更低，误差线反映估计不确定性。",
        "result": "首先锋和首塔明显偏蓝方，首龙明显偏红方，呈现上半区与下半区的结构分化。",
        "caution": "不同结果单位可能经过标准化；条形长度不能脱离横轴单位直接理解为胜率贡献。",
    },
    {
        "title": "顺序分解瀑布图",
        "read": "瀑布图从总蓝方差异开始，依次减去被早期目标、15 分钟经济和首塔吸收的部分，最后留下模型未解释部分。",
        "result": "15 分钟经济是最大的可量化吸收项，剩余部分仍接近总差异的一半。",
        "caution": "瀑布图的分配会随变量顺序改变，剩余也可能包含遗漏变量和测量误差，不能直接标记为地图几何因果效应。",
    },
    {
        "title": "2026 路径项与 bootstrap 区间",
        "read": "柱高是路径点估计，误差线是 600 次整场 bootstrap 的 95% CI；零线表示没有路径项。",
        "result": "先锋、15 分钟经济和首塔为正，首龙为负；直接残差区间跨过零。",
        "caution": "区间不跨零表示当前模型中的估计稳定，不代表已经满足严格因果中介假设。",
    },
    {
        "title": "15 分钟经济差与胜率",
        "read": "横轴是 15 分钟经济差区间，纵轴是最终胜率；曲线展示从大幅落后到大幅领先时胜率如何变化。",
        "result": "关系近似单调且非常陡峭，经济接近持平处胜率接近 50%，领先 3000 金以上时胜率超过 90%。",
        "caution": "这是分箱关联曲线，不是对经济差进行随机干预后的因果反应函数。",
    },
    {
        "title": "机器学习变量重要性",
        "read": "条形越长，表示打乱该变量后 AUC 下降越多，或该变量的平均 SHAP 贡献越大；应按图中标注确认使用的是哪种指标。",
        "result": "15 分钟经济差远高于其他变量，blue 标签的重要性很低。",
        "caution": "相关变量会替代彼此，重要性也受模型和量纲影响；排名不能解释为因果贡献比例。",
    },
    {
        "title": "blue 剩余效应衰减",
        "read": "横轴表示模型逐步加入更晚的早期状态，纵轴表示仍留在 blue 系数中的胜率百分点；虚线通常标示参考阈值。",
        "result": "随着 15、20、25 分钟经济和首大龙进入，blue 剩余效应持续下降到约 1.38 pp。",
        "caution": "衰减说明信息被比赛状态吸收，但加入中间变量可能过度控制，因此不能直接当作因果中介百分比。",
    },
    {
        "title": "DiD 事件研究",
        "read": "横轴是相对政策年份，纵轴是各年份与解耦度的交互估计；参考年系数设为 0，误差线为 95% CI。",
        "result": "2024 年政策前估计已经偏高，与 2026 年接近，说明平行趋势假设不理想。",
        "caution": "政策前系数不平坦会削弱 DiD 解释；政策后点估计不显著也不等于政策没有效果。",
    },
    {
        "title": "蓝方 OR 五年稳定",
        "read": "每个点是年度 OR，误差线是 95% CI；OR=1 的水平线表示蓝红胜算无差异，阴影或标线标出 2026 新规时期。",
        "result": "2026 年 OR 仍位于此前年度的总体波动范围，没有出现明显断点。",
        "caution": "没有视觉断点只是描述性证据；若同期存在版本、赛区构成或选择行为变化，仍不能单独识别政策效果。",
    },
]


GLOSSARY = [
    ("N 与分析单位", "N 是某项分析实际使用的观测数。43,037 场比赛是 match-level N，86,074 个 team-game 是行数；某些变量缺失时，表格中的有效 N 会减少。解释标准误前必须先确认观测是否独立。"),
    ("比例、百分比与百分点 pp", "52.9% 是比例；从 47.1% 到 52.9% 相差 5.8 个百分点，而不是“提高 5.8%”。相对增长率与百分点是不同概念。"),
    ("标准误 SE", "标准误衡量估计量在重复抽样中的波动。比例标准误常近似为 √[p̂(1-p̂)/n]。样本越大，标准误通常越小；同局镜像或重复队伍会使独立样本公式失效，因此本报告按 gameid 聚类。"),
    ("95% 置信区间", "95% CI 常写为估计值±1.96×标准误，或由 bootstrap 分位数得到。严格含义是：若反复抽样并用同一程序构造区间，约 95% 的区间会覆盖真实参数；不是“真实参数有 95% 概率在本次区间里”。"),
    ("零假设与 p 值", "p 值是在零假设成立时，得到当前或更极端统计量的概率。p<0.05 通常称为显著，但它不是“零假设为真的概率”，也不衡量效应在游戏中的实际重要性。"),
    ("odds 与 OR", "概率 p 对应胜算 odds=p/(1-p)。OR 是两组胜算之比；OR=1 无差异，OR>1 表示第一组胜算更高。OR=1.20 表示胜算高 20%，不等于胜率高 20 个百分点。"),
    ("回归系数与控制其他变量", "回归系数描述某变量变化与结果变化的条件关联。“控制其他变量”表示在模型中比较其他已包含变量相同的观测，不表示现实中真正完成了随机化。"),
    ("LPM", "线性概率模型把 0/1 胜负直接做 OLS。blue 系数 +0.055 可读为蓝方胜率高约 5.5 pp。优点是直观，缺点包括异方差和预测值可能超出 0–1，因此应使用稳健或聚类标准误。"),
    ("Logistic 回归", "Logistic 适合二元结果，把线性预测值连接到 log-odds。系数取指数得到 OR；OR 区间通常为 e^(β±1.96SEβ)。它不依赖普通线性回归的正态误差假设。"),
    ("OLS", "普通最小二乘用于连续结果，例如 15 分钟经济差。系数以金币、经验或补刀等原始单位解释；显著系数仍可能受到遗漏变量和反向关系影响。"),
    ("dummy variables 与固定效应", "分类变量可展开成一组 0/1 dummy variables。team-season 固定效应相当于为每个队伍×赛季加入一组 dummy，吸收该组内不随比赛变化的平均实力与风格。"),
    ("Elo 与混杂控制", "Elo 是赛前强度的代理变量。若强队同时更常选蓝方且更容易获胜，队伍实力就是混杂因素；加入 Elo 或固定效应可减少该偏差，但代理变量不完美，不能保证所有混杂都被消除。"),
    ("聚类标准误", "当同一场的两行或同一队伍的多场比赛相关时，普通标准误会把信息量估得过高。聚类标准误允许簇内误差相关。本报告的 team-game 回归按 gameid 聚类，bootstrap 也按整场重采样。"),
    ("交互项", "交互项检验一个变量的关联是否随另一个变量而变化。例如 blue×year 检验蓝方 OR 是否随年份改变；解耦度×2026 检验政策后不同解耦程度赛区的变化差异。"),
    ("似然比检验与 chi-square", "嵌套 Logistic 模型可比较加入变量前后的对数似然。两倍对数似然差近似服从卡方分布；较小 p 值说明新增变量改善拟合，但不说明它具有因果作用。"),
    ("标准化效应 SD", "把原始系数除以结果变量标准差，可将不同单位转成可比较的 SD。0.39 SD 通常比 0.04 SD 更大，但实际意义仍需结合游戏机制和原始单位。"),
    ("交叉验证与 GroupKFold", "交叉验证反复把数据分成训练和测试部分，评估样本外表现。GroupKFold 保证同一 gameid 的蓝红两行进入同一折，避免训练集提前看到测试比赛的镜像信息。"),
    ("AUC", "AUC 衡量模型排序胜队与败队的能力。AUC=0.835 可理解为随机抽一支胜队和败队时，模型约有 83.5% 的概率给胜队更高分；它不是 83.5% 的准确率，也不保证概率校准。"),
    ("Permutation 与 SHAP", "Permutation importance 衡量打乱变量后模型性能下降；SHAP 衡量变量对单场预测输出的局部贡献并做汇总。两者解释预测模型，不是因果分解，且相关变量会相互分摊信息。"),
    ("bootstrap", "bootstrap 从现有样本中有放回地重复抽样，重新计算统计量，形成经验抽样分布。本报告按整场比赛抽样 600 次，以保留蓝红配对结构；次数越多区间越稳定，但不会修复研究设计偏差。"),
    ("路径分析与直接残差", "描述性路径项常写为 a×b：a 是 blue 与渠道的关联，b 是渠道与胜率的条件关联。直接残差是模型未被已测渠道吸收的部分，可能包含真实未测机制、遗漏变量、测量误差或模型设定问题。"),
    ("稳健性检查", "稳健性检查通过子样本、不同控制、不同模型或不同变量定义观察结论是否改变。结果稳定提高可信度，但同一数据上的多种模型不是多次独立实验。"),
    ("DiD、事件研究与平行趋势", "标准 DiD 比较处理组和对照组在政策前后的变化差。事件研究展示各时期交互项并检查政策前趋势；政策前应大致平坦。没有未处理组或预趋势不平坦时，DiD 只能谨慎视为探索性。"),
    ("安慰剂检验", "安慰剂把政策时间、处理变量或结果替换为理论上不应受影响的版本。如果仍得到类似显著结果，可能说明模型在捕捉其他趋势。本报告的安慰剂不显著，但这不能反过来证明主设计有效。"),
    ("描述、预测与因果", "描述问“样本中有什么规律”；预测问“新比赛中能否排序或预测”；因果问“若人为改变某因素，结果会怎样”。固定效应、机器学习或显著 p 值都不能单独把描述升级为因果。"),
]


def set_paragraph_shading(paragraph, fill):
    ppr = paragraph._p.get_or_add_pPr()
    shd = ppr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        ppr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_left_border(paragraph, color=base.BLUE, size=18, space=8):
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    left = pbdr.find(qn("w:left"))
    if left is None:
        left = OxmlElement("w:left")
        pbdr.append(left)
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), str(size))
    left.set(qn("w:space"), str(space))
    left.set(qn("w:color"), color)


def configure_explanation_styles(doc):
    styles = doc.styles
    if "Explanation Title" not in styles:
        style = styles.add_style("Explanation Title", WD_STYLE_TYPE.PARAGRAPH)
    else:
        style = styles["Explanation Title"]
    base.set_style_font(style, 9.4, bold=True, color=base.NAVY)
    style.paragraph_format.space_before = Pt(5)
    style.paragraph_format.space_after = Pt(2)
    style.paragraph_format.left_indent = Pt(7)
    style.paragraph_format.right_indent = Pt(3)
    style.paragraph_format.keep_with_next = True

    if "Explanation Body" not in styles:
        style = styles.add_style("Explanation Body", WD_STYLE_TYPE.PARAGRAPH)
    else:
        style = styles["Explanation Body"]
    base.set_style_font(style, 8.8, color=base.TEXT)
    style.paragraph_format.space_before = Pt(0)
    style.paragraph_format.space_after = Pt(1.8)
    style.paragraph_format.left_indent = Pt(11)
    style.paragraph_format.right_indent = Pt(3)
    style.paragraph_format.line_spacing = 1.12

    if "Glossary Term" not in styles:
        style = styles.add_style("Glossary Term", WD_STYLE_TYPE.PARAGRAPH)
    else:
        style = styles["Glossary Term"]
    base.set_style_font(style, 10.2, bold=True, color=base.BLUE)
    style.paragraph_format.space_before = Pt(6)
    style.paragraph_format.space_after = Pt(1.5)
    style.paragraph_format.keep_with_next = True


def insert_paragraph_after(doc, anchor, style=None):
    paragraph = doc.add_paragraph(style=style)
    anchor.addnext(paragraph._p)
    return paragraph


def add_labeled_paragraph(doc, anchor, label, text):
    paragraph = insert_paragraph_after(doc, anchor, "Explanation Body")
    run = paragraph.add_run(f"{label}｜")
    base.set_run_font(run, 8.8, bold=True, color=base.BLUE)
    run = paragraph.add_run(text)
    base.set_run_font(run, 8.8, color=base.TEXT)
    return paragraph._p


def add_explanation_box(doc, anchor, title, fields):
    title_p = insert_paragraph_after(doc, anchor, "Explanation Title")
    set_paragraph_shading(title_p, base.PALE_BLUE)
    set_left_border(title_p)
    run = title_p.add_run(title)
    base.set_run_font(run, 9.4, bold=True, color=base.NAVY)
    current = title_p._p
    for label, text in fields:
        current = add_labeled_paragraph(doc, current, label, text)
    return current


def replace_paragraph_text(paragraph, text, size=10, color=base.MID_GREY):
    for run in list(paragraph.runs):
        paragraph._p.remove(run._r)
    for index, line in enumerate(text.split("\n")):
        if index:
            paragraph.add_run().add_break()
        run = paragraph.add_run(line)
        base.set_run_font(run, size, color=color, bold=index == 0)


def collect_image_caption_anchors(doc):
    anchors = []
    body = list(doc.element.body.iterchildren())
    for index, child in enumerate(body):
        if child.tag == qn("w:p") and child.xpath(".//w:drawing"):
            anchor = child
            if index + 1 < len(body) and body[index + 1].tag == qn("w:p"):
                anchor = body[index + 1]
            anchors.append(anchor)
    return anchors


def add_step_guides(doc):
    original_paragraphs = list(doc.paragraphs)
    found = set()
    for paragraph in original_paragraphs:
        heading = paragraph.text.strip()
        if heading not in STEP_GUIDES:
            continue
        found.add(heading)
        add_explanation_box(
            doc,
            paragraph._p,
            "本节阅读提示",
            STEP_GUIDES[heading],
        )
    missing = set(STEP_GUIDES) - found
    if missing:
        raise RuntimeError("Missing step headings: " + " | ".join(sorted(missing)))


def add_table_explanations(doc, data_tables):
    if len(data_tables) != len(TABLE_EXPLANATIONS):
        raise RuntimeError(f"Expected {len(TABLE_EXPLANATIONS)} data tables, found {len(data_tables)}")
    for index, (table, info) in enumerate(zip(data_tables, TABLE_EXPLANATIONS), start=1):
        fields = [
            ("这张表回答什么", info["purpose"]),
            ("统计知识", info["knowledge"]),
            ("怎么读", info["read"]),
            ("关键结论", info["result"]),
            ("不能过度解释", info["caution"]),
            ("汇报时可以说", info["script"]),
        ]
        add_explanation_box(
            doc,
            table._tbl,
            f"表格讲解 {index}｜{info['title']}",
            fields,
        )


def add_figure_explanations(doc, image_caption_anchors):
    if len(image_caption_anchors) != len(FIGURE_EXPLANATIONS):
        raise RuntimeError(
            f"Expected {len(FIGURE_EXPLANATIONS)} figures, found {len(image_caption_anchors)}"
        )
    for index, (anchor, info) in enumerate(zip(image_caption_anchors, FIGURE_EXPLANATIONS), start=1):
        add_explanation_box(
            doc,
            anchor,
            f"图形讲解 {index}｜{info['title']}",
            [
                ("怎么看图", info["read"]),
                ("图中结论", info["result"]),
                ("不能过度解释", info["caution"]),
            ],
        )


def append_glossary(doc):
    page = doc.add_paragraph()
    page.add_run().add_break(WD_BREAK.PAGE)

    heading = doc.add_paragraph("附录 A：统计知识速查", style="Heading 1")
    base.set_keep(heading)
    intro = doc.add_paragraph()
    intro.paragraph_format.space_after = Pt(5)
    base.add_inline(
        intro,
        "这一附录把报告中出现的核心统计概念集中解释。汇报时不需要背诵全部公式，但要能够说清楚：指标测量什么、无差异基准是什么、什么结论可以说、什么结论不能说。",
        9.5,
    )

    for term, explanation in GLOSSARY:
        p = doc.add_paragraph(term, style="Glossary Term")
        set_left_border(p, color=base.LIGHT_BLUE, size=12, space=5)
        p = doc.add_paragraph(style="Explanation Body")
        p.paragraph_format.left_indent = Pt(8)
        run = p.add_run(explanation)
        base.set_run_font(run, 9.0, color=base.TEXT)

    closing = doc.add_paragraph()
    closing.paragraph_format.space_before = Pt(8)
    set_paragraph_shading(closing, base.PALE_BLUE)
    set_left_border(closing)
    run = closing.add_run("统计结果的通用解读结构｜")
    base.set_run_font(run, 9.3, bold=True, color=base.NAVY)
    run = closing.add_run(
        "先说研究问题，再说为什么选择该方法；随后报告效应大小、95% CI 和 p 值；最后说明游戏含义与识别边界。"
    )
    base.set_run_font(run, 9.3, color=base.TEXT)


def update_cover_and_metadata(doc):
    cover_changed = False
    for paragraph in doc.paragraphs[:12]:
        if "最终增强版 · 2026-07-15" in paragraph.text:
            replace_paragraph_text(
                paragraph,
                "最终版 · 2026年7月15日\n统计知识与逐表讲解版",
                10,
                base.MID_GREY,
            )
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cover_changed = True
            break
    if not cover_changed:
        raise RuntimeError("Cover version line not found")

    for section in doc.sections:
        for paragraph in section.header.paragraphs:
            if "43,037-Match Enhanced Final Report" in paragraph.text:
                replace_paragraph_text(
                    paragraph,
                    "Map Side vs Draft Timing · 43,037-Match Final Report · Statistical Guide",
                    7.6,
                    base.MID_GREY,
                )
                paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    props = doc.core_properties
    props.title = "职业《英雄联盟》蓝方优势完整分析报告最终版"
    props.subject = "43,037 场比赛的完整分析、统计知识与逐表讲解"
    props.author = "Vincent"
    props.keywords = (
        "League of Legends; 蓝方优势; 置信区间; OR; fixed effects; "
        "LPM; Logistic; bootstrap; machine learning; DiD"
    )
    props.comments = "最终版日期：2026年7月15日；LPLOL 保留；逐表与逐图统计讲解。"
    props.modified = datetime(2026, 7, 15, 15, 0, 0)


def main():
    doc = Document(REFERENCE)
    configure_explanation_styles(doc)

    data_tables = [table for table in doc.tables if len(table.rows) > 1]
    image_caption_anchors = collect_image_caption_anchors(doc)

    update_cover_and_metadata(doc)
    add_step_guides(doc)
    add_table_explanations(doc, data_tables)
    add_figure_explanations(doc, image_caption_anchors)
    append_glossary(doc)

    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
