import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from paper_readiness_audit import (  # noqa: E402
    build_markdown_report,
    collect_evidence_status,
    extract_action_items,
    extract_flagship_candidates,
)


class ExtractFlagshipCandidatesTest(unittest.TestCase):
    def test_handles_english_and_chinese_markers(self) -> None:
        text = textwrap.dedent(
            """
            Recommended flagship paper: "Not all early leads are equal"
            Complementary draft paper candidate: "Disentangling Map-Side from Draft"
            推荐旗舰主题：《赢得 BP ≠ 赢得比赛》
            """
        )

        candidates = extract_flagship_candidates(text)

        self.assertEqual(
            candidates,
            [
                "Not all early leads are equal",
                "Disentangling Map-Side from Draft",
                "赢得 BP ≠ 赢得比赛",
            ],
        )

    def test_strips_markdown_emphasis_and_trailing_punctuation(self) -> None:
        text = 'Recommended flagship paper: **"Not all early leads are equal"**'

        candidates = extract_flagship_candidates(text)

        self.assertEqual(candidates, ["Not all early leads are equal"])

    def test_prefers_longer_wrapped_title_over_partial_line(self) -> None:
        text = textwrap.dedent(
            """
            Recommended flagship paper: **"Not all early leads are equal
            in pro League of Legends"**
            Recommended flagship paper: **"Not all early leads are equal
            """
        )

        candidates = extract_flagship_candidates(text)

        self.assertEqual(candidates, ["Not all early leads are equal in pro League of Legends"])


class ExtractActionItemsTest(unittest.TestCase):
    def test_reads_numbered_and_bulleted_items_from_multiple_sections(self) -> None:
        text = textwrap.dedent(
            """
            Still pending before paper-level completion:
            - external matchup-quality data
            - exact literature verification

            动笔前的待办（按优先级）：
            1. 查证 2026 的 `firstPick` 口径
            2. 补一个更糙的稳健性

            Some later section.
            """
        )

        items = extract_action_items(text)

        self.assertEqual(
            items,
            [
                "external matchup-quality data",
                "exact literature verification",
                "查证 2026 的 `firstPick` 口径",
                "补一个更糙的稳健性",
            ],
        )

    def test_stops_collecting_when_section_ends(self) -> None:
        text = textwrap.dedent(
            """
            Still pending before paper-level completion:
            - verify references
            - add matchup-quality data
            Active exploration:
            - this should not be treated as a blocker
            """
        )

        items = extract_action_items(text)

        self.assertEqual(items, ["verify references", "add matchup-quality data"])


class BuildMarkdownReportTest(unittest.TestCase):
    def test_marks_missing_evidence_and_lists_blockers(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / "brief.md").write_text(
                textwrap.dedent(
                    """
                    Recommended flagship paper: "Paper A"
                    Still pending before paper-level completion:
                    - verify references
                    """
                ),
                encoding="utf-8",
            )
            (root / "figure.png").write_bytes(b"png")

            evidence = collect_evidence_status(
                root,
                [
                    ("Core figure", Path("figure.png")),
                    ("OR table", Path("table.csv")),
                ],
            )
            report = build_markdown_report(
                report_date="2026-06-22",
                source_notes=[root / "brief.md"],
                flagship_candidates=["Paper A"],
                blockers=["verify references"],
                evidence=evidence,
            )

            self.assertIn("Paper A", report)
            self.assertIn("verify references", report)
            self.assertIn("Core figure", report)
            self.assertIn("OR table", report)
            self.assertIn("missing", report.lower())


if __name__ == "__main__":
    unittest.main()
