#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path


FULL_TEXT_FLAGSHIP_PATTERNS = [
    re.compile(r'Recommended flagship paper:\s*\*\*[\"“]?(.+?)[\"”]?\*\*', re.S),
    re.compile(r'Complementary draft paper candidate:\s*\*\*[\"“]?(.+?)[\"”]?\*\*', re.S),
]

LINE_FLAGSHIP_PATTERNS = [
    re.compile(r"Recommended flagship paper:\s*[\"“]?(.+?)[\"”]?$"),
    re.compile(r"Complementary draft paper candidate:\s*[\"“]?(.+?)[\"”]?$"),
    re.compile(r"推荐旗舰主题：[《\"]?(.+?)[》\"]?$"),
]

ACTION_SECTION_MARKERS = [
    "still pending before paper-level completion",
    "动笔前的待办",
    "待办（按优先级）",
]

EVIDENCE_SPECS = [
    ("Global topic report", Path("analysis/研究主题建议报告.md")),
    ("Draft/map-side report", Path("topics/报告/红蓝方/红蓝方与选秀优势的迷思_研究报告.md")),
    ("Core figure", Path("analysis/figures/draft_value.png")),
    ("OR table", Path("analysis/outputs/draft_value_ORs.csv")),
    ("Main dataset", Path("analysis/team_game.csv")),
    ("Literature PDF", Path("论文/03_Team_Resource_Allocation_and_Win_Percentages.pdf")),
]

SOURCE_NOTES = [
    Path("README.md"),
    Path("analysis/研究选题.md"),
    Path("analysis/研究主题建议报告.md"),
    Path("topics/报告/红蓝方/红蓝方与选秀优势的迷思_研究报告.md"),
]


def _append_unique_title(candidates: list[str], title: str) -> None:
    if not title:
        return

    for existing in list(candidates):
        if title == existing or title in existing:
            return
        if existing in title:
            candidates.remove(existing)

    candidates.append(title)


def extract_flagship_candidates(text: str) -> list[str]:
    candidates: list[str] = []
    for pattern in FULL_TEXT_FLAGSHIP_PATTERNS:
        for match in pattern.finditer(text):
            title = " ".join(match.group(1).split())
            title = title.strip("*").strip()
            title = title.strip('"“”').strip()
            title = title.strip("》").strip("《").strip()
            title = title.rstrip("》。.")
            _append_unique_title(candidates, title)

    for raw_line in text.splitlines():
        line = raw_line.strip()
        for pattern in LINE_FLAGSHIP_PATTERNS:
            match = pattern.search(line)
            if match:
                title = " ".join(match.group(1).split())
                title = title.strip("*").strip()
                title = title.strip('"“”').strip()
                title = title.strip("》").strip("《").strip()
                title = title.rstrip("》。.")
                _append_unique_title(candidates, title)
    return candidates


def extract_action_items(text: str) -> list[str]:
    items: list[str] = []
    collect = False
    saw_item = False
    collect_inline = False
    inline_parts: list[str] = []

    for raw_line in text.splitlines():
        line = raw_line.strip()
        lowered = line.lower()

        if any(marker in lowered or marker in line for marker in ACTION_SECTION_MARKERS):
            if ":" in line:
                tail = line.split(":", 1)[1].strip()
                if tail:
                    collect_inline = True
                    inline_parts = [tail]
            collect = True
            saw_item = False
            continue

        if collect_inline:
            if not line or line.startswith("#") or line.startswith("**") or line.endswith(":"):
                joined = " ".join(inline_parts)
                for part in [segment.strip() for segment in joined.split(",")]:
                    cleaned = part.rstrip("。.")
                    cleaned = re.sub(r"^and\s+", "", cleaned, flags=re.I)
                    if cleaned and cleaned not in items:
                        items.append(cleaned)
                collect_inline = False
                inline_parts = []
                collect = False
            else:
                inline_parts.append(line)
                continue

        if collect:
            bullet_match = re.match(r"^(?:[-*]|\d+[.)])\s+(.*)$", line)
            if bullet_match:
                item = bullet_match.group(1).strip()
                if item and item not in items:
                    items.append(item)
                saw_item = True
                continue

            if saw_item and (not line or line.startswith("#") or not bullet_match):
                collect = False

    if collect_inline and inline_parts:
        joined = " ".join(inline_parts)
        for part in [segment.strip() for segment in joined.split(",")]:
            cleaned = part.rstrip("。.")
            cleaned = re.sub(r"^and\s+", "", cleaned, flags=re.I)
            if cleaned and cleaned not in items:
                items.append(cleaned)

    return items


def collect_evidence_status(project_root: Path, specs: list[tuple[str, Path]]) -> list[dict[str, str]]:
    evidence: list[dict[str, str]] = []
    for label, relative_path in specs:
        full_path = project_root / relative_path
        status = "present" if full_path.exists() else "missing"
        evidence.append(
            {
                "label": label,
                "path": str(relative_path),
                "status": status,
            }
        )
    return evidence


def build_markdown_report(
    report_date: str,
    source_notes: list[Path],
    flagship_candidates: list[str],
    blockers: list[str],
    evidence: list[dict[str, str]],
) -> str:
    lines = [
        f"# LoL Paper Readiness Audit - {report_date}",
        "",
        "## Source Notes",
    ]
    for note in source_notes:
        lines.append(f"- `{note}`")

    lines.extend(["", "## Flagship Candidates"])
    if flagship_candidates:
        for candidate in flagship_candidates:
            lines.append(f"- {candidate}")
    else:
        lines.append("- None extracted")

    lines.extend(["", "## Open Blockers"])
    if blockers:
        for blocker in blockers:
            lines.append(f"- {blocker}")
    else:
        lines.append("- None extracted")

    lines.extend(["", "## Evidence Inventory"])
    for item in evidence:
        lines.append(f"- {item['label']}: `{item['path']}` ({item['status']})")

    return "\n".join(lines) + "\n"


def build_project_audit(project_root: Path, report_date: str) -> str:
    texts: list[str] = []
    available_sources: list[Path] = []
    for relative_path in SOURCE_NOTES:
        full_path = project_root / relative_path
        if full_path.exists():
            texts.append(full_path.read_text(encoding="utf-8"))
            available_sources.append(relative_path)

    combined_text = "\n".join(texts)
    flagship_candidates = extract_flagship_candidates(combined_text)
    blockers = extract_action_items(combined_text)
    evidence = collect_evidence_status(project_root, EVIDENCE_SPECS)

    return build_markdown_report(
        report_date=report_date,
        source_notes=available_sources,
        flagship_candidates=flagship_candidates,
        blockers=blockers,
        evidence=evidence,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a LoL paper-readiness audit.")
    parser.add_argument("--project-root", required=True, help="Path to the LoL project root.")
    parser.add_argument("--report-date", required=True, help="Date label for the audit.")
    parser.add_argument("--output", required=True, help="Markdown file to write.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_root = Path(args.project_root).expanduser().resolve()
    output_path = Path(args.output).expanduser().resolve()
    report = build_project_audit(project_root, args.report_date)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(report, encoding="utf-8")


if __name__ == "__main__":
    main()
