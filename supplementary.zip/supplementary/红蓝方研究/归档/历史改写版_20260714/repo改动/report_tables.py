"""Generate the canonical descriptive tables used by the Chinese report.

All tables read the single committed analysis file, ``redblue_teamgames.csv``.
Keeping these summaries inside ``run_all.py`` prevents the report from drifting
back to an archived pilot sample.

Outputs
-------
results/sample_by_year.csv
results/firstpick_crosstab_2026.csv
results/blue_by_league.csv
results/strength_control_by_year.csv
"""
from __future__ import annotations

import os
import sys

import pandas as pd
from statsmodels.stats.proportion import proportion_confint

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as cfg
from team_strength import add_pre_game_elo
from utils import load_teamgames, logit_cluster, or_ci, z


def sample_by_year(d: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for year in sorted(d["year"].unique()):
        s = d[d.year == year].dropna(subset=["result", "blue"])
        blue = s[s.blue == 1]
        lo, hi = proportion_confint(
            int(blue.result.sum()), len(blue), method="wilson"
        )
        OR, OR_lo, OR_hi, p = or_ci(logit_cluster("result ~ blue", s), "blue")
        rows.append(
            {
                "year": int(year),
                "games": int(s.gameid.nunique()),
                "team_games": int(len(s)),
                "leagues": int(s.league.nunique()),
                "blue_wr": float(blue.result.mean()),
                "wr_ci_lo": float(lo),
                "wr_ci_hi": float(hi),
                "OR": OR,
                "OR_lo": OR_lo,
                "OR_hi": OR_hi,
                "p": p,
            }
        )
    return pd.DataFrame(rows)


def firstpick_crosstab(d: pd.DataFrame) -> pd.DataFrame:
    s = d[d.year == 2026].dropna(subset=["result", "blue", "firstPick"]).copy()
    s["map_side"] = s.blue.map({1: "Blue", 0: "Red"})
    s["pick_order"] = s.firstPick.map({1.0: "First pick", 0.0: "Second pick"})
    out = (
        s.groupby(["map_side", "pick_order"], observed=True)
        .agg(team_games=("gameid", "size"), win_rate=("result", "mean"))
        .reset_index()
    )
    return out.sort_values(["map_side", "pick_order"]).reset_index(drop=True)


def blue_by_league(d: pd.DataFrame, min_games: int = 600) -> pd.DataFrame:
    rows = []
    for league, s in d.groupby("league"):
        blue = s[s.blue == 1].dropna(subset=["result"])
        if len(blue) < min_games:
            continue
        lo, hi = proportion_confint(
            int(blue.result.sum()), len(blue), method="wilson"
        )
        rows.append(
            {
                "league": league,
                "games": int(len(blue)),
                "blue_wr": float(blue.result.mean()),
                "wr_ci_lo": float(lo),
                "wr_ci_hi": float(hi),
            }
        )
    return pd.DataFrame(rows).sort_values(["blue_wr", "league"]).reset_index(drop=True)


def strength_control_by_year(d: pd.DataFrame) -> pd.DataFrame:
    elo = add_pre_game_elo(d)
    elo["z_rd"] = z(elo["rating_diff"])
    rows = []
    for year in sorted(elo.year.unique()):
        s = elo[elo.year == year].dropna(subset=["result", "blue", "z_rd"])
        raw = or_ci(logit_cluster("result ~ blue", s), "blue")
        controlled = or_ci(logit_cluster("result ~ blue + z_rd", s), "blue")
        rows.append(
            {
                "year": int(year),
                "raw_OR": raw[0],
                "controlled_OR": controlled[0],
                "controlled_lo": controlled[1],
                "controlled_hi": controlled[2],
                "controlled_p": controlled[3],
                "mean_blue_rating_diff": float(s.loc[s.blue == 1, "rating_diff"].mean()),
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    d = load_teamgames()
    outputs = {
        "sample_by_year.csv": sample_by_year(d),
        "firstpick_crosstab_2026.csv": firstpick_crosstab(d),
        "blue_by_league.csv": blue_by_league(d),
        "strength_control_by_year.csv": strength_control_by_year(d),
    }
    for name, frame in outputs.items():
        path = os.path.join(cfg.RESULTS_DIR, name)
        frame.to_csv(path, index=False)
        print(f"wrote results/{name} ({len(frame)} rows)")

    print(
        f"canonical sample: {d.gameid.nunique():,} games / {len(d):,} team-games / "
        f"{d.league.nunique()} league labels"
    )


if __name__ == "__main__":
    main()
