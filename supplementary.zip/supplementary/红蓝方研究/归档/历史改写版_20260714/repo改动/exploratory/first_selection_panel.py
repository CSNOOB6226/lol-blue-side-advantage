"""Exploratory league-panel association after First Selection.

This is intentionally *not* presented as a causal Difference-in-Differences
design. First Selection rolled out in every region, while the quantity below is
a post-policy strategic behavior rather than exogenous adoption intensity:

    D_league = share of a league's 2026 first-pick team-games that are RED side
             = 1 - P(blue | firstPick, 2026).
    D = 0  -> still fully coupled (old regime);  D large -> strongly decoupled.

Panel: league x year (2022-2026). Outcome: blue-side win difference in pp
(100 * (blue win-rate - 0.5)). Weighted panel regressions with league and year fixed effects,
weighted by games, cluster-robust by league:

    blue_adv_{l,t} = a_l + g_t + b * (D_l * 1[t=2026]) + e

Because all regions were exposed, D is measured after exposure, and pre-period
interactions are not flat, the coefficient is descriptive heterogeneity only.

Outputs stay under exploratory/results and exploratory/figures.
"""
from __future__ import annotations
import os, sys
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
SRC = os.path.join(REPO, "src")
OUT = os.path.join(HERE, "results")
FIG = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)
os.makedirs(FIG, exist_ok=True)
sys.path.insert(0, SRC)
import config as cfg
from utils import load_teamgames

MIN_GAMES_YEAR = 40       # a league-year needs enough games to estimate a blue WR
MIN_FP26 = 30             # need enough 2026 first-pick games to estimate D
LOG: list[str] = []
def log(m=""):
    print(m); LOG.append(str(m))


def fit(formula, panel, rhs_terms):
    try:
        m = smf.wls(formula, panel, weights=panel["n"]).fit(
            cov_type="cluster", cov_kwds={"groups": panel["league"]})
    except Exception:
        m = smf.wls(formula, panel, weights=panel["n"]).fit(cov_type="HC1")
    return m


def main():
    d = load_teamgames()

    # ---- treatment intensity D per league (from 2026) --------------------
    d26 = d[d.year == 2026]
    fp = d26[d26.firstPick == 1]
    dl = fp.groupby("league").agg(blue_share=("blue", "mean"), n_fp=("blue", "size"))
    dl = dl[dl.n_fp >= MIN_FP26].copy()
    dl["D"] = 1.0 - dl["blue_share"]           # 0 = coupled, higher = decoupled
    Dmap = dl["D"].to_dict()

    # ---- league-year panel of blue advantage + placebo -------------------
    blue = d[d.blue == 1]
    panel = blue.groupby(["league", "year"]).agg(
        blue_wr=("result", "mean"),
        blue_herald=("firstherald", "mean"),
        n=("result", "size")).reset_index()
    panel = panel[panel.n >= MIN_GAMES_YEAR]
    panel["D"] = panel["league"].map(Dmap)
    panel = panel.dropna(subset=["D"])
    # keep leagues observed in 2026 and >=3 years total
    yrs = panel.groupby("league").agg(has26=("year", lambda s: 2026 in set(s)),
                                      nyear=("year", "nunique"))
    keep = yrs[(yrs.has26) & (yrs.nyear >= 3)].index
    panel = panel[panel.league.isin(keep)].copy()
    panel["blue_adv"] = 100 * (panel["blue_wr"] - 0.5)
    panel["herald_adv"] = 100 * (panel["blue_herald"] - 0.5)
    panel["post"] = (panel["year"] == 2026).astype(int)
    panel["D_post"] = panel["D"] * panel["post"]

    log(f"Exploratory panel: {panel.league.nunique()} leagues, {len(panel)} league-years")
    log(f"  post-policy behavior D across kept leagues: "
        f"min={panel.D.min():.2f} median={panel.D.median():.2f} max={panel.D.max():.2f}")
    top = dl.sort_values("D", ascending=False).head(6)
    log("  most-decoupled leagues (D): " +
        ", ".join(f"{lg}={row.D:.2f}" for lg, row in top.iterrows()))

    # ---- primary descriptive panel association ---------------------------
    m = fit("blue_adv ~ C(league) + C(year) + D_post", panel, ["D_post"])
    b, se, p = m.params["D_post"], m.bse["D_post"], m.pvalues["D_post"]
    log("\nPRIMARY ASSOCIATION (outcome = observed blue-side win difference, pp):")
    log(f"  b(D x post2026) = {b:+.2f} pp per unit decoupling  "
        f"95%CI[{b-1.96*se:+.2f},{b+1.96*se:+.2f}]  p={p:.3g}")
    log(f"  fitted contrast at D~0.7 = {0.7*b:+.2f} pp (descriptive, not causal).")

    # ---- event study (2025 = reference year) ----------------------------
    for yy in (2022, 2023, 2024, 2026):
        panel[f"D_{yy}"] = panel["D"] * (panel["year"] == yy).astype(int)
    es = fit("blue_adv ~ C(league) + C(year) + D_2022 + D_2023 + D_2024 + D_2026",
             panel, ["D_2022", "D_2023", "D_2024", "D_2026"])
    log("\nYEAR-INTERACTION DIAGNOSTIC (D x year, relative to 2025):")
    es_rows = []
    pre_coefs = []
    for yy in (2022, 2023, 2024, 2026):
        term = f"D_{yy}"
        bb, ss = es.params[term], es.bse[term]
        flag = "  <-- 2026" if yy == 2026 else "  (pre-period diagnostic)"
        log(f"   {yy}: {bb:+.2f} pp  95%CI[{bb-1.96*ss:+.2f},{bb+1.96*ss:+.2f}]{flag}")
        es_rows.append(dict(year=yy, coef=bb, lo=bb-1.96*ss, hi=bb+1.96*ss))
        if yy != 2026:
            pre_coefs.append(bb)
    es_rows.append(dict(year=2025, coef=0.0, lo=0.0, hi=0.0))   # reference
    max_pre = max(abs(c) for c in pre_coefs)
    log(f"  parallel-trends check: largest pre-period |coef| = {max_pre:.2f} pp "
        f"(2026 = {es.params['D_2026']:+.2f} pp).")
    if max_pre > 0.5 * abs(es.params["D_2026"]):
        log("  CAUTION: pre-period coefficients are not flat and the panel is small.")
        log("  The 2026 coefficient cannot be interpreted as a policy effect.")

    # ---- secondary outcome: first-herald rate ----------------------------
    mp = fit("herald_adv ~ C(league) + C(year) + D_post", panel, ["D_post"])
    bp, sep, pp_ = mp.params["D_post"], mp.bse["D_post"], mp.pvalues["D_post"]
    log("\nSECONDARY OUTCOME (blue-side FIRST-HERALD rate):")
    log(f"  b(D x post2026) = {bp:+.2f} pp  95%CI[{bp-1.96*sep:+.2f},{bp+1.96*sep:+.2f}]  p={pp_:.3g}")
    log("  This null association does not validate the policy design.")

    log("\nINTERPRETATION LIMIT:")
    log("D is a post-policy choice, all regions were exposed, and pre-period interactions")
    log("are not flat. These estimates describe cross-league heterogeneity; they neither")
    log("show that First Selection worked nor show that it failed.")

    panel.to_csv(os.path.join(OUT, "league_panel.csv"), index=False)
    es_frame = pd.DataFrame(es_rows).sort_values("year")
    es_frame.to_csv(os.path.join(OUT, "year_interactions.csv"), index=False)
    with open(os.path.join(OUT, "first_selection_panel.txt"), "w") as f:
        f.write("\n".join(LOG) + "\n")

    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    pre = es_frame[es_frame.year <= 2025]
    post = es_frame[es_frame.year == 2026]
    ax.errorbar(pre.year, pre.coef,
                yerr=[pre.coef - pre.lo, pre.hi - pre.coef],
                fmt="s-", color="#2c3e50", capsize=4, lw=1.8, ms=7,
                label="pre-period diagnostic / reference")
    ax.errorbar(post.year, post.coef,
                yerr=[post.coef - post.lo, post.hi - post.coef],
                fmt="o", color="#c0392b", capsize=4, ms=10,
                label="2026 association")
    ax.axhline(0.0, color="black", ls="--", lw=1)
    ax.set_xticks(es_frame.year.astype(int))
    ax.set_ylabel("D x year coefficient (pp)")
    ax.set_title("Exploratory league-panel association after First Selection\n"
                 "Not a causal policy estimate; pre-period interactions are not flat")
    ax.legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "first_selection_panel.png"), dpi=150, bbox_inches="tight")
    plt.close(fig)
    log("\nWrote exploratory results and figure.")


if __name__ == "__main__":
    main()
