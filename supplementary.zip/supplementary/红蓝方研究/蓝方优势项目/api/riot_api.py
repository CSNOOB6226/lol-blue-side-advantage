"""Minimal Riot API access and data-availability pilot.

The key is loaded from ``RIOT_API_KEY`` or ``api/.riotkey`` and is never printed.
This script tests three separate questions without treating one failed ID lookup as
proof that all professional-game data is unavailable through every Riot product.
"""
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))

def load_key():
    k = os.environ.get('RIOT_API_KEY')
    if k: return k.strip()
    p = os.path.join(HERE, '.riotkey')
    if os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            return f.read().strip().replace('RIOT_API_KEY=', '').strip()
    raise SystemExit('No API key. Put it in env RIOT_API_KEY or in api/.riotkey')

KEY = None
_last = [0.0]
def get(host, path, params=None, tries=4):
    """host e.g. 'kr.api.riotgames.com' or 'asia.api.riotgames.com'."""
    global KEY
    if KEY is None: KEY = load_key()
    q = ('?' + urllib.parse.urlencode(params)) if params else ''
    url = f'https://{host}{path}{q}'
    for attempt in range(tries):
        # gentle client-side spacing (dev key ~20/s, 100/2min)
        dt = time.time()-_last[0]
        if dt < 0.06: time.sleep(0.06-dt)
        req = urllib.request.Request(url, headers={'X-Riot-Token': KEY})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                _last[0]=time.time(); return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            _last[0]=time.time()
            if e.code in (429,500,502,503,504):
                wait = int(e.headers.get('Retry-After', 2)) if e.code==429 else 2**attempt
                time.sleep(wait); continue
            raise RuntimeError(f'HTTP {e.code} on {path}: {e.read()[:200]}')
    raise RuntimeError(f'failed after {tries} tries: {path}')

# regional routing for match-v5: americas / asia / europe
PLATFORM_TO_REGION = {'na1':'americas','br1':'americas','la1':'americas','la2':'americas',
                      'kr':'asia','jp1':'asia','euw1':'europe','eun1':'europe','tr1':'europe','ru':'europe',
                      'oc1':'americas','sea':'asia','vn2':'asia'}

if __name__ == '__main__':
    KEY = load_key()
    print('key loaded securely (value hidden)')
    PLAT='kr'; REG=PLATFORM_TO_REGION[PLAT]
    # 1) validate key
    try:
        st = get(f'{PLAT}.api.riotgames.com', '/lol/status/v4/platform-data')
        print('1) KEY VALID ✓  platform:', st.get('id'))
    except Exception as e:
        print('1) KEY TEST FAILED:', e); sys.exit(1)
    # 2) Can OpenEsports tournament IDs be used directly as Match-V5 IDs?
    print('\n2) direct OpenEsports-ID lookup test:')
    direct_hits = 0
    for mid in ['ESPORTSTMNT01_3408461', 'NA1_ESPORTSTMNT01_3408461']:
        try:
            get(f'{REG}.api.riotgames.com', f'/lol/match/v5/matches/{mid}')
            direct_hits += 1
            print(f'   {mid}: reachable')
        except Exception as e:
            print(f'   {mid}: not reachable -> {str(e)[:80]}')
    if direct_hits == 0:
        print('   result: these OE IDs are not directly accepted by Match-V5.')
        print('   interpretation: an ID mapping or a separate esports-data product would be required;')
        print('   this does not prove that every professional game is unavailable from Riot.')
    # 3) confirm high-elo soloQ match+timeline has COORDINATES
    print('\n3) high-elo soloQ timeline coordinate check:')
    chal = get(f'{PLAT}.api.riotgames.com', '/lol/league/v4/challengerleagues/by-queue/RANKED_SOLO_5x5')
    entry = chal['entries'][0]; puuid = entry.get('puuid')
    if not puuid:
        s = get(f'{PLAT}.api.riotgames.com', f'/lol/summoner/v4/summoners/{entry["summonerId"]}'); puuid=s['puuid']
    ids = get(f'{REG}.api.riotgames.com', f'/lol/match/v5/matches/by-puuid/{puuid}/ids', {'count':3,'queue':420})
    print('   sample Challenger match ids:', ids[:3])
    if ids:
        tl = get(f'{REG}.api.riotgames.com', f'/lol/match/v5/matches/{ids[0]}/timeline')
        frames = tl['info']['frames']; pf = frames[5]['participantFrames']['1']
        has_pos = 'position' in pf
        n_events = sum(len(f['events']) for f in frames)
        print(f'   timeline: {len(frames)} frames, participant position present={has_pos}, total events={n_events}')
        if has_pos:
            print('   sample pos @frame5 p1:', pf['position'], '✓ COORDINATES AVAILABLE for soloQ')
    print('\nACCESS SUMMARY:')
    print('   - standard developer key authentication: passed')
    print('   - direct OE tournament-ID lookup:', 'passed' if direct_hits else 'failed')
    print('   - soloQ timeline coordinates: checked above; these are not pro-game observations')
