"""
04_mediation.py — Causal-ordered (sequential) mediation of the blue-side win advantage.

Chain (causal order): blue -> early objective allocation (first herald & first dragon, contemporaneous)
                       -> early gold@15 -> first tower -> win.
LPM (additive => decomposable), cluster SE by gameid. Pooled (year FE) + per-season robust numbers.
Honest: report spec sensitivity + the unexplained residual; do NOT headline a single split.
Outputs: console + outputs/04_mediation.csv
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf

HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'), low_memory=False)
OUT=os.path.join(ROOT,'outputs')

def coef(df, formula, term='blue'):
    return smf.ols(formula, df).fit(cov_type='cluster', cov_kwds={'groups':df.gameid}).params[term]

# ---- per-season robust numbers: herald-alone & dragon-alone contributions (pp) ----
print('================ Per-season: each early objective\'s share of blue\'s edge (pp) ================')
rows=[]
for y,g in P.groupby('year'):
    d=g.dropna(subset=['firstherald','firstdragon','golddiffat15','firsttower']).copy()
    b0=coef(d,'win~blue')
    bh=coef(d,'win~blue+firstherald'); bd=coef(d,'win~blue+firstdragon')
    rows.append(dict(year=y, blue_total_pp=round(b0*100,2),
                     herald_alone_pp=round((b0-bh)*100,2), dragon_alone_pp=round((b0-bd)*100,2)))
per=pd.DataFrame(rows); print(per.to_string(index=False))
print('  herald_alone>0: top-side control explains part of blue edge; dragon_alone<0: blue wins DESPITE conceding dragon.')

# ---- pooled (year FE) ordered decomposition ----
print('\n================ Pooled ordered decomposition (year FE) ================')
d=P.dropna(subset=['firstherald','firstdragon','golddiffat15','firsttower']).copy()
d['z_gd15']=(d.golddiffat15-d.golddiffat15.mean())/d.golddiffat15.std()
b0=coef(d,'win~blue+C(year)')
b1=coef(d,'win~blue+C(year)+firstherald+firstdragon')
b2=coef(d,'win~blue+C(year)+firstherald+firstdragon+z_gd15')
b3=coef(d,'win~blue+C(year)+firstherald+firstdragon+z_gd15+firsttower')
stages=[('early objective allocation (herald+dragon)',b0-b1),
        ('early gold@15 (beyond objectives)',b1-b2),
        ('first tower (beyond above)',b2-b3),
        ('UNEXPLAINED residual (direct blue)',b3)]
print(f'  blue TOTAL: {b0*100:+.2f} pp (100%)')
out=[]
for name,v in stages:
    print(f'   -> {name:46s}: {v*100:+.2f} pp ({100*v/b0:4.0f}%)')
    out.append(dict(stage=name, pp=round(v*100,2), pct=round(100*v/b0,1)))
pd.DataFrame(out).to_csv(os.path.join(OUT,'04_mediation.csv'),index=False)
per.to_csv(os.path.join(OUT,'04_mediation_perseason.csv'),index=False)

print('''
HONEST NOTES:
 - Robust across seasons: first herald (top-side) is the engine; first dragon is a suppressor
   (blue wins DESPITE conceding it); early gold contributes positively; first tower minor.
 - The objectives-vs-gold split is spec/era-sensitive (correlated mediators) -> no single headline %.
 - A substantial residual remains unexplained by measurable channels -> consistent with an
   UNMEASURABLE root cause (map geometry/camera), which OE cannot capture (no coordinates).
''')
