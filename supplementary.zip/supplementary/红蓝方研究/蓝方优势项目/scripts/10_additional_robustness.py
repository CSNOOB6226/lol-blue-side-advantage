"""
Additional robustness checks for the blue-side analysis.
 (A) Side-exogeneity / balance check: is blue side uncorrelated with team strength (Elo)?
 (B) Bootstrap CIs (cluster by gameid) for the key mediation shares (gold@15-alone; all early channels).
 (C) Temporal out-of-sample validation: train on 2022-2024, test on 2025-2026.
Outputs: estimates and diagnostics printed to the console.
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore'); import statsmodels.formula.api as smf
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'),low_memory=False); P['void_grubs']=P['void_grubs'].fillna(0)
OUT=os.path.join(ROOT,'outputs')

print('================ (A) SIDE EXOGENEITY: is blue uncorrelated with team strength? ================')
elo=pd.read_csv(os.path.join(OUT,'06_elo.csv'))         # gameid, blue, win, own_minus_opp_elo
b=elo[elo.blue==1].dropna(subset=['own_minus_opp_elo'])
gap=b.own_minus_opp_elo                                  # blue_elo - red_elo per game
m=smf.ols('own_minus_opp_elo~1', b).fit()
print(f'mean(blue Elo - red Elo) = {gap.mean():+.2f}  (SD {gap.std():.1f}); H0: =0 -> p={m.pvalues["Intercept"]:.3f}')
print(f'  => if ~0 and non-significant, blue teams are NOT systematically stronger -> side is balanced/exogenous.')
print(f'  (for scale: 1 SD of Elo gap = {gap.std():.0f} pts; the blue imbalance is {abs(gap.mean())/gap.std():.3f} SD)')

print('\n================ (B) BOOTSTRAP CIs for mediation shares (cluster by gameid) ================')
d=P.dropna(subset=['golddiffat15','firstherald','firstdragon','firsttower','win','blue']).copy()
d['z']=(d.golddiffat15-d.golddiffat15.mean())/d.golddiffat15.std()
W=d['win'].to_numpy(float); BL=d['blue'].to_numpy(float); Z=d['z'].to_numpy(float)
H=d['firstherald'].to_numpy(float); DR=d['firstdragon'].to_numpy(float); TW=d['firsttower'].to_numpy(float)
one=np.ones(len(d))
def bluecoef(cols, idx):
    X=np.column_stack([c[idx] for c in cols]); y=W[idx]
    beta,*_=np.linalg.lstsq(X,y,rcond=None); return beta[1]   # col1 = blue
def shares(idx):
    b0=bluecoef([one,BL],idx)
    bg=bluecoef([one,BL,Z],idx)
    ba=bluecoef([one,BL,H,DR,TW,Z],idx)
    return (b0-bg)/b0, (b0-ba)/b0, b0
full=np.arange(len(d))
pt_gold,pt_all,b0=shares(full)
print(f'point: blue total +{b0*100:.2f}pp | gold@15 mediates {pt_gold*100:.0f}% | all early channels {pt_all*100:.0f}%')
# cluster bootstrap by gameid
gidx={}
for i,g in enumerate(d.gameid.to_numpy()): gidx.setdefault(g,[]).append(i)
keys=np.array(list(gidx.keys()),dtype=object); arrs={k:np.array(v) for k,v in gidx.items()}
rng=np.random.default_rng(0); REPS=300; bg_s=[]; ba_s=[]
for r in range(REPS):
    samp=rng.choice(keys,size=len(keys),replace=True)
    idx=np.concatenate([arrs[k] for k in samp])
    sg,sa,_=shares(idx); bg_s.append(sg); ba_s.append(sa)
bg_s=np.array(bg_s)*100; ba_s=np.array(ba_s)*100
print(f'gold@15-alone mediation: {pt_gold*100:.0f}%  95% CI [{np.percentile(bg_s,2.5):.0f}, {np.percentile(bg_s,97.5):.0f}]  ({REPS} cluster-bootstraps)')
print(f'all-early-channels     : {pt_all*100:.0f}%  95% CI [{np.percentile(ba_s,2.5):.0f}, {np.percentile(ba_s,97.5):.0f}]')

print('\n================ (C) TEMPORAL OUT-OF-SAMPLE: train 2022-24 -> test 2025-26 ================')
feats=['blue','golddiffat10','golddiffat15','xpdiffat15','csdiffat15','firstherald','firstdragon','firsttower','firstblood','void_grubs','killsat15']
dd=P.dropna(subset=feats+['win']).copy()
tr=dd[dd.year<=2024]; te=dd[dd.year>=2025]
sc=StandardScaler().fit(tr[feats]);
clf=LogisticRegression(max_iter=1000).fit(sc.transform(tr[feats]),tr.win)
auc=roc_auc_score(te.win, clf.predict_proba(sc.transform(te[feats]))[:,1])
print(f'train 2022-24 (n={len(tr)}) -> test 2025-26 (n={len(te)}): out-of-sample AUC = {auc:.4f}')
# blue OR on the held-out years (does the side effect generalize forward?)
mo=smf.logit('win~blue',te).fit(disp=0,cov_type='cluster',cov_kwds={'groups':te.gameid})
print(f'blue OR on held-out 2025-26 = {np.exp(mo.params.blue):.3f} (p={mo.pvalues.blue:.2g}) -> side effect generalizes forward.')
print('\nAdditional robustness checks complete.')
