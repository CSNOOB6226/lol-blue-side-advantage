"""
02_rule_out_draft.py — Is the blue advantage a DRAFT-ORDER effect (first-pick priority)?

Uses the 2026 First Selection natural experiment, which decoupled first pick from side.
Tests whether firstPick predicts winning after controlling side; LR tests; team-strength FE.
Outputs: console + outputs/02_firstpick_models.csv
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
import statsmodels.api as sm

HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'), low_memory=False)
P['team_season']=P.teamname.astype(str)+'_'+P.year.astype(str)
OUT=os.path.join(ROOT,'outputs')

print('================ A. WHY 2026 IS NEEDED: first-pick ~ blue collinearity by season ================')
for y,g in P.groupby('year'):
    gg=g[g.firstPick.notna()]
    if len(gg)==0: print(f'  {y}: no firstPick data'); continue
    share=gg[gg.firstPick==1].blue.mean()
    print(f'  {y}: firstPick==1 is Blue {100*share:5.1f}% of the time  (n={len(gg)} team-games)')
print('  -> pre-2026 first pick is ~always blue (collinear, inseparable). 2026 First Selection breaks this.')

d=P[(P.year==2026) & P.firstPick.notna()].copy()
print(f'\n================ B. 2026 natural experiment (n={len(d)} team-games, {d.gameid.nunique()} games) ================')
print('\n--- descriptive ---')
print('win rate by firstPick:'); print(d.groupby('firstPick').win.agg(['mean','size']).round(4))
print('win rate by side:'); print(d.groupby('side').win.agg(['mean','size']).round(4))
print('cross-tab side x firstPick (win rate):')
print(d.groupby(['side','firstPick']).win.agg(['mean','size']).round(4))

def logit(formula, df):
    return smf.logit(formula, df).fit(disp=0, cov_type='cluster', cov_kwds={'groups':df.gameid})
def orrow(m,term):
    b=m.params[term]; se=m.bse[term]; return np.exp(b),np.exp(b-1.96*se),np.exp(b+1.96*se),m.pvalues[term]

print('\n--- logistic models (cluster SE by gameid) ---')
m0=logit('win~firstPick',d); m1=logit('win~firstPick+blue',d)
mu=logit('win~blue',d)  # blue-only
m2=logit('win~firstPick+blue+C(league)+C(patch)',d)
rows=[]
for name,m,terms in [('M0 firstPick-only',m0,['firstPick']),
                     ('M1 firstPick+blue',m1,['firstPick','blue']),
                     ('M2 +league+patch FE',m2,['firstPick','blue'])]:
    for t in terms:
        o,lo,hi,p=orrow(m,t); rows.append(dict(model=name,term=t,OR=round(o,3),CI_lo=round(lo,3),CI_hi=round(hi,3),p=round(p,4)))
res=pd.DataFrame(rows); print(res.to_string(index=False)); res.to_csv(os.path.join(OUT,'02_firstpick_models.csv'),index=False)

# LPM for pp + team-season FE (control team strength)
lp_raw=smf.ols('win~firstPick+blue',d).fit(cov_type='cluster',cov_kwds={'groups':d.gameid})
lp_fe =smf.ols('win~firstPick+blue+C(team_season)',d).fit(cov_type='cluster',cov_kwds={'groups':d.gameid})
print('\n--- LPM (pp) and team-strength control ---')
print(f'  firstPick: raw {lp_raw.params.firstPick*100:+.2f}pp (p={lp_raw.pvalues.firstPick:.2g}) | +team FE {lp_fe.params.firstPick*100:+.2f}pp (p={lp_fe.pvalues.firstPick:.2g})')
print(f'  blue     : raw {lp_raw.params.blue*100:+.2f}pp (p={lp_raw.pvalues.blue:.2g}) | +team FE {lp_fe.params.blue*100:+.2f}pp (p={lp_fe.pvalues.blue:.2g})')

# LR tests (plain logit loglik)
def llf(formula): return smf.logit(formula,d).fit(disp=0).llf
ll_first=llf('win~firstPick'); ll_blue=llf('win~blue'); ll_both=llf('win~firstPick+blue')
from scipy.stats import chi2
lr_blue=2*(ll_both-ll_first); lr_first=2*(ll_both-ll_blue)
print('\n--- likelihood-ratio tests (df=1) ---')
print(f'  adding BLUE on top of firstPick : LR chi2={lr_blue:.2f}, p={chi2.sf(lr_blue,1):.2g}  (blue adds signal?)')
print(f'  adding firstPick on top of BLUE : LR chi2={lr_first:.2f}, p={chi2.sf(lr_first,1):.2g}  (first pick adds signal?)')
print('\nCONCLUSION: if blue is significant & firstPick is not (and team FE leaves it unchanged),')
print('the blue advantage is NOT a draft-order/first-pick effect.')
