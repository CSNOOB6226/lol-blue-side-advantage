# Why Does Blue Side Win More Often?

## Separating Map Position from Draft Priority and Tracing the Early-Game Economy in Professional *League of Legends*

**Vincent Feng**  
Independent research paper · August 2026

---

## Abstract

Professional *League of Legends* teams win more often from the blue side of Summoner's Rift, but the source of this imbalance has been difficult to isolate. Until 2026, blue side was almost always bundled with first-pick priority in champion selection, so historical estimates combined a map-position association with a possible draft-order association. Riot Games' 2026 First Selection rule partially separated these assets and created the first large professional sample in which first pick could occur on red side. Using 43,037 games (86,074 team-games) from 80 non-Chinese league labels between 2022 and 2 June 2026, this study estimates game-clustered logistic and linear probability models, adjusts for pre-match team strength, reconstructs role-level reveal order, and traces associations among side, early objectives, 15-minute gold, and match outcome. Blue teams won 52.89% of games, with season-specific win odds ratios between 1.20 and 1.31. In the 2026 sample, blue side remained positively associated with winning after first-pick status was included (OR 1.27, 95% CI 1.12-1.44), whereas first-pick priority showed no detectable independent association (OR 0.94, 95% CI 0.83-1.07). The latter interval was too wide to establish practical equivalence, so the result does not prove that first pick is valueless. Blue side was also associated with an average lead of about 275 gold at 15 minutes, substantially more first-herald and first-tower ownership, and substantially less first-dragon ownership. Teams leading in gold at 15 minutes won 74.0% of games. An associational path decomposition indicates that recent blue-side advantages are concentrated in top-side objective control and early economy, with first dragon acting as a suppressor rather than an explanation. These findings suggest that the observed imbalance tracks map position more closely than draft priority and becomes visible through the early-game economy, while leaving the underlying spatial mechanism unresolved.

**Keywords:** esports analytics; League of Legends; side advantage; first-pick priority; early-game economy; objective control; observational study

---

## 1. Introduction

Competitive balance is a basic requirement of credible sport. If one starting position systematically improves a team's chance of winning, tournament results become partly dependent on how that position is allocated. The practical response depends on the mechanism. A draft-related imbalance can be addressed through champion-selection rules; a map-related imbalance instead requires changes to map geometry, objective placement, side allocation, or series format. Estimating the size of an imbalance is therefore only the first step. The more important question is why it persists.

Professional *League of Legends* provides a useful setting for this problem. Each match begins with one team on the blue side of Summoner's Rift and the other on the red side. The map is rotationally symmetric but not mirror symmetric. The teams approach the river, lanes, jungle entrances, and neutral objectives from different directions. The game is also played through an isometric camera, so the two orientations are not visually identical. At the same time, the pre-game champion draft has historically differed by side: through 2025, the blue-side team almost always selected the first champion.

These two features created an identification problem. A higher blue-side win rate could reflect the map, first-pick access to a high-priority champion, later counter-pick opportunities on red side, team strength, or some combination of these factors. Earlier data could describe the combined imbalance but could not separate map position from draft priority because the two variables were nearly perfectly collinear.

The 2026 First Selection rule changed that institutional structure. Under the new procedure, a team with selection rights chooses either map side or first-pick priority, while its opponent receives the other asset (Riot Games, 2026). In the data used here, 25.1% of first-pick team-games in 2026 were played from red side, compared with 0% in each season from 2022 through 2025. This variation does not create random assignment: teams make strategic choices, and stronger teams may choose differently from weaker teams. It does, however, make map side and first-pick status empirically distinguishable for the first time in this sample.

This paper uses that change to study a single organizing question: **why do blue-side teams win more often?** The analysis proceeds in three stages.

First, it establishes the phenomenon. Across 43,037 professional games from 2022 through the first five months of 2026, blue-side win rates remain above 52% in every season. The association is stable in sign and survives adjustment for pre-match Elo and increasingly restrictive team controls in the pre-reform seasons.

Second, it separates map position from draft procedure. In 2026, the observed win association follows blue side more closely than first-pick status. Role-level counter-pick timing also shows little independent predictive value, although the champion match-up eventually obtained is associated with winning in several roles. This distinction is important: the evidence concerns the procedural timing of a draft, not whether drafting strong champions and coherent compositions matters.

Third, it traces where the blue-side association becomes visible in play. Blue teams are much more likely to secure the first rift herald and less likely to secure the first dragon. They also obtain first tower more often and hold an average lead of about 275 gold at 15 minutes. A positive gold differential at 15 minutes is strongly associated with winning: 74.0% of 15-minute gold leaders win the match. The resulting picture is not that one objective mechanically causes the entire advantage. Rather, blue side is associated with a distinctive early resource profile that is converted into economic tempo and, eventually, wins.

The paper makes three contributions. It uses the 2026 rule variation to separate two quantities that were previously bundled; it connects the side imbalance to an interpretable early-game economic pathway rather than treating side as a stand-alone prediction feature; and it states the limits of the evidence directly. First-pick priority is non-significant but not shown to be practically negligible. The pathway analysis is associational, because objectives and gold are not randomized and are causally ordered among themselves. The 2026 season is incomplete, and side choice is strategic. The findings therefore narrow the set of plausible explanations without claiming a randomized map effect.

## 2. Competitive Background and Related Research

### 2.1 Map side, objectives, and the early economy

Summoner's Rift contains three lanes separated by jungle territory. Five conventional roles—top, jungle, middle, bottom carry, and support—divide lane and map responsibilities. Neutral objectives are distributed asymmetrically across the river. Rift herald and, from 2024, void grubs occupy the top half of the map, while dragon occupies the bottom half. Riot's 2024 map update explicitly changed river walls, brush, gank paths, and the top-side objective schedule in an effort to make the two sides more comparable (Riot Games, 2023).

The strategic relevance of these objectives is partly economic. First blood produces direct kill gold. Rift herald can create tower pressure. First tower provides a large burst of team gold. Dragon usually offers a persistent combat bonus rather than an immediate gold payment. These rewards differ in timing and convertibility, so equal objective counts need not have equal effects on the 15-minute economy.

Research on professional *League of Legends* consistently identifies gold, towers, and objective control as strong correlates of match outcome. Martín Castellanos and Benito Corps (2021) document large differences in economic and objective variables between winners and losers at the 2019 World Championship. Novak et al. (2020) model performance at the 2018 World Championship and identify tower percentage and inhibitors in their best-performing outcome model. Young (2023) similarly finds that tower destruction and gold advantage are central performance indicators and that first blood and first tower are strongly related to economic advantage. These studies establish the importance of the early economy, but they do not isolate whether a side imbalance originates in map position or in the draft procedure bundled with that position.

Recent work also emphasizes that performance is multi-dimensional and context dependent. Sharpe et al. (2026) identify 87 performance variables across eight domains and caution against treating easily measured box-score statistics as complete descriptions of competitive performance. That warning is directly relevant here: the available data describe objectives and economy but not exact player coordinates, pathing distance, camera constraints, or ward geometry.

### 2.2 Existing evidence on side advantage

The earliest fairness work on multiplayer online battle arena games treated map side and pick order as linked design features. Wu, Xiong, and Iida (2016), for example, compared side and ban-pick win rates across several MOBA titles and reported a 58.3% blue-side win rate in 72 games from the 2015 *League of Legends* World Championship. The sample was small and descriptive, but it recognized that map asymmetry and draft order should be studied together.

Jadowski and Cunningham (2022) later reported a 54.08% blue win rate in 882 professional matches and rejected equal side win rates with a chi-square test. Their primary objective was match prediction, and they did not separate blue side from first-pick priority. The closest study to the present analysis is Kang and Kim (2025), who use 7,696 professional games from 2024, Elo ratings, and a linear probability model. They estimate an Elo-adjusted blue-side advantage of approximately 4.45 percentage points and show that the estimate varies across patches and competitive stages. Because their sample predates First Selection, their side coefficient still represents the bundle of map position and first pick.

The present study extends this literature in two directions. It uses the 2026 decoupling to estimate side and first-pick associations in the same model, and it links the side association to early objectives and 15-minute gold. The goal is explanatory rather than purely predictive.

### 2.3 Draft timing versus draft quality

Champion selection is a sequential information problem. A team selecting first can secure one high-priority champion; a team selecting later can observe more of the opponent's composition before revealing a role. Draft-recommendation research demonstrates that champion identities, player preferences, synergy, and opponent competence contain meaningful information. DraftRec, for example, uses a hierarchical recommendation model trained on 280,000 *League of Legends* matches and explicitly represents player preferences and champion interactions (Lee et al., 2022).

That literature concerns which champions are selected and how they work together. The procedural question in this paper is narrower: holding map side constant, does selecting first—or revealing a role later—carry an independent association with winning? A null result on timing would not imply that champion strength, team composition, player comfort, or match-up quality is irrelevant.

## 3. Data

### 3.1 Source, coverage, and sample construction

The data come from Oracle's Elixir, a public source of professional *League of Legends* match records. Yearly files contain player-game rows and two team-summary rows for each match. Team rows provide side, outcome, objective ownership, and economic differentials; player rows are used to map the ordered champion selections to the five roles.

The analysis covers the 2022-2026 seasons. The 2026 file ends on 2 June 2026 and is therefore incomplete. Chinese LPL and LDL games are excluded because the early-timing variables needed for the economic analysis are largely missing in those leagues. The final sample contains 43,037 games, 86,074 team-games, and 80 distinct non-Chinese league labels. Two voided or remade matches with incomplete mirrored outcomes are removed.

**Table 1. Sample composition by season**

| Season | Games | Team-games | League labels | Coverage | Blue win rate | Clean draft reconstruction |
|---|---:|---:|---:|---|---:|---:|
| 2022 | 10,641 | 21,282 | 51 | Jan 10-Dec 21 | 52.30% | 79.5% |
| 2023 | 9,372 | 18,744 | 48 | Jan 10-Nov 27 | 53.34% | 82.6% |
| 2024 | 8,803 | 17,606 | 49 | Jan 5-Dec 8 | 52.88% | 96.3% |
| 2025 | 9,221 | 18,442 | 44 | Jan 11-Dec 29 | 53.29% | 99.7% |
| 2026 | 5,000 | 10,000 | 35 | Jan 8-Jun 2 | 52.62% | 98.6% |
| **All** | **43,037** | **86,074** | **80 distinct** | Jan 2022-Jun 2026 | **52.89%** | **90.2%** |

*Note.* Clean draft reconstruction is the share of team-games belonging to matches in which all ten champion-to-pick-slot assignments were recovered.

### 3.2 Unit of observation and dependence

The principal unit is the team-game. Each match contributes exactly two rows: one for blue and one for red. These observations are deterministic mirrors—one team wins when the other loses, and opponent-difference variables reverse sign. Treating the rows as independent would understate uncertainty. All reported standard errors are therefore clustered by game identifier.

The pipeline checks that each game contains two teams, one blue and one red side, and one winner and one loser; that `win` is binary; that side labels and indicators agree; and that mirrored differential variables sum to zero. The corrected sample retains 763 games from the Portuguese league labelled LPLOL, which an earlier substring-based filter accidentally removed together with LPL.

### 3.3 Variables

The outcome `win` equals one for the winning team. `blue` equals one for the blue-side team, and `firstPick` identifies the team selecting the first champion. `rating_diff` is the difference between the team's pre-match Elo rating and its opponent's rating.

Early-state variables include first herald, first dragon, first tower, first blood, void-grub count, gold differential at 10 and 15 minutes, and experience differential at 15 minutes. The central economic variable is `golddiffat15`, defined as the team's gold minus its opponent's gold at minute 15.

Oracle's Elixir records which team secured the first named objective but not the event time for first herald, first dragon, first tower, or first blood in the files used here. These indicators are commonly interpreted as early-game events, but temporal ordering relative to minute 15 cannot be verified in every game. For this reason, regressions relating objective ownership to GD@15 are presented as composition associations, not as proof that each event occurred before and caused the recorded 15-minute lead.

To study counter-pick timing, each role's champion is matched to its team's ordered pick list. Within-team pick slots are converted to the global professional sequence. A positive role-level reveal gap means that the team revealed its champion for that role after the opponent's champion. Match-up quality is estimated from the expected 15-minute lane gold differential for the ordered champion pairing, using five-fold cross-fitting by game and empirical-Bayes shrinkage.

## 4. Empirical Strategy

### 4.1 Estimating the side association

The baseline model is a logistic regression estimated separately by season:

$$
\operatorname{logit}\left[\Pr(Win_{ig}=1)\right]
= \beta_0 + \beta_1 Blue_{ig},
$$

where team $i$ plays in game $g$. Results are reported as odds ratios. Because an odds ratio is not a probability ratio, the paper also reports linear probability estimates in percentage points when an additive interpretation is useful.

Team strength is addressed in two ways. First, a pre-match Elo rating is initialized at 1500 and updated sequentially within each league-season with $K=24$. Second, pooled linear probability models absorb own-team-season and opponent-team fixed effects. These controls do not randomize side, but they test whether repeated allocation of blue side to stronger teams mechanically explains the pooled association.

### 4.2 Separating map side from first-pick priority

In 2022-2025, `blue` and `firstPick` are collinear and cannot be entered together. The separation model is therefore estimated on 2026 only:

$$
\operatorname{logit}\left[\Pr(Win_{ig}=1)\right]
= \beta_0 + \beta_1 Blue_{ig} + \beta_2 FirstPick_{ig}.
$$

Identification comes from the 1,239 red-side first-pick team-games created by First Selection. The coefficient $\beta_2$ is not a randomized treatment effect. A team's allocation reflects side-selection rules and strategic choice; selection may correlate with team strength, opponent strength, league format, or series state.

### 4.3 Draft timing, multiple testing, and practical equivalence

For each role and season in 2025-2026, the win model includes the standardized reveal gap and blue side. The family contains ten estimates. Benjamini-Hochberg false-discovery-rate adjustment controls multiplicity (Benjamini & Hochberg, 1995).

Because failure to reject a zero coefficient does not establish a negligible effect, two one-sided equivalence tests are also reported (Lakens, 2017). The pre-specified practical-equivalence region is odds ratios from 0.909 to 1.100, corresponding to approximately ±10% in the odds of winning. Equivalence at the 5% level requires the 90% confidence interval to fall entirely inside that region. A stricter ±5% region is reported as a sensitivity check.

### 4.4 Tracing the early-game economy

The pathway analysis has four components.

First, binary objective ownership and count outcomes are regressed on blue side over team-game rows with game-clustered standard errors, estimating blue-minus-red contrasts. Signed gold and experience differences use one blue row per game to estimate the mean blue lead and its 95% confidence interval. Void-grub contrasts use 2024-2026 only.

Second, GD@15 is regressed on first-herald, first-dragon, first-tower, first-blood, void-grub count, and season indicators. The coefficients describe conditional associations with the 15-minute economy; they are not causal objective valuations.

Third, team-games are grouped into GD@15 bins to display the empirical conversion from economic state to win rate. This step is descriptive and intentionally transparent.

Fourth, a linear-probability path decomposition estimates the total blue-side win gap and the products $a_jb_j$, where $a_j$ is the side-channel association and $b_j$ is the channel-win association with channels entered jointly. Whole games are resampled in a 600-replicate cluster bootstrap. The decomposition is additive, but it is not causal mediation: the channels are not randomized, they are causally ordered among themselves, and sequential ignorability is not assumed.

### 4.5 Supplementary reform check

A league-by-season difference-in-differences model relates a league's 2026 decoupling intensity to its change in blue-side win advantage. The event study uses 2025 as the reference year. Because the pre-reform coefficients are not flat, this model is treated as a diagnostic appendix rather than a causal policy evaluation.

## 5. Results

### 5.1 Blue-side teams win more often in every observed season

Blue-side teams won 52.89% of all games, equivalent to a raw 5.79-percentage-point gap between blue and red team-games. The pattern appears in every season. The season-specific blue-side odds ratio ranges from 1.202 in 2022 to 1.307 in 2023, and every estimate is statistically distinguishable from one at $p<0.001$.

![Figure 1. Blue-side win odds ratio by season, 2022-2026.](../paper_jqas/figures/fig_en1_blue_or_by_season.png)

**Figure 1. Blue-side win odds ratio by season, 2022-2026.** Error bars are 95% confidence intervals from logistic regressions with game-clustered standard errors. The 2026 season ends on 2 June.

**Table 2. Blue-side association by season**

| Season | Blue win rate | Odds ratio | 95% CI | $p$ |
|---|---:|---:|---|---:|
| 2022 | 52.30% | 1.202 | [1.114, 1.297] | $2.2\times10^{-6}$ |
| 2023 | 53.34% | 1.307 | [1.205, 1.417] | $1.0\times10^{-10}$ |
| 2024 | 52.88% | 1.259 | [1.158, 1.369] | $6.7\times10^{-8}$ |
| 2025 | 53.29% | 1.302 | [1.199, 1.413] | $2.7\times10^{-10}$ |
| 2026 | 52.62% | 1.233 | [1.104, 1.378] | $2.1\times10^{-4}$ |

The result is not explained by a simple imbalance in team quality. In 2022-2025, adding pre-match Elo leaves the odds ratio unchanged or increases it: 1.205, 1.331, 1.338, and 1.416, respectively. In pooled linear probability models, the raw +5.79-point gap becomes +5.49 points with own-team-season fixed effects and +4.57 points after opponent-team fixed effects are added. These are robustness controls rather than causal estimates, but they show that the result is not created solely by repeated observations of strong teams.

The 2026 season is different. Adding Elo reduces the blue estimate from OR 1.233 to 1.114 (95% CI 0.990-1.254, $p=0.072$). This attenuation is consistent with non-random selection into blue side after First Selection. It does not by itself show which teams chose side, why they did so, or what the causal value of that choice was.

### 5.2 The 2026 association tracks side more closely than first pick

The raw 2026 cross-tabulation already separates the two patterns. Among blue-side team-games, teams with first pick won 52.2% and teams without it won 53.8%. Among red-side team-games, the corresponding rates were 46.2% and 47.8%. Holding first-pick status fixed, the difference between blue and red remains approximately six percentage points in both cells.

In the joint logistic model, first-pick priority has an odds ratio of 0.939 (95% CI 0.825-1.068, $p=0.34$), while blue side has an odds ratio of 1.269 (95% CI 1.115-1.443, $p<0.001$). Adding Elo moves the first-pick estimate to 0.926 ($p=0.27$).

**Table 3. Map side and first-pick priority in 2026**

| Model | Predictor | Odds ratio | 95% CI | $p$ |
|---|---|---:|---|---:|
| Side + first pick | Blue side | **1.269** | [1.115, 1.443] | $2.98\times10^{-4}$ |
| Side + first pick | First pick | 0.939 | [0.825, 1.068] | 0.340 |
| Side + first pick + Elo | First pick | 0.926 | not reported | 0.270 |

The first-pick result must be interpreted more cautiously than the blue-side result. Its 90% confidence interval, [0.843, 1.047], extends beyond the pre-specified ±10% equivalence region. The data therefore support the statement that first-pick priority has **no detectable independent association** in this partial-season sample; they do not support the stronger statement that its effect is zero or practically negligible.

### 5.3 Blue side is associated with a distinct early resource profile

The largest observable side differences occur around the map's two halves. Blue-side teams secure first herald 19.33 percentage points more often, but first dragon 19.48 points less often. They also secure first tower 8.70 points more often and first blood 2.82 points more often. From 2024 onward, blue teams collect almost one additional void grub on average.

The economic pattern is already visible by minute 10 and grows by minute 15. Blue teams lead by about 124 gold on average at minute 10 and about 275 gold at minute 15. The experience difference at minute 15 is much smaller relative to its dispersion.

**Table 4. Observable blue-minus-red contrasts and mean blue leads, 2022-2026**

| Outcome | Estimate | 95% CI | Estimate / SD |
|---|---:|---|---:|
| First herald (blue minus red) | +19.33 pp | [18.40, 20.25] | +0.387 SD |
| First dragon (blue minus red) | **-19.48 pp** | [-20.41, -18.56] | -0.390 SD |
| First tower (blue minus red) | +8.70 pp | [7.75, 9.64] | +0.174 SD |
| First blood (blue minus red) | +2.82 pp | [1.88, 3.77] | +0.056 SD |
| Void grubs, 2024-2026 (blue minus red) | +0.98 | [0.94, 1.03] | +0.521 SD |
| Gold difference at 10 minutes (mean blue lead) | +124 gold | [110, 138] | +0.084 SD |
| Gold difference at 15 minutes (mean blue lead) | **+275 gold** | [246, 303] | +0.092 SD |
| Experience difference at 15 minutes (mean blue lead) | +52 XP | [32, 72] | +0.025 SD |

*Note.* Objective ownership and grub counts are blue-minus-red contrasts over team-game rows. Signed gold and experience differences are means over one blue row per game, with 95% confidence intervals for the mean; their estimates are not doubled mirror-row contrasts.

These results reject a simple “blue gets every early objective” explanation. The side advantage is geographically asymmetric: blue gains top-side control while red gains bottom-side dragon control. The dragon difference therefore works against the blue win advantage rather than explaining it.

### 5.4 Fifteen-minute gold is the clearest economic bridge to winning

Economic state at 15 minutes is strongly ordered with final outcome. Teams with any positive GD@15 won 73.96% of games. The relationship is monotonic across the observed bins: teams behind by more than 3,000 gold won 8.1%, while teams ahead by more than 3,000 won 91.9%.

| GD@15 interval | Team-games | Win rate |
|---|---:|---:|
| Below -3,000 | 12,311 | 8.1% |
| -3,000 to -2,000 | 7,586 | 20.5% |
| -2,000 to -1,000 | 10,628 | 30.7% |
| -1,000 to -500 | 6,158 | 39.9% |
| -500 to 0 | 6,357 | 46.2% |
| 0 to +500 | 6,363 | 53.7% |
| +500 to +1,000 | 6,153 | 60.2% |
| +1,000 to +2,000 | 10,626 | 69.3% |
| +2,000 to +3,000 | 7,582 | 79.5% |
| Above +3,000 | 12,306 | 91.9% |

![Figure 2. Win rate by gold-difference bin at 15 minutes.](figures/fig_gold_conversion_en.png)

**Figure 2. Win rate by gold-difference bin at 15 minutes.** The curve uses 86,070 team-games. The annotation reports the win rate among all teams with positive GD@15, not only the displayed bin midpoints.

The objective-composition model provides a second view of this bridge. Conditional on the other listed indicators and season, first tower is associated with +2,773 GD@15, first blood with +1,431, first herald with +1,203, first dragon with +590, and each void grub with +235. All estimates have $p<0.001$ with game-clustered standard errors. The objective indicators and season effects together produce $R^2=0.478$.

**Table 5. Conditional associations with gold difference at 15 minutes**

| Predictor | Associated GD@15 difference | Interpretation |
|---|---:|---|
| First tower | +2,773 gold | Largest conditional association |
| First blood | +1,431 gold | Large immediate economic association |
| First herald | +1,203 gold | Top-side objective associated with economic tempo |
| First dragon | +590 gold | Positive for the securing team, although blue secures it less often |
| One void grub | +235 gold | Per-grub association, 2024 onward |

*Note.* OLS with season indicators and game-clustered standard errors, $N=86{,}070$. Objective ownership is not timestamped in the source files, so the table describes association with GD@15 rather than verified pre-15 causal contribution.

The distinction between first dragon's within-game value and its role in the side imbalance is important. Securing first dragon is associated with a better economic state for the team that secures it, but blue side secures it much less often. Dragon therefore suppresses the observed blue-side advantage. By contrast, blue side is associated with both greater first-herald ownership and a positive herald contribution in recent seasons.

### 5.5 The pathway changes across eras

The additive path decomposition illustrates the recent pattern. In 2026, the total blue-side win gap is +5.2 percentage points. The estimated components are +2.0 points through first herald, -1.9 through first dragon, +2.6 through GD@15, +1.3 through first tower, and +1.3 unexplained. The 2025 decomposition is similar.

![Figure 3. Associational path decomposition of the blue-side advantage in 2026.](../paper_jqas/figures/fig_en2_path_decomposition.png)

**Figure 3. Associational path decomposition of the 2026 blue-side win gap.** Components come from linear probability models with all channels entered jointly; intervals are from a 600-replicate game-cluster bootstrap.

**Table 6. Associational path decomposition**

| Component | 2025 | 95% CI | 2026 | 95% CI |
|---|---:|---|---:|---|
| Total blue-side gap | +6.6 pp | [4.6, 8.5] | +5.2 pp | [2.4, 8.0] |
| First herald component | +2.5 pp | [2.0, 2.9] | +2.0 pp | [1.3, 2.8] |
| First dragon component | -2.8 pp | [-3.3, -2.4] | -1.9 pp | [-2.4, -1.4] |
| GD@15 component | +3.6 pp | [2.8, 4.4] | +2.6 pp | [1.5, 3.7] |
| First tower component | +1.4 pp | [1.0, 1.8] | +1.3 pp | [0.7, 1.8] |
| Direct/unexplained component | +2.0 pp | [0.3, 3.6] | +1.3 pp | [-1.1, 3.5] |

The herald component is not stable across the entire study. It is negative in 2022 and 2023 (-0.6 points in each year), becomes positive in 2024 (+1.5), and grows in 2025 (+2.5) and 2026 (+2.0). In 2022-2023, GD@15 carries most of the positive association (+3.9 and +4.6 points). The sign change coincides with Riot's 2024 top-side map and objective revision, but temporal coincidence is not identification. It is better interpreted as evidence that the mechanism is patch dependent than as proof that one map update caused the change.

Adding the full set of observable pre-15-minute state variables does not remove the residual. The unexplained share remains 21% in 2024, 37% in 2025, and 24% in 2026. This is consistent with unmeasured spatial mechanisms, such as pathing or camera geometry, but it is equally consistent with other omitted variables. The data locate the gap in the early economy more successfully than they identify its physical root cause.

### 5.6 Draft timing is secondary to the match-up obtained

None of the ten role-season reveal-gap estimates is significant after false-discovery-rate correction. The odds ratios range from 0.960 to 1.042. All ten 90% confidence intervals fit inside the ±10% practical-equivalence region, although only four fit inside the stricter ±5% region. These results provide stronger support for a small counter-pick timing association than the first-pick model provides.

Controlling for cross-fitted champion match-up quality does not make reveal timing predictive. The top-lane timing estimate, for example, moves only from OR 1.020 to 1.023. Match-up quality itself is associated with winning in top (OR 1.044 per SD), bottom (1.100), and support (1.041), but not in jungle or mid. Revealing later is associated with a better measured match-up only in jungle; it is negative or null in the other four roles.

The synthesis is narrow but useful. The champion match-up a team finishes with can matter even when the procedural act of revealing later carries little independent value. This finding does not reduce drafting to a mechanical order variable; it argues for evaluating draft quality through champion strength, interaction, composition, and player fit rather than through pick position alone.

## 6. Discussion

### 6.1 What the study establishes

The observed blue-side imbalance is persistent. It appears in five consecutive seasons, survives strong-team controls in the pre-reform period, and is similar in magnitude to earlier estimates from smaller samples. In the only season where side and first pick can be entered separately, the win association follows blue side more closely than first-pick status.

The study also identifies where the imbalance becomes visible. Blue side is associated with top-side objective control and a measurable economic lead by minutes 10 and 15. GD@15 is the clearest bridge to final outcome: a 15-minute leader wins approximately three quarters of games, and win rate rises smoothly with the size of the lead. This economic interpretation fits the broader performance literature, which repeatedly identifies gold and towers as central outcome correlates.

At the same time, the results show why a single-objective story is insufficient. Blue teams concede first dragon at nearly the same rate that they gain first herald. The herald pathway changes across seasons. A substantial component remains after the observable early state is added. The mechanism is therefore better described as a patch-dependent pattern of map control and economic conversion than as “blue wins because of herald.”

### 6.2 Implications for competition design

The 2026 evidence does not show that separating first-pick priority from side was followed by a smaller blue-side imbalance. The blue odds ratio in the partial 2026 season remains inside the range observed from 2022 to 2025. However, that fact cannot distinguish a genuinely ineffective reform from an effect offset by strategic selection, league composition, or meta changes.

For tournament organizers, the conservative implication is that draft procedure should not be assumed to solve a map-position imbalance. Side alternation within series, balanced allocation rules, or map-level interventions have mechanisms that more directly correspond to the evidence. For teams, the findings suggest that early economic conversion and the match-up actually drafted deserve more attention than first/last-pick labels alone.

### 6.3 Implications for research

The remaining explanatory gap points to data rather than another regression on the same box score. Positional timelines could measure travel distance to objectives, river-entry timing, ward placement geometry, camera-facing lane interactions, and rotation speed. Objective timestamps would establish whether first tower, herald, and dragon occurred before the economic snapshot being explained. Draft data with explicit side-choice rights and series state would improve the first-pick analysis. These additions would allow future work to distinguish spatial mechanisms from strategic selection.

## 7. Limitations

**The design is observational.** Neither side nor first-pick priority is randomized in the sample. Pre-2026 allocation follows tournament procedures; in 2026 teams or formats determine the selection. The estimates are associations, not treatment effects.

**The 2026 season is partial.** Coverage ends on 2 June 2026. Every estimate that separates side from first pick relies on one incomplete season and should be refreshed when complete data are available.

**First pick is imprecisely estimated.** The coefficient is non-significant, but the equivalence test fails. A moderate association remains compatible with the confidence interval.

**Objective timing is not observed.** The source identifies the team securing first blood, first tower, first herald, and first dragon but not the event time in the files used here. The objective-to-GD@15 model is therefore descriptive and may include events occurring after minute 15.

**The pathway decomposition is not causal mediation.** Objectives, towers, and gold are mutually dependent and ordered. Estimated components vary with the channel set and season.

**Team strength is measured imperfectly.** Elo begins at 1500 within each league-season and is weak early in a season. Team fixed effects absorb stable differences but do not measure changing rosters, preparation, or within-series adaptation.

**Match-up quality is internally constructed.** Cross-fitting prevents a game from predicting itself, but the score is learned from the same professional population and is not an external benchmark of champion strength.

**The sample excludes Chinese leagues.** Missing early-timing data require exclusion of LPL and LDL, limiting generalization to the professional ecosystem as a whole.

**The residual has multiple interpretations.** Unmeasured map geometry is plausible, but any omitted variable correlated with side and outcome could produce an unexplained component.

## 8. Conclusion

Across 43,037 professional *League of Legends* games, blue-side teams win more often in every observed season. The 2026 First Selection rule makes map side and first-pick priority separately observable in a substantial professional sample. In that partial season, blue side remains positively associated with winning after first pick is controlled, while first pick has no detectable independent association. The evidence does not establish that first pick is negligible, but it shifts the empirical explanation away from draft priority alone.

The blue-side imbalance is already visible in the early economy. Blue teams obtain more top-side objectives and first towers, concede more first dragons, and average a lead of about 275 gold at 15 minutes. Teams leading at that point win 74.0% of games. The most defensible summary is therefore not that draft is irrelevant or that one objective causes the imbalance. It is that the observed advantage tracks map side, is expressed through a patch-dependent pattern of early resource control and economic tempo, and cannot yet be fully explained without positional and timestamped data.

## Data and Reproducibility

All tables and figures in this paper are generated from the project's analysis-ready team-game panel and reproducible scripts. Raw yearly match files are available from Oracle's Elixir under its own terms. The local pipeline rebuilds the derived panel, audits the mirrored game structure, and regenerates the statistical outputs with fixed random seeds.

## References

Bahrololloomi, F., Klonowski, F., Sauer, S., Horst, R., & Dörner, R. (2023). E-sports player performance metrics for predicting the outcome of *League of Legends* matches considering player roles. *SN Computer Science, 4*, 238. https://doi.org/10.1007/s42979-022-01660-6

Benjamini, Y., & Hochberg, Y. (1995). Controlling the false discovery rate: A practical and powerful approach to multiple testing. *Journal of the Royal Statistical Society: Series B, 57*(1), 289-300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x

Jadowski, R., & Cunningham, S. (2022). Statistical models for predicting results in professional *League of Legends*. In *ArtsIT, Interactivity and Game Creation*. Springer. https://doi.org/10.1007/978-3-030-95531-1_10

Kang, J., & Kim, S. (2025). A tilted eSports: An Elo rating-based analysis of side effects in *League of Legends*. *eSports Studies: Journal of the Korean Society for eSports Studies, 7*(1), 105-125. https://doi.org/10.59924/ises.2025.7.1.08

Lakens, D. (2017). Equivalence tests: A practical primer for *t* tests, correlations, and meta-analyses. *Social Psychological and Personality Science, 8*(4), 355-362. https://doi.org/10.1177/1948550617697177

Lee, H., Hwang, D., Kim, H., Lee, B., & Choo, J. (2022). DraftRec: Personalized draft recommendation for winning in multi-player online battle arena games. In *Proceedings of the ACM Web Conference 2022* (pp. 3428-3439). https://doi.org/10.1145/3485447.3512278

Martín Castellanos, A., & Benito Corps, G. (2021). Variables related to the outcome of an eSports professional tournament: Case study of the 2019 *League of Legends* World Championship Series. *International Journal of Esports, 1*(1).

Novak, A. R., Bennett, K. J. M., Pluss, M. A., & Fransen, J. (2020). Performance analysis in esports: Modelling performance at the 2018 *League of Legends* World Championship. *International Journal of Sports Science & Coaching, 15*(5-6), 809-817. https://doi.org/10.1177/1747954120932853

Riot Games. (2023, November). */dev: Season 2024 map changes*. https://www.leagueoflegends.com/en-gb/news/dev/dev-season-2024-map-changes/

Riot Games. (2026, January). *Season start 2026: LoL Esports*. https://lolesports.com/en-US/news/season-start-2026-lol-esports

Sharpe, B. T., Nicholson, M., Leis, O., Poulus, D., Birch, P. D. J., & McNulty, C. (2026). Indexing *League of Legends* performance: A systematic review and focus group study. *International Journal of Sports Science & Coaching, 21*(1). https://doi.org/10.1177/17479541251381652

Wu, M., Xiong, S., & Iida, H. (2016). Fairness mechanism in multiplayer online battle arena games. In *2016 3rd International Conference on Systems and Informatics* (pp. 387-392). IEEE. https://doi.org/10.1109/ICSAI.2016.7810986

Young, K. (2023). The best points to score: An econometric approach to competitive *League of Legends*. *Curiosity: Interdisciplinary Journal of Research and Innovation, 1*, 1-17. https://doi.org/10.36898/001c.73175

---

## Appendix A. Role-Level Counter-Pick Estimates

| Season | Role | OR per SD reveal gap | 95% CI | FDR-adjusted $p$ | Equivalent within ±10% odds? |
|---|---|---:|---|---:|---|
| 2025 | Top | 1.010 | [0.968, 1.053] | 0.813 | Yes |
| 2025 | Jungle | 0.996 | [0.956, 1.038] | 0.855 | Yes |
| 2025 | Mid | 0.960 | [0.921, 1.000] | 0.512 | Yes |
| 2025 | Bottom | 1.010 | [0.970, 1.053] | 0.813 | Yes |
| 2025 | Support | 1.033 | [0.991, 1.076] | 0.526 | Yes |
| 2026 | Top | 1.042 | [0.984, 1.102] | 0.526 | Yes |
| 2026 | Jungle | 0.980 | [0.927, 1.036] | 0.800 | Yes |
| 2026 | Mid | 1.023 | [0.967, 1.082] | 0.800 | Yes |
| 2026 | Bottom | 0.972 | [0.919, 1.028] | 0.785 | Yes |
| 2026 | Support | 0.995 | [0.941, 1.052] | 0.855 | Yes |

## Appendix B. Supplementary Reform Check

The league-by-season difference-in-differences model includes 24 leagues and 109 league-years. Adoption intensity is the share of a league's 2026 first-pick team-games played from red side. The main estimate is +4.04 percentage points per unit of adoption intensity (95% CI -4.07 to +12.15, $p=0.329$). A placebo using blue-side first-herald rate is also non-significant (+2.55 points, $p=0.465$).

The event study prevents a causal interpretation. Relative to 2025, the 2024 pre-period coefficient is +3.71 points, similar in magnitude to the 2026 coefficient of +4.62. Leagues that later decoupled side and first pick more intensively were already on different trends before the reform. The defensible conclusion is limited to the descriptive fact that the partial 2026 blue-side odds ratio does not show an obvious break from the 2022-2025 range.
