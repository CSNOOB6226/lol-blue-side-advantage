from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "figures" / "fig_path_decomposition_en.png"


def font(size: int, bold: bool = False):
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Times New Roman.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size=size)
    return ImageFont.load_default()


W, H = 1800, 1050
img = Image.new("RGB", (W, H), "white")
d = ImageDraw.Draw(img)

ink = "#202124"
navy = "#1f4d78"
positive = "#3b78b5"
negative = "#b85450"
residual = "#6b7280"
grid = "#d9dde3"
muted = "#6b7280"
panel = "#f5f7fa"

title_font = font(42, True)
subtitle_font = font(27)
label_font = font(29, True)
value_font = font(27)
axis_font = font(24)
note_font = font(23)

title = "Recent blue-side difference is concentrated in early economy and top-side control"
tb = d.textbbox((0, 0), title, font=title_font)
d.text(((W - (tb[2] - tb[0])) / 2, 30), title, fill=ink, font=title_font)

subtitle = "Associational components of the +5.2 percentage-point blue-side win difference (2026)"
sb = d.textbbox((0, 0), subtitle, font=subtitle_font)
d.text(((W - (sb[2] - sb[0])) / 2, 92), subtitle, fill=muted, font=subtitle_font)

left, top, right, bottom = 600, 200, 1660, 820
xmin, xmax = -3.0, 4.0


def xp(value):
    return left + (value - xmin) / (xmax - xmin) * (right - left)


d.rounded_rectangle((55, top - 24, 1715, bottom + 6), radius=20, fill=panel, outline="#e3e7ec", width=2)

for tick in range(-3, 5):
    x = xp(tick)
    d.line((x, top, x, bottom), fill=(navy if tick == 0 else grid), width=(4 if tick == 0 else 2))
    label = f"{tick:+d}" if tick != 0 else "0"
    bb = d.textbbox((0, 0), label, font=axis_font)
    d.text((x - (bb[2] - bb[0]) / 2, bottom + 18), label, fill=ink, font=axis_font)

items = [
    ("First herald", 2.0, 1.3, 2.8, positive),
    ("First dragon (suppressor)", -1.9, -2.4, -1.4, negative),
    ("Gold difference at 15 min", 2.6, 1.5, 3.7, positive),
    ("First tower", 1.3, 0.7, 1.8, positive),
    ("Direct / unexplained", 1.3, -1.1, 3.5, residual),
]

row_gap = 112
for idx, (name, estimate, lo, hi, color) in enumerate(items):
    y = top + 62 + idx * row_gap
    d.text((90, y - 28), name, fill=ink, font=label_font)

    value = f"{estimate:+.1f} pp  [{lo:+.1f}, {hi:+.1f}]"
    d.text((90, y + 10), value, fill=color, font=value_font)

    lo_x, hi_x, est_x = xp(lo), xp(hi), xp(estimate)
    zero_x = xp(0)
    bar_left, bar_right = sorted((zero_x, est_x))
    d.rounded_rectangle((bar_left, y - 19, bar_right, y + 19), radius=9, fill=color)
    d.line((lo_x, y, hi_x, y), fill=color, width=6)
    d.line((lo_x, y - 14, lo_x, y + 14), fill=color, width=4)
    d.line((hi_x, y - 14, hi_x, y + 14), fill=color, width=4)
    d.ellipse((est_x - 11, y - 11, est_x + 11, y + 11), fill="white", outline=color, width=4)

axis_title = "Component contribution (percentage points; 95% cluster-bootstrap CI)"
ab = d.textbbox((0, 0), axis_title, font=axis_font)
d.text(((left + right - (ab[2] - ab[0])) / 2, 876), axis_title, fill=ink, font=axis_font)

note = "Descriptive path components; objective timing is not observed in every match."
nb = d.textbbox((0, 0), note, font=note_font)
d.text(((W - (nb[2] - nb[0])) / 2, 950), note, fill=muted, font=note_font)

OUT.parent.mkdir(parents=True, exist_ok=True)
img.save(OUT, dpi=(300, 300))
print(OUT)
