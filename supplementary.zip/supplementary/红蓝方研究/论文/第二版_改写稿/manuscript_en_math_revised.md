# Why Does Blue Side Win More Often?

## Separating Map Position from Draft Priority and Quantifying the Early-Game Economy in Professional *League of Legends*

**Vincent Feng**  
Manuscript in preparation for submission · August 2026

---

## Abstract

Professional *League of Legends* teams win more often from the blue side of Summoner's Rift, but historical data have made the source of this imbalance difficult to isolate because blue side and first-pick priority were almost perfectly collinear. Riot Games' 2026 First Selection rule partially separated these assets. Using 43,037 games (86,074 team-games) from 80 non-Chinese league labels between 2022 and 2 June 2026, this study estimates game-clustered logistic regressions, linear probability models, fixed-effects specifications, and an associational path decomposition. The blue-side win rate is 52.89%, with season-specific win odds ratios from 1.20 to 1.31. In 2026, a joint model estimates a blue-side odds ratio of 1.27 (95% CI 1.12-1.44), whereas first-pick priority has no detectable independent association (OR 0.94, 95% CI 0.83-1.07). Blue side is also associated with substantially more first-herald and first-tower ownership, substantially less first-dragon ownership, and an average lead of about 275 gold at 15 minutes. A five-fold grouped predictive benchmark compares Logistic Regression, Random Forest, and XGBoost on the same early-state variables. Their mean out-of-sample AUC values are 0.834, 0.833, and 0.833, respectively; the nonlinear ensembles do not improve on the interpretable logistic benchmark under the tested specifications. The evidence therefore places the observable imbalance closer to map side than draft priority and locates its strongest measurable expression in early resource control and economy, while leaving the underlying spatial mechanism unresolved.

**Keywords:** esports analytics; League of Legends; side advantage; logistic regression; random forest; XGBoost; early-game economy; objective control

---

## 1. Introduction

Competitive balance is a basic requirement of credible sport. If one starting position is systematically associated with a higher chance of winning, tournament results partly depend on how that position is allocated. The practical response depends on the mechanism. A draft-related imbalance can be addressed through champion-selection rules; a map-related imbalance instead calls attention to map geometry, objective placement, side allocation, or series format. Estimating the size of the imbalance is therefore only the first step. The more important question is where the imbalance appears and which explanations remain compatible with the data.

Professional *League of Legends* provides a useful setting. Each match begins with one team on the blue side of Summoner's Rift and the other on the red side. The map is rotationally symmetric but not mirror symmetric. The teams approach river entrances, lanes, jungle corridors, and neutral objectives from different directions. The game is also viewed through an isometric camera, so the two orientations are not visually identical. At the same time, through 2025 the blue-side team almost always selected the first champion in the pre-game draft.

The resulting collinearity creates an identification problem. A higher blue-side win rate could reflect map position, first-pick access to a high-priority champion, team strength, or a combination of these factors. Historical data describe the combined imbalance but cannot separate map side from first-pick priority when both indicators take the same value in virtually every game.

The 2026 First Selection rule changes that empirical structure. A team with selection rights chooses either map side or first-pick priority, while its opponent receives the other asset (Riot Games, 2026). In this sample, 25.1% of first-pick team-games in 2026 occur on red side, compared with 0% in each season from 2022 through 2025. The change is not random assignment: strategic choice may correlate with team strength, opponent strength, league format, or series state. It nevertheless creates the first substantial sample in which the two coefficients can be estimated jointly.

This paper studies one organizing question: **why do blue-side teams win more often?** The analysis proceeds in four stages. First, it establishes the blue-side association and tests its stability across five seasons. Second, it estimates map-side and first-pick coefficients jointly in 2026 and examines sensitivity to pre-match Elo and fixed effects. Third, it quantifies how side is associated with early objectives, gold, experience, and the conversion of 15-minute economic state into final outcome. Fourth, it compares Logistic Regression with Random Forest and XGBoost under an identical grouped cross-validation design. This final step asks whether a flexible nonlinear learner discovers materially more predictive structure than the interpretable regression model; it is a predictive robustness check, not a causal test.

The study makes three contributions. It uses the 2026 rule variation to separate quantities that were previously bundled; it connects the observed side imbalance to an explicit system of early-state equations; and it reports the statistical architecture in sufficient detail to distinguish inference, decomposition, and prediction. The conclusions remain deliberately associational. Side and first-pick priority are not randomized in the study sample, objective timing is incompletely observed, and the machine-learning comparison cannot validate a causal mechanism. The models narrow the set of plausible explanations without claiming a randomized map effect.

## 2. Competitive Background and Related Research

### 2.1 Map side, objectives, and the early economy

Summoner's Rift contains three lanes separated by jungle territory. Five conventional roles - top, jungle, middle, bottom carry, and support - divide lane and map responsibilities. Neutral objectives are distributed asymmetrically across the river. Rift herald and, from 2024, void grubs occupy the top half of the map, while dragon occupies the bottom half. Riot's 2024 update changed river walls, brush, gank paths, and the top-side objective schedule in an effort to make the two sides more comparable (Riot Games, 2023).

The strategic relevance of these objectives is partly economic. First blood produces immediate kill gold. Rift herald can create tower pressure. First tower produces a large burst of team gold. Dragon usually provides a persistent combat bonus rather than an immediate gold payment. These rewards differ in timing and convertibility, so equal objective counts need not have equal associations with the 15-minute economy.

Research on professional *League of Legends* consistently identifies gold, towers, and objective control as strong correlates of match outcome. Martín Castellanos and Benito Corps (2021) document large economic and objective differences between winners and losers at the 2019 World Championship. Novak et al. (2020) identify tower percentage and inhibitors in their best-performing outcome model for the 2018 World Championship. Young (2023) similarly finds that tower destruction and gold advantage are central performance indicators. These studies establish the importance of economic and objective state, but they do not isolate whether a side imbalance originates in map position or in the first-pick priority historically bundled with that position.

Recent work also emphasizes that performance is multidimensional and context dependent. Sharpe et al. (2026) identify 87 performance variables across eight domains and caution against treating readily available box-score variables as complete representations of competitive performance. That warning applies directly here: the available data describe objectives and economy but not exact player coordinates, pathing distance, camera constraints, ward geometry, or team communications.

[[PAGEBREAK]]

### 2.2 Existing evidence on side advantage

Early fairness work on multiplayer online battle arena games treated map side and pick order as linked design features. Wu, Xiong, and Iida (2016), for example, report a 58.3% blue-side win rate in 72 games from the 2015 *League of Legends* World Championship. The sample is small and descriptive, but the study recognizes that map asymmetry and selection order should be examined together.

Jadowski and Cunningham (2022) later report a 54.08% blue win rate in 882 professional matches and reject equal side win rates with a chi-square test. Their primary objective is match prediction, and they do not separate blue side from first-pick priority. Kang and Kim (2025) use 7,696 professional games from 2024, Elo ratings, and a linear probability model. They estimate an Elo-adjusted blue-side advantage of approximately 4.45 percentage points and show that the estimate varies across patches and competitive stages. Because their sample predates First Selection, their side coefficient still represents the bundle of map position and first pick.

The present study extends this literature by estimating blue side and first-pick priority in the same 2026 model, connecting the side coefficient to early economic state, and benchmarking the interpretable regression against nonlinear predictive models.

### 2.3 Draft priority and strategic flexibility

Champion selection is a sequential information problem. Selecting first can secure a high-priority champion, while selecting later allows a team to observe more of the opposing composition and can create a counter-pick opportunity.

Because selection intent is not observed, the empirical draft analysis is restricted to the observable first-pick indicator.

## 3. Data, Units, and Variable Coding

### 3.1 Source, coverage, and sample construction

The data come from Oracle's Elixir, a public source of professional *League of Legends* match records. The analysis uses team-summary rows containing side, outcome, first-pick status, objective ownership, and economic differentials. The study covers the 2022-2026 seasons; the 2026 file ends on 2 June 2026 and is therefore incomplete. Chinese LPL and LDL games are excluded because the economic and objective variables required by the analysis are largely missing in those leagues. Two voided or remade matches with incomplete mirrored outcomes are also removed.

The final sample contains 43,037 games, 86,074 team-games, and 80 distinct non-Chinese league labels. Table 1 reports the seasonal composition. Each valid game contributes exactly two team-game observations.

[[PAGEBREAK]]

**Table 1. Sample composition by season**

| Season | Games | Team-games | League labels | Coverage | Blue win rate |
|---|---:|---:|---:|---|---:|
| 2022 | 10,641 | 21,282 | 51 | Jan 10-Dec 21 | 52.30% |
| 2023 | 9,372 | 18,744 | 48 | Jan 10-Nov 27 | 53.34% |
| 2024 | 8,803 | 17,606 | 49 | Jan 5-Dec 8 | 52.88% |
| 2025 | 9,221 | 18,442 | 44 | Jan 11-Dec 29 | 53.29% |
| 2026 | 5,000 | 10,000 | 35 | Jan 8-Jun 2 | 52.62% |
| **All** | **43,037** | **86,074** | **80 distinct** | Jan 2022-Jun 2026 | **52.89%** |

### 3.2 Unit of observation and dependence

Let $g=1,\ldots,G$ index games and $i\in\{1,2\}$ index the two teams within a game. The outcome rows are deterministic mirrors: $Y_{1g}+Y_{2g}=1$, and the side indicators satisfy $B_{1g}+B_{2g}=1$. Opponent-difference variables reverse sign across the paired rows. Treating the 86,074 rows as independent would therefore understate uncertainty.

All inferential regressions use standard errors clustered by `gameid`. If $s_{ig}=x_{ig}\hat{u}_{ig}$ denotes an observation-level score contribution, the cluster-robust covariance estimator aggregates the two team rows before forming the variance:

$$
V̂(β̂) = (X'X)^(-1) [Σ_g (Σ_i s_ig)(Σ_i s_ig)'] (X'X)^(-1).
$$

The predictive analysis uses the same dependence logic: GroupKFold assigns both rows from one `gameid` to the same training or test fold, preventing mirror-row leakage.

### 3.3 Dummy variables, continuous variables, and reference categories

Binary regressors are implemented as dummy (indicator) variables. Red side is the reference category for `blue`, not-first-pick is the reference category for `firstPick`, and failure to secure an objective is the reference category for each first-objective indicator. Continuous difference variables are always defined from the focal team's perspective, so positive values favor the row's team.

**Table 2. Analysis variables and coding**

| Symbol / field | Type and coding | Measurement | Statistical role |
|---|---|---|---|
| $Y_{ig}$ / `result` | Dummy: win = 1, loss = 0 | Final match outcome | Dependent variable in win models |
| $B_{ig}$ / `blue` | Dummy: blue = 1, red = 0 | Assigned/selected map side | Main exposure |
| $F_{ig}$ / `firstPick` | Dummy: first champion selected = 1, otherwise = 0 | Pre-game draft | Draft-priority regressor |
| $R_{ig}$ / `rating_diff` | Own pre-match Elo minus opponent pre-match Elo | Before the game | Team-strength control |
| $H_{ig}$ / `firstherald` | Dummy: secured first herald = 1 | Match event; exact time unavailable | Top-side objective state |
| $D_{ig}$ / `firstdragon` | Dummy: secured first dragon = 1 | Match event; exact time unavailable | Bottom-side objective state |
| $T_{ig}$ / `firsttower` | Dummy: secured first tower = 1 | Match event; exact time unavailable | Economic/objective state |
| $K_{ig}$ / `firstblood` | Dummy: secured first blood = 1 | Match event; exact time unavailable | Combat/economic state |
| $V_{ig}$ / `void_grubs` | Count; set to 0 before the mechanic existed | 2024 onward | Top-side objective count |
| $G10_{ig},G15_{ig}$ | Own gold minus opponent gold | Minutes 10 and 15 | Early economic state |
| $X10_{ig},X15_{ig}$ | Own XP minus opponent XP | Minutes 10 and 15 | Early development state |
| $α_{q},δ_{o}$ | Absorbed dummy sets | Team-season and opponent team | Fixed-effects controls |

Oracle's Elixir identifies the team securing first blood, first tower, first herald, and first dragon, but the files used here do not provide a reliable event timestamp for every game. Regressions relating these indicators to $G15$ are therefore composition associations rather than verified pre-15 causal effects.

## 4. Statistical and Machine-Learning Methods

### 4.1 Baseline Logistic Regression

Because $Y_{ig}$ is binary, the primary outcome model uses the logistic link. For season $t$, the baseline specification is

$$
p_ig = Pr(Y_ig = 1 | B_ig),    logit(p_ig) = log[p_ig / (1 - p_ig)] = β_0t + β_1t B_ig.     (1)
$$

The reported side effect is the odds ratio $OR_blue=exp(β_1t)$. An odds ratio above one indicates greater win odds for blue relative to the red reference category. Odds ratios are not probability ratios; for that reason, linear probability estimates are also reported where an additive percentage-point interpretation is useful.

### 4.2 Separating side, first pick, and team strength

From 2022 through 2025, $B_{ig}$ and $F_{ig}$ are perfectly collinear in the estimation sample and cannot enter the same regression. The 2026 separation model is

$$
logit[Pr(Y_ig = 1)] = β_0 + β_B B_ig + β_F F_ig + β_R z(R_ig).     (2)
$$

The unadjusted joint model omits $z(R_{ig})$; the Elo-adjusted version includes it. Pre-match Elo begins at 1500 and is updated sequentially within each league-season with $K=24$. Because $R_{ig}$ is computed before game $g$, it contains no information generated by the outcome being modeled.

As a complementary robustness check, pooled linear probability models absorb high-dimensional dummy-variable sets:

$$
Y_ig = β_B B_ig + α_q(i,g) + δ_o(i,g) + ε_ig.     (3)
$$

Here $α_{q(i,g)}$ denotes an own-team-by-season fixed effect and $δ_{o(i,g)}$ denotes an opponent-team fixed effect. The coefficients are estimated by the within transformation rather than by printing thousands of dummy coefficients. Algebraically, this residualizes both $Y$ and $B$ with respect to the fixed-effect groups and estimates $β_B$ from within-group variation.

### 4.3 Early-state equations

For each observable state variable $M^{(k)}_{ig}$, the pooled side association is estimated as

$$
M^(k)_ig = α_k + a_k B_ig + u^(k)_ig,     k = 1,...,K.     (4)
$$

For binary and count outcomes, Equation (4) estimates the blue-minus-red contrast over team-game rows with game-clustered standard errors; $100a_k$ is a percentage-point contrast for binary variables and $a_k$ is a count contrast for count variables. Signed gold and experience differences instead use one blue row per game to estimate the mean blue lead and its 95% confidence interval. Void-grub contrasts use 2024-2026 only.

The objective-composition model for 15-minute gold is

$$
G15_ig = θ_0 + θ_H H_ig + θ_D D_ig + θ_T T_ig + θ_K K_ig + θ_V V_ig + λ_t + η_ig,     (5)
$$

where $λ_t$ is a full set of season dummy variables. The coefficients are conditional associations with $G15$, not causal gold valuations, because exact objective timing and sequential assignment are not observed.

### 4.4 Associational path decomposition

For the mediator vector $M_{ig}=(H_{ig},D_{ig},z(G15_{ig}),T_{ig})'$, the path system is

$$
M_jig = α_j + a_j B_ig + u_jig,     j = 1,...,4,     (6a)
$$

$$
Y_ig = c' B_ig + Σ_j b_j M_jig + e_ig.     (6b)
$$

With linear probability models, the total side coefficient decomposes additively:

$$
c = c' + Σ_j a_j b_j.     (7)
$$

Each product $a_jb_j$ is reported as an indirect component and $c'$ as the direct/unexplained component. Ninety-five percent intervals come from a 600-replicate cluster bootstrap that resamples whole games, preserving the paired blue/red rows. This is an associational decomposition, not causal mediation: the channels are not randomized, they are ordered among themselves, and sequential ignorability is not assumed.

### 4.5 Predictive model triangulation

The predictive benchmark uses the complete 86,070-team-game subset (43,035 games) for which the ten features below are observed. The common feature vector is

$$
x_ig = [B_ig,G10_ig,G15_ig,X10_ig,X15_ig,H_ig,D_ig,T_ig,K_ig,V_ig]'.     (8)
$$

Logistic Regression estimates

$$
p̂_Logit(x) = σ(β_0 + Σ_j β_j x_j),     σ(z) = 1 / [1 + exp(-z)].     (9)
$$

Random Forest averages probability estimates from $L=300$ depth-limited classification trees (Breiman, 2001):

$$
p̂_RF(x) = (1/L) Σ_l h_l(x).     (10)
$$

XGBoost constructs an additive sequence of $M=300$ regression trees and maps the final score through the logistic function (Chen & Guestrin, 2016):

$$
F_M(x) = F_0(x) + Σ_m η f_m(x),     p̂_XGB(x) = σ[F_M(x)].     (11)
$$

All models use the same five grouped folds. Logistic standardization is fitted inside each training fold. Random Forest uses maximum depth 8 and minimum leaf size 5. XGBoost uses maximum depth 4, learning rate 0.10, 90% row subsampling, and 90% column subsampling. Performance is evaluated with area under the receiver-operating-characteristic curve (AUC), log loss, and Brier score:

$$
AUC_CV = (1/5) Σ_k AUC_k,     Brier = (1/N) Σ_i (Y_i - p̂_i)^2.     (12)
$$

Two chronological tests supplement GroupKFold: train through 2024 and test on 2025; then train through 2025 and test on 2026. The incremental discrimination supplied by map side is calculated as $ΔAUC_B=AUC(x)-AUC(x\setminus B)$. These comparisons test predictive adequacy under the specified feature set. They do not establish causation and do not prove that all possible nonlinear specifications are irrelevant.

**Table 3. Model specification summary**

| Analysis | Outcome | Predictor set | Estimator and dependence treatment |
|---|---|---|---|
| Seasonal side association | Win dummy $Y$ | Blue dummy $B$ | Logistic; SE clustered by game |
| 2026 side-priority separation | Win dummy $Y$ | $B$, first-pick dummy $F$, optional $z(R)$ | Logistic; SE clustered by game |
| Team-strength robustness | Win dummy $Y$ | $B$ plus absorbed dummy sets $α_q,δ_o$ | LPM; SE clustered by game |
| Side-to-state equations | Objective/economy variable $M_k$ | Blue dummy $B$ | LPM or OLS; SE clustered by game |
| Gold composition | $G15$ | $H,D,T,K,V$, season dummies | OLS; SE clustered by game |
| Path decomposition | Win dummy $Y$ | $B$ and mediator vector $M$ | LPM system; 600 game-cluster bootstrap |
| Predictive triangulation | Win dummy $Y$ | Common ten-feature vector $x$ | Logit, RF, XGBoost; 5-fold GroupKFold by game |

### 4.6 Supplementary reform check

A league-by-season difference-in-differences model relates a league's 2026 decoupling intensity to its change in blue-side win advantage. The event study uses 2025 as the reference year. Because the pre-reform coefficients are not flat, the model is retained only as a diagnostic appendix and is not interpreted as a causal policy estimate.

[[PAGEBREAK]]

## 5. Results

### 5.1 Blue-side teams win more often in every observed season

Blue-side teams won 52.89% of all games, equivalent to a raw 5.79-percentage-point difference between blue and red team-games. The association appears in every season. The season-specific blue-side odds ratio ranges from 1.202 in 2022 to 1.307 in 2023, and every estimate differs statistically from one at $p<0.001$.

![Figure 1. Blue-side win odds ratio by season, 2022-2026.](../paper_jqas/figures/fig_en1_blue_or_by_season.png)

**Figure 1. Blue-side win odds ratio by season, 2022-2026.** Error bars are 95% confidence intervals from Equation (1) with game-clustered standard errors. The 2026 season ends on 2 June.

**Table 4. Blue-side association by season**

| Season | Blue win rate | Odds ratio | 95% CI | $p$ |
|---|---:|---:|---|---:|
| 2022 | 52.30% | 1.202 | [1.114, 1.297] | $2.2\times10^{-6}$ |
| 2023 | 53.34% | 1.307 | [1.205, 1.417] | $1.0\times10^{-10}$ |
| 2024 | 52.88% | 1.259 | [1.158, 1.369] | $6.7\times10^{-8}$ |
| 2025 | 53.29% | 1.302 | [1.199, 1.413] | $2.7\times10^{-10}$ |
| 2026 | 52.62% | 1.233 | [1.104, 1.378] | $2.1\times10^{-4}$ |

The result is not generated by a simple imbalance in team quality. In 2022-2025, adding pre-match Elo leaves the odds ratio unchanged or increases it: 1.205, 1.331, 1.338, and 1.416. In pooled linear probability models, the raw +5.79-point difference becomes +5.49 points with own-team-season fixed effects and +4.57 points after opponent-team fixed effects are added. These are robustness controls rather than causal estimates, but they show that the result is not created solely by repeatedly observing strong teams on blue side.

The 2026 season differs. Adding Elo reduces the blue estimate from OR 1.233 to 1.114 (95% CI 0.990-1.254, $p=0.072$). The attenuation is consistent with non-random selection into blue side after First Selection. It does not reveal which teams selected side, why they did so, or the causal value of that choice.

### 5.2 The 2026 association tracks side more closely than first pick

The raw 2026 cross-tabulation separates the two patterns. Among blue-side team-games, teams with first pick won 52.2% and teams without it won 53.8%. Among red-side team-games, the corresponding rates were 46.2% and 47.8%. Holding first-pick status fixed, the blue-red difference remains approximately six percentage points in both cells.

In Equation (2) without Elo, first-pick priority has an odds ratio of 0.939 (95% CI 0.825-1.068, $p=0.34$), while blue side has an odds ratio of 1.269 (95% CI 1.115-1.443, $p<0.001$). Adding Elo moves the first-pick estimate to 0.926 (95% CI 0.807-1.062, $p=0.27$) and the blue-side estimate to 1.152 (95% CI 1.005-1.322, $p=0.043$).

**Table 5. Map side and first-pick priority in 2026**

| Specification | Predictor | Odds ratio | 95% CI | $p$ |
|---|---|---:|---|---:|
| Side + first pick | Blue side | **1.269** | [1.115, 1.443] | $2.98\times10^{-4}$ |
| Side + first pick | First pick | 0.939 | [0.825, 1.068] | 0.340 |
| Side + first pick + Elo | Blue side | 1.152 | [1.005, 1.322] | 0.043 |
| Side + first pick + Elo | First pick | 0.926 | [0.807, 1.062] | 0.270 |

The first-pick estimate requires more caution than the side estimate. Its 90% confidence interval, [0.843, 1.047], is too wide to establish that the association is practically negligible. The evidence supports the statement that first-pick priority has **no detectable independent association** in this partial-season sample; it does not support the stronger claim that first pick has zero value.

### 5.3 Blue side is associated with a distinct early resource profile

The largest observable side differences occur across the map's two halves. Blue-side teams secure first herald 19.33 percentage points more often but first dragon 19.48 points less often. They also secure first tower 8.70 points more often and first blood 2.82 points more often. From 2024 onward, blue teams collect almost one additional void grub on average.

The economic pattern is visible by minute 10 and grows by minute 15. Blue teams lead by about 124 gold on average at minute 10 and about 275 gold at minute 15. The corresponding experience difference at minute 15 is much smaller relative to its dispersion.

**Table 6. Observable blue-minus-red contrasts and mean blue leads, 2022-2026**

| Outcome | Estimate | 95% CI | Estimate / SD |
|---|---:|---|---:|
| First herald (blue minus red) | +19.33 pp | [18.40, 20.25] | +0.387 SD |
| First dragon (blue minus red) | **-19.48 pp** | [-20.41, -18.56] | -0.390 SD |
| First tower (blue minus red) | +8.70 pp | [7.75, 9.64] | +0.174 SD |
| First blood (blue minus red) | +2.82 pp | [1.88, 3.77] | +0.056 SD |
| Void grubs, 2024-2026 (blue minus red) | +0.98 | [0.94, 1.03] | +0.521 SD |
| Gold difference at 10 minutes (mean blue lead) | +124 gold | [110, 138] | +0.084 SD |
| Gold difference at 15 minutes (mean blue lead) | **+275 gold** | [246, 303] | +0.092 SD |
| Experience difference at 15 minutes (mean blue lead) | +52 XP | [32, 72] | +0.025 SD |

*Note.* Objective ownership and grub counts are blue-minus-red contrasts over team-game rows. Signed gold and experience differences are means over one blue row per game, with 95% confidence intervals for the mean; their estimates are not doubled mirror-row contrasts.

These estimates reject a simple “blue secures every early objective” explanation. The association is geographically asymmetric: blue gains top-side control while red gains bottom-side dragon control. The dragon difference therefore works against the blue win imbalance rather than explaining it.

### 5.4 Fifteen-minute gold is the clearest economic bridge to winning

Economic state at 15 minutes is strongly ordered with final outcome. Teams with any positive $G15$ won 73.96% of games. The relationship is monotonic across the observed bins: teams behind by more than 3,000 gold won 8.1%, while teams ahead by more than 3,000 won 91.9%.

**Table 7. Empirical win conversion by gold difference at 15 minutes**

| GD@15 interval | Team-games | Win rate |
|---|---:|---:|
| Below -3,000 | 12,311 | 8.1% |
| -3,000 to -2,000 | 7,586 | 20.5% |
| -2,000 to -1,000 | 10,628 | 30.7% |
| -1,000 to -500 | 6,158 | 39.9% |
| -500 to 0 | 6,357 | 46.2% |
| 0 to +500 | 6,363 | 53.7% |
| +500 to +1,000 | 6,153 | 60.2% |
| +1,000 to +2,000 | 10,626 | 69.3% |
| +2,000 to +3,000 | 7,582 | 79.5% |
| Above +3,000 | 12,306 | 91.9% |

![Figure 2. Win rate by gold-difference bin at 15 minutes.](figures/fig_gold_conversion_en.png)

**Figure 2. Win rate by gold-difference bin at 15 minutes.** The curve uses 86,070 team-games. The annotation reports the win rate among all teams with positive $G15$, not only the displayed bin midpoints.

Equation (5) provides a conditional view of this bridge. Holding the other listed indicators and season dummies fixed, first tower is associated with +2,773 $G15$, first blood with +1,431, first herald with +1,203, first dragon with +590, and each void grub with +235. All estimates have $p<0.001$ with game-clustered standard errors. The objective indicators and season dummies together produce $R^2=0.478$.

**Table 8. Conditional associations with gold difference at 15 minutes**

| Predictor | Associated GD@15 difference | Interpretation |
|---|---:|---|
| First tower | +2,773 gold | Largest conditional association |
| First blood | +1,431 gold | Large immediate economic association |
| First herald | +1,203 gold | Top-side objective associated with economic tempo |
| First dragon | +590 gold | Positive for the securing team, although blue secures it less often |
| One void grub | +235 gold | Per-grub association, 2024 onward |

*Note.* OLS with season dummy variables and game-clustered standard errors, $N=86{,}070$. Objective ownership is not timestamped in the source files, so the estimates describe association with $G15$ rather than verified pre-15 causal contribution.

The distinction between first dragon's within-game value and its role in the side imbalance is important. Securing first dragon is associated with a better economic state for the team that secures it, but blue side secures it much less often. Dragon therefore suppresses the observed blue-side advantage. Blue side, by contrast, is associated with both greater first-herald ownership and a positive recent herald component.

[[PAGEBREAK]]

### 5.5 The associational pathway changes across eras

The additive path decomposition illustrates the recent pattern. In 2026, the total blue-side win difference is +5.2 percentage points. The estimated components are +2.0 points through first herald, -1.9 through first dragon, +2.6 through $G15$, +1.3 through first tower, and +1.3 unexplained. The 2025 decomposition is similar.

![Figure 3. Associational path decomposition of the blue-side advantage in 2026.](figures/fig_path_decomposition_en.png)

**Figure 3. Associational path decomposition of the 2026 blue-side win difference.** Components are defined by Equations (6)-(7); intervals come from a 600-replicate game-cluster bootstrap.

**Table 9. Associational path decomposition**

| Component | 2025 | 95% CI | 2026 | 95% CI |
|---|---:|---|---:|---|
| Total blue-side difference | +6.6 pp | [4.6, 8.5] | +5.2 pp | [2.4, 8.0] |
| First herald component | +2.5 pp | [2.0, 2.9] | +2.0 pp | [1.3, 2.8] |
| First dragon component | -2.8 pp | [-3.3, -2.4] | -1.9 pp | [-2.4, -1.4] |
| GD@15 component | +3.6 pp | [2.8, 4.4] | +2.6 pp | [1.5, 3.7] |
| First tower component | +1.4 pp | [1.0, 1.8] | +1.3 pp | [0.7, 1.8] |
| Direct/unexplained component | +2.0 pp | [0.3, 3.6] | +1.3 pp | [-1.1, 3.5] |

The herald component is not stable over the entire period. It is negative in 2022 and 2023 (-0.6 points in each year), becomes positive in 2024 (+1.5), and grows in 2025 (+2.5) and 2026 (+2.0). In 2022-2023, $G15$ carries most of the positive association (+3.9 and +4.6 points). The sign change coincides with Riot's 2024 top-side map and objective revision, but temporal coincidence is not identification. It is evidence that the observable pathway is patch dependent, not proof that one update caused the change.

Adding the full set of observable state variables does not remove the residual. The unexplained share remains 21% in 2024, 37% in 2025, and 24% in 2026. This is compatible with unmeasured spatial mechanisms such as pathing or camera geometry, but it is equally compatible with other omitted variables. The data locate the difference in early economy more successfully than they identify its physical origin.

### 5.6 Logistic Regression matches the nonlinear predictive benchmarks

Table 10 compares the three model families under identical grouped folds. Logistic Regression attains the highest mean AUC (0.8343), followed by XGBoost (0.8331) and Random Forest (0.8328). The differences are approximately one to two thousandths of AUC and are smaller than the fold-to-fold standard deviations. Logistic Regression also has the lowest mean log loss and Brier score. The chronological tests preserve the same ordering closely: all models achieve AUC near 0.83 on 2025 and near 0.84 on 2026.

**Table 10. Out-of-sample predictive model comparison**

| Model | Grouped CV AUC, mean (SD) | Log loss | Brier score | $ΔAUC_B$ | 2025 time-test AUC | 2026 time-test AUC |
|---|---:|---:|---:|---:|---:|---:|
| Logistic Regression | **0.8343 (0.0036)** | **0.4990** | **0.1662** | +0.0005 | **0.8293** | **0.8447** |
| Random Forest | 0.8328 (0.0030) | 0.5014 | 0.1670 | +0.0002 | 0.8270 | 0.8443 |
| XGBoost | 0.8331 (0.0030) | 0.5011 | 0.1668 | +0.0006 | 0.8266 | 0.8438 |

*Note.* Five-fold GroupKFold by `gameid`; both team rows from one match remain in the same fold. $ΔAUC_B$ is the full-feature AUC minus the AUC after `blue` is removed from the same model. Time tests train through the preceding season and evaluate on the named season.

![Figure 4. Predictive discrimination and early-state feature importance.](../map-side-vs-draft/figures/en/fig_en6_ml_validation.png)

**Figure 4. Predictive discrimination and early-state feature importance.** Panel A reports mean grouped-fold AUC with fold standard deviations. Panel B reports test-fold Random Forest permutation importance, measured as the decrease in AUC after a feature is shuffled.

The model comparison supports the use of Logistic Regression as the primary explanatory benchmark: under the tested information set, flexible interactions and nonlinear splits do not yield better out-of-sample discrimination. The correct conclusion is conditional, not universal. It does not show that the data-generating process is linear, and it does not convert regression coefficients into causal effects.

The permutation analysis is consistent with the economic results. Shuffling $G15$ reduces Random Forest AUC by 0.091 on average; the corresponding decreases are 0.024 for $X15$, 0.008 for first dragon, and 0.005 for first tower. The AUC decrease for `blue` is only 0.00019 once the model observes the early state. Because correlated predictors can share importance, these quantities are predictive diagnostics rather than causal shares.

## 6. Discussion

### 6.1 What the study establishes

The observed blue-side imbalance is persistent. It appears in five consecutive seasons, remains under pre-match Elo and fixed-effects controls, and is similar in magnitude to estimates from smaller earlier studies. In the only season where side and first pick can be entered separately, the win association tracks blue side more closely than first-pick status.

The study also identifies where the imbalance becomes visible. Blue side is associated with top-side objective control and a measurable economic lead by minutes 10 and 15. $G15$ is the clearest observed bridge to final outcome: a 15-minute leader wins approximately three quarters of games, and win rate increases monotonically with the size of the lead.

At the same time, a one-objective story is insufficient. Blue teams concede first dragon at nearly the same rate that they gain first herald, the herald component changes across seasons, and a substantial component remains after observable state is added. The mechanism is better described as a patch-dependent pattern of map control and economic conversion than as “blue wins because of herald.”

### 6.2 What the model comparison contributes

The statistical and machine-learning models answer different questions. Logistic coefficients and fixed-effects estimates quantify interpretable conditional associations. The path equations organize those associations into an additive descriptive system. Random Forest and XGBoost test whether the same variables contain important nonlinear or interaction-based predictive structure that the logistic benchmark misses.

Their near-identical out-of-sample performance strengthens a limited methodological conclusion: the main predictive signal is not available only to a complex learner. A transparent logistic model extracts approximately the same discriminatory information as the two tree ensembles under the specified design. This makes Logistic Regression a defensible primary model when interpretation matters, while leaving causal identification to the research design and assumptions rather than to algorithmic complexity.

### 6.3 Implications for competition design and future data

The 2026 evidence does not show that separating first-pick priority from side was followed by a smaller blue-side imbalance. The blue odds ratio in the partial 2026 season remains within the 2022-2025 range. That fact cannot distinguish an ineffective reform from an effect offset by strategic selection, league composition, or meta change.

For tournament organizers, the conservative implication is that draft procedure should not be assumed to solve a map-position imbalance. Side alternation within series, balanced allocation rules, or map-level interventions correspond more directly to the observable evidence. For teams, early economic conversion deserves attention independently of first-pick labels.

The remaining explanatory gap points toward richer data rather than more complexity applied to the same box score. Positional timelines could measure travel distance to objectives, river-entry timing, ward placement geometry, camera-facing lane interactions, and rotation speed. Reliable objective timestamps would establish whether first tower, herald, and dragon occurred before the economic snapshot being explained. Draft data with explicit side-choice rights and series state would improve the first-pick analysis.

[[PAGEBREAK]]

## 7. Limitations

**The design is observational.** Neither side nor first-pick priority is randomized in the sample. Pre-2026 allocation follows tournament procedures; in 2026 teams or formats determine the selection. The estimates are associations, not treatment effects.

**The 2026 season is partial.** Coverage ends on 2 June 2026. Every estimate that separates side from first pick relies on one incomplete season and should be refreshed when full-season data become available.

**First pick is imprecisely estimated.** The coefficient is non-significant, but its interval remains compatible with a moderate association. Failure to detect an effect is not proof that first pick is valueless.

**Objective timing is not observed.** The source identifies the team securing first blood, first tower, first herald, and first dragon but not a reliable event time in every file used here. The objective-to-$G15$ model may therefore include events occurring after minute 15.

**The pathway decomposition is not causal mediation.** Objectives, towers, and gold are mutually dependent and sequentially ordered. Estimated components vary with the channel set and season.

**Team strength is measured imperfectly.** Elo begins at 1500 within each league-season and is weak early in a season. Fixed effects absorb stable group differences but do not measure roster changes, preparation, or within-series adaptation.

**The predictive benchmark is conditional on its design.** The comparison uses one feature set and pre-specified representative hyperparameters. Similar AUC values do not prove that no alternative nonlinear model can improve prediction, and predictive importance is not causal importance.

**The sample excludes Chinese leagues.** Missing economic and objective data require exclusion of LPL and LDL, limiting generalization to the professional ecosystem as a whole.

**The residual has multiple interpretations.** Unmeasured map geometry is plausible, but any omitted variable correlated with side and outcome could produce an unexplained component.

## 8. Conclusion

Across 43,037 professional *League of Legends* games, blue-side teams win more often in every observed season. The 2026 First Selection rule makes map side and first-pick priority separately observable in a substantial professional sample. In that partial season, blue side remains positively associated with winning after first pick is controlled, while first pick has no detectable independent association. The evidence does not establish that first pick is negligible, but it shifts the empirical explanation away from draft priority alone.

The imbalance is already visible in the early economy. Blue teams obtain more top-side objectives and first towers, concede more first dragons, and average a lead of about 275 gold at 15 minutes. Teams leading at that point win 74.0% of games. Logistic Regression, Random Forest, and XGBoost produce nearly identical grouped-fold AUC values, and the interpretable logistic model is not outperformed under the tested specifications. The defensible summary is therefore not that draft is irrelevant, one objective causes the imbalance, or machine learning proves the regression correct. It is that the observed advantage tracks map side, is expressed through a patch-dependent pattern of early resource control and economic tempo, and is captured as well by a transparent logistic benchmark as by the tested nonlinear ensembles.

[[PAGEBREAK]]

## Data and Reproducibility

All reported tables, figures, and model comparisons are generated from the project's analysis-ready team-game panel and reproducible scripts. The analysis pipeline verifies exactly two team rows, one blue and one red team, and one winner and one loser per game. Inferential models cluster by `gameid`; predictive models group cross-validation by the same identifier. Raw yearly files are available from Oracle's Elixir under its own terms. Random seeds and model hyperparameters are fixed in the repository.

## References

Bahrololloomi, F., Klonowski, F., Sauer, S., Horst, R., & Dörner, R. (2023). E-sports player performance metrics for predicting the outcome of *League of Legends* matches considering player roles. *SN Computer Science, 4*, 238. https://doi.org/10.1007/s42979-022-01660-6

Breiman, L. (2001). Random forests. *Machine Learning, 45*, 5-32. https://doi.org/10.1023/A:1010933404324

Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. In *Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining* (pp. 785-794). https://doi.org/10.1145/2939672.2939785

Jadowski, R., & Cunningham, S. (2022). Statistical models for predicting results in professional *League of Legends*. In *ArtsIT, Interactivity and Game Creation*. Springer. https://doi.org/10.1007/978-3-030-95531-1_10

Kang, J., & Kim, S. (2025). A tilted eSports: An Elo rating-based analysis of side effects in *League of Legends*. *eSports Studies: Journal of the Korean Society for eSports Studies, 7*(1), 105-125. https://doi.org/10.59924/ises.2025.7.1.08

Martín Castellanos, A., & Benito Corps, G. (2021). Variables related to the outcome of an eSports professional tournament: Case study of the 2019 *League of Legends* World Championship Series. *International Journal of Esports, 1*(1).

Novak, A. R., Bennett, K. J. M., Pluss, M. A., & Fransen, J. (2020). Performance analysis in esports: Modelling performance at the 2018 *League of Legends* World Championship. *International Journal of Sports Science & Coaching, 15*(5-6), 809-817. https://doi.org/10.1177/1747954120932853

Riot Games. (2023, November). */dev: Season 2024 map changes*. https://www.leagueoflegends.com/en-gb/news/dev/dev-season-2024-map-changes/

Riot Games. (2026, January). *Season start 2026: LoL Esports*. https://lolesports.com/en-US/news/season-start-2026-lol-esports

Sharpe, B. T., Nicholson, M., Leis, O., Poulus, D., Birch, P. D. J., & McNulty, C. (2026). Indexing *League of Legends* performance: A systematic review and focus group study. *International Journal of Sports Science & Coaching, 21*(1). https://doi.org/10.1177/17479541251381652

Wu, M., Xiong, S., & Iida, H. (2016). Fairness mechanism in multiplayer online battle arena games. In *2016 3rd International Conference on Systems and Informatics* (pp. 387-392). IEEE. https://doi.org/10.1109/ICSAI.2016.7810986

Young, K. (2023). The best points to score: An econometric approach to competitive *League of Legends*. *Curiosity: Interdisciplinary Journal of Research and Innovation, 1*, 1-17. https://doi.org/10.36898/001c.73175

---

## Appendix A. Machine-Learning Validation Details

The grouped-fold sample contains 86,070 team-games from 43,035 complete games. Fold membership is defined at the `gameid` level, so each game's winner and loser enter the same fold. Standardization for Logistic Regression is estimated only on the training portion of each fold. Random Forest and XGBoost use unstandardized inputs. Before 2024, `void_grubs` is coded as zero because the mechanic did not exist.

**Table A1. Random Forest test-fold permutation importance**

| Feature | Mean AUC decrease | Fold SD |
|---|---:|---:|
| Gold difference at 15 minutes | 0.09103 | 0.00331 |
| XP difference at 15 minutes | 0.02445 | 0.00065 |
| First dragon | 0.00796 | 0.00077 |
| First tower | 0.00474 | 0.00047 |
| Gold difference at 10 minutes | 0.00180 | 0.00030 |
| First herald | 0.00073 | 0.00014 |
| XP difference at 10 minutes | 0.00035 | 0.00018 |
| Blue side | 0.00019 | 0.00003 |
| Void-grub count | 0.00012 | 0.00005 |
| First blood | -0.00003 | 0.00002 |

Permutation importance is calculated on held-out folds. A negative value can occur when random shuffling slightly improves performance by chance. Correlated predictors distribute importance across one another, so the ranking must not be interpreted as a causal decomposition.

## Appendix B. Supplementary Reform Check

The league-by-season difference-in-differences model includes 24 leagues and 109 league-years. Adoption intensity is the share of a league's 2026 first-pick team-games played from red side. The main estimate is +4.04 percentage points per unit of adoption intensity (95% CI -4.07 to +12.15, $p=0.329$). A placebo using blue-side first-herald rate is also non-significant (+2.55 points, $p=0.465$).

The event study prevents a causal interpretation. Relative to 2025, the 2024 pre-period coefficient is +3.71 points, similar in magnitude to the 2026 coefficient of +4.62. Leagues that later decoupled side and first pick more intensively were already on different trends before the reform. The defensible conclusion is limited to the descriptive fact that the partial 2026 blue-side odds ratio does not show an obvious break from the 2022-2025 range.
