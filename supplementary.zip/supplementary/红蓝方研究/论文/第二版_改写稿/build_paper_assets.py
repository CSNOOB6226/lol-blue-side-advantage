from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "figures" / "fig_gold_conversion_en.png"


def font(size: int, bold: bool = False):
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Times New Roman.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size=size)
    return ImageFont.load_default()


W, H = 1800, 1050
img = Image.new("RGB", (W, H), "white")
d = ImageDraw.Draw(img)

ink = "#202124"
blue = "#2f73c9"
grid = "#d9dde3"
muted = "#6b7280"

title_font = font(42, True)
axis_font = font(29)
tick_font = font(25)
note_font = font(25)

title = "Fifteen-minute gold difference strongly orders final win probability"
tb = d.textbbox((0, 0), title, font=title_font)
d.text(((W - (tb[2] - tb[0])) / 2, 34), title, fill=ink, font=title_font)

left, top, right, bottom = 175, 155, 1690, 845
xmin, xmax = -3500, 3500
ymin, ymax = 0, 100


def xp(x):
    return left + (x - xmin) / (xmax - xmin) * (right - left)


def yp(y):
    return bottom - (y - ymin) / (ymax - ymin) * (bottom - top)


for y in [0, 20, 40, 50, 60, 80, 100]:
    color = muted if y == 50 else grid
    width = 3 if y == 50 else 2
    d.line((left, yp(y), right, yp(y)), fill=color, width=width)
    if y != 50:
        label = f"{y}"
        bb = d.textbbox((0, 0), label, font=tick_font)
        d.text((left - 22 - (bb[2] - bb[0]), yp(y) - 14), label, fill=ink, font=tick_font)

for x in [-3000, -2000, -1000, 0, 1000, 2000, 3000]:
    d.line((xp(x), top, xp(x), bottom), fill=grid, width=2)
    label = f"{x:,}"
    bb = d.textbbox((0, 0), label, font=tick_font)
    d.text((xp(x) - (bb[2] - bb[0]) / 2, bottom + 20), label, fill=ink, font=tick_font)

d.line((left, top, left, bottom), fill=ink, width=4)
d.line((left, bottom, right, bottom), fill=ink, width=4)
d.line((xp(0), top, xp(0), bottom), fill=muted, width=3)

x_mid = [-3500, -2500, -1500, -750, -250, 250, 750, 1500, 2500, 3500]
win = [8.1, 20.5, 30.7, 39.9, 46.2, 53.7, 60.2, 69.3, 79.5, 91.9]
pts = [(xp(x), yp(y)) for x, y in zip(x_mid, win)]
d.line(pts, fill=blue, width=7, joint="curve")
for px, py in pts:
    d.ellipse((px - 12, py - 12, px + 12, py + 12), fill=blue, outline="white", width=3)

annotation = "Teams ahead at 15 minutes won 74.0% of games"
abox = d.rounded_rectangle((995, 290, 1605, 368), radius=16, fill="#eef4fc", outline=blue, width=2)
d.text((1020, 311), annotation, fill=blue, font=note_font)
d.line((1200, 368, xp(1500), yp(69.3) - 15), fill=blue, width=3)

xlabel = "Gold difference at 15 minutes"
bb = d.textbbox((0, 0), xlabel, font=axis_font)
d.text(((W - (bb[2] - bb[0])) / 2, 922), xlabel, fill=ink, font=axis_font)

ylabel = "Win rate (%)"
layer = Image.new("RGBA", (320, 70), (255, 255, 255, 0))
ld = ImageDraw.Draw(layer)
ld.text((0, 0), ylabel, fill=ink, font=axis_font)
layer = layer.rotate(90, expand=True)
img.paste(layer, (42, 405), layer)

d.text((left, 980), "Source: 86,070 team-games, Oracle's Elixir, 2022-2026; 2026 ends 2 June.", fill=muted, font=note_font)

OUT.parent.mkdir(parents=True, exist_ok=True)
img.save(OUT, dpi=(300, 300))
print(OUT)
