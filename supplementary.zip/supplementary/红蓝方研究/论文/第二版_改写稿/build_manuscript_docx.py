from __future__ import annotations

import argparse
import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "manuscript_en_rewrite.md"
OUTPUT = ROOT / "manuscript_en_rewrite.docx"

FONT = "Times New Roman"
MATH_FONT = "Cambria Math"
NAVY = "1F4D78"
MUTED = "5F6670"
LIGHT_FILL = "E8EEF5"
GRID = "B7BDC5"
WIDTH_DXA = 9360
TABLE_INDENT_DXA = 120


def set_run_font(run, name=FONT, size=None, bold=None, italic=None, color=None):
    run.font.name = name
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:hAnsi"), name)
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)


def style_font(style, name=FONT, size=11, bold=False, italic=False, color="000000"):
    style.font.name = name
    style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:ascii"), name)
    style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:hAnsi"), name)
    style._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), name)
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.italic = italic
    style.font.color.rgb = RGBColor.from_string(color)


def set_cell_margins(table, top=80, bottom=80, start=120, end=120):
    tbl_pr = table._tbl.tblPr
    old = tbl_pr.find(qn("w:tblCellMar"))
    if old is not None:
        tbl_pr.remove(old)
    mar = OxmlElement("w:tblCellMar")
    for side, value in (("top", top), ("bottom", bottom), ("start", start), ("end", end)):
        node = OxmlElement(f"w:{side}")
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")
        mar.append(node)
    tbl_pr.append(mar)


def set_table_borders(table):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.find(qn("w:tblBorders"))
    if borders is not None:
        tbl_pr.remove(borders)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), GRID)
        borders.append(el)
    tbl_pr.append(borders)


def set_table_geometry(table, widths):
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths)))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(TABLE_INDENT_DXA))
    tbl_ind.set(qn("w:type"), "dxa")

    old_grid = table._tbl.tblGrid
    for child in list(old_grid):
        old_grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        old_grid.append(col)

    for row in table.rows:
        for cell, width in zip(row.cells, widths):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def mark_header_row(row):
    tr_pr = row._tr.get_or_add_trPr()
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    tr_pr.append(header)


def keep_row_together(row):
    tr_pr = row._tr.get_or_add_trPr()
    cant = OxmlElement("w:cantSplit")
    tr_pr.append(cant)


def set_picture_alt(shape, text):
    doc_pr = shape._inline.docPr
    doc_pr.set("descr", text)
    doc_pr.set("title", text)


def add_page_field(paragraph):
    run = paragraph.add_run()
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    run._r.addnext(fld)


def clean_math(text):
    replacements = {
        r"\operatorname{logit}": "logit",
        r"\Pr": "Pr",
        r"\ldots": "…",
        r"\in": "∈",
        r"\left": "",
        r"\right": "",
        r"\beta": "β",
        r"\times": "×",
        r"\pm": "±",
        r"\hat": "",
        r"\setminus": " without ",
        r"\{": "{",
        r"\}": "}",
        r"\,": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"_\{([^}]+)\}", r"_\1", text)
    text = re.sub(r"\^\{([^}]+)\}", r"^\1", text)
    text = text.replace("\\", "")
    text = text.replace("{", "").replace("}", "")
    return text.strip()


def add_math_runs(paragraph, text, size=None):
    """Render simple underscore/caret math as real Word sub/superscript runs."""
    text = clean_math(text)
    parts = re.split(r"(_[A-Za-z0-9]+|\^\([^)]*\)|\^[+\-]?[A-Za-z0-9]+)", text)
    for part in parts:
        if not part:
            continue
        mode = None
        value = part
        if part.startswith("_"):
            mode, value = "sub", part[1:]
        elif part.startswith("^"):
            mode, value = "sup", part[1:]
            if value.startswith("(") and value.endswith(")"):
                value = value[1:-1]
        run = paragraph.add_run(value)
        set_run_font(run, name=MATH_FONT, size=size, italic=(mode is None))
        if mode == "sub":
            run.font.subscript = True
        elif mode == "sup":
            run.font.superscript = True


INLINE = re.compile(r"(\*\*.+?\*\*|\*[^*]+?\*|`[^`]+?`|\$[^$]+?\$)")


def add_inline(paragraph, text, base_size=None, base_italic=False):
    pos = 0
    for match in INLINE.finditer(text):
        if match.start() > pos:
            run = paragraph.add_run(text[pos:match.start()])
            set_run_font(run, size=base_size, italic=base_italic)
        token = match.group(0)
        if token.startswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, size=base_size, bold=True, italic=base_italic)
        elif token.startswith("*"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, size=base_size, italic=True)
        elif token.startswith("`"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, name="Courier New", size=(base_size or 11) - 0.5)
        else:
            add_math_runs(paragraph, token[1:-1], size=base_size)
        pos = match.end()
    if pos < len(text):
        run = paragraph.add_run(text[pos:])
        set_run_font(run, size=base_size, italic=base_italic)


def paragraph_kind(text):
    if text.startswith("**Table "):
        return "table_caption"
    if text.startswith("**Figure "):
        return "figure_caption"
    return "body"


def add_text_paragraph(doc, text, section_name):
    kind = paragraph_kind(text)
    if kind == "table_caption":
        p = doc.add_paragraph(style="Table Caption")
        p.paragraph_format.keep_with_next = True
        add_inline(p, text, base_size=9.5)
    elif kind == "figure_caption":
        p = doc.add_paragraph(style="Figure Caption")
        add_inline(p, text, base_size=9.0, base_italic=True)
    elif section_name == "References":
        p = doc.add_paragraph(style="Reference")
        add_inline(p, text, base_size=9.5)
    else:
        p = doc.add_paragraph(style="Normal")
        add_inline(p, text, base_size=10.8)
    return p


def column_widths(headers, rows):
    weights = []
    for j, header in enumerate(headers):
        longest = max([len(header)] + [len(r[j]) if j < len(r) else 0 for r in rows])
        weights.append(max(0.8, min(2.4, longest / 15)))
    total = sum(weights)
    widths = [int(WIDTH_DXA * w / total) for w in weights]
    widths[-1] += WIDTH_DXA - sum(widths)
    return widths


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1, cols=len(headers))
    widths = column_widths(headers, rows)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    size = 8.2 if len(headers) >= 6 else 8.8 if len(headers) >= 5 else 9.2

    for idx, value in enumerate(headers):
        cell = table.rows[0].cells[idx]
        cell.text = ""
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        shade_cell(cell, LIGHT_FILL)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        add_inline(p, value, base_size=size)
        for run in p.runs:
            run.font.bold = True
            run.font.color.rgb = RGBColor.from_string(NAVY)
    mark_header_row(table.rows[0])
    keep_row_together(table.rows[0])

    for row_values in rows:
        row = table.add_row()
        keep_row_together(row)
        for idx, value in enumerate(row_values):
            cell = row.cells[idx]
            cell.text = ""
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            numeric = bool(re.match(r"^[\[\]$+\-−0-9.,%×^ ]+$", value)) or value in {"Yes", "No"}
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if numeric else WD_ALIGN_PARAGRAPH.LEFT
            add_inline(p, value, base_size=size)

    set_table_geometry(table, widths)
    set_cell_margins(table)
    set_table_borders(table)
    after = doc.add_paragraph()
    after.paragraph_format.space_after = Pt(1)
    return table


def configure_styles(doc):
    styles = doc.styles
    normal = styles["Normal"]
    style_font(normal, FONT, 10.8)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.15
    normal.paragraph_format.widow_control = True

    # Use document-specific paragraph styles rather than Word's built-in
    # outline styles.  Some LibreOffice versions import outline paragraphs as
    # side/run-in headings and let the following text frame spill across pages.
    # Avoid style names ending in "Heading 1/2": LibreOffice heuristically
    # maps those names back onto its side-heading presets even without outline
    # properties.
    top_heading = "Section Title"
    sub_heading = "Subsection Title"
    minor_heading = "Minor Section Title"
    for heading_style in (top_heading, sub_heading, minor_heading):
        if heading_style not in styles:
            styles.add_style(heading_style, WD_STYLE_TYPE.PARAGRAPH)
        styles[heading_style].base_style = normal

    for name, size, before, after in (
        (top_heading, 15, 16, 7),
        (sub_heading, 12.5, 12, 5),
        (minor_heading, 11.5, 9, 4),
    ):
        st = styles[name]
        # Keep the styles visually and semantically named as headings while
        # omitting converter-sensitive outline/frame/keep-next properties.
        p_pr = st._element.get_or_add_pPr()
        for tag in ("w:framePr", "w:keepNext", "w:outlineLvl"):
            node = p_pr.find(qn(tag))
            if node is not None:
                p_pr.remove(node)
        style_font(st, FONT, size, bold=True, color=NAVY)
        st.paragraph_format.space_before = Pt(before)
        st.paragraph_format.space_after = Pt(after)
        st.paragraph_format.widow_control = True

    caption = styles["Caption"]
    style_font(caption, FONT, 9, italic=True, color="333333")

    if "Table Caption" not in styles:
        styles.add_style("Table Caption", 1)
    style_font(styles["Table Caption"], FONT, 9.5, bold=True, color="111111")
    styles["Table Caption"].paragraph_format.space_before = Pt(8)
    styles["Table Caption"].paragraph_format.space_after = Pt(4)

    if "Figure Caption" not in styles:
        styles.add_style("Figure Caption", 1)
    style_font(styles["Figure Caption"], FONT, 9, italic=True, color="333333")
    styles["Figure Caption"].paragraph_format.space_before = Pt(3)
    styles["Figure Caption"].paragraph_format.space_after = Pt(8)

    if "Reference" not in styles:
        styles.add_style("Reference", 1)
    style_font(styles["Reference"], FONT, 9.5, color="111111")
    styles["Reference"].paragraph_format.left_indent = Inches(0.25)
    styles["Reference"].paragraph_format.first_line_indent = Inches(-0.25)
    styles["Reference"].paragraph_format.space_after = Pt(5)
    styles["Reference"].paragraph_format.line_spacing = 1.0


def configure_section(section):
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)
    section.different_first_page_header_footer = True

    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run("BLUE-SIDE ADVANTAGE IN PROFESSIONAL LEAGUE OF LEGENDS")
    set_run_font(run, name="Arial", size=8, bold=True, color=MUTED)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fp.paragraph_format.space_before = Pt(0)
    fp.paragraph_format.space_after = Pt(0)
    add_page_field(fp)
    for run in fp.runs:
        set_run_font(run, name="Arial", size=8, color=MUTED)


def add_title_page(doc, title, subtitle, author, metadata):
    for _ in range(3):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(10)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(16)
    run = p.add_run(title)
    set_run_font(run, size=23, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(34)
    run = p.add_run(subtitle)
    set_run_font(run, size=14, italic=True, color="374151")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(7)
    run = p.add_run(author.replace("**", ""))
    set_run_font(run, size=12, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(metadata.replace("  ", " ").replace("·", "-").strip())
    set_run_font(run, size=10.5, color=MUTED)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(42)
    p.paragraph_format.space_after = Pt(0)
    p_pr = p._p.get_or_add_pPr()
    p_bdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "8")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), NAVY)
    p_bdr.append(bottom)
    p_pr.append(p_bdr)

    doc.add_page_break()


def parse_markdown(doc, lines, start_index):
    i = start_index
    section_name = ""
    paragraph_buffer = []

    def flush():
        nonlocal paragraph_buffer
        if paragraph_buffer:
            text = " ".join(x.strip() for x in paragraph_buffer).strip()
            if text:
                add_text_paragraph(doc, text, section_name)
            paragraph_buffer = []

    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()

        if not stripped:
            flush()
            i += 1
            continue
        if stripped == "---":
            flush()
            i += 1
            continue

        if stripped == "[[PAGEBREAK]]":
            flush()
            doc.add_page_break()
            i += 1
            continue

        if stripped == "$$":
            flush()
            i += 1
            eq_lines = []
            while i < len(lines) and lines[i].strip() != "$$":
                eq_lines.append(lines[i].strip())
                i += 1
            eq = clean_math(" ".join(eq_lines))
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(5)
            p.paragraph_format.space_after = Pt(7)
            add_math_runs(p, eq, size=10.5)
            i += 1
            continue

        image_match = re.match(r"!\[(.*?)\]\((.*?)\)", stripped)
        if image_match:
            flush()
            alt, rel = image_match.groups()
            image_path = (ROOT / rel).resolve()
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.keep_with_next = True
            run = p.add_run()
            picture_width = 5.25 if "gold-difference bin" in alt.lower() else 6.15
            shape = run.add_picture(str(image_path), width=Inches(picture_width))
            set_picture_alt(shape, alt)
            i += 1
            continue

        if stripped.startswith("## "):
            flush()
            heading = stripped[3:]
            section_name = re.sub(r"\*", "", heading)
            if section_name.startswith("Appendix A."):
                doc.add_page_break()
            # Direct-format a Normal paragraph.  LibreOffice can otherwise
            # reinterpret even custom heading styles as run-in headings.
            p = doc.add_paragraph(style="Normal")
            p.paragraph_format.space_before = Pt(16)
            p.paragraph_format.space_after = Pt(7)
            add_inline(p, heading, base_size=15)
            for run in p.runs:
                set_run_font(run, size=15, bold=True, color=NAVY)
            i += 1
            continue
        if stripped.startswith("### "):
            flush()
            heading = stripped[4:]
            p = doc.add_paragraph(style="Normal")
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(5)
            add_inline(p, heading, base_size=12.5)
            for run in p.runs:
                set_run_font(run, size=12.5, bold=True, color=NAVY)
            i += 1
            continue

        if stripped.startswith("|") and i + 1 < len(lines) and re.match(r"^\|(?:\s*:?-+:?\s*\|)+$", lines[i + 1].strip()):
            flush()
            headers = [x.strip() for x in stripped.strip("|").split("|")]
            i += 2
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                values = [x.strip() for x in lines[i].strip().strip("|").split("|")]
                if len(values) < len(headers):
                    values += [""] * (len(headers) - len(values))
                rows.append(values[: len(headers)])
                i += 1
            add_table(doc, headers, rows)
            continue

        paragraph_buffer.append(stripped)
        i += 1

    flush()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()

    lines = source.read_text(encoding="utf-8").splitlines()
    title = lines[0][2:].strip()
    subtitle = lines[2][3:].strip()
    author = lines[4].strip()
    metadata = lines[5].strip()

    doc = Document()
    configure_styles(doc)
    configure_section(doc.sections[0])
    doc.core_properties.title = f"{title}: {re.sub(r'\*', '', subtitle)}"
    doc.core_properties.author = "Vincent Feng"
    doc.core_properties.subject = "Professional League of Legends blue-side advantage"
    doc.core_properties.keywords = "esports analytics, League of Legends, blue side, early-game economy"

    add_title_page(doc, title, re.sub(r"\*", "", subtitle), author, metadata)
    parse_markdown(doc, lines, 7)
    doc.save(output)
    print(output)


if __name__ == "__main__":
    main()
