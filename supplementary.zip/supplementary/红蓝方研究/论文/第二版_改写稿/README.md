# 第二版论文稿件与构建源码

| 文件 | 内容 |
|---|---|
| `manuscript_en_math_revised.md` | 英文数学模型版稿件，包含变量编码、模型方程与预测比较。 |
| `manuscript_en_rewrite.md` | 英文叙事版稿件，包含角色选取顺序、TOST 与 FDR 分析。 |
| `build_manuscript_docx.py` | 将 Markdown 稿件转换为 Word 文档。 |
| `build_paper_assets.py` | 构建经济转化图。 |
| `build_path_figure.py` | 构建关联路径分解图。 |
| `figures/fig_gold_conversion_en.png` | 英文经济转化图。 |
| `figures/fig_path_decomposition_en.png` | 英文路径分解图。 |

