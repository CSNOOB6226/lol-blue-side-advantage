from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUTPUT = str(Path(__file__).resolve().parents[1] / 'manuscript/League_of_Legends_esports_literature_review.docx')
Path(OUTPUT).parent.mkdir(parents=True, exist_ok=True)

BLUE = RGBColor(31, 78, 121)
DARK_BLUE = RGBColor(17, 45, 78)
MUTED = RGBColor(90, 98, 108)
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F2F4F7"
WHITE = RGBColor(255, 255, 255)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=100, start=120, bottom=100, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_repeat_keep(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    keep_next = OxmlElement("w:keepNext")
    p_pr.append(keep_next)


def set_font(run, size=11, bold=False, italic=False, color=None):
    run.font.name = "Arial"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Arial")
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = color


def add_rich_paragraph(doc, segments, style=None, align=None, before=0, after=6):
    p = doc.add_paragraph(style=style)
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.15
    for text, kwargs in segments:
        run = p.add_run(text)
        set_font(run, **kwargs)
    return p


def add_body(doc, text, bold_prefix=None):
    if bold_prefix and text.startswith(bold_prefix):
        return add_rich_paragraph(
            doc,
            [
                (bold_prefix, {"bold": True}),
                (text[len(bold_prefix):], {}),
            ],
        )
    return add_rich_paragraph(doc, [(text, {})])


def add_bullet(doc, text, level=0):
    style = "List Bullet" if level == 0 else "List Bullet 2"
    p = doc.add_paragraph(style=style)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    set_font(p.add_run(text))
    return p


def add_number(doc, text):
    p = doc.add_paragraph(style="List Number")
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    set_font(p.add_run(text))
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    p.paragraph_format.keep_with_next = True
    set_font(
        p.add_run(text),
        size={1: 16, 2: 13, 3: 12}[level],
        bold=True,
        color=BLUE if level < 3 else DARK_BLUE,
    )
    return p


def add_equation(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.keep_together = True
    set_font(p.add_run(text), size=11, italic=True, color=DARK_BLUE)
    return p


def add_link_line(doc, label, url):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    set_font(p.add_run(f"{label}: "), bold=True)
    set_font(p.add_run(url), color=BLUE)
    return p


def add_section_intro(doc):
    add_heading(doc, 'Literature selection', 1)
    add_body(doc, 'The five papers cover:')
    for item in [
        'Real-time win probability prediction',
        'Player-champion experience',
        'Within-team gold allocation',
        'Player performance evaluation',
        'Team-level match prediction',
    ]:
        add_bullet(doc, item)
    add_body(
        doc,
        "Only paper 3 directly uses professional match data. The other papers primarily use ranked games, so their findings should be re-evaluated with Oracle's Elixir before being applied to professional play.",
    )


def add_paper_1(doc):
    add_heading(doc, "1. Smart Kills and Worthless Deaths: eSports Analytics for League of Legends", 1)
    add_heading(doc, 'Full citation', 2)
    add_body(doc, "Maymin, P. Z. (2021). “Smart kills and worthless deaths: eSports analytics for League of Legends.” Journal of Quantitative Analysis in Sports, 17(1), 11–27.")
    add_link_line(doc, 'Paper link', "https://doi.org/10.1515/jqas-2019-0096")

    add_heading(doc, 'Research question', 2)
    add_body(doc, 'Can high-frequency game-state data improve on conventional kills, deaths and gold when used to:')
    add_bullet(doc, 'Predict match win probability;')
    add_bullet(doc, "Measure a player's contribution to team victory?")

    add_heading(doc, 'Dataset', 2)
    add_body(doc, 'The author collected millions of ranked LoL games using spectator systems, computer vision and client data collection.')
    add_body(doc, 'The main analysis uses:')
    for item in [
        'Approximately 150,000 matches on the same patch;',
        'Players ranked from Bronze to Challenger;',
        'Game states sampled once per minute;',
        'Champion positions, abilities, damage, vision and resource states.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Methods', 2)
    for item in [
        'Logistic regression',
        'Stochastic gradient descent (SGD)',
        'Fast-and-frugal trees (FFT)',
        'Correlation analysis',
        'Role-specific regression',
        'Computer vision data collection',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Main variables', 2)
    for item in [
        "Game minute",
        "Team kills",
        "Towers destroyed",
        "Major monsters killed",
        "Champion location",
        "Movement and map coverage",
        "Damage dealt and received",
        "Vision and vision denial",
        'Health, mana and cooldowns',
        "Smart kills",
        "Worthless deaths",
        "Survivability",
        "Time management",
        "Laning performance",
        "Gold-related metrics",
    ]:
        add_bullet(doc, item)
    add_body(doc, 'Definitions:')
    add_bullet(doc, "Smart kill: a kill followed by a substantial increase in the team's predicted win probability.")
    add_bullet(doc, 'Worthless death: a death that offers insufficient strategic return and substantially lowers win probability.')

    add_heading(doc, 'Main findings', 2)
    add_body(doc, 'Metrics weighted by the impact of actions on win probability explain team victory better than conventional KDA.')
    add_body(doc, 'A simplified decision tree using advanced performance metrics achieves approximately 80% prediction accuracy.')
    add_body(doc, 'Kills are not equally valuable. A kill reflects meaningful contribution when it substantially improves team win probability.')

    add_heading(doc, 'Limitations', 2)
    for item in [
        'The data describe ranked rather than professional play;',
        "The collection process is complex and cannot be fully reproduced with Oracle's Elixir;",
        'The collected data span multiple patches;',
        'The simplified win-probability model omits gold difference, champion composition and player strength;',
        'The results are predictive associations and do not establish causation.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Implications for this project', 2)
    add_body(doc, 'Win probability added (WPA) can be used to evaluate key top-lane actions.')
    add_body(doc, 'For example:')
    add_equation(doc, 'WPA = P(win after action) − P(win before action)')
    add_body(doc, 'This distinguishes:')
    for item in ['Valuable top-lane kills;', 'Solo kills with little strategic value;', 'Sacrifices that secure team resources;', 'Deaths that substantially damage win probability.']:
        add_bullet(doc, item)

    add_heading(doc, 'Most relevant research topic', 2)
    add_body(doc, "5. Early-Game Win Probability Modeling")


def add_paper_2(doc):
    add_heading(doc, "2. Using Machine Learning to Predict Game Outcomes Based on Player-Champion Experience in League of Legends", 1)
    add_heading(doc, 'Full citation', 2)
    add_body(doc, "Do, T. D., Wang, S. I., Yu, D. S., McMillian, M. G., & McMahan, R. P. (2021). “Using Machine Learning to Predict Game Outcomes Based on Player-Champion Experience in League of Legends.” Proceedings of the 16th International Conference on the Foundations of Digital Games.")
    add_link_line(doc, 'Paper link', "https://doi.org/10.1145/3472538.3472579")
    add_link_line(doc, 'Preprint link', "https://arxiv.org/abs/2108.02799")

    add_heading(doc, 'Research question', 2)
    add_body(doc, "Can match outcomes be predicted before play begins using only players' experience with their selected champions?")

    add_heading(doc, 'Dataset', 2)
    for item in [
        "Riot Games API",
        '5,000 distinct ranked matches from 2020',
        'North American server',
        'Iron to Diamond ranks',
        "80% Training Set",
        "20% Test Set",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Methods', 2)
    for item in [
        'Deep neural network (DNN)',
        'Random forest (RF)',
        'Gradient boosting',
        'Support vector classifier (SVC)',
        'k-nearest neighbors (kNN)',
        'Pearson correlation',
        'Stratified cross-validation',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Main variables', 2)
    add_body(doc, 'Player-level variables include:')
    for item in [
        "Champion mastery points",
        "Player-champion win rate",
        "Season games played on champion",
        "Champion games among the last 20 games",
    ]:
        add_bullet(doc, item)
    add_body(doc, 'Team-level summaries include:')
    for item in ["Mean", "Median", "Variance", "Standard deviation", "Skewness", "Kurtosis"]:
        add_bullet(doc, item)
    add_body(doc, 'The final model contains 44 features.')

    add_heading(doc, 'Main findings', 2)
    for item in [
        'Gradient boosting achieves approximately 75.4% accuracy;',
        'The DNN achieves approximately 75.1% accuracy;',
        'Champion win rate and mastery points are strong predictors;',
        'Champion game count alone is a weaker predictor.',
    ]:
        add_bullet(doc, item)
    add_body(doc, 'Playing many games on a champion does not necessarily imply proficiency.')

    add_heading(doc, 'Limitations', 2)
    for item in [
        'The sample contains only 5,000 matches;',
        'Only one server and one season are represented;',
        'Elite professional competition is not covered;',
        'Matchups, team composition, patch and team strength are not fully controlled;',
        'Random splits do not test prediction on future patches.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Implications for this project', 2)
    add_body(doc, 'When evaluating the value of additional gold on a champion, controls should include:')
    for item in [
        "The player's champion proficiency;",
        "The player's previous performance on that champion;",
        'Player × champion interaction.',
    ]:
        add_bullet(doc, item)
    add_body(doc, 'An additional 500 gold may have different value when the same top laner plays a familiar versus an unfamiliar champion.')

    add_heading(doc, 'Most relevant research topic', 2)
    add_body(doc, "4. Marginal Value of Gold by Champion")


def add_paper_3(doc):
    add_heading(doc, "3. Analysis of Team Resource Allocation and Win Percentages in League of Legends", 1)
    add_heading(doc, 'Full citation', 2)
    add_body(doc, "Larose, C. D., & Mehling, S. A. (2022). “Analysis of Team Resource Allocation and Win Percentages in League of Legends.” Proceedings of the Joint Statistical Meetings, 699–715.")
    add_link_line(doc, 'Paper link', "https://0633e92166c0a27ea1aa-ab47878a9e45eb9e2f15be38a59f867e.ssl.cf1.rackcdn.com/JTJLFYSY-2258804-1828585-Upload-1669675867.pdf")

    add_heading(doc, 'Research question', 2)
    add_body(doc, 'How is the distribution of team gold across the five roles at 15 minutes associated with final win probability in professional matches?')

    add_heading(doc, 'Dataset', 2)
    for item in [
        "Oracle’s Elixir",
        '2019 LCS Spring and Summer',
        '184 regular-season matches',
        'The main model excludes matches with an absolute gold difference greater than 2,000 at 15 minutes',
    ]:
        add_bullet(doc, item)
    add_body(doc, 'This restriction focuses the analysis on close games whose outcomes are less clearly determined.')

    add_heading(doc, 'Methods', 2)
    for item in [
        "Classification and Regression Trees，CART",
        'Association rule mining',
        "Correlation Analysis",
        "Train/Test Evaluation",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Main variables', 2)
    for item in [
        "Top gold share at 15",
        "Jungle gold share at 15",
        "Mid gold share at 15",
        "Bot gold share at 15",
        "Support gold share at 15",
        "Team side",
        "Gold difference at 15",
        "Match result",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Main findings', 2)
    add_body(doc, 'CART achieves 60.7% accuracy, above the 53.5% baseline that always predicts a blue-side win.')
    add_body(doc, 'Main findings include:')
    for item in [
        'Higher red-side top-lane gold share is associated with a greater blue-side win probability;',
        'Blue-side teams have higher win rates when their top-lane gold share remains within a normal range;',
        'Top-lane and bot-lane gold shares exhibit a clear resource trade-off;',
        'More balanced gold allocation is generally associated with higher win rates in close games;',
        'Concentrating a very large amount of gold on top lane is not necessarily optimal.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Limitations', 2)
    for item in [
        'The sample is small;',
        'Only one league and one season are studied;',
        'CART thresholds may be unstable;',
        'Champion type, lane matchup, player strength, patch and team strength are not controlled;',
        'Gold allocation and win probability are associated; the analysis does not establish causation;',
        'High top-lane gold share may reflect reactive side-lane farming by a team that is already behind.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Implications for this project', 2)
    add_body(doc, 'This paper is the closest match to the current research question.')
    add_body(doc, 'Possible extensions include:')
    for item in [
        'Use more seasons and leagues;',
        'Distinguish tank and carry top laners;',
        'Use restricted cubic splines;',
        'Include team, player, champion and patch fixed effects;',
        'Test whether carry top laners have a gold threshold.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Most relevant research topic', 2)
    add_body(doc, "3. Carry Top Gold Threshold")
    add_body(doc, 'It is also closely related to:')
    add_bullet(doc, "1. Tank Top vs Carry Top")
    add_bullet(doc, "2. Weak-Side Top Effect")


def add_paper_4(doc):
    add_heading(doc, "4. The SIDO Performance Model for League of Legends", 1)
    add_heading(doc, 'Full citation', 2)
    add_body(doc, "Zhang, A. X., & Naidu, P. (2024). “The SIDO Performance Model for League of Legends.” arXiv preprint arXiv:2403.04873.")
    add_link_line(doc, 'Paper link', "https://arxiv.org/abs/2403.04873")

    add_heading(doc, 'Research question', 2)
    add_body(doc, 'Can player performance be separated into:')
    add_number(doc, 'Resources obtained by the player;')
    add_number(doc, 'Resources enabled for teammates;')
    add_number(doc, 'Resources denied to opponents?')

    add_heading(doc, 'Dataset', 2)
    for item in [
        'High-ranked solo queue collected through the Riot API',
        'NA, EUW and Korean servers',
        "Patch 13.14–13.18",
        'The top 1,000 accounts in the daily rankings',
        'At least 50 games per account',
        'At least 30 distinct accounts per champion',
        'Game states at 7, 15 and 25 minutes',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Methods', 2)
    for item in [
        'Hierarchical Bayesian models',
        "Player Random Effects",
        "Champion Random Effects",
        "Plus-Minus Model",
        'Residual-based contribution models',
        "t-tests",
        'Metric stability analysis',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Main variables', 2)
    for item in [
        "Gold earned",
        "Damage dealt to champions",
        "Damage taken",
        "Player",
        "Champion",
        "Role",
        "Region",
        "Game phase",
        "Ally residual performance",
        "Enemy residual performance",
        "Professional-player account status",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Core framework', 2)
    add_body(doc, 'SIDO separates player performance into:')
    add_equation(doc, "Own Contribution + Ally-Enabling Contribution + Enemy-Denial Contribution")
    add_body(doc, 'In other words:')
    for item in ['Resources obtained directly;', 'Resources enabled for teammates;', 'Resources denied to enemies.']:
        add_bullet(doc, item)

    add_heading(doc, 'Main findings', 2)
    for item in [
        'SIDO distinguishes high-level players better than simple averages and conventional plus-minus models;',
        'Denying opponents gold is an important contribution of professional junglers;',
        'ADC performance depends more strongly on individual mechanics and direct damage;',
        'Jungle and support value is reflected more strongly in strategic and team contributions;',
        'Individual gold or damage alone is insufficient to evaluate performance.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Limitations', 2)
    for item in [
        'Solo queue differs from coordinated professional play;',
        'Professional-player accounts are not completely identified;',
        'Ally-enabling and enemy-denial contributions are less clearly distinguished;',
        'Only a short patch window is covered;',
        'The model is complex and may require simplification for an undergraduate project.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Implications for this project', 2)
    add_body(doc, 'Top-lane performance can be separated into:')
    add_equation(doc, "Own Gold + Gold Enabled for Teammates + Gold Denied from Opponents")
    add_body(doc, 'This framework is particularly useful for weak-side top-lane analysis.')
    add_body(doc, 'A weak-side top laner may:')
    for item in [
        'Receive relatively little gold;',
        'Face frequent pressure from the opposing jungler;',
        'Absorb substantial pressure;',
        'Enable additional resources for the allied bot lane and jungler;',
        "Have negative GD15 while still contributing to the team's overall position.",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Most relevant research topic', 2)
    add_body(doc, "2. Weak-Side Top Effect")
    add_body(doc, 'It is also closely related to topic 4, Marginal Value of Gold by Champion.')


def add_paper_5(doc):
    add_heading(doc, "5. Multi-Objective Multi-Instance Learning: A New Approach to Machine Learning for eSports", 1)
    add_heading(doc, 'Full citation', 2)
    add_body(doc, "Birant, K. U., & Birant, D. (2023). “Multi-Objective Multi-Instance Learning: A New Approach to Machine Learning for eSports.” Entropy, 25(1), 28.")
    add_link_line(doc, 'Paper link', "https://doi.org/10.3390/e25010028")

    add_heading(doc, 'Research question', 2)
    add_body(doc, 'Does modeling five players jointly as a team predict match outcomes more accurately than treating players as independent observations?')

    add_heading(doc, 'Dataset', 2)
    for item in [
        'Public ranked LoL data from Kaggle',
        '1,834,520 player records',
        'North America and Europe',
        "Season 3–7",
        'Approximately 40 match-performance variables',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Methods', 2)
    for item in [
        "Multi-Instance Logistic Regression",
        "Multi-Instance SVM",
        "Multi-Instance Boosting",
        "Decision Trees",
        "SimpleMI",
        "10-Fold Cross-Validation",
        "Mann–Whitney U Test",
        "Feature Importance Analysis",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Main variables', 2)
    for item in [
        "Kills",
        "Deaths",
        "Assists",
        "Damage",
        "Healing",
        "Wards",
        "Vision score",
        "Gold earned",
        "Turret kills",
        "Rewards",
        "Per-minute statistics",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Main findings', 2)
    for item in [
        'Team-level multi-instance models generally outperform player-level models;',
        'SimpleMI achieves approximately 94% average accuracy;',
        'Turret kills, deaths per minute and assists per minute are important predictors;',
        'Model performance varies substantially between seasons.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Limitations', 2)
    add_body(doc, 'A central limitation is that many variables may be measured at the end of a match.')
    add_body(doc, 'Using final turret counts, deaths or damage to predict the outcome can produce:')
    add_body(doc, 'Outcome leakage / data leakage')
    add_body(doc, 'High accuracy does not demonstrate that the model can predict outcomes early in a match.')
    add_body(doc, 'Further limitations include:')
    for item in [
        'Random cross-validation does not test future seasons;',
        'Patch changes are not fully addressed;',
        'The emphasis is prediction accuracy rather than statistical interpretation;',
        'The models do not directly answer causal strategy questions.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Implications for this project', 2)
    add_body(doc, 'LoL data have a hierarchical structure:')
    add_equation(doc, "Player ⊂ Role ⊂ Team ⊂ Match")
    add_body(doc, 'Player-game rows therefore should not be treated as fully independent observations.')
    add_body(doc, 'Suitable approaches include:')
    for item in [
        "Mixed-Effects Logistic Regression",
        "Clustered Standard Errors",
        "Team Fixed Effects",
        "Player Random Effects",
        "Champion Random Effects",
    ]:
        add_bullet(doc, item)

    add_heading(doc, 'Most relevant research topic', 2)
    add_body(doc, "5. Early-Game Win Probability Modeling")
    add_body(doc, 'The main methodological lesson is to avoid data leakage.')


def add_synthesis(doc):
    add_heading(doc, 'Comparative synthesis', 1)
    rows = [
        ("Common datasets", "Riot API ranked games, Kaggle Riot data, Oracle's Elixir professional matches and fixed-minute game states"),
        ("Common variables", "Gold, gold share, gold difference, kills, deaths, assists, damage, towers, objectives, champion, role, game time"),
        ("Common methods", "Logistic Regression, Decision Trees, Gradient Boosting, Neural Networks, Cross-Validation, Hierarchical Models"),
        ("Common weaknesses", 'Limited transfer from ranked to professional play; patch instability; small professional samples; random rather than temporal validation; data leakage'),
        ("Player evaluation weakness", 'Individual gold, damage and KDA often overlook pressure absorption, ally enabling and enemy denial'),
        ("Statistical weakness", 'Repeated observations of teams, players and champions are often ignored; clustered standard errors or mixed models are missing'),
        ("Causal weakness", 'Most studies establish associations or prediction, not that changing gold allocation causes higher win rates'),
        ("Evaluation weakness", 'Accuracy receives more attention than calibration, Brier score, log loss or uncertainty intervals'),
        ("Research gaps", 'Weak-side top lane, champion-specific gold efficiency, nonlinear gold thresholds, tank/carry interactions and resource opportunity costs'),
        ("Validation gaps", 'Validation across patches, seasons and leagues, and genuinely out-of-sample evaluation, remain uncommon'),
    ]
    table = doc.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.columns[0].width = Inches(1.75)
    table.columns[1].width = Inches(4.75)
    hdr = table.rows[0].cells
    hdr[0].text = 'Dimension'
    hdr[1].text = 'Common practices or findings'
    set_repeat_table_header(table.rows[0])
    for cell in hdr:
        set_cell_shading(cell, LIGHT_BLUE)
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for p in cell.paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:
                set_font(r, bold=True, color=DARK_BLUE)
    for label, detail in rows:
        cells = table.add_row().cells
        cells[0].width = Inches(1.75)
        cells[1].width = Inches(4.75)
        cells[0].text = label
        cells[1].text = detail
        for cell in cells:
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.05
                for r in p.runs:
                    set_font(r, size=9.5)
        set_cell_shading(cells[0], LIGHT_GRAY)
        for r in cells[0].paragraphs[0].runs:
            r.bold = True


def add_borrowed_ideas(doc):
    add_heading(doc, 'A. Five adaptable research designs', 1)

    add_heading(doc, "1. Gold-Share Threshold Model", 2)
    add_body(doc, 'Extend Larose and Mehling without relying on a single decision tree to identify thresholds.')
    add_body(doc, 'A possible model is:')
    add_equation(doc, "P(Win) = f(Top Gold Share₁₅) + Controls")
    add_body(doc, 'The function f can use:')
    for item in ["Restricted Cubic Splines;", "Segmented Regression;", "Quadratic Terms."]:
        add_bullet(doc, item)
    add_body(doc, 'This tests whether top-lane gold exhibits:')
    for item in ['Increasing returns;', 'Diminishing marginal returns;', 'An optimal range;', 'Negative associations after excessive investment.']:
        add_bullet(doc, item)

    add_heading(doc, "2. Champion-Adjusted Gold Efficiency", 2)
    add_body(doc, 'Adapt SIDO using champion and player random effects.')
    add_body(doc, 'For example:')
    add_equation(doc, "Damageᵢ = β₀ + β₁Goldᵢ + uChampion + uPlayer + εᵢ")
    add_body(doc, "Compare champions' efficiency in converting gold into damage or win probability.")

    add_heading(doc, "3. Top-Lane Win Probability Added", 2)
    add_body(doc, 'Following Maymin, estimate an early-game win-probability model and evaluate changes associated with top-lane events.')
    add_body(doc, 'Candidate events include:')
    for item in [
        "First Blood involving top",
        "Top death before 15",
        "Rift Herald",
        "First top turret",
        "Teleport play",
        "Top-lane solo kill",
    ]:
        add_bullet(doc, item)

    add_heading(doc, "4. Player-Champion Interaction", 2)
    add_body(doc, 'Following Do et al., examine:')
    add_equation(doc, "Player × Champion")
    add_body(doc, 'Separate champion strength from player ability, and player proficiency from champion gold efficiency.')

    add_heading(doc, "5. Nested Team Modeling", 2)
    add_body(doc, "Adapt MOMIL's team-level perspective using more interpretable statistical models:")
    add_equation(doc, "Player-Game ⊂ Team-Game ⊂ Match")
    add_body(doc, 'Suitable undergraduate methods include:')
    for item in [
        "Mixed-Effects Logistic Regression;",
        "Team Fixed Effects;",
        "Patch Fixed Effects;",
        'Standard errors clustered by match or team.',
    ]:
        add_bullet(doc, item)


def add_rare_analyses(doc):
    add_heading(doc, "B. Five feasible extensions using Oracle's Elixir", 1)

    add_heading(doc, "1. Nonlinear Marginal Value of Top Gold", 2)
    add_body(doc, 'Examine whether additional top-lane gold has different marginal value for tanks and carries:')
    add_equation(doc, "P(Win) = f(Top Gold Share₁₅) + Top Type + f(Gold Share) × Top Type + Controls")
    add_body(doc, 'Key questions include:')
    for item in [
        'Do carry top laners require a gold threshold before becoming effective?',
        'Do tank top laners retain strategic value at low gold levels?',
        'Do carry top laners exhibit diminishing returns at high gold levels?',
    ]:
        add_bullet(doc, item)

    add_heading(doc, "2. Weak-Side Residual Performance Index", 2)
    add_body(doc, "First predict a top laner's expected GD15 under the observed conditions:")
    add_equation(doc, "GD15̂ = f(Champion Matchup, Side, Player, Opponent, Patch, Team Strength)")
    add_body(doc, 'Then calculate:')
    add_equation(doc, "Weak-Side Residual = Actual GD15 − GD15̂")
    add_body(doc, 'If a player is expected to trail by 700 gold but actually trails by only 250 gold:')
    add_equation(doc, "−250 − (−700) = 450")
    add_body(doc, "The player's weak-side performance exceeds the prediction.")

    add_heading(doc, "3. Gold Opportunity-Cost Analysis", 2)
    add_body(doc, 'Evaluate allocating gold to top lane rather than mid or bot.')
    add_body(doc, "The five roles' gold shares sum to approximately 100%, making them compositional data.")
    add_body(doc, 'Recommended methods include:')
    for item in [
        "Log-Ratio Transformation;",
        "Isometric Log-Ratio，ILR;",
        "Relative Gold Share;",
        "Role-to-Role Gold Trade-Off.",
    ]:
        add_bullet(doc, item)
    add_body(doc, 'This addresses:')
    add_body(doc, 'Holding team gold constant, how is transferring 1% of gold share from bot to top associated with win probability?')

    add_heading(doc, "4. Champion-Specific Gold Response Curves", 2)
    add_body(doc, 'For champions with sufficient observations, estimate:')
    add_equation(doc, "Gold → Damage")
    add_body(doc, 'And:')
    add_equation(doc, "Gold → P(Win)")
    add_body(doc, 'Use partial pooling to shrink estimates for small-sample champions toward their archetype mean.')
    add_body(doc, 'This permits comparison of:')
    for item in [
        'Gold-conversion efficiency among carry top laners;',
        'Response-curve shapes for tanks and carries;',
        'Champions that benefit substantially only after an item spike.',
    ]:
        add_bullet(doc, item)

    add_heading(doc, "5. Strategy-Player Compatibility", 2)
    add_body(doc, "Estimate each top laner's historical resource-allocation pattern:")
    add_equation(doc, "Historical Top Gold Share")
    add_body(doc, "Then calculate the current game's deviation from that pattern:")
    add_equation(doc, "|Current Gold Share − Historical Gold Share|")
    add_body(doc, 'Test:')
    for item in [
        'Whether assigning a carry role to a habitual weak-side player is associated with lower win probability;',
        "Whether a resource-oriented player's strengths are underused on tanks;",
        'Whether player style interacts with team strategy.',
    ]:
        add_bullet(doc, item)



def configure_styles(doc):
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.49)
    section.footer_distance = Inches(0.49)

    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.15

    for name, size, color, before, after in [
        ("Heading 1", 16, BLUE, 16, 8),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ]:
        style = doc.styles[name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for list_style in ["List Bullet", "List Bullet 2", "List Number"]:
        style = doc.styles[list_style]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
        style.font.size = Pt(11)
        style.paragraph_format.space_after = Pt(4)
        style.paragraph_format.line_spacing = 1.15


def add_header_footer(section):
    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hp.paragraph_format.space_after = Pt(0)
    set_font(hp.add_run('League of Legends esports statistics | Literature review'), size=9, color=MUTED)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = fp.add_run("Page ")
    set_font(run, size=9, color=MUTED)
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)


def build():
    doc = Document()
    configure_styles(doc)
    add_header_footer(doc.sections[0])

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(110)
    p.paragraph_format.space_after = Pt(12)
    set_font(p.add_run('League of Legends esports statistics'), size=28, bold=True, color=DARK_BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    set_font(p.add_run('Five-paper review and research-design proposals'), size=18, bold=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    set_font(p.add_run('Topics: Top-Lane Resource Allocation, Player Performance and Win Probability'), size=11, color=MUTED)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(p.add_run('Undergraduate statistics research materials'), size=11, color=MUTED)

    doc.add_page_break()
    add_section_intro(doc)
    add_paper_1(doc)
    add_paper_2(doc)
    add_paper_3(doc)
    add_paper_4(doc)
    add_paper_5(doc)
    add_synthesis(doc)
    add_borrowed_ideas(doc)
    add_rare_analyses(doc)

    doc.core_properties.title = 'League of Legends esports statistics: five-paper review and research-design proposals'
    doc.core_properties.subject = "League of Legends esports statistics literature review"
    doc.core_properties.author = "Vincent"
    doc.core_properties.keywords = "League of Legends, esports, statistics, Oracle's Elixir"
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    build()
