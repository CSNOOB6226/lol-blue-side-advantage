"""Check that report publishing preserves numeric evidence in English output."""
import importlib.util
from pathlib import Path
import re
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd
from docx import Document

ROOT = Path(__file__).resolve().parents[2]


def load_module(name, relative_path):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def all_text(doc):
    paragraphs = [paragraph.text for paragraph in doc.paragraphs]
    cells = [cell.text for table in doc.tables for row in table.rows for cell in row.cells]
    return '\n'.join(paragraphs + cells)


class EnglishReportTests(unittest.TestCase):
    def test_topic1_english_report_preserves_numeric_tables(self):
        module = load_module('topic1_english', 'topics/code/topic1_weakside_toplane/build_topic1_report.py')
        summary = pd.DataFrame([['stable_weak_side', 837, 0.778, 0.180, 47.6]], columns=['group', 'N', 'win_rate', 'mean_share', 'mean_gold_difference'])
        coefficients = pd.DataFrame([['M3', 'stable_weak_side', 1.370, 3.933, 3.321, 4.658, '<0.001']], columns=['model', 'variable', 'coefficient', 'odds_ratio', 'ci_low', 'ci_high', 'p_value'])
        fit = pd.DataFrame([['M3', 10000, -6764.6, -6931.5, 0.024]], columns=['model', 'N', 'log_likelihood', 'null_log_likelihood', 'pseudo_r2'])
        tests = pd.DataFrame([['M3', 'stable_weak_side', 250.0, 1, '<0.001']], columns=['model', 'test', 'lr_chi_square', 'df', 'p_value'])
        analysis = {
            'q25': 0.188,
            'summaries': {'quartiles': summary, 'stable': summary},
            'coef_table': coefficients, 'fit_table': fit, 'lr_table': tests,
        }
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'topic1_report.docx'
            with patch.object(module, 'OUT', output):
                module.build_mirrored_docx(analysis)
            doc = Document(output)
            text = all_text(doc)
            self.assertIsNone(re.search(r'[\u3400-\u9fff]', text))
            self.assertIn('Research Question', text)
            self.assertIn('3.933', text)
            self.assertEqual(sum(p.text == 'English Report' for p in doc.paragraphs), 1)

    def test_topic3_english_report_preserves_core_coefficients(self):
        module = load_module('topic3_english', 'topics/code/topic3_carry_toplane_gold_threshold/analyze_carry_toplane_gold_threshold.py')
        data_dir = ROOT / 'topics/data/topic3_carry_toplane_gold_threshold'
        coefficients = pd.read_csv(data_dir / 'topic3_logistic_coefficients.csv')
        core = coefficients[coefficients['variable'].isin(module.MODEL_CONTINUOUS_FEATURES[:3])]
        controls = coefficients[coefficients['variable'].isin(module.MODEL_CONTINUOUS_FEATURES[3:])]
        fit = pd.read_csv(data_dir / 'topic3_model_fit_metrics.csv').iloc[0].to_dict()
        tests = pd.read_csv(data_dir / 'topic3_likelihood_ratio_tests.csv')
        predictions = pd.read_csv(data_dir / 'topic3_gold_threshold_predictions.csv')
        model = pd.DataFrame(index=range(int(fit['N'])))
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'topic3_report.docx'
            with patch.object(module, 'DOCX_OUT', output):
                module.build_mirrored_topic3_docx(
                    model, core, controls, coefficients, fit, tests, predictions,
                    'No 10 percentage-point threshold was found.',
                    'logit(P(Win_i = 1)) = beta0 + beta1(is_carry_i)',
                    module.load_ml_results(),
                )
            doc = Document(output)
            text = all_text(doc)
            self.assertIsNone(re.search(r'[\u3400-\u9fff]', text))
            self.assertIn('Core Carry-Threshold Variables', text)
            self.assertIn('-2000.000', text)
            self.assertIn('0.230', text)
            self.assertEqual(sum(p.text == 'Research Report' for p in doc.paragraphs), 1)


if __name__ == '__main__':
    unittest.main()
