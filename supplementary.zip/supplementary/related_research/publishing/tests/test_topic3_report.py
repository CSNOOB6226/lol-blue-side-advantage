import importlib.util
from pathlib import Path
import unittest

import pandas as pd
from docx import Document


SCRIPT = (
    Path(__file__).resolve().parents[2]
    / "topics/code/topic3_carry_toplane_gold_threshold/analyze_carry_toplane_gold_threshold.py"
)


def load_topic3_module():
    spec = importlib.util.spec_from_file_location("topic3_report", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Topic3ReportTests(unittest.TestCase):
    def test_inferential_model_excludes_post_15_minute_controls(self):
        module = load_topic3_module()
        forbidden = {
            "dragon_diff",
            "herald_diff",
            "void_grubs_diff",
            "game_length_5min",
        }

        self.assertFalse(forbidden & set(module.MODEL_CONTINUOUS_FEATURES))

    def test_add_table_only_formats_explicit_p_value_columns_as_p_values(self):
        module = load_topic3_module()
        doc = Document()
        data = pd.DataFrame(
            [{"top_gold_diff15": -2000, "p_value": 0.0001}]
        )

        module.add_table(doc, data)

        self.assertEqual(doc.tables[0].cell(1, 0).text, "-2000.000")
        self.assertEqual(doc.tables[0].cell(1, 1).text, "<0.001")


if __name__ == "__main__":
    unittest.main()
