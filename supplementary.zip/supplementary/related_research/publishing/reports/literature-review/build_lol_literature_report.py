from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT = str(Path(__file__).resolve().parents[3] / 'manuscript/League_of_Legends_esports_literature_review_revised.docx')
Path(OUT).parent.mkdir(parents=True, exist_ok=True)


def set_run_font(run, size=None, bold=None, color=None, font="Calibri"):
    run.font.name = font
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)


def set_para_spacing(paragraph, before=0, after=6, line=1.10):
    fmt = paragraph.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line


def add_p(doc, text="", style=None, size=11, bold=False, color="111827", after=6, before=0):
    p = doc.add_paragraph(style=style)
    set_para_spacing(p, before=before, after=after)
    if text:
        r = p.add_run(text)
        set_run_font(r, size=size, bold=bold, color=color)
    return p


def add_heading(doc, text, level):
    p = doc.add_paragraph(style=f"Heading {level}")
    set_para_spacing(p, before=16 if level == 1 else 10, after=6)
    r = p.add_run(text)
    set_run_font(r, size={1: 16, 2: 13, 3: 12}[level], bold=True, color="2E74B5" if level < 3 else "1F4D78")
    return p


def add_bullets(doc, items, level=0):
    style = "List Bullet" if level == 0 else "List Bullet 2"
    for item in items:
        p = doc.add_paragraph(style=style)
        set_para_spacing(p, after=4, line=1.167)
        r = p.add_run(item)
        set_run_font(r, size=10.5, color="111827")


def add_numbered(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Number")
        set_para_spacing(p, after=4, line=1.167)
        r = p.add_run(item)
        set_run_font(r, size=10.5, color="111827")


def add_callout(doc, title, body):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), "F4F6F9")
    tc_pr.append(shd)
    p = cell.paragraphs[0]
    set_para_spacing(p, after=3)
    r = p.add_run(title)
    set_run_font(r, size=10.5, bold=True, color="1F4D78")
    p2 = cell.add_paragraph()
    set_para_spacing(p2, after=0, line=1.15)
    r2 = p2.add_run(body)
    set_run_font(r2, size=10.5, color="111827")
    doc.add_paragraph()


def add_citation(doc, citation, links=None):
    add_p(doc, 'Full citation', size=10.5, bold=True, color="1F4D78", after=2)
    add_p(doc, citation, size=10.5, color="111827", after=2)
    if links:
        for label, url in links:
            add_p(doc, f"{label}: {url}", size=9.5, color="4B5563", after=1)


def setup_styles(doc):
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    for name in ["Heading 1", "Heading 2", "Heading 3"]:
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string("2E74B5" if name != "Heading 3" else "1F4D78")


def build():
    doc = Document()
    setup_styles(doc)

    p = add_p(doc, 'League of Legends esports statistics', size=24, bold=True, color="0B2545", after=2)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = add_p(doc, 'Five-paper review and research-design proposals: revised report', size=18, bold=True, color="2E74B5", after=10)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = add_p(doc, 'Topics: Top-Lane Resource Allocation, Gold Distribution, Marginal Value of Gold and Win Probability', size=11, color="4B5563", after=18)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_callout(
        doc,
        'Revision scope',
        'This version replaces the earlier comparative synthesis and research-design lists, and expands paper 3 into a project-oriented review of Analysis of Team Resource Allocation and Win Percentages in League of Legends. The focus is tank versus carry top laners, weak-side play, gold distribution, the marginal value of gold and win probability.'
    )

    add_heading(doc, '1. Literature selection', 1)
    add_p(doc, "The five papers cover win-probability prediction, champion experience, within-team gold allocation, player evaluation and team-level modeling. Only paper 3 directly uses professional match data; findings from ranked or other public game data require re-evaluation with Oracle's Elixir before application to professional play.", size=11)
    add_bullets(doc, [
        'Real-time win probability prediction',
        'Player-champion experience',
        'Within-team gold allocation / gold share',
        'Player performance evaluation',
        'Team-level match prediction',
    ])

    add_heading(doc, '2. Paper 1: Smart Kills and Worthless Deaths', 1)
    add_citation(
        doc,
        "Maymin, P. Z. (2021). Smart kills and worthless deaths: eSports analytics for League of Legends. Journal of Quantitative Analysis in Sports, 17(1), 11–27.",
        [('Paper link', "https://doi.org/10.1515/jqas-2019-0096")],
    )
    add_heading(doc, 'Research question and data', 2)
    add_p(doc, 'The paper asks whether high-frequency game-state data improve on conventional KDA, kills and gold when predicting team wins and evaluating individual contributions. Spectator systems, computer vision and client collection provide ranked-game data. The main analysis uses approximately 150,000 matches on one patch, sampled by minute for position, abilities, damage, vision and resource states.')
    add_heading(doc, 'Main methods and variables', 2)
    add_bullets(doc, [
        'Methods include logistic regression, stochastic gradient descent, fast-and-frugal trees, correlation analysis, role-specific regression and computer vision data collection.',
        'Variables include game minute, team kills, towers, major monsters, champion positions, damage, vision, health, mana, cooldowns and gold metrics.',
        'A smart kill substantially increases predicted team win probability. A worthless death lacks sufficient strategic return and substantially reduces it.'
    ])
    add_heading(doc, 'Main findings', 2)
    add_bullets(doc, [
        'Metrics weighted by their association with win probability explain team victory better than conventional KDA.',
        'A simplified decision tree using advanced performance metrics achieves approximately 80% accuracy.',
        'Kills are not equally valuable; their contribution depends on improvements in team win probability.'
    ])
    add_heading(doc, 'Limitations and project implications', 2)
    add_bullets(doc, [
        "Limitations include ranked rather than professional data, complex collection that Oracle's Elixir cannot fully reproduce, cross-patch variation and a simplified win-probability model. Predictive associations do not establish causation.",
        'An early-game win-probability model can estimate WPA for top-lane deaths before 15 minutes, solo kills, Herald participation and teleport plays.'
    ])

    add_heading(doc, '3. Paper 2: Player-Champion Experience and Game Outcome Prediction', 1)
    add_citation(
        doc,
        "Do, T. D., Wang, S. I., Yu, D. S., McMillian, M. G., & McMahan, R. P. (2021). Using Machine Learning to Predict Game Outcomes Based on Player-Champion Experience in League of Legends. Proceedings of FDG 2021.",
        [('Paper link', "https://doi.org/10.1145/3472538.3472579"), ('Preprint link', "https://arxiv.org/abs/2108.02799")],
    )
    add_heading(doc, 'Research question and data', 2)
    add_p(doc, 'The paper predicts outcomes before play begins using experience with the selected champion. Riot Games API data cover 5,000 distinct ranked matches from the North American server in 2020, spanning Iron to Diamond, with an 80% training and 20% test split.')
    add_heading(doc, 'Main methods and variables', 2)
    add_bullets(doc, [
        'Methods include deep neural networks, random forests, gradient boosting, support vector classifiers, k-nearest neighbors, Pearson correlation and stratified cross-validation.',
        'Player variables include mastery points, player-champion win rate, season games on the champion and champion appearances among the last 20 games.',
        'Team summaries include mean, median, variance, standard deviation, skewness and kurtosis; the final model contains 44 features.'
    ])
    add_heading(doc, 'Main findings', 2)
    add_bullets(doc, [
        'Gradient boosting achieves approximately 75.4% accuracy and the DNN approximately 75.1%.',
        'Champion win rate and mastery points are strong predictors.',
        'Game count alone is weaker: frequent play does not necessarily imply proficiency.'
    ])
    add_heading(doc, 'Limitations and project implications', 2)
    add_bullets(doc, [
        'Limitations include only 5,000 games, one server and one season, no professional competition, and incomplete controls for matchups, composition, patch and team strength.',
        'Analyses of additional champion gold should control for player × champion interactions. The marginal value of 500 extra gold may differ between familiar and unfamiliar champions for the same player.'
    ])

    add_heading(doc, '4. Paper 3: Team Resource Allocation and Win Percentages', 1)
    add_citation(
        doc,
        "Larose, C. D., & Mehling, S. A. (2022). Analysis of Team Resource Allocation and Win Percentages in League of Legends. Proceedings of the Joint Statistical Meetings, 699–715.",
        [('Paper link', "https://0633e92166c0a27ea1aa-ab47878a9e45eb9e2f15be38a59f867e.ssl.cf1.rackcdn.com/JTJLFYSY-2258804-1828585-Upload-1669675867.pdf")],
    )
    add_heading(doc, 'Core content', 2)
    add_p(doc, "The paper uses Oracle's Elixir professional data from the 2019 LCS Spring and Summer regular seasons. Its focus is role-level gold share rather than total team gold: Gold Share = Player Gold / Team Gold.")
    add_p(doc, 'Only information from the first 15 minutes is used, avoiding later Baron or inhibitor statistics that may leak the outcome. Matches with a gold difference greater than 2,000 at 15 minutes are excluded to focus on relatively close games.')
    add_heading(doc, 'Main findings', 2)
    add_bullets(doc, [
        'EDA indicates that higher top-lane gold share does not necessarily accompany higher win rates, whereas higher bot and support shares are associated with winning.',
        'CART and association rules link high top share to lower win rates and high bot share to higher win rates.',
        'One finding is that a very high red-side top gold share is associated with a substantially greater blue-side win probability.',
        'In close professional matches, more balanced gold distribution is associated with higher win rates. Heavy concentration on top lane may be suboptimal; coordinated team allocation may matter more than a single carry.'
    ])
    add_heading(doc, '1. Links to Topic 2 (Weak-Side Top) and Topic 3 (Gold Distribution)', 2)
    add_bullets(doc, [
        'Weak-side top: receiving less gold need not imply low strategic value. If excessive top share is associated with lower win rates, weak-side play may represent a reasonable allocation rather than a purely sacrificial role.',
        'Gold distribution: the paper shifts attention from total gold to role-level shares. When total team gold is similar, allocation across top, jungle, mid, bot and support may explain outcome differences.',
        'Marginal value of gold: additional top gold may be less valuable than bot or mid gold, or valuable only for particular champion types, compositions and game states.',
        'Tank versus carry: the paper does not separate the two types. An extension can test whether extra top gold creates carry value or displaces resources with greater marginal value elsewhere.'
    ])
    add_heading(doc, '2. Existing findings that a follow-up should extend', 2)
    add_bullets(doc, [
        'Move beyond the basic question of whether 15-minute gold share predicts outcomes; role-level shares are already established as relevant research variables.',
        'Use logistic regression, restricted cubic splines, interactions or compositional methods for more robust tests than CART or association-rule thresholds alone.',
        'Extend beyond 2019 LCS or a single league, because single-season findings may depend on the meta, patch and team styles.',
        'Examine moderation by top type, champion class, team allocation, objectives, side, patch and team strength rather than simply contrasting high and low top share.',
        'Account for the overall gold lead. Report both close-game subsamples, excluding absolute 15-minute gaps greater than 2,000, and full-sample robustness checks.'
    ])
    add_heading(doc, '3. Open questions for follow-up research', 2)
    add_bullets(doc, [
        'Do tank and carry top laners have different marginal returns to gold share?',
        'Does high top share reflect proactive investment or reactive side-lane farming by a trailing team?',
        'How do champion selection, matchup, player strength, team strength and patch effects change the association?',
        'How do gold-allocation paths at 10, 15 and 20 minutes relate to win probability?',
        'What trade-offs link Void Grubs, Dragons, Herald, first turret and top-lane gold share?'
    ])
    add_heading(doc, '4. Extending Topic 3: Distribution versus Total Gold', 2)
    add_p(doc, "Extend the question from whether gold share is associated with winning to whether role-level allocation retains explanatory value after controlling for total gold advantage, and whether top-lane type changes gold's marginal value.")
    add_bullets(doc, [
        'Observation unit: team-game or matched team pair. Each match contributes two team-game observations; cluster standard errors by match.',
        "Dependent variable: result，1 = win, 0 = loss.",
        'Main predictors: top_gold_share15, bot_gold_share15, mid_gold_share15, jungle_gold_share15, support_gold_share15, team_gold_diff15, top_gold_diff15, is_carry, is_tank and carry × top_gold_share15.',
        'Modeling: logistic regression as a baseline; restricted cubic splines for nonlinear marginal value; interactions for tank/carry differences; ILR or log-ratio transformations for compositional gold shares.',
        'Controls: side, league, patch_str, team fixed effects, opponent strength, champion class, matchup, game_length, dragon_diff, herald_diff, void_grubs_diff, first_turret or plates.',
        'Key tests: whether allocation remains associated with winning after team_gold_diff15 controls; whether top share has lower marginal value than bot/mid; whether carries have a gold threshold; and whether weak-side value coincides with reallocating resources to bot/mid.'
    ])
    add_heading(doc, '5. Advantages of LCK 2026 or multi-league data', 2)
    add_bullets(doc, [
        'Time coverage: the patch, map resources and top-lane environment differ markedly between 2019 LCS and 2026. Newer data can incorporate resources such as Void Grubs.',
        'League coverage: LCK macro discipline, exchanges and top-lane roles may differ from LCS. Multiple leagues also permit external-validity checks.',
        'Sample size: approximately 300+ LCK 2026 matches offer more scope for stable models than a short single season; multiple leagues add observations and champion variation.',
        'Variables: champion choices, tank/carry classes, objectives, patch controls and team/player fixed effects offer a richer framework for strategic interpretation.',
        'Research question: move from whether top share is associated with winning to which top-lane types and allocation structures give extra gold greater marginal value.'
    ])
    add_heading(doc, '6. Potential follow-up research questions', 2)
    add_numbered(doc, [
        'Weak-Side Top Value: after controlling for team gold difference, bot/mid share and early objectives, is low top share still associated with higher win probability, and is this limited to tanks or resilient weak-side players?',
        'Role-Specific Marginal Value of Gold: in close professional matches, does an additional 1% gold share have different marginal associations for top, mid and bot, and does top lane show diminishing returns?',
        'Tank versus Carry Response Curves: do their gold-to-win curves differ, and do carries require a 15-minute gold threshold before outperforming tanks?',
        'Gold Concentration versus Team Coordination: is concentrated allocation associated with lower win rates, and does the relationship vary by league, patch, objective trades and composition?',
        "Proactive Funnel or Reactive Farming: distinguish intentional top investment from a trailing team's recovery farming using 10/15/20-minute resource paths, objective control and sequences of gold swings."
    ])

    add_heading(doc, '5. Paper 4: The SIDO Performance Model for League of Legends', 1)
    add_citation(
        doc,
        "Zhang, A. X., & Naidu, P. (2024). The SIDO Performance Model for League of Legends. arXiv preprint arXiv:2403.04873.",
        [('Paper link', "https://arxiv.org/abs/2403.04873")],
    )
    add_heading(doc, 'Research question and framework', 2)
    add_p(doc, 'SIDO separates own, ally-enabling and enemy-denial contributions: resources obtained directly, enabled for teammates and denied to opponents.')
    add_heading(doc, 'Main methods and variables', 2)
    add_bullets(doc, [
        'Riot API data cover high-ranked NA, EUW and Korean games on patches 13.14–13.18.',
        'Methods include hierarchical Bayesian models, player and champion random effects, plus-minus models, residual contribution models and metric stability analysis.',
        'Variables include gold, damage dealt and taken, player, champion, role, region, game phase, ally residual performance and enemy residual performance.'
    ])
    add_heading(doc, 'Main findings', 2)
    add_bullets(doc, [
        'SIDO distinguishes high-level players better than simple averages and conventional plus-minus models.',
        'Gold denial is an important jungler contribution; ADC performance depends more on mechanics and direct damage.',
        'Jungle and support value includes strategy and team contributions, so individual gold and damage alone are insufficient.'
    ])
    add_heading(doc, 'Limitations and project implications', 2)
    add_bullets(doc, [
        'Limitations include differences between solo queue and professional coordination, incomplete identification of professional accounts, limited separation of ally and enemy contributions, a short patch window and model complexity requiring simplification for an undergraduate project.',
        'A weak-side top laner may have low own gold but high ally-enabling or enemy-denial contributions. Negative GD15 can reflect pressure absorption and resources released to teammates rather than low value.'
    ])

    add_heading(doc, '6. Paper 5: Multi-Objective Multi-Instance Learning for eSports', 1)
    add_citation(
        doc,
        "Birant, K. U., & Birant, D. (2023). Multi-Objective Multi-Instance Learning: A New Approach to Machine Learning for eSports. Entropy, 25(1), 28.",
        [('Paper link', "https://doi.org/10.3390/e25010028")],
    )
    add_heading(doc, 'Research question and data', 2)
    add_p(doc, 'The paper models five players jointly as a team and compares this with treating them independently. Public Kaggle ranked data include 1,834,520 player records from North America and Europe over seasons 3–7.')
    add_heading(doc, 'Methods, findings and limitations', 2)
    add_bullets(doc, [
        'Methods include multi-instance logistic regression, multi-instance SVM, multi-instance boosting, decision trees, SimpleMI, 10-fold cross-validation and the Mann–Whitney U test.',
        'Team-level multi-instance models generally outperform player-level models. SimpleMI averages approximately 94% accuracy; turret kills, deaths per minute and assists per minute are important predictors.',
        'Many variables may be end-of-match statistics, causing outcome or data leakage. High accuracy does not establish early prediction or support causal strategy conclusions.',
        'LoL observations are nested as player, role, team and match. Suitable methods include mixed-effects logistic regression, clustered standard errors, team fixed effects and player or champion random effects.'
    ])

    add_heading(doc, '7. Synthesis', 1)
    add_p(doc, 'The five papers motivate studying allocation, marginal value, role and champion differences, and team-level dependence rather than total gold alone. Paper 3 is the closest foundation, with scope to extend 2019 LCS gold-share associations across leagues and patches using tank/carry classes, early objectives, fixed effects and nonlinear gold response.')
    add_p(doc, 'Topic 2 asks whether low top gold share retains strategic value. Topic 3 asks whether allocation remains independently associated with win probability after accounting for team gold and early resources. These questions extend rather than repeat the existing findings.')

    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
