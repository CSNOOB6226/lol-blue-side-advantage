from pathlib import Path
from docx import Document


path = str(Path(__file__).resolve().parents[3] / 'manuscript/League_of_Legends_esports_literature_review_revised.docx')
text = "\n".join(p.text for p in Document(path).paragraphs)
checks = [
    # These sections belonged to the earlier report and are intentionally absent.
    ('Comparative synthesis', False),
    ('Gold-Share Threshold Model', False),
    ('Five feasible extensions', False),
    ('Links to Topic 2 (Weak-Side Top) and Topic 3 (Gold Distribution)', True),
    ('Existing findings that a follow-up should extend', True),
    ('Open questions for follow-up research', True),
    ('Distribution versus Total Gold', True),
    ('LCK 2026', True),
    ('Potential follow-up research questions', True),
]
print("file", path)
print("chars", len(text))
for check, expected in checks:
    present = check in text
    print(f"{check}: present={present}, expected={expected}, passed={present == expected}")
