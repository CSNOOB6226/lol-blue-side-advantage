from pathlib import Path
import re

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


SOURCE = Path(__file__).resolve().parent / "inputs/topic1_source.txt"
OUT = Path(__file__).resolve().parents[1]

BLUE = RGBColor(46, 116, 181)
DARK_BLUE = RGBColor(31, 77, 120)
LIGHT_BLUE = "E8EEF5"
GRID = "B8C4D1"


TRANSLATIONS = {}


def font_run(run, size=7.4, bold=False, color=None, name="Calibri"):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = color


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=60, start=90, bottom=60, end=90):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def configure_document(doc, chinese=False):
    section = doc.sections[0]
    section.top_margin = Inches(0.42)
    section.bottom_margin = Inches(0.42)
    section.left_margin = Inches(0.56)
    section.right_margin = Inches(0.56)
    section.header_distance = Inches(0.18)
    section.footer_distance = Inches(0.20)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(7.4)
    normal.paragraph_format.space_after = Pt(0.4)
    normal.paragraph_format.line_spacing = 0.88

    for style_name, size, color, before, after in (
        ("Heading 1", 11.8, BLUE, 4, 1.5),
        ("Heading 2", 9.4, BLUE, 3, 1),
        ("Heading 3", 8.5, DARK_BLUE, 2, 0.7),
    ):
        style = styles[style_name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for style_name in ("List Bullet", "List Number"):
        style = styles[style_name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(7.4)
        style.paragraph_format.left_indent = Inches(0.28)
        style.paragraph_format.first_line_indent = Inches(-0.14)
        style.paragraph_format.space_after = Pt(0.5)
        style.paragraph_format.line_spacing = 0.95

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = header.add_run("TOPIC 1 | LOGISTIC REGRESSION" if not chinese else "TOPIC 1 | LOGISTIC REGRESSION")
    font_run(r, 7.0, bold=True, color=RGBColor(105, 115, 125))

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = footer.add_run("Topic1 Knowledge")
    font_run(r, 7.0, color=RGBColor(120, 125, 130))


def translate_text(text):
    if text in TRANSLATIONS:
        return TRANSLATIONS[text]
    numbered_heading = re.fullmatch(r"(\d+)\.\s+(.+)", text)
    if numbered_heading and numbered_heading.group(2) in TRANSLATIONS:
        return f"{numbered_heading.group(1)}. {TRANSLATIONS[numbered_heading.group(2)]}"
    replacements = {
        "Win": "Win",
        "Lose": "Lose",
        "Otherwise": "Otherwise",
        "TopGoldShare15 \\le 0.188": "TopGoldShare15 \\le 0.188",
        "GoldDiff15 \\ge -500": "GoldDiff15 \\ge -500",
    }
    out = text
    for old, new in replacements.items():
        out = out.replace(old, new)
    return out


def add_title_block(doc, title, subtitle, chinese=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(title)
    font_run(r, 18, bold=True, color=RGBColor(22, 55, 82))
    p2 = doc.add_paragraph()
    p2.paragraph_format.space_after = Pt(7)
    r = p2.add_run(subtitle)
    font_run(r, 10.3, bold=True, color=BLUE)
    p_pr = p2._p.get_or_add_pPr()
    border = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "10")
    bottom.set(qn("w:space"), "5")
    bottom.set(qn("w:color"), "2E74B5")
    border.append(bottom)
    p_pr.append(border)


def add_equation(doc, lines, chinese=False):
    display = []
    for line in lines:
        stripped = line.strip()
        if chinese:
            stripped = translate_text(stripped)
        display.append(stripped)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(0.5)
    p.paragraph_format.space_after = Pt(1.2)
    p.paragraph_format.keep_together = True
    text = "\n".join(display)
    r = p.add_run(text)
    font_run(r, 7.7, name="Cambria Math")


def parse_table(lines, chinese=False):
    rows = []
    for line in lines:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r"[-:]+", c or "-") for c in cells):
            continue
        if chinese:
            cells = [translate_text(c) for c in cells]
        rows.append(cells)
    return rows


def add_table(doc, rows):
    cols = max(len(r) for r in rows)
    table = doc.add_table(rows=len(rows), cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    widths = [Inches(3.15), Inches(3.15)] if cols == 2 else [Inches(6.3 / cols)] * cols
    for i, row_data in enumerate(rows):
        for j in range(cols):
            cell = table.cell(i, j)
            cell.width = widths[j]
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            text = row_data[j] if j < len(row_data) else ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            r = p.add_run(text)
            font_run(r, 7.1, bold=(i == 0))
            if i == 0:
                set_cell_shading(cell, LIGHT_BLUE)
        if i == 0:
            set_repeat_table_header(table.rows[0])
    table.style = "Table Grid"
    after = doc.add_paragraph()
    after.paragraph_format.space_after = Pt(0)


def build(chinese=False):
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    doc = Document()
    configure_document(doc, chinese)

    title = translate_text("Topic1Knowledge") if chinese else "Topic1Knowledge"
    subtitle = translate_text("Weak Side Top Effect & Logistic Regression Notes") if chinese else "Weak Side Top Effect & Logistic Regression Notes"
    add_title_block(doc, title, subtitle, chinese)

    i = 2
    in_equation = False
    equation_lines = []
    while i < len(lines):
        raw = lines[i]
        stripped = raw.strip()
        if stripped == "---" or stripped == "":
            i += 1
            continue
        if stripped == "[":
            in_equation = True
            equation_lines = []
            i += 1
            continue
        if in_equation:
            if stripped == "]":
                add_equation(doc, equation_lines, chinese)
                in_equation = False
            else:
                equation_lines.append(raw)
            i += 1
            continue
        if stripped.startswith("|"):
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                table_lines.append(lines[i])
                i += 1
            add_table(doc, parse_table(table_lines, chinese))
            continue
        heading = re.match(r"^(#{1,3})\s+(.*)$", stripped)
        if heading:
            level = len(heading.group(1))
            text = heading.group(2)
            if chinese:
                text = translate_text(text)
            p = doc.add_paragraph(text, style=f"Heading {level}")
            p.paragraph_format.keep_with_next = True
            i += 1
            continue
        bullet = re.match(r"^-\s+(.*)$", stripped)
        if bullet:
            text = translate_text(bullet.group(1)) if chinese else bullet.group(1)
            doc.add_paragraph(text, style="List Bullet")
            i += 1
            continue
        numbered = re.match(r"^\d+\.\s+(.*)$", stripped)
        if numbered:
            text = translate_text(numbered.group(1)) if chinese else numbered.group(1)
            doc.add_paragraph(text, style="List Number")
            i += 1
            continue
        if stripped in ("→",):
            i += 1
            continue
        text = translate_text(stripped) if chinese else stripped
        p = doc.add_paragraph()
        p.paragraph_format.keep_together = False
        if stripped.endswith(":") or stripped in {"Important:", "Interpretation:", "Conclusion:", "Purpose:", "Goal:", "Metrics:", "Question:"}:
            r = p.add_run(text)
            font_run(r, 7.4, bold=True, color=DARK_BLUE)
        elif stripped == "→":
            r = p.add_run(text)
            font_run(r)
        else:
            r = p.add_run(text)
            font_run(r)
        i += 1

    # Make arrow pipelines compact and visually continuous.
    for p in doc.paragraphs:
        if p.text in {"Variables", "Log Odds", "Odds", "Probability", "Win/Lose",
                      "Remove variable", "Compare SSE", "Compare Log Likelihood",
                      "Remove variable", "Compare SSE", "Compare Log Likelihood"}:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(0.5)

    filename = "Topic1_Knowledge_Full_English.docx"
    path = OUT / filename
    doc.save(path)
    return path


if __name__ == "__main__":
    print(build(False))
