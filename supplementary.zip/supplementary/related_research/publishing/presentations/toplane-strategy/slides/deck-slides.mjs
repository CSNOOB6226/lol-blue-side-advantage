import { C, F, M } from "./theme.mjs";
import { background, barChart, bulletList, formula, lineChart, metric, panel, rect, smallTable, text } from "./helpers.mjs";

export const D = {
  t1Quartiles: [
    { label: "Q1 lowest", value: 0.546, display: "54.6%", color: C.gold },
    { label: "Q2", value: 0.502, display: "50.2%", color: C.cyan },
    { label: "Q3", value: 0.468, display: "46.8%", color: C.slate },
    { label: "Q4 highest", value: 0.484, display: "48.4%", color: C.slate }
  ],
  thresholdTank: [[-2000, .398], [-1000, .445], [0, .492], [1000, .540], [2000, .586], [3000, .632]],
  thresholdCarry: [[-2000, .420], [-1000, .463], [0, .507], [1000, .550], [2000, .594], [3000, .636]]
};

export async function buildSlide(n, presentation, ctx) {
  const slide = presentation.slides.add();
  const fn = slides[n];
  if (!fn) throw new Error(`Missing slide ${n}`);
  fn(ctx, slide);
  return slide;
}

const slides = {
  1(ctx, slide) {
    rect(ctx, slide, 0, 0, ctx.W, ctx.H, C.bg, "#00000000", 0);
    rect(ctx, slide, 0, 0, 22, ctx.H, C.gold, "#00000000", 0);
    rect(ctx, slide, 22, 0, 5, ctx.H, C.cyan, "#00000000", 0);
    for (let i = 0; i < 9; i += 1) rect(ctx, slide, 720 + i * 34, 92 + i * 23, 245, 1.2, i % 3 === 0 ? C.gold : C.line, "#00000000", 0);
    text(ctx, slide, "WEEK 2 RESEARCH MEETING", 76, 72, 460, 24, { size: 13, color: C.gold2, bold: true, face: F.latin });
    text(ctx, slide, "Top-Lane Resource Allocation", 76, 128, 760, 70, { size: 48, bold: true });
    text(ctx, slide, "Weak-Side Top Strategy  /  Carry Top Gold Threshold", 80, 215, 760, 34, { size: 24, color: C.cyan2, face: F.latin });
    text(ctx, slide, "2026 Oracle’s Elixir data; LPL and LPL-related games excluded.", 82, 277, 705, 34, { size: 21, color: C.muted });
    metric(ctx, slide, "filtered games", "5,000", 82, 420, 190);
    metric(ctx, slide, "Topic 1 rows", "10,000", 300, 420, 190);
    metric(ctx, slide, "Topic 3 rows", "9,695", 518, 420, 190);
    text(ctx, slide, "01", 1185, 674, 42, 28, { size: 18, color: C.gold, align: "right", face: F.latin });
  },
  2(ctx, slide) {
    background(ctx, slide, 2, "RESEARCH OVERVIEW", "How do top-lane resources translate into win probability?");
    panel(ctx, slide, 88, 170, 500, 330, { fill: C.panel2, topRule: "gold" });
    text(ctx, slide, "Topic 1", 116, 202, 120, 26, { size: 18, color: C.gold2, bold: true, face: F.latin });
    text(ctx, slide, "Weak-Side Top Strategy", 116, 238, 340, 42, { size: 26, bold: true });
    bulletList(ctx, slide, ["Does low top_gold_share15 hurt win odds?", "Can a stable, low-resource top be valuable?", "Key definition: stable_weak_side"], 122, 306, 410, { size: 19, gap: 48 });
    panel(ctx, slide, 678, 170, 500, 330, { fill: C.panel2, topRule: "cyan" });
    text(ctx, slide, "Topic 3", 706, 202, 120, 26, { size: 18, color: C.cyan2, bold: true, face: F.latin });
    text(ctx, slide, "Carry Top Gold Threshold", 706, 238, 380, 42, { size: 26, bold: true });
    bulletList(ctx, slide, ["Do carry tops need a larger gold lead?", "The interaction term is the key threshold test.", "Goal: find a clear carry-over-tank threshold."], 712, 306, 410, { size: 19, gap: 48, marker: C.cyan });
    text(ctx, slide, "Research setup, statistical results, and limits of interpretation.", 150, 560, 900, 34, { size: 22, color: C.muted, align: "center" });
  },
  3(ctx, slide) {
    background(ctx, slide, 3, "DATA & SAMPLE", "Both topics use the same filtered 2026 match dataset");
    const steps = [
      ["raw", "65,448 rows\n5,454 games"],
      ["Exclusions", "LPL games\nLPL-related teams"],
      ["Filtered", "60,000 rows\n5,000 games"],
      ["Unit of analysis", "top-lane\nteam-game"]
    ];
    steps.forEach((s, i) => {
      const x = 86 + i * 292;
      panel(ctx, slide, x, 190, 230, 168, { fill: i === 3 ? "#102E42" : C.panel2, line: i === 3 ? C.gold : C.line, topRule: i === 3 ? "gold" : undefined });
      text(ctx, slide, s[0], x + 22, 218, 180, 28, { size: 23, bold: true, color: i === 3 ? C.gold2 : C.white });
      text(ctx, slide, s[1], x + 22, 267, 178, 58, { size: 22, color: C.muted, face: F.latin });
      if (i < 3) {
        rect(ctx, slide, x + 246, 269, 30, 3, C.gold, "#00000000", 0);
        rect(ctx, slide, x + 272, 263, 11, 11, C.gold, "#00000000", 0);
      }
    });
    metric(ctx, slide, "Topic 1 analytic sample", "10,000", 210, 438, 260);
    metric(ctx, slide, "Topic 3 model sample", "9,695", 510, 438, 260, { color: C.cyan2 });
    metric(ctx, slide, "eligible top champions", "40", 810, 438, 260);
    text(ctx, slide, "Each match contributes one top-lane record per team.", 170, 576, 920, 34, { size: 21, color: C.muted, align: "center" });
  },
  4(ctx, slide) {
    background(ctx, slide, 4, "TOPIC 1 · RESEARCH QUESTION", "The weak-side hypothesis combines low allocation with lane stability");
    text(ctx, slide, "Research Question", 92, 180, 260, 30, { size: 20, color: C.gold2, bold: true, face: F.latin });
    text(ctx, slide, "Does low top-lane allocation reduce win probability, or free team resources when the lane remains stable?", 92, 224, 720, 94, { size: 28, bold: true });
    panel(ctx, slide, 150, 390, 250, 120, { fill: C.panel2, topRule: "gold" });
    text(ctx, slide, "Low resource", 177, 418, 190, 30, { size: 24, color: C.gold2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "bottom quartile\nof top_gold_share15", 180, 458, 188, 42, { size: 17, color: C.muted, face: F.latin, align: "center" });
    rect(ctx, slide, 430, 446, 120, 3, C.gold, "#00000000", 0);
    text(ctx, slide, "+", 477, 410, 32, 40, { size: 34, color: C.gold2, bold: true, align: "center" });
    panel(ctx, slide, 582, 390, 250, 120, { fill: C.panel2, topRule: "cyan" });
    text(ctx, slide, "Lane stability", 610, 418, 190, 30, { size: 24, color: C.cyan2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "golddiffat15\n>= -500", 614, 458, 185, 42, { size: 19, color: C.muted, face: F.latin, align: "center" });
    rect(ctx, slide, 860, 446, 80, 3, C.cyan, "#00000000", 0);
    panel(ctx, slide, 966, 365, 205, 170, { fill: "#102E42", line: C.gold, topRule: "gold" });
    text(ctx, slide, "stable_weak_side", 988, 422, 164, 30, { size: 20, color: C.gold2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "Main hypothesis", 996, 462, 150, 28, { size: 20, color: C.white, align: "center" });
  },
  5(ctx, slide) {
    background(ctx, slide, 5, "TOPIC 1 · VARIABLES", "Separating resource allocation from lane outcomes");
    const groups = [
      ["Dependent Variable", ["result", "1 = win, 0 = loss"], C.gold],
      ["Main X", ["top_gold_share15", "weak_side_q1", "stable_weak_side"], C.cyan],
      ["Lane Control", ["golddiffat15", "golddiffat15_500"], C.green],
      ["Context Controls", ["game_length_5min", "side / league / patch_str"], C.slate]
    ];
    groups.forEach((g, i) => {
      const x = 86 + (i % 2) * 560;
      const y = 178 + Math.floor(i / 2) * 190;
      panel(ctx, slide, x, y, 490, 140, { fill: C.panel2, line: g[2], topRule: g[2] === C.gold ? "gold" : "cyan" });
      text(ctx, slide, g[0], x + 24, y + 22, 220, 25, { size: 16, color: g[2], bold: true, face: F.latin });
      text(ctx, slide, g[1].join("\n"), x + 24, y + 58, 360, 68, { size: 19, color: C.white, face: F.latin });
    });
    text(ctx, slide, "top_gold_share15 = top goldat15 / team_goldat15_calc; Q1 cutoff ≤ 0.188.", 120, 585, 960, 30, { size: 20, color: C.muted, align: "center" });
  },
  6(ctx, slide) {
    background(ctx, slide, 6, "TOPIC 1 · REGRESSION MODELS", "From continuous gold share to stable weak-side indicators");
    const models = [
      ["M1", "Continuous Top Gold Share", "top_gold_share15_pp + golddiffat15_500 + controls"],
      ["M2", "Weak-Side Indicator", "weak_side_q1 + golddiffat15_500 + controls"],
      ["M3", "Stable Weak-Side Top", "stable_weak_side + side + league + patch + game_length"]
    ];
    models.forEach((m, i) => {
      const y = 164 + i * 142;
      panel(ctx, slide, 110, y, 975, 102, { fill: i === 2 ? "#102E42" : C.panel2, line: i === 2 ? C.gold : C.line });
      text(ctx, slide, m[0], 138, y + 24, 70, 42, { size: 31, color: i === 2 ? C.gold2 : C.cyan2, bold: true, face: F.latin, align: "center" });
      text(ctx, slide, m[1], 246, y + 18, 360, 28, { size: 22, bold: true, face: F.latin });
      text(ctx, slide, m[2], 246, y + 56, 725, 22, { size: 19, color: C.muted, face: F.latin });
    });
    formula(ctx, slide, ["logit(P(Win_i = 1)) = ln(P_i / (1 - P_i))"], 170, 590, 850, 62);
  },
  7(ctx, slide) {
    background(ctx, slide, 7, "TOPIC 1 · DESCRIPTIVE RESULTS", "The lowest top gold-share group has a 54.6% raw win rate");
    panel(ctx, slide, 88, 168, 660, 340, { fill: C.panel2, topRule: "gold" });
    text(ctx, slide, "Win rate by top_gold_share15 quartile", 118, 194, 420, 24, { size: 18, color: C.gold2, bold: true, face: F.latin });
    barChart(ctx, slide, D.t1Quartiles, 120, 245, 570, 210, { max: 0.60 });
    panel(ctx, slide, 804, 168, 318, 340, { fill: C.panel2, topRule: "cyan" });
    text(ctx, slide, "stable_weak_side", 836, 205, 240, 28, { size: 23, color: C.cyan2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "77.8%", 866, 260, 180, 58, { size: 50, color: C.gold2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "n = 837\navg top share = 0.180\navg golddiff15 = +47.6", 848, 340, 205, 86, { size: 19, color: C.muted, face: F.latin, align: "center" });
    text(ctx, slide, "These descriptive patterns do not establish causation.", 150, 575, 900, 28, { size: 20, color: C.muted, align: "center" });
  },
  8(ctx, slide) {
    background(ctx, slide, 8, "TOPIC 1 · REGRESSION RESULTS", "Stable weak-side has the largest focal odds ratio");
    smallTable(ctx, slide,
      ["Model", "Variable", "Coef", "Odds Ratio", "95% CI", "p"],
      [
        ["M1", "top_gold_share15_pp", "-0.570", "0.565", "0.546–0.585", "<0.001"],
        ["M2", "weak_side_q1", "1.269", "3.556", "3.166–3.994", "<0.001"],
        ["M3", "stable_weak_side", "1.370", "3.933", "3.321–4.658", "<0.001"]
      ],
      86, 176, [70, 240, 80, 110, 140, 80], 52, { goldCols: [3], cyanCols: [1], size: 14, headerSize: 12.5 });
    panel(ctx, slide, 855, 176, 280, 220, { fill: C.panel2, topRule: "gold" });
    text(ctx, slide, "Model Fit", 886, 204, 190, 28, { size: 21, color: C.gold2, bold: true, face: F.latin });
    text(ctx, slide, "McFadden pseudo R²", 886, 252, 190, 24, { size: 15, color: C.muted, face: F.latin });
    text(ctx, slide, "M1  0.148\nM2  0.093\nM3  0.024", 888, 286, 170, 92, { size: 22, color: C.white, face: F.latin });
    text(ctx, slide, "Controls: side, league, patch, and game length. M1/M2 also control top gold difference.", 128, 545, 910, 40, { size: 20, color: C.muted, align: "center" });
  },
  9(ctx, slide) {
    background(ctx, slide, 9, "TOPIC 1 · DATA LIMITATIONS", "Early map resources remain incompletely measured");
    panel(ctx, slide, 90, 172, 480, 330, { fill: C.panel2, topRule: "gold" });
    text(ctx, slide, "Current limitations", 122, 205, 240, 26, { size: 19, color: C.gold2, bold: true, face: F.latin });
    bulletList(ctx, slide, [
      "top_gold_share15 combines allocation with early lane outcomes.",
      "Early objectives remain incomplete: grubs, dragons, first turret, and plates.",
      "Missing jungle proximity and gank pressure limit weak-side measurement."
    ], 125, 252, 382, { size: 18, lineH: 68, gap: 78 });
    panel(ctx, slide, 675, 172, 430, 330, { fill: C.panel2, topRule: "cyan" });
    text(ctx, slide, "Next controls", 710, 205, 200, 26, { size: 19, color: C.cyan2, bold: true, face: F.latin });
    bulletList(ctx, slide, [
      "Add early objective differences: grubs, dragons, herald, and first turret.",
      "Add champion and champion-class controls.",
      "Test team or player fixed effects to reduce strength confounding."
    ], 712, 252, 330, { size: 18, lineH: 68, gap: 78, marker: C.cyan });
    text(ctx, slide, "Topic 1 provides association evidence rather than a causal strategy estimate.", 165, 585, 890, 28, { size: 21, color: C.muted, align: "center" });
  },
  10(ctx, slide) {
    background(ctx, slide, 10, "TOPIC 3 · RESEARCH QUESTION & SAMPLE", "Do carry tops convert gold leads more effectively?");
    text(ctx, slide, "Research Question", 92, 176, 260, 28, { size: 19, color: C.gold2, bold: true, face: F.latin });
    text(ctx, slide, "After teammate and objective controls, how much top gold advantage gives carries a clear win-probability edge over tanks?", 92, 220, 850, 116, { size: 31, bold: true });
    metric(ctx, slide, "model sample", "9,695", 108, 430, 230, { color: C.cyan2 });
    metric(ctx, slide, "eligible champions", "40", 384, 430, 230);
    metric(ctx, slide, "champion threshold", "≥21 apps", 660, 430, 230, { color: C.gold2 });
    panel(ctx, slide, 962, 410, 190, 118, { fill: "#102E42", line: C.gold, topRule: "gold" });
    text(ctx, slide, "Key test", 990, 438, 130, 22, { size: 18, color: C.gold2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "interaction term", 988, 478, 138, 28, { size: 19, color: C.white, face: F.latin, align: "center" });
  },
  11(ctx, slide) {
    background(ctx, slide, 11, "TOPIC 3 · VARIABLES", "The threshold test uses carry identity × top gold difference");
    const vars = [
      ["Dependent", "result", "1 = win, 0 = loss", C.gold],
      ["Main X", "is_carry", "1 = carry / warrior-carry", C.cyan],
      ["Slope", "top_gold_diff15_500", "top lane 15-min gold diff per 500", C.green],
      ["Interaction", "is_carry × top_gold_diff15_500", "Does carry identity change the gold-conversion slope?", C.gold2]
    ];
    vars.forEach((v, i) => {
      const x = 88 + (i % 2) * 555;
      const y = 166 + Math.floor(i / 2) * 155;
      panel(ctx, slide, x, y, 500, 110, { fill: C.panel2, line: v[3] });
      text(ctx, slide, v[0], x + 24, y + 17, 150, 22, { size: 15, color: v[3], bold: true, face: F.latin });
      text(ctx, slide, v[1], x + 24, y + 46, 420, 26, { size: 22, color: C.white, face: F.latin, bold: true });
      text(ctx, slide, v[2], x + 24, y + 78, 420, 18, { size: 15, color: C.muted });
    });
    panel(ctx, slide, 190, 515, 820, 70, { fill: "#081827", line: C.line });
    text(ctx, slide, "Controls: non_top_gold_diff15_500 · non_top_kill_diff15 · dragon_diff · herald_diff · void_grubs_diff · side · league · patch_str · game_length_5min", 218, 538, 760, 42, { size: 17, color: C.muted, face: F.latin, align: "center" });
  },
  12(ctx, slide) {
    background(ctx, slide, 12, "TOPIC 3 · REGRESSION MODEL", "An interaction tests the carry gold-conversion premium");
    formula(ctx, slide, [
      "logit(P(Win_i = 1)) = β0 + β1(is_carry_i)",
      "+ β2(top_gold_diff15_500_i)",
      "+ β3(is_carry_i × top_gold_diff15_500_i)",
      "+ teammate controls + objective controls",
      "+ side_i + league_i + patch_i + game_length_i + ε_i"
    ], 100, 180, 960, 265);
    panel(ctx, slide, 180, 500, 820, 82, { fill: C.panel2, topRule: "cyan" });
    text(ctx, slide, "A significantly positive β3 would support stronger gold conversion for carries.", 215, 526, 745, 28, { size: 22, color: C.white, align: "center" });
  },
  13(ctx, slide) {
    background(ctx, slide, 13, "TOPIC 3 · REGRESSION RESULTS", "Top gold advantage is significant; the carry interaction is not");
    smallTable(ctx, slide,
      ["Variable", "Coef", "z", "p", "Odds Ratio", "95% CI"],
      [
        ["is_carry", "0.127", "1.995", "0.046", "1.135", "1.002–1.285"],
        ["top_gold_diff15_500", "0.205", "8.319", "<0.001", "1.228", "1.170–1.288"],
        ["carry_x_top_gold_diff15_500", "-0.015", "-0.505", "0.613", "0.985", "0.927–1.045"],
        ["dragon_diff", "0.755", "41.642", "<0.001", "2.128", "2.054–2.205"]
      ],
      78, 170, [255, 82, 72, 76, 110, 135], 48, { goldCols: [4], cyanCols: [0], size: 13.5, headerSize: 12 });
    panel(ctx, slide, 872, 175, 270, 230, { fill: C.panel2, topRule: "gold" });
    text(ctx, slide, "Model Fit", 900, 205, 185, 24, { size: 21, color: C.gold2, bold: true, face: F.latin });
    text(ctx, slide, "N = 9,695\ndf_model = 54\nMcFadden pseudo R² = 0.492", 900, 252, 210, 88, { size: 18, color: C.white, face: F.latin });
    text(ctx, slide, "LR tests: carry class terms p = 0.1125; top gold advantage terms p < 0.001.", 128, 552, 930, 34, { size: 20, color: C.muted, align: "center" });
  },
  14(ctx, slide) {
    background(ctx, slide, 14, "TOPIC 3 · THRESHOLD PREDICTION", "No carry advantage of 10 percentage points in the tested range");
    smallTable(ctx, slide,
      ["top_gold_diff15", "Tank", "Carry", "Carry - Tank"],
      [
        ["-2000", "39.8%", "42.0%", "+2.1 pp"],
        ["-1000", "44.5%", "46.3%", "+1.8 pp"],
        ["0", "49.2%", "50.7%", "+1.5 pp"],
        ["+1000", "54.0%", "55.0%", "+1.1 pp"],
        ["+2000", "58.6%", "59.4%", "+0.7 pp"],
        ["+3000", "63.2%", "63.6%", "+0.4 pp"]
      ],
      95, 170, [180, 135, 135, 160], 46, { goldCols: [2, 3], cyanCols: [1], size: 14.5, headerSize: 12.5 });
    panel(ctx, slide, 890, 180, 260, 180, { fill: C.panel2, line: C.gold, topRule: "gold" });
    text(ctx, slide, "Max gap shown", 920, 213, 190, 24, { size: 19, color: C.gold2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "≈ 2.1 pp", 930, 260, 170, 48, { size: 40, color: C.gold2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "Below the 10 pp threshold", 920, 322, 195, 22, { size: 16, color: C.muted, align: "center" });
    panel(ctx, slide, 890, 390, 260, 105, { fill: "#081827", line: C.line });
    text(ctx, slide, "Displayed range", 920, 414, 190, 20, { size: 15, color: C.cyan2, bold: true, face: F.latin, align: "center" });
    text(ctx, slide, "top_gold_diff15\n-2000 to +3000", 922, 444, 188, 42, { size: 18, color: C.white, face: F.latin, align: "center" });
  },
  15(ctx, slide) {
    background(ctx, slide, 15, "TOPIC 3 · DATA LIMITATIONS", "Early resources and team composition may remain confounded");
    panel(ctx, slide, 90, 172, 480, 330, { fill: C.panel2, topRule: "gold" });
    text(ctx, slide, "Current limitations", 122, 205, 240, 26, { size: 19, color: C.gold2, bold: true, face: F.latin });
    bulletList(ctx, slide, [
      "Dragon, herald, and grub differences lack detailed timing.",
      "First turret, plates, and objective timing remain incomplete.",
      "Broad carry/tank classes combine different champion and composition roles."
    ], 125, 252, 382, { size: 18, lineH: 68, gap: 78 });
    panel(ctx, slide, 675, 172, 430, 330, { fill: C.panel2, topRule: "cyan" });
    text(ctx, slide, "Next controls", 710, 205, 200, 26, { size: 19, color: C.cyan2, bold: true, face: F.latin });
    bulletList(ctx, slide, [
      "Separate objectives before and after 15 minutes.",
      "Add lane matchup and champion-class controls.",
      "Test carry thresholds of 5, 10, and 15 pp."
    ], 712, 252, 330, { size: 18, lineH: 68, gap: 78, marker: C.cyan });
    text(ctx, slide, "Topic 3 estimates controlled associations; the threshold remains provisional.", 165, 585, 890, 28, { size: 21, color: C.muted, align: "center" });
  }
};
