import { C, F } from "./theme.mjs";
import { base, bullets, callout, header, metric, rect, reportImage, text } from "./helpers.mjs";

const slides = [
  async (ctx, slide) => {
    base(ctx, slide, 1, "Week 2 Research Meeting");
    rect(ctx, slide, 58, 82, 6, 455, C.gold, "#00000000", 0);
    text(ctx, slide, "Top-Lane Resource Allocation", 88, 106, 800, 56, { size: 38, color: C.blue, bold: true });
    text(ctx, slide, "Weak-Side Top Strategy / Carry Top Gold Threshold", 90, 176, 830, 30, { size: 21, color: C.blue2, face: F.latin });
    text(ctx, slide, "Research questions, models, and findings from the two top-lane reports.", 90, 235, 900, 42, { size: 22, color: C.ink });
    metric(ctx, slide, "filtered games", "5,000", 90, 380, 210);
    metric(ctx, slide, "Topic 1 top-lane rows", "10,000", 328, 380, 240);
    metric(ctx, slide, "Topic 3 model rows", "9,695", 596, 380, 230);
    callout(ctx, slide, "Deck principle: follow the report sections, preserve tables/equations as source evidence, keep interpretation light for oral delivery.", 90, 540, 930, 78, { size: 18, face: F.latin });
  },
  async (ctx, slide) => {
    header(ctx, slide, 2, "Deck Structure", "Two research questions and their evidence");
    bullets(ctx, slide, [
      "Topic 1: Research Question → Data/Sample → Variables → Regression Models → Results → Indicators → Limitations",
      "Topic 3: Research Question → Data/Sample → Variables → Logistic Model → Regression Results → Threshold Prediction → Limitations",
      "Tables and equations reproduce the source reports.",
      "The slides summarize the variables, models, results, and limitations."
    ], 100, 190, 1040, { size: 22, gap: 62, lineH: 48 });
  },
  async (ctx, slide) => {
    base(ctx, slide, 3, "Topic 1 Divider");
    text(ctx, slide, "Topic 1", 78, 118, 320, 36, { size: 24, color: C.gold, bold: true, face: F.latin });
    text(ctx, slide, "Weak-Side Top Strategy", 78, 168, 720, 64, { size: 48, color: C.blue, bold: true });
    text(ctx, slide, "Weak-Side Top Strategy", 82, 252, 640, 32, { size: 24, color: C.blue2, face: F.latin });
    callout(ctx, slide, "Does low resource allocation work only when the top laner remains stable?", 82, 360, 820, 96, { size: 26, bold: true });
  },
  async (ctx, slide) => {
    header(ctx, slide, 4, "Topic 1 · Research Question", "Is weak-side top associated with higher win probability?");
    bullets(ctx, slide, [
      "Can professional teams allocate fewer early resources to top while maintaining a high win rate?",
      "Resource measure: top_gold_share15 is the top laner’s share of team gold at 15 minutes.",
      "Hypothesis: weak-side top requires low resource share and no severe lane deficit by 15 minutes.",
      "The model separates weak_side_q1 from stable_weak_side to distinguish low allocation from a lost lane."
    ], 92, 188, 1010, { size: 22, gap: 64, lineH: 50 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 5, "Topic 1 · Data and Sample", "Top-lane team-game observations from filtered Oracle’s Elixir data");
    metric(ctx, slide, "original rows", "65,448", 96, 185, 190);
    metric(ctx, slide, "original games", "5,454", 314, 185, 190);
    metric(ctx, slide, "after removing LPL-related games", "60,000 rows", 532, 185, 250);
    metric(ctx, slide, "filtered games", "5,000", 810, 185, 190);
    callout(ctx, slide, "Each game contributes two top-lane team-game records, giving 10,000 observations for Topic 1.", 100, 330, 1000, 88, { size: 23 });
    bullets(ctx, slide, [
      "Excluded: all LPL games and all games involving LPL teams.",
      "Purpose: reduce confounding from mixing LPL teams with other regions.",
      "Controls: side, league, patch_str, and game_length_5min."
    ], 126, 475, 900, { size: 21, gap: 46 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 6, "Topic 1 · Variables", "Variable definitions from the source report");
    await reportImage(ctx, slide, "t1_variables.png", 118, 170, 1040, 455);
  },
  async (ctx, slide) => {
    header(ctx, slide, 7, "Topic 1 · Regression Models", "Three logistic regression specifications");
    await reportImage(ctx, slide, "t1_models.png", 115, 178, 1050, 350);
    callout(ctx, slide, "Focal variables: M1 top_gold_share15_pp; M2 weak_side_q1; M3 stable_weak_side.", 150, 570, 930, 58, { size: 20 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 8, "Topic 1 · Main Results", "Weak-side indicators have odds ratios significantly above 1");
    bullets(ctx, slide, [
      "Both weak_side_q1 and stable_weak_side have odds ratios significantly above 1.",
      "stable_weak_side: OR ≈ 3.93; 95% CI [3.32, 4.66]; p < 0.001.",
      "Low resource share combined with lane stability is strongly associated with higher win odds."
    ], 100, 190, 980, { size: 24, gap: 78, lineH: 58 });
    callout(ctx, slide, "These results describe associations and do not establish a causal strategy effect.", 150, 565, 850, 58, { size: 20, face: F.latin });
  },
  async (ctx, slide) => {
    header(ctx, slide, 9, "Topic 1 · Indicators and Limitations", "Statistical measures and data limitations");
    callout(ctx, slide, "Measures", 82, 175, 220, 52, { size: 24, bold: true });
    bullets(ctx, slide, [
      "p-value: evidence against the null hypothesis.",
      "95% confidence interval: uncertainty in the odds ratio.",
      "McFadden pseudo R²: logistic model fit relative to the null.",
      "Likelihood-ratio test: compares full and reduced models."
    ], 100, 255, 500, { size: 19, gap: 55, lineH: 42 });
    callout(ctx, slide, "Limitations", 682, 175, 220, 52, { size: 24, bold: true, bar: C.blue2 });
    bullets(ctx, slide, [
      "Early objectives are incomplete: Void Grubs, dragons, first turret, and plates.",
      "Jungle proximity and gank pressure are missing, limiting measurement of true weak-side play.",
      "top_gold_share15 reflects both allocation and lane outcomes, limiting causal interpretation."
    ], 700, 255, 470, { size: 19, gap: 65, lineH: 50, marker: C.blue2 });
  },
  async (ctx, slide) => {
    base(ctx, slide, 10, "Topic 3 Divider");
    text(ctx, slide, "Topic 3", 78, 118, 320, 36, { size: 24, color: C.gold, bold: true, face: F.latin });
    text(ctx, slide, "Carry Top Gold Threshold", 78, 168, 820, 64, { size: 46, color: C.blue, bold: true });
    text(ctx, slide, "Carry Top Gold Threshold", 82, 252, 640, 32, { size: 24, color: C.blue2, face: F.latin });
    callout(ctx, slide, "How large a top-lane gold lead makes a carry clearly preferable to a tank, after controls?", 82, 360, 930, 100, { size: 24, bold: true });
  },
  async (ctx, slide) => {
    header(ctx, slide, 11, "Topic 3 · Research Question", "How much gold advantage does a carry top need?");
    bullets(ctx, slide, [
      "After controlling for teammate advantages and neutral objectives, do carry tops win more often than tanks?",
      "At 15 minutes, how much top-lane gold advantage makes a carry’s predicted win probability clearly exceed a tank’s?",
      "Key test: the interaction is_carry × top_gold_diff15_500.",
      "A significantly positive interaction would indicate stronger gold conversion for carry tops."
    ], 92, 188, 1010, { size: 22, gap: 64, lineH: 50 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 12, "Topic 3 · Data and Sample", "Top-lane team-game observations after excluding LPL-related games");
    metric(ctx, slide, "initial non-LPL games", "5,000", 105, 190, 220);
    metric(ctx, slide, "top-lane observations", "10,000", 362, 190, 240);
    metric(ctx, slide, "model sample", "9,695", 640, 190, 220);
    metric(ctx, slide, "champion inclusion rule", "≥21 top apps", 900, 190, 240);
    bullets(ctx, slide, [
      "Retain champions with enough top-lane appearances to reduce sparse-category estimates.",
      "Compare carry/warrior-carry and tank tops within one logistic regression.",
      "Controls include teammate advantage, objectives, side, league, patch, and game length."
    ], 130, 380, 950, { size: 22, gap: 60, lineH: 48 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 13, "Topic 3 · Variables", "Variable definitions from the source report");
    await reportImage(ctx, slide, "t3_variables.png", 100, 165, 1080, 475);
  },
  async (ctx, slide) => {
    header(ctx, slide, 14, "Topic 3 · Regression Formula", "Logistic regression equation and specification");
    await reportImage(ctx, slide, "t3_formula.png", 85, 185, 1110, 245);
    callout(ctx, slide, "The binary result (win/loss) motivates logistic regression. Results report coefficients, odds ratios, p-values, and confidence intervals.", 105, 515, 1030, 76, { size: 22, face: F.latin });
  },
  async (ctx, slide) => {
    header(ctx, slide, 15, "Topic 3 · Core Carry Threshold Variables", "Regression results for the carry-threshold variables");
    await reportImage(ctx, slide, "t3_core_results.png", 96, 178, 1080, 350);
    callout(ctx, slide, "Interaction p = 0.613: no significant evidence of stronger gold conversion for carries.", 118, 565, 1040, 58, { size: 20 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 16, "Topic 3 · Teammate and Objective Controls", "Regression results for teammate and objective controls");
    await reportImage(ctx, slide, "t3_controls_results.png", 96, 178, 1080, 398);
  },
  async (ctx, slide) => {
    header(ctx, slide, 17, "Topic 3 · Statistical Indicators", "Model fit and statistical interpretation");
    bullets(ctx, slide, [
      "Coefficient: change in log-odds. Odds ratio: multiplicative change in win odds.",
      "Standard errors measure uncertainty; z statistics standardize the estimates.",
      "p-values test the null; confidence intervals show odds-ratio uncertainty.",
      "Logistic regression uses McFadden pseudo R² and likelihood-ratio tests rather than ordinary R², adjusted R², or F tests."
    ], 88, 178, 640, { size: 18.5, gap: 53, lineH: 43 });
    await reportImage(ctx, slide, "t3_model_fit.png", 745, 218, 430, 95);
  },
  async (ctx, slide) => {
    header(ctx, slide, 18, "Topic 3 · ANOVA-Style Tests", "Likelihood-ratio / ANOVA-style table");
    await reportImage(ctx, slide, "t3_anova_part1.png", 95, 165, 1085, 290);
    await reportImage(ctx, slide, "t3_anova_part2.png", 95, 485, 1085, 150);
  },
  async (ctx, slide) => {
    header(ctx, slide, 19, "Topic 3 · Economic Threshold Prediction", "Predicted win probabilities across gold differences");
    await reportImage(ctx, slide, "t3_thresholds.png", 145, 165, 990, 485);
  },
  async (ctx, slide) => {
    header(ctx, slide, 20, "Topic 3 · Practical Significance", "No 10 percentage-point carry advantage within the tested range");
    bullets(ctx, slide, [
      "No tested gold difference produces a carry win probability at least 10 percentage points above a tank’s.",
      "The threshold accounts for teammate and objective advantages rather than comparing raw win rates.",
      "carry_minus_tank falls as the gold lead increases, providing no support for a growing carry advantage."
    ], 95, 190, 1010, { size: 22, gap: 82, lineH: 58 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 21, "Topic 3 · Limitations and Future Work", "Limitations and future work");
    await reportImage(ctx, slide, "t3_practical_limitations.png", 95, 170, 1080, 260);
    callout(ctx, slide, "Objective timing remains incomplete: exact grub counts and timing, dragon type, first turret, plates, lane swaps, and jungle paths.", 110, 492, 1040, 86, { size: 21, bar: C.blue2 });
  },
  async (ctx, slide) => {
    header(ctx, slide, 22, "Appendix · Full Coefficient Table A", "Full coefficient table, part 1");
    await reportImage(ctx, slide, "t3_appendix_coefficients_1.png", 210, 160, 850, 495);
  },
  async (ctx, slide) => {
    header(ctx, slide, 23, "Appendix · Full Coefficient Table B", "Full coefficient table, part 2");
    await reportImage(ctx, slide, "t3_appendix_coefficients_2.png", 235, 160, 800, 500);
  },
  async (ctx, slide) => {
    header(ctx, slide, 24, "Appendix · Full Coefficient Table C", "Full coefficient table, part 3");
    await reportImage(ctx, slide, "t3_appendix_coefficients.png", 235, 160, 800, 500);
  },
];

export async function buildSlide(n, presentation, ctx) {
  const slide = presentation.slides.add();
  const fn = slides[n - 1];
  if (!fn) throw new Error(`Missing slide ${n}`);
  await fn(ctx, slide);
  return slide;
}
