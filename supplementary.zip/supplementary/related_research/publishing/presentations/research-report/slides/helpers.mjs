import path from "node:path";
import { C, F } from "./theme.mjs";

export function rect(ctx, slide, x, y, w, h, fill = C.white, line = C.line, lw = 1) {
  return ctx.addShape(slide, { x, y, w, h, fill, line: ctx.line(line, lw) });
}

export function text(ctx, slide, value, x, y, w, h, opts = {}) {
  return ctx.addText(slide, {
    text: value,
    x,
    y,
    w,
    h,
    fontSize: opts.size ?? 20,
    color: opts.color ?? C.ink,
    bold: opts.bold ?? false,
    typeface: opts.face ?? F.body,
    align: opts.align ?? "left",
    valign: opts.valign ?? "top",
    fill: opts.fill ?? "#00000000",
    line: ctx.line(opts.line ?? "#00000000", opts.lineWidth ?? 0),
    insets: opts.insets ?? { left: 0, right: 0, top: 0, bottom: 0 },
  });
}

export function base(ctx, slide, page, section = "Week 2 Research Meeting") {
  rect(ctx, slide, 0, 0, ctx.W, ctx.H, C.paper, "#00000000", 0);
  rect(ctx, slide, 0, 0, ctx.W, 8, C.blue, "#00000000", 0);
  rect(ctx, slide, 0, 8, ctx.W, 3, C.gold, "#00000000", 0);
  text(ctx, slide, section, 58, 24, 520, 20, { size: 10.5, color: C.blue2, bold: true, face: F.latin });
  text(ctx, slide, String(page).padStart(2, "0"), 1170, 676, 48, 20, { size: 13, color: C.blue2, face: F.latin, align: "right" });
  text(ctx, slide, "Sources: Topic 1 & Topic 3 source reports", 58, 676, 520, 20, { size: 9.5, color: C.muted, face: F.latin });
}

export function header(ctx, slide, page, kicker, title) {
  base(ctx, slide, page, kicker);
  text(ctx, slide, kicker.toUpperCase(), 58, 60, 520, 18, { size: 10.5, color: C.gold, bold: true, face: F.latin });
  text(ctx, slide, title, 58, 86, 1050, 48, { size: 28, color: C.blue, bold: true });
  rect(ctx, slide, 58, 145, 1160, 1.2, C.line, "#00000000", 0);
}

export function bullets(ctx, slide, items, x, y, w, opts = {}) {
  let cy = y;
  for (const item of items) {
    rect(ctx, slide, x, cy + 9, 6, 6, opts.marker ?? C.gold, "#00000000", 0);
    text(ctx, slide, item, x + 18, cy, w - 18, opts.lineH ?? 40, { size: opts.size ?? 20, color: opts.color ?? C.ink, face: opts.face ?? F.body });
    cy += opts.gap ?? 46;
  }
}

export function callout(ctx, slide, value, x, y, w, h, opts = {}) {
  rect(ctx, slide, x, y, w, h, opts.fill ?? C.panel, opts.line ?? C.line, 1);
  rect(ctx, slide, x, y, 4, h, opts.bar ?? C.gold, "#00000000", 0);
  text(ctx, slide, value, x + 22, y + 18, w - 42, h - 30, { size: opts.size ?? 20, color: opts.color ?? C.ink, bold: opts.bold ?? false, face: opts.face ?? F.body, valign: opts.valign ?? "top" });
}

export function metric(ctx, slide, label, value, x, y, w, opts = {}) {
  rect(ctx, slide, x, y, w, 92, C.white, C.line, 1);
  text(ctx, slide, value, x + 14, y + 17, w - 28, 34, { size: opts.valueSize ?? 28, color: opts.color ?? C.blue, bold: true, face: F.latin, align: "center" });
  text(ctx, slide, label, x + 12, y + 57, w - 24, 20, { size: 12.5, color: C.muted, face: F.latin, align: "center" });
}

export async function reportImage(ctx, slide, name, x, y, w, h) {
  const p = path.join(ctx.assetDir, "crops", name);
  rect(ctx, slide, x - 8, y - 8, w + 16, h + 16, C.white, C.line, 1);
  await ctx.addImage(slide, { path: p, x, y, w, h, fit: "contain", alt: name });
}
