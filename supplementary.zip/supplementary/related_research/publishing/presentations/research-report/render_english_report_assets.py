"""Render English versions of the translated report excerpts used by the deck.

The variable definitions, equations, and legacy regression values reproduce the
original report excerpts. Numeric crops already written in English are retained.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ASSETS = Path(__file__).resolve().parent / 'assets'
CROPS = ASSETS / 'crops'
FONT_DIR = Path('/System/Library/Fonts/Supplemental')
BLUE = '#23547D'
GRID = '#374151'
LIGHT_BLUE = '#D9EAF6'


def font(size, bold=False):
    return ImageFont.truetype(str(FONT_DIR / ('Arial Bold.ttf' if bold else 'Arial.ttf')), size)


def wrap(draw, value, face, width):
    lines = []
    for paragraph in str(value).split('\n'):
        line = ''
        for word in paragraph.split():
            if draw.textlength((line + ' ' + word).strip(), font=face) <= width:
                line = (line + ' ' + word).strip()
                continue
            if line:
                lines.append(line)
            line = ''
            for char in word:
                if draw.textlength(line + char, font=face) > width:
                    lines.append(line)
                    line = char
                else:
                    line += char
        lines.append(line)
    return lines


def table(name, title, headers, rows, widths, size, height, padding=20, min_row=44):
    image = Image.new('RGB', (1396, height), 'white')
    draw = ImageDraw.Draw(image)
    draw.text((42, 24), title, fill=BLUE, font=font(31, True))
    y = 83
    for i, row in enumerate([headers] + rows):
        face = font(size, i == 0)
        lines = [wrap(draw, cell, face, width - 24) for cell, width in zip(row, widths)]
        line_height = size + 7
        row_height = max(min_row, max(map(len, lines)) * line_height + padding)
        x = 42
        for cell_lines, width in zip(lines, widths):
            draw.rectangle((x, y, x + width, y + row_height), fill=LIGHT_BLUE if i == 0 else 'white', outline=GRID, width=1)
            cy = y + (row_height - len(cell_lines) * line_height) / 2
            for line in cell_lines:
                draw.text((x + 12, cy), line, fill='black', font=face)
                cy += line_height
            x += width
        y += row_height
    if y > height - 16:
        raise ValueError(f'{name}: table extends to {y}, image height is {height}')
    image.save(CROPS / name)


def paragraphs(name, sections, width, height, size=25):
    image = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(image)
    y = 30
    for title, text in sections:
        if title:
            draw.text((42, y), title, fill=BLUE, font=font(size + 5, True))
            y += size + 24
        for line in wrap(draw, text, font(size), width - 84):
            draw.text((42, y), line, fill='black', font=font(size))
            y += size + 11
        y += 24
    if y > height:
        raise ValueError(f'{name}: content extends to {y}, image height is {height}')
    image.save(CROPS / name)


def formulas(name, lines, width, height):
    image = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(image)
    y = 24
    face = font(23)
    for line in lines:
        for part in wrap(draw, line, face, width - 84):
            draw.text((42, y), part, fill=BLUE, font=face)
            y += 31
        y += 18
    if y > height:
        raise ValueError(f'{name}: formulas extend to {y}, image height is {height}')
    image.save(CROPS / name)


def render():
    formulas('t1_general_formula.png', ['General: logit(P(Win_i = 1)) = ln(P_i / (1 - P_i))'], 1161, 199)
    formulas('t1_models.png', [
        'Model 1: logit(P(Win_i=1)) = β0 + β1(top_gold_share15_pp_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i',
        'Model 2: logit(P(Win_i=1)) = β0 + β1(weak_side_q1_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i',
        'Model 3: logit(P(Win_i=1)) = β0 + β1(stable_weak_side_i) + β2(game_length_5min_i) + β3(side_i) + β4(league_i) + β5(patch_i) + ε_i',
    ], 1231, 411)
    table('t1_variables.png', '3. Variable Definitions', ['Variable', 'Role', 'Meaning'], [
        ['result', 'Response', 'Team result: 1 = win, 0 = loss.'],
        ['goldat15', 'Input', 'Top-lane gold at 15 minutes.'],
        ['team_goldat15_calc', 'Derived', 'Team gold at 15, summed across all five roles.'],
        ['top_gold_share15', 'Main predictor', 'Top gold at 15 / team gold at 15; lower values indicate a smaller top resource share.'],
        ['top_gold_share15_pp', 'Scaled', 'top_gold_share15 × 100, interpreted in percentage points.'],
        ['weak_side_q1', 'Weak-side indicator', '1 if top gold share is in the lowest 25%; cutoff ≤ 0.188.'],
        ['stable_weak_side', 'Stable weak-side indicator', '1 if weak_side_q1 = 1 and golddiffat15 ≥ -500.'],
        ['golddiffat15_500', 'Control', 'Top gold difference from the opposing top at 15 / 500.'],
        ['game_length_5min', 'Control', 'Game length measured in five-minute units.'],
        ['side, league, patch_str', 'Controls', 'Controls for side, league, and patch differences.'],
    ], [340, 235, 735], 21, 874)
    table('t3_variables.png', '3. Variable Definitions', ['Variable', 'Role', 'Meaning'], [
        ['result', 'Response', '1 = win, 0 = loss.'],
        ['is_carry', 'Main predictor', '1 = carry/warrior-carry top; 0 = tank top.'],
        ['top_gold_diff15_500', 'Main predictor', 'Top gold difference at 15, per 500 gold.'],
        ['is_carry × top_gold_diff15_500', 'Interaction', 'Tests whether carry tops convert gold leads into win probability differently from tanks.'],
        ['non_top_gold_diff15_500', 'Control', 'Teammate gold difference at 15 excluding top, per 500 gold.'],
        ['non_top_kill_diff15', 'Control', 'Teammate kill difference at 15 excluding top.'],
        ['dragon_diff / herald_diff / void_grubs_diff', 'Controls', 'Differences in dragon, Herald, and Void Grub counts.'],
        ['side / league / patch_str', 'Controls', 'Controls for side, league, and patch.'],
        ['game_length_5min', 'Control', 'Game length, per five-minute unit.'],
    ], [400, 215, 695], 21, 696)
    table('t3_core_results.png', '6.1 Core Carry-Threshold Variables', ['Variable', 'Coef.', 'SE', 'z', 'p', 'OR', 'CI low', 'CI high'], [
        ['is_carry', '0.127', '0.063', '1.995', '0.046', '1.135', '1.002', '1.285'],
        ['top_gold_diff15_500', '0.205', '0.025', '8.319', '<0.001', '1.228', '1.170', '1.288'],
        ['carry_x_top_gold_diff15_500', '-0.015', '0.031', '-0.505', '0.613', '0.985', '0.927', '1.045'],
    ], [340] + [138] * 7, 23, 426)
    paragraphs('t3_practical_limitations.png', [
        ('9. Practical Significance and Preliminary Conclusion', 'Within the tested gold-difference range, the model finds no threshold where carry tops have a predicted win probability at least 10 percentage points above tanks. The model estimates how much gold advantage makes a carry clearly preferable after teammate and objective controls, rather than simply comparing average carry and tank strength.'),
        ('10. Limitations and Future Work', 'This observational analysis supports association rather than causation. Some neutral-objective variables may occur after the top-lane lead forms. Future work can add champion and team fixed effects, fit patch-specific models, and test alternative thresholds of 5 or 15 percentage points.'),
    ], 1396, 546, 24)
    # Restore the gold grid from the source model; the old crop incorrectly
    # formatted nonpositive gold values as p-values ("<0.001"). Probabilities
    # below are transcribed unchanged from the original table.
    predictions = [
        ['0.398', '0.420', '0.021'], ['0.410', '0.431', '0.021'],
        ['0.422', '0.441', '0.020'], ['0.433', '0.452', '0.019'],
        ['0.445', '0.463', '0.018'], ['0.457', '0.474', '0.017'],
        ['0.469', '0.485', '0.016'], ['0.480', '0.496', '0.015'],
        ['0.492', '0.507', '0.015'], ['0.504', '0.518', '0.014'],
        ['0.516', '0.529', '0.013'], ['0.528', '0.540', '0.012'],
        ['0.540', '0.550', '0.011'], ['0.551', '0.561', '0.010'],
        ['0.563', '0.572', '0.009'], ['0.575', '0.583', '0.008'],
        ['0.586', '0.594', '0.007'], ['0.598', '0.604', '0.006'],
        ['0.610', '0.615', '0.006'], ['0.621', '0.626', '0.005'],
        ['0.632', '0.636', '0.004'],
    ]
    table('t3_thresholds.png', '8. Gold-Threshold Predictions',
          ['Top gold difference at 15', 'Tank win probability', 'Carry win probability', 'Carry minus tank'],
          [[str(gold)] + values for gold, values in zip(range(-2000, 3001, 250), predictions)],
          [328, 328, 328, 326], 21, 996, padding=12, min_row=32)
    # Rebuild the contact sheet so the preview also contains the translated assets.
    paths = sorted(CROPS.glob('*.png'))
    thumbnail_w, thumbnail_h, label_h = 390, 300, 32
    columns = 3
    rows = (len(paths) + columns - 1) // columns
    contact = Image.new('RGB', (columns * thumbnail_w, rows * (thumbnail_h + label_h)), 'white')
    draw = ImageDraw.Draw(contact)
    for i, path in enumerate(paths):
        crop = Image.open(path).convert('RGB')
        crop.thumbnail((thumbnail_w - 20, thumbnail_h - 20))
        x = (i % columns) * thumbnail_w
        y = (i // columns) * (thumbnail_h + label_h)
        contact.paste(crop, (x + 10, y + 10))
        draw.text((x + 10, y + thumbnail_h), path.name, fill='black', font=font(14))
    contact.save(ASSETS / 'crop-contact.png')


if __name__ == '__main__':
    render()
