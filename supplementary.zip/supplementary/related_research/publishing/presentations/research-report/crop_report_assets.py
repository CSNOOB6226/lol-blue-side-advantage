from pathlib import Path
from PIL import Image, ImageOps


ROOT = Path(__file__).resolve().parents[3]
SRC = ROOT / "publishing/reports/research-report/docx-render"
OUT = ROOT / "publishing/presentations/research-report/assets/crops"


def crop(name, rel, box, pad=18):
    img = Image.open(SRC / rel).convert("RGB")
    region = img.crop(box)
    region = ImageOps.expand(region, border=pad, fill="white")
    region.save(OUT / name, quality=96)
    print(name, region.size)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    crops = [
        ("t1_variables.png", "topic1/page-5.png", (95, 780, 1455, 1618)),
        ("t1_models.png", "topic1/page-6.png", (190, 55, 1385, 430)),
        ("t3_variables.png", "topic3/page-7.png", (95, 620, 1455, 1280)),
        ("t3_formula.png", "topic3/page-7.png", (190, 1455, 1395, 1648)),
        ("t3_core_results.png", "topic3/page-8.png", (95, 95, 1455, 485)),
        ("t3_controls_results.png", "topic3/page-8.png", (95, 560, 1455, 1035)),
        ("t3_model_fit.png", "topic3/page-8.png", (95, 1385, 1455, 1530)),
        ("t3_anova_part1.png", "topic3/page-8.png", (95, 1515, 1455, 1970)),
        ("t3_anova_part2.png", "topic3/page-9.png", (95, 55, 1455, 405)),
        ("t3_thresholds.png", "topic3/page-9.png", (95, 455, 1455, 1415)),
        ("t3_practical_limitations.png", "topic3/page-9.png", (95, 1430, 1455, 1940)),
        ("t3_appendix_coefficients_1.png", "topic3/page-4.png", (95, 845, 1455, 1960)),
        ("t3_appendix_coefficients_2.png", "topic3/page-10.png", (95, 280, 1455, 1900)),
        ("t3_appendix_coefficients.png", "topic3/page-11.png", (95, 70, 1455, 1660)),
    ]
    for item in crops:
        crop(*item)


if __name__ == "__main__":
    main()
