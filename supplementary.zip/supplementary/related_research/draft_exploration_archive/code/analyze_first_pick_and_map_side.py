"""Analyze first-pick priority versus blue-side map advantage in 2026.

The key identification comes from Riot's 2026 First Selection rule: first pick
is no longer perfectly tied to blue side. This script keeps the analysis narrow:
does first-pick priority predict wins after separating it from map side?
"""
import os
import warnings

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv")
OUT_DIR = os.path.join(ROOT, "data/first_pick_derived_data")

COLS = [
    "position",
    "gameid",
    "side",
    "result",
    "league",
    "patch",
    "datacompleteness",
    "firstPick",
    "champion",
    "pick1",
    "pick2",
    "pick3",
    "pick4",
    "pick5",
    "firstdragon",
    "firstherald",
    "firsttower",
    "golddiffat15",
    "visionscore",
]

HISTORY_FILES = {
    2022: os.path.join(ROOT, "data/raw/2022_LoL_esports_match_data_from_OraclesElixir.csv"),
    2023: os.path.join(ROOT, "data/raw/2023_LoL_esports_match_data_from_OraclesElixir.csv"),
    2024: os.path.join(ROOT, "data/raw/2024_LoL_esports_match_data_from_OraclesElixir.csv"),
    2025: os.path.join(ROOT, "data/raw/2025_LoL_esports_match_data_from_OraclesElixir.csv"),
    2026: RAW,
}


def fmt_p(p):
    if p < 0.001:
        return "<0.001"
    return f"{p:.3f}"


def load_raw(path, exclude_china=False):
    d = pd.read_csv(path, usecols=lambda c: c in COLS, low_memory=False)
    d = d[d["datacompleteness"] == "complete"].copy()
    if exclude_china:
        china_mask = d["league"].astype(str).str.contains("LPL|LDL", na=False)
        d = d[~china_mask].copy()
    return d


def load_team_games(path=RAW, exclude_china=False):
    d = load_raw(path, exclude_china=exclude_china)

    team = d[d["position"] == "team"][
        [
            "gameid",
            "side",
            "result",
            "league",
            "patch",
            "pick1",
            "pick2",
            "pick3",
            "pick4",
            "pick5",
            "firstdragon",
            "firstherald",
            "firsttower",
            "golddiffat15",
        ]
    ].copy()
    vision = (
        d[d["position"].isin(["top", "jng", "mid", "bot", "sup"])]
        .groupby(["gameid", "side"], as_index=False)["visionscore"]
        .sum()
        .rename(columns={"visionscore": "team_vision"})
    )
    team = team.merge(vision, on=["gameid", "side"], how="left")
    fp = d[d["position"] == "top"][["gameid", "side", "firstPick"]].copy()
    tm = team.merge(fp, on=["gameid", "side"], how="left").dropna(subset=["firstPick"])
    tm["firstPick"] = tm["firstPick"].astype(int)
    tm["blue"] = (tm["side"] == "Blue").astype(int)
    tm["patch_str"] = tm["patch"].astype(str)
    return tm


def top_pick_slot_summary(path=RAW):
    d = load_raw(path)
    top = d[d["position"] == "top"][
        ["gameid", "side", "result", "league", "patch", "champion", "golddiffat15", "firstPick"]
    ].copy()
    team = d[d["position"] == "team"][["gameid", "side", "pick1", "pick2", "pick3", "pick4", "pick5"]].copy()
    top = top.merge(team, on=["gameid", "side"], how="left")

    def pick_slot(row):
        for i in range(1, 6):
            if row.get(f"pick{i}") == row["champion"]:
                return i
        return np.nan

    top["team_pick_slot"] = top.apply(pick_slot, axis=1)
    top = top.dropna(subset=["team_pick_slot"]).copy()
    top["team_pick_slot"] = top["team_pick_slot"].astype(int)
    top["slot5"] = (top["team_pick_slot"] == 5).astype(int)
    top["slot1"] = (top["team_pick_slot"] == 1).astype(int)
    top["blue"] = (top["side"] == "Blue").astype(int)
    top["patch_str"] = top["patch"].astype(str)

    desc = (
        top.groupby("team_pick_slot")
        .agg(
            n=("result", "size"),
            winrate=("result", "mean"),
            golddiff15=("golddiffat15", "mean"),
            blue_rate=("blue", "mean"),
            first_pick_rate=("firstPick", "mean"),
        )
        .reset_index()
        .sort_values("team_pick_slot")
    )

    slot_extremes = top[top["team_pick_slot"].isin([1, 5])].copy()
    slot_reg = smf.logit(
        "result ~ slot5 + blue + firstPick + C(league) + C(patch_str)",
        slot_extremes,
    ).fit(disp=0, cov_type="cluster", cov_kwds={"groups": slot_extremes["gameid"]})
    gold_reg = smf.ols(
        "golddiffat15 ~ slot5 + blue + firstPick + C(league) + C(patch_str)",
        slot_extremes,
    ).fit(cov_type="cluster", cov_kwds={"groups": slot_extremes["gameid"]})

    slot_rows = []
    for label, res, transform in [
        ("result", slot_reg, "or"),
        ("golddiffat15", gold_reg, "linear"),
    ]:
        coef = res.params["slot5"]
        se = res.bse["slot5"]
        row = {
            "outcome": label,
            "coef": coef,
            "std_error": se,
            "stat": coef / se,
            "p_value": res.pvalues["slot5"],
            "p": fmt_p(res.pvalues["slot5"]),
            "n": int(res.nobs),
        }
        if transform == "or":
            row["effect"] = np.exp(coef)
            row["ci_low"] = np.exp(coef - 1.96 * se)
            row["ci_high"] = np.exp(coef + 1.96 * se)
            row["unit"] = "odds_ratio"
        else:
            row["effect"] = coef
            row["ci_low"] = coef - 1.96 * se
            row["ci_high"] = coef + 1.96 * se
            row["unit"] = "gold"
        slot_rows.append(row)

    return desc, pd.DataFrame(slot_rows)


def historical_firstpick_audit():
    rows = []
    league_rows = []
    for year, path in HISTORY_FILES.items():
        d = load_team_games(path=path, exclude_china=(year != 2026))
        fp = d[d["firstPick"] == 1].copy()
        rows.append(
            {
                "year": year,
                "games": int(d["gameid"].nunique()),
                "team_games": int(len(d)),
                "first_pick_team_games": int(len(fp)),
                "blue_share_among_first_pick": fp["blue"].mean(),
                "red_share_among_first_pick": 1 - fp["blue"].mean(),
                "first_pick_winrate": fp["result"].mean(),
                "blue_winrate": d[d["blue"] == 1]["result"].mean(),
            }
        )
        if year == 2026:
            per_league = (
                d.groupby("league")
                .agg(
                    team_games=("result", "size"),
                    first_pick_team_games=("firstPick", "sum"),
                    blue_share_among_first_pick=("blue", lambda s: d.loc[s.index][d.loc[s.index, "firstPick"] == 1]["blue"].mean()),
                    first_pick_winrate=("result", lambda s: d.loc[s.index][d.loc[s.index, "firstPick"] == 1]["result"].mean()),
                    blue_winrate=("result", lambda s: d.loc[s.index][d.loc[s.index, "blue"] == 1]["result"].mean()),
                )
                .reset_index()
            )
            per_league["red_share_among_first_pick"] = 1 - per_league["blue_share_among_first_pick"]
            league_rows.append(
                per_league.sort_values(["team_games", "league"], ascending=[False, True]).reset_index(drop=True)
            )
    return pd.DataFrame(rows), league_rows[0]


def or_ci(res, term):
    b = res.params[term]
    se = res.bse[term]
    return {
        "coef_log_odds": b,
        "std_error": se,
        "z_stat": b / se,
        "p_value": res.pvalues[term],
        "p": fmt_p(res.pvalues[term]),
        "odds_ratio": np.exp(b),
        "or_ci_low": np.exp(b - 1.96 * se),
        "or_ci_high": np.exp(b + 1.96 * se),
    }


def avg_discrete_effect(res, data, var):
    lo = data.copy()
    hi = data.copy()
    lo[var] = 0
    hi[var] = 1
    return float((res.predict(hi) - res.predict(lo)).mean())


def fit_models(tm):
    specs = [
        ("M0 first-pick only", "result ~ firstPick", ["firstPick"]),
        ("M1 first-pick + blue side", "result ~ firstPick + blue", ["firstPick", "blue"]),
        (
            "M2 first-pick + blue + league/patch FE",
            "result ~ firstPick + blue + C(league) + C(patch_str)",
            ["firstPick", "blue"],
        ),
    ]

    rows = []
    fits = {}
    for name, formula, terms in specs:
        res = smf.logit(formula, tm).fit(
            disp=0,
            cov_type="cluster",
            cov_kwds={"groups": tm["gameid"]},
        )
        fits[name] = res
        for term in terms:
            row = {"model": name, "term": term}
            row.update(or_ci(res, term))
            row["avg_discrete_effect"] = avg_discrete_effect(res, tm, term)
            row["n"] = int(res.nobs)
            row["log_likelihood"] = res.llf
            row["null_log_likelihood"] = res.llnull
            row["mcfadden_pseudo_r2"] = 1 - (res.llf / res.llnull)
            rows.append(row)
    return pd.DataFrame(rows), fits


def fit_mechanism_models(tm):
    specs = [
        ("firstdragon", "First Dragon", "pp"),
        ("firstherald", "First Herald", "pp"),
        ("firsttower", "First Tower", "pp"),
        ("golddiffat15", "Gold diff at 15", "gold"),
        ("team_vision", "Team vision score", "vision"),
    ]
    rows = []
    for outcome, label, unit in specs:
        sub = tm.dropna(subset=[outcome, "firstPick", "blue", "league", "patch_str"]).copy()
        res = smf.ols(f"{outcome} ~ firstPick + blue + C(league) + C(patch_str)", sub).fit(
            cov_type="cluster",
            cov_kwds={"groups": sub["gameid"]},
        )
        for term in ["firstPick", "blue"]:
            coef = res.params[term]
            se = res.bse[term]
            row = {
                "outcome": outcome,
                "label": label,
                "term": term,
                "coef": coef,
                "std_error": se,
                "t_stat": coef / se,
                "p_value": res.pvalues[term],
                "p": fmt_p(res.pvalues[term]),
                "ci_low": coef - 1.96 * se,
                "ci_high": coef + 1.96 * se,
                "unit": unit,
                "n": int(res.nobs),
                "r_squared": res.rsquared,
            }
            rows.append(row)
    return pd.DataFrame(rows)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    tm = load_team_games()

    raw_side = (
        tm.groupby("side")
        .agg(n=("result", "size"), winrate=("result", "mean"), first_pick_rate=("firstPick", "mean"))
        .reset_index()
    )
    raw_pick = (
        tm.groupby("firstPick")
        .agg(n=("result", "size"), winrate=("result", "mean"), blue_rate=("blue", "mean"))
        .reset_index()
    )
    cross = (
        tm.groupby(["side", "firstPick"])
        .agg(n=("result", "size"), winrate=("result", "mean"))
        .reset_index()
    )
    by_league = (
        tm.groupby("league")
        .agg(
            team_games=("result", "size"),
            first_pick_winrate=("result", lambda s: tm.loc[s.index][tm.loc[s.index, "firstPick"] == 1]["result"].mean()),
            blue_winrate=("result", lambda s: tm.loc[s.index][tm.loc[s.index, "blue"] == 1]["result"].mean()),
            first_pick_blue_rate=("firstPick", lambda s: tm.loc[s.index][tm.loc[s.index, "firstPick"] == 1]["blue"].mean()),
        )
        .reset_index()
        .sort_values(["team_games", "league"], ascending=[False, True])
    )

    reg, fits = fit_models(tm)
    mech = fit_mechanism_models(tm)
    history, firstpick_2026_leagues = historical_firstpick_audit()
    top_slot_desc, top_slot_reg = top_pick_slot_summary()

    raw_side.to_csv(os.path.join(OUT_DIR, "first_pick_by_map_side.csv"), index=False)
    raw_pick.to_csv(os.path.join(OUT_DIR, "first_pick_descriptive.csv"), index=False)
    cross.to_csv(os.path.join(OUT_DIR, "first_pick_map_side_crosstab.csv"), index=False)
    by_league.to_csv(os.path.join(OUT_DIR, "first_pick_by_league.csv"), index=False)
    reg.to_csv(os.path.join(OUT_DIR, "first_pick_blue_side_regressions.csv"), index=False)
    mech.to_csv(os.path.join(OUT_DIR, "first_pick_blue_side_early_mechanism_regressions.csv"), index=False)
    history.to_csv(os.path.join(OUT_DIR, "first_pick_historical_definition_checks.csv"), index=False)
    firstpick_2026_leagues.to_csv(os.path.join(OUT_DIR, "first_pick_2026_league_definition_checks.csv"), index=False)
    top_slot_desc.to_csv(os.path.join(OUT_DIR, "toplane_draft_order_descriptive.csv"), index=False)
    top_slot_reg.to_csv(os.path.join(OUT_DIR, "toplane_pick5_vs_pick1_robustness.csv"), index=False)

    print(f"Saved outputs to {OUT_DIR}")
    print(f"Team-games: {len(tm)}; games: {tm.gameid.nunique()}; leagues: {tm.league.nunique()}; patches: {tm.patch_str.nunique()}")
    print("\nHistorical first-pick audit")
    print(history.round(4).to_string(index=False))
    print("\nRaw by side")
    print(raw_side.round(4).to_string(index=False))
    print("\nRaw by firstPick")
    print(raw_pick.round(4).to_string(index=False))
    print("\nSide x firstPick")
    print(cross.round(4).to_string(index=False))
    print("\nRegression key terms")
    keep = [
        "model",
        "term",
        "coef_log_odds",
        "std_error",
        "z_stat",
        "p",
        "odds_ratio",
        "or_ci_low",
        "or_ci_high",
        "avg_discrete_effect",
        "mcfadden_pseudo_r2",
    ]
    print(reg[keep].round(4).to_string(index=False))
    print("\nEarly mechanism models: outcome ~ firstPick + blue + league/patch FE")
    print(mech[["label", "term", "coef", "ci_low", "ci_high", "p", "unit", "r_squared"]].round(4).to_string(index=False))
    print("\n2026 per-league first-pick audit")
    print(firstpick_2026_leagues.round(4).to_string(index=False))
    print("\nTop-lane coarse robustness: team pick slot")
    print(top_slot_desc.round(4).to_string(index=False))
    print("\nTop-lane coarse robustness: pick5 vs pick1")
    print(top_slot_reg.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
