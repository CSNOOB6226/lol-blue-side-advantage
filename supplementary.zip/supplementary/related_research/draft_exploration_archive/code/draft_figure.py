"""Forest plot for the flagship 'draft value' finding + exact ORs/CIs.
All draft advantages (first-pick, counterpick x5 lanes) cluster at OR=1; only blue side departs.
"""
import pandas as pd, numpy as np, warnings, os
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NEED=['position','gameid','side','result','golddiffat15','champion','firstPick','league','datacompleteness',
      'pick1','pick2','pick3','pick4','pick5']
SF={1:1,2:4,3:5,4:8,5:9}; SS={1:2,2:3,3:6,4:7,5:10}

def load(p,nonchina=False):
    d=pd.read_csv(p,usecols=lambda c:c in NEED,low_memory=False)
    if nonchina:
        ch=[l for l in d.league.unique() if 'LPL' in str(l) or 'LDL' in str(l)]; d=d[~d.league.isin(ch)]
    return d[d.datacompleteness=='complete']

def or_ci(res,name):
    b=res.params[name]; se=res.bse[name]
    return np.exp(b),np.exp(b-1.96*se),np.exp(b+1.96*se),res.pvalues[name]

def counterpick_or(d,role):
    teams=d[d.position=='team'][['gameid','side','pick1','pick2','pick3','pick4','pick5']]
    pr=d[d.position==role][['gameid','side','champion','result','firstPick']].copy()
    m=pr.merge(teams,on=['gameid','side'],how='left')
    def pidx(r):
        for i in range(1,6):
            if r.get(f'pick{i}')==r['champion']: return i
        return np.nan
    m['pi']=m.apply(pidx,axis=1); m=m.dropna(subset=['pi','firstPick'])
    m['go']=m.apply(lambda r:(SF if r.firstPick==1 else SS)[int(r.pi)],axis=1)
    opp=m[['gameid','side','go']].copy(); opp['side']=opp.side.map({'Blue':'Red','Red':'Blue'}); opp=opp.rename(columns={'go':'oppgo'})
    m=m.merge(opp,on=['gameid','side'],how='left').dropna(subset=['oppgo'])
    m['gap']=m.go-m.oppgo; m['zgap']=(m.gap-m.gap.mean())/m.gap.std(); m['blue']=(m.side=='Blue').astype(int)
    r=smf.logit('result~zgap+blue',m).fit(disp=0,cov_type='cluster',cov_kwds={'groups':m.gameid})
    return or_ci(r,'zgap')

def blue_or(d):
    t=d[d.position=='team'][['gameid','side','result']].copy(); t['blue']=(t.side=='Blue').astype(int)
    r=smf.logit('result~blue',t).fit(disp=0,cov_type='cluster',cov_kwds={'groups':t.gameid})
    return or_ci(r,'blue')

def firstpick_or(d):
    t=d[d.position=='team'][['gameid','side','result']].merge(
        d[d.position=='top'][['gameid','side','firstPick']],on=['gameid','side']).dropna()
    t['blue']=(t.side=='Blue').astype(int)
    try:
        r=smf.logit('result~firstPick+blue',t).fit(disp=0,cov_type='cluster',cov_kwds={'groups':t.gameid})
        return or_ci(r,'firstPick')
    except Exception:
        return (np.nan,)*4

d26=load(os.path.join(ROOT,'data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv'))
d25=load(os.path.join(ROOT,'data/raw/2025_LoL_esports_match_data_from_OraclesElixir.csv'),nonchina=True)

rows=[]  # (label, group, OR, lo, hi, p, year)
rows.append(('Blue side (map)','side',*blue_or(d26),'2026'))
rows.append(('Blue side (map)','side',*blue_or(d25),'2025'))
rows.append(('First pick priority','draft',*firstpick_or(d26),'2026'))
for role in ['top','jng','mid','bot','sup']:
    rows.append((f'Counterpick {role}','draft',*counterpick_or(d26,role),'2026'))
    rows.append((f'Counterpick {role}','draft',*counterpick_or(d25,role),'2025'))
res=pd.DataFrame(rows,columns=['label','group','OR','lo','hi','p','year'])
res.to_csv(os.path.join(ROOT,'code/outputs/draft_value_ORs.csv'),index=False)
print(res.round(3).to_string(index=False))

# ---- forest plot ----
order=['Blue side (map)','First pick priority','Counterpick top','Counterpick jng','Counterpick mid','Counterpick bot','Counterpick sup']
fig,ax=plt.subplots(figsize=(8.4,6.2))
y=0; yt=[]; yl=[]
for lab in order:
    sub=res[res.label==lab]
    for _,r in sub.iterrows():
        col='#c0392b' if r.group=='side' else ('#2c3e50' if r.year=='2026' else '#7f8c8d')
        mk='o' if r.year=='2026' else 's'
        ax.plot([r.lo,r.hi],[y,y],color=col,lw=1.6,zorder=2)
        ax.scatter([r.OR],[y],color=col,marker=mk,s=46,zorder=3,
                   label=('2026' if (mk=='o' and 'l26' not in yl) else ('2025' if (mk=='s' and 'l25' not in yl) else None)))
        if mk=='o' and 'l26' not in yl: yl.append('l26')
        if mk=='s' and 'l25' not in yl: yl.append('l25')
        y-=1
    yt.append(y+ (0.5 if len(sub)==1 else 1.0));
    y-=0.4
labels_pos=[]; yy=0
for lab in order:
    n=len(res[res.label==lab]); center=-(yy+(n-1)/2.0); labels_pos.append(center); yy+=n+0.4
ax.axvline(1.0,color='k',ls='--',lw=1,zorder=1)
ax.set_yticks(labels_pos); ax.set_yticklabels(order,fontsize=11)
ax.set_xscale('log'); ax.set_xticks([0.8,0.9,1.0,1.1,1.2,1.3,1.4]); ax.set_xticklabels(['0.8','0.9','1.0','1.1','1.2','1.3','1.4'])
ax.set_xlabel('Win odds ratio (95% CI) — per SD / vs baseline',fontsize=11)
ax.set_title('Winning the draft ≠ winning the game: draft advantage does not translate into wins\nBlue map side remains associated with wins (non-China pro LoL, 2025–2026)',fontsize=11.5)
from matplotlib.lines import Line2D
leg=[Line2D([0],[0],marker='o',color='w',markerfacecolor='#2c3e50',markersize=8,label='2026'),
     Line2D([0],[0],marker='s',color='w',markerfacecolor='#7f8c8d',markersize=8,label='2025'),
     Line2D([0],[0],marker='o',color='w',markerfacecolor='#c0392b',markersize=8,label='Blue-side (map)')]
ax.legend(handles=leg,loc='lower right',fontsize=9,framealpha=0.9)
ax.text(1.005,labels_pos[0]+0.6,'OR=1\nNo effect',fontsize=8,color='k',va='bottom')
plt.tight_layout();
out=os.path.join(ROOT,'code/figures/draft_value.png'); plt.savefig(out,dpi=150)
print('\nsaved',out)
