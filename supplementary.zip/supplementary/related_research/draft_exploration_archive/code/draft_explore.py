"""Exploratory analysis: re-test role determinism (deterministic) + top-lane counterpick chain.
Runs on 2026 non-China and 2025 (China excluded) for replication.
"""
import pandas as pd, numpy as np, warnings, os
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F26 = os.path.join(ROOT, 'data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv')
F25 = os.path.join(ROOT, 'data/raw/2025_LoL_esports_match_data_from_OraclesElixir.csv')

def load(path, nonchina_filter=False):
    cols = ['position','gameid','side','golddiffat15','xpdiffat15','playername','champion',
            'teamname','league','result','datacompleteness',
            'pick1','pick2','pick3','pick4','pick5','firstPick']
    d = pd.read_csv(path, usecols=lambda c: c in cols, low_memory=False)
    if nonchina_filter:
        china = [l for l in d.league.unique() if 'LPL' in str(l) or 'LDL' in str(l)]
        d = d[~d.league.isin(china)]
    d = d[d.datacompleteness=='complete']
    return d

def add_opp(tc):
    opp = tc[['gameid','side','champion']].copy()
    opp['side'] = opp.side.map({'Blue':'Red','Red':'Blue'})
    opp = opp.rename(columns={'champion':'opp_champ'})
    return tc.merge(opp, on=['gameid','side'], how='left')

# deterministic decomposition via adjusted-R^2 (single factor)
def cap(s, minn):
    vc = s.value_counts(); keep = vc[vc>=minn].index
    return s.where(s.isin(keep), 'OTHER')

def decomp_adjR2(d, role):
    tc = d[d.position==role][['gameid','side','golddiffat15','playername','champion']].copy()
    tc = add_opp(tc).dropna()
    tc['pl']=cap(tc.playername,15); tc['ch']=cap(tc.champion,15); tc['oc']=cap(tc.opp_champ,15)
    out={}
    for lab,f in [('player','golddiffat15~C(pl)'),('champ','golddiffat15~C(ch)'),('matchup','golddiffat15~C(oc)')]:
        m=smf.ols(f,tc).fit(); out[lab]=max(m.rsquared_adj,0)
    return out, len(tc)

# top-lane counterpick reconstruction
SCHED_FIRST  = {1:1,2:4,3:5,4:8,5:9}    # team with first overall pick
SCHED_SECOND = {1:2,2:3,3:6,4:7,5:10}   # the other team (gets last pick = counterpick)

def top_counterpick(d):
    tops = d[d.position=='top'][['gameid','side','champion','golddiffat15','xpdiffat15','result','firstPick','playername']].copy()
    teams = d[d.position=='team'][['gameid','side','pick1','pick2','pick3','pick4','pick5']].copy()
    # firstPick lives on player rows; take from top row itself
    m = tops.merge(teams, on=['gameid','side'], how='left')
    def pidx(r):
        for i in range(1,6):
            if r.get(f'pick{i}')==r['champion']: return i
        return np.nan
    m['top_pickidx']=m.apply(pidx,axis=1)
    def gorder(r):
        if pd.isna(r.top_pickidx): return np.nan
        return (SCHED_FIRST if r.firstPick==1 else SCHED_SECOND)[int(r.top_pickidx)]
    m['top_global']=m.apply(gorder,axis=1)
    m=m.dropna(subset=['top_global'])
    # opponent global order
    opp=m[['gameid','side','top_global']].copy()
    opp['side']=opp.side.map({'Blue':'Red','Red':'Blue'}); opp=opp.rename(columns={'top_global':'opp_top_global'})
    m=m.merge(opp,on=['gameid','side'],how='left').dropna(subset=['opp_top_global'])
    # counterpick = my top revealed AFTER opponent's top (higher global order)
    m['top_counterpicks']=(m.top_global>m.opp_top_global).astype(int)
    m['reveal_gap']=m.top_global-m.opp_top_global  # >0 = I revealed later (more info)
    return m

def report_counterpick(m, tag):
    print(f'--- {tag}: top counterpick chain (n={len(m)}) ---')
    # 1) does counterpicking top win LANE (golddiff15 / xpdiff15)?
    cp=m[m.top_counterpicks==1]; bp=m[m.top_counterpicks==0]
    print('  golddiff15: counterpick %.0f vs blind-side %.0f  (diff %.0f)'%(cp.golddiffat15.mean(),bp.golddiffat15.mean(),cp.golddiffat15.mean()-bp.golddiffat15.mean()))
    print('  xpdiff15:   counterpick %.0f vs blind-side %.0f  (diff %.0f)'%(cp.xpdiffat15.mean(),bp.xpdiffat15.mean(),cp.xpdiffat15.mean()-bp.xpdiffat15.mean()))
    # 2) does counterpicking top win the GAME?
    print('  win rate:   counterpick %.3f vs blind-side %.3f'%(cp.result.mean(),bp.result.mean()))
    # regression: result ~ reveal_gap (cluster by gameid), and golddiff15 ~ reveal_gap
    import statsmodels.api as sm
    mm=m.dropna(subset=['reveal_gap','golddiffat15','result']).copy()
    mm['z_gap']=(mm.reveal_gap-mm.reveal_gap.mean())/mm.reveal_gap.std()
    r1=smf.ols('golddiffat15~z_gap',mm).fit(cov_type='cluster',cov_kwds={'groups':mm.gameid})
    r2=smf.logit('result~z_gap',mm).fit(disp=0,cov_type='cluster',cov_kwds={'groups':mm.gameid})
    print('  OLS golddiff15 ~ z(reveal_gap): beta=%.0f gold/SD (p=%.3g)'%(r1.params.z_gap,r1.pvalues.z_gap))
    print('  Logit result   ~ z(reveal_gap): OR=%.3f (p=%.3g)'%(np.exp(r2.params.z_gap),r2.pvalues.z_gap))

if __name__=='__main__':
    print('2026 non-China')
    d26=load(F26)
    print('\n[decomposition: adjusted-R^2, deterministic]')
    print('%-5s %8s %8s %8s   %s'%('role','player','champ','matchup','(champ+match)/player'))
    for role in ['top','jng','mid','bot','sup']:
        o,n=decomp_adjR2(d26,role); r=(o['champ']+o['matchup'])/o['player'] if o['player']>0 else float('nan')
        print('%-5s %7.3f %8.3f %8.3f   %.2fx'%(role,o['player'],o['champ'],o['matchup'],r))
    print('\n[top counterpick]')
    report_counterpick(top_counterpick(d26),'2026')

    print('\n2025 non-China')
    d25=load(F25, nonchina_filter=True)
    print('\n[decomposition: adjusted-R^2, deterministic]')
    print('%-5s %8s %8s %8s   %s'%('role','player','champ','matchup','(champ+match)/player'))
    for role in ['top','jng','mid','bot','sup']:
        o,n=decomp_adjR2(d25,role); r=(o['champ']+o['matchup'])/o['player'] if o['player']>0 else float('nan')
        print('%-5s %7.3f %8.3f %8.3f   %.2fx'%(role,o['player'],o['champ'],o['matchup'],r))
    print('\n[top counterpick]')
    report_counterpick(top_counterpick(d25),'2025')
