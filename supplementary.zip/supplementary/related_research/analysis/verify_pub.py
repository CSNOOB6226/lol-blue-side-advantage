import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import chi2
from prep import load, z
d,_=load()

print("="*70)
print("CHECK 1 — Does champion gold-to-win CONVERSION truly vary by champion,")
print("          or is the A5 pattern just small-sample noise?")
print("="*70)
champs=d['top_champion'].value_counts(); keep=champs[champs>=60].index
s=d[d['top_champion'].isin(keep)].copy()
s['z_gd']=z(s['top_golddiffat15']); s['z_tg']=z(s['team_golddiff15'])
# Model A: common slope + champion intercepts ; Model B: champion-specific slopes
A=smf.logit('result ~ z_gd + z_tg + C(top_champion)',s).fit(disp=0)
B=smf.logit('result ~ z_gd*C(top_champion) + z_tg',s).fit(disp=0)
lr=2*(B.llf-A.llf); df=B.df_model-A.df_model; p=chi2.sf(lr,df)
print(f"  champions tested: {len(keep)} (n>=60), sample n={len(s)}")
print(f"  LR test for champion-specific gold slopes: chi2({int(df)})={lr:.1f}, p={p:.3f}")
print("  -> if p>0.05, champion 'conversion' differences are NOT distinguishable")
print("     from noise => that topic is WEAK for publication.")

print("\n"+"="*70)
print("CHECK 2 — Do headline findings REPLICATE on 2025 data (out-of-sample)?")
print("="*70)
cols=['gameid','league','position','side','result','patch',
      'goldat15','xpat15','csat15','golddiffat15','xpdiffat15','csdiffat15',
      'killsat15','deathsat15','firstblood']
raw=pd.read_csv('../topics/data/raw/2025_LoL_esports_match_data_from_OraclesElixir.csv',
                usecols=cols, low_memory=False)
china=['LPL','LDL']
raw=raw[~raw['league'].isin(china)]
team=raw[raw.position=='team'].copy()
team=team[team['golddiffat15'].notna()]
# per-role gold diff at 15
roles=['top','jng','mid','bot','sup']
base=team[['gameid','side','result','league','patch','golddiffat15','firstblood',
           'killsat15','deathsat15']].rename(columns={'golddiffat15':'team_gd15'})
for r in roles:
    sub=raw[raw.position==r][['gameid','side','golddiffat15','xpdiffat15','csdiffat15']]
    sub=sub.rename(columns={'golddiffat15':f'{r}_gd',' xpdiffat15':f'{r}_xp'})
    sub=sub.rename(columns={'xpdiffat15':f'{r}_xp','csdiffat15':f'{r}_cs'})
    base=base.merge(sub,on=['gameid','side'],how='left')
base=base.dropna(subset=[f'{r}_gd' for r in roles]+['team_gd15'])
base['team_xp15']=base[[f'{r}_xp' for r in roles]].sum(axis=1)
base['team_cs15']=base[[f'{r}_cs' for r in roles]].sum(axis=1)
base['team_kill15']=base['killsat15']-base['deathsat15']
def Z(s): return (s-s.mean())/s.std()
for c in ['team_gd15','team_xp15','team_cs15','team_kill15']: base['z_'+c]=Z(base[c])
for r in roles: base['z_'+r]=Z(base[f'{r}_gd'])
def logit(df,xv): 
    return sm.Logit(df['result'],sm.add_constant(df[xv])).fit(disp=0,cov_type='cluster',cov_kwds={'groups':df['gameid']})
print(f"  2025 non-China sample: {base['gameid'].nunique()} games, {len(base)} team-rows")
print("\n  [Replicate G1 lead quality] full model:")
m=logit(base,['z_team_gd15','z_team_xp15','z_team_cs15','z_team_kill15'])
for v,l in [('z_team_gd15','gold'),('z_team_xp15','XP'),('z_team_cs15','CS'),('z_team_kill15','KILL')]:
    print(f"    {l:5s}: OR={np.exp(m.params[v]):.3f} (p={m.pvalues[v]:.2e})")
print("\n  [Replicate Paper1 lane decomposition] OR per +1SD lane gold lead:")
m=logit(base,['z_top','z_jng','z_mid','z_bot','z_sup'])
for r in sorted(roles,key=lambda r:-np.exp(m.params['z_'+r])):
    print(f"    {r:4s}: OR={np.exp(m.params['z_'+r]):.3f}")
print("\n  [Replicate G2 first blood] :")
fb1=logit(base,['firstblood']); fb2=logit(base,['firstblood','z_team_gd15'])
print(f"    alone OR={np.exp(fb1.params['firstblood']):.3f}; +gold OR={np.exp(fb2.params['firstblood']):.3f} (p={fb2.pvalues['firstblood']:.2e})")
