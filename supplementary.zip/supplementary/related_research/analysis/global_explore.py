import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import statsmodels.api as sm
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, StratifiedKFold
from prep import load, z
d,_=load()
def logit(df,xvars,y='result'):
    X=sm.add_constant(df[xvars]); return sm.Logit(df[y],X).fit(disp=0,cov_type='cluster',cov_kwds={'groups':df['gameid']})
def OR(m,n): return f"OR={np.exp(m.params[n]):.3f} (b={m.params[n]:+.3f}, p={m.pvalues[n]:.2e})"

# team-level composite diffs at 15
d['team_xpdiff15']=d[['top_xpdiffat15','jng_xpdiffat15','mid_xpdiffat15','bot_xpdiffat15','sup_xpdiffat15']].sum(axis=1)
d['team_csdiff15']=d[['top_csdiffat15','jng_csdiffat15','mid_csdiffat15','bot_csdiffat15','sup_csdiffat15']].sum(axis=1)
d['team_killdiff15']=d['team_killsat15']-d['team_deathsat15']
for c in ['team_golddiff15','team_xpdiff15','team_csdiff15','team_killdiff15','team_golddiff10']:
    d['z_'+c]=z(d[c])

print("="*72)
print("TEST 1 — QUALITY of a 15-min gold lead: does COMPOSITION add info")
print("         beyond the total gold number? (kills vs xp vs cs)")
print("="*72)
m=logit(d,['z_team_golddiff15','z_team_xpdiff15','z_team_csdiff15','z_team_killdiff15'])
for v in ['z_team_golddiff15','z_team_xpdiff15','z_team_csdiff15','z_team_killdiff15']:
    print(f"  {v:20s}: {OR(m,v)}")
print("  (If kills ~ OR 1 / n.s., kill leads are fully 'priced into' gold;")
print("   if xp/cs stay positive, they carry extra information beyond gold.)")

print("\n"+"="*72)
print("TEST 2 — Is FIRST BLOOD overrated once you know the gold it created?")
print("="*72)
m1=logit(d,['firstblood']); print("  firstblood alone        :",OR(m1,'firstblood'))
m2=logit(d,['firstblood','z_team_golddiff15']); print("  + team gold@15          :",OR(m2,'firstblood'))
m3=logit(d,['z_team_killdiff15','z_team_golddiff15'])
print("  kill-diff@15 | gold@15  :",OR(m3,'z_team_killdiff15'))

print("\n"+"="*72)
print("TEST 3 — OBJECTIVE TIER LIST: which EARLY neutral objective has the")
print("         strongest INDEPENDENT link to winning (controlling team gold)?")
print("="*72)
m=logit(d,['firstdragon','firstherald','grub_diff','firsttower','z_team_golddiff15'])
for v in ['firstdragon','firstherald','grub_diff','firsttower']:
    print(f"  {v:12s}: {OR(m,v)}")
print("  team_golddiff15:",OR(m,'z_team_golddiff15'))

print("\n"+"="*72)
print("TEST 4 — HOW DETERMINISTIC is a game from 15 min, and WHERE?")
print("   (AUC of gold@15-only model + base rate the 15min gold-leader wins)")
print("="*72)
d['gold_leader_wins']=((d['team_golddiff15']>0)&(d['result']==1))|((d['team_golddiff15']<0)&(d['result']==0))
rows=[]
cv=StratifiedKFold(5,shuffle=True,random_state=1)
big=d['league'].value_counts(); 
for lg in big[big>=400].index:
    s=d[d.league==lg]
    auc=cross_val_score(LogisticRegression(max_iter=500),s[['team_golddiff15']],s['result'],cv=cv,scoring='roc_auc').mean()
    br=s['gold_leader_wins'].mean()
    rows.append((lg,len(s),auc,br))
rr=pd.DataFrame(rows,columns=['league','n','auc_gold15','leader_winrate']).sort_values('leader_winrate',ascending=False)
print(rr.round(3).to_string(index=False))
print(f"\n  OVERALL: 15-min gold leader wins {d['gold_leader_wins'].mean()*100:.1f}% of games")

print("\n"+"="*72)
print("TEST 5 — WHICH ROLE's 15-min lead matters most (global, not top-centric)")
print("="*72)
for r in ['top','jng','mid','bot','sup']: d['z_'+r]=z(d[r+'_golddiffat15'])
m=logit(d,['z_top','z_jng','z_mid','z_bot','z_sup'])
for r in sorted(['top','jng','mid','bot','sup'],key=lambda r:-np.exp(m.params['z_'+r])):
    print(f"  {r:4s}: OR={np.exp(m.params['z_'+r]):.3f}")
