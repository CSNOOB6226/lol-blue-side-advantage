import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import statsmodels.api as sm
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
from prep import load, z
d,_=load()
def logit(df,xvars,y='result'):
    X=sm.add_constant(df[xvars]); return sm.Logit(df[y],X).fit(disp=0,cov_type='cluster',cov_kwds={'groups':df['gameid']})
for c in ['team_golddiff15','top_golddiffat15']:
    d['z_'+c]=z(d[c])

print("="*70); print("ANALYSIS 7: 'Abandoned top' — can a team win while FEEDING top lane?")
print("="*70)
beh=d[d['top_golddiffat15']<=d['top_golddiffat15'].quantile(1/3)]   # top clearly behind
print(f"Games where top is in worst tercile of lane gold-diff@15 (top behind): n={len(beh)}")
print(f"  Win rate of these teams: {beh['result'].mean()*100:.1f}%")
strong=beh[beh['team_golddiff15']>0]
print(f"  Of 'top behind' games, share where TEAM is still ahead@15: {len(strong)/len(beh)*100:.1f}%  (these win {strong['result'].mean()*100:.1f}%)")
# What lets you win with a losing top? objective + other-lane substitution
beh=beh.copy()
beh['z_other']=z(beh['team_golddiff15']-beh['top_golddiffat15'])  # team gold ex-top
beh['z_grub']=z(beh['grub_diff']); beh['z_drag']=z(beh['drag_diff'])
m=logit(beh,['z_other','z_grub','z_drag','firstdragon'])
print("\nAmong 'top behind' teams, what predicts winning anyway?")
for v in ['z_other','z_grub','z_drag','firstdragon']:
    b=m.params[v]; print(f"  {v:10s}: OR={np.exp(b):.3f} (b={b:+.3f}, p={m.pvalues[v]:.2e})")
# interaction: does objective control substitute for a top lead?
d['z_grub']=z(d['grub_diff']); d['gd_x_grub']=d['z_top_golddiffat15']*d['z_grub']
mi=logit(d,['z_top_golddiffat15','z_grub','gd_x_grub','z_team_golddiff15'])
print("\nFull sample: result ~ top_golddiff * grub_diff + team_gold (substitution test)")
for v in ['z_top_golddiffat15','z_grub','gd_x_grub']:
    print(f"  {v:18s}: OR={np.exp(mi.params[v]):.3f} (p={mi.pvalues[v]:.2e})")

print("\n"+"="*70); print("ROBUSTNESS: top gold-diff@15 coefficient AFTER team-gold control,")
print("  across regions / patches / with fixed effects"); print("="*70)
res=[]
big=d['league'].value_counts(); leagues=big[big>=400].index.tolist()
for lg in leagues:
    s=d[d.league==lg]
    if s['result'].nunique()<2: continue
    m=logit(s,['z_top_golddiffat15','z_team_golddiff15'])
    res.append(('league:'+lg,len(s),np.exp(m.params['z_top_golddiffat15']),m.pvalues['z_top_golddiffat15']))
for pt in sorted(d['patch'].dropna().unique()):
    s=d[d.patch==pt]
    if len(s)<400 or s['result'].nunique()<2: continue
    m=logit(s,['z_top_golddiffat15','z_team_golddiff15'])
    res.append(('patch:'+str(pt),len(s),np.exp(m.params['z_top_golddiffat15']),m.pvalues['z_top_golddiffat15']))
rr=pd.DataFrame(res,columns=['subset','n','top_OR_adj','p'])
print("\n(top_OR_adj ~ effect of top lane lead AFTER controlling team gold; ~1 or <1 = no independent value)")
print(rr.round(3).to_string(index=False))
# pooled with FE
dd=d.copy()
fe=pd.get_dummies(dd['league'],prefix='lg',drop_first=True).astype(float)
ptd=pd.get_dummies(dd['patch'].astype(str),prefix='p',drop_first=True).astype(float)
dd['blue']=(dd['side']=='Blue').astype(float)
Xfe=pd.concat([dd[['z_top_golddiffat15','z_team_golddiff15','blue']],fe,ptd],axis=1)
mfe=sm.Logit(dd['result'],sm.add_constant(Xfe)).fit(disp=0,cov_type='cluster',cov_kwds={'groups':dd['gameid']})
print(f"\nPooled + league&patch&side FE:  top_golddiff15 OR={np.exp(mfe.params['z_top_golddiffat15']):.3f} "
      f"(b={mfe.params['z_top_golddiffat15']:+.3f}, p={mfe.pvalues['z_top_golddiffat15']:.2e}); "
      f"team OR={np.exp(mfe.params['z_team_golddiff15']):.2f}")

# headline figures
# A1 coefficient-shift plot
m1=logit(d,['z_top_golddiffat15']); m2=logit(d,['z_top_golddiffat15','z_team_golddiff15'])
fig,ax=plt.subplots(figsize=(6.5,3.2))
vals=[np.exp(m1.params['z_top_golddiffat15']),np.exp(m2.params['z_top_golddiffat15'])]
ax.barh(['Top-lane gold alone\n(M1: top alone)','Controlling for team gold\n(M2: + team gold)'],vals,color=['#c0504d','#4f81bd'])
ax.axvline(1,ls='--',c='k'); ax.set_xlabel('Win odds ratio for a top-lane gold lead (per +1 SD)')
ax.set_title('The independent association of top gold disappears after controlling for team gold')
for i,v in enumerate(vals): ax.text(v+0.03,i,f'{v:.2f}',va='center')
fig.tight_layout(); fig.savefig('figures/A1_top_collapse.png',dpi=130); plt.close()
# A4 lane bar
for r in ['top','jng','mid','bot','sup']: d['z_'+r]=z(d[r+'_golddiffat15'])
m4=logit(d,['z_top','z_jng','z_mid','z_bot','z_sup'])
ors={r:np.exp(m4.params['z_'+r]) for r in ['top','jng','mid','bot','sup']}
order=sorted(ors,key=ors.get)
fig,ax=plt.subplots(figsize=(6.5,3.6))
cols=['#4f81bd' if k!='top' else '#c0504d' for k in order]
ax.bar(order,[ors[k] for k in order],color=cols)
ax.axhline(1,ls='--',c='k'); ax.set_ylabel('OR per +1SD lane gold lead')
ax.set_title('Which role benefits most from the same gold lead? (bot > mid > top ≈ jng > sup)')
for i,k in enumerate(order): ax.text(i,ors[k]+0.02,f'{ors[k]:.2f}',ha='center')
fig.tight_layout(); fig.savefig('figures/A4_lane_value.png',dpi=130); plt.close()
print("\nFigures saved: A1_top_collapse.png, A4_lane_value.png")
