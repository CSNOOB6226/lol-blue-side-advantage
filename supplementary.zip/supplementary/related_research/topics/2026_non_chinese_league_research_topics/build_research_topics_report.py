from pathlib import Path
import math

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[2]
PROJECT_DIR = Path(__file__).resolve().parent
DATA_FILE = ROOT / "topics/data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv"
CHART_DIR = PROJECT_DIR / "figures"
REPORT_FILE = PROJECT_DIR / "2026_non_chinese_league_research_topics_report.docx"

ROLES = ["top", "jng", "mid", "bot", "sup"]
FOCUS_LEAGUES = {"LCK", "LEC", "LCS", "LCP", "CBLOL"}

BLUE = "2E74B5"
DARK_BLUE = "17365D"
INK = "1F2937"
MUTED = "667085"
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F4F6F9"
PALE_GOLD = "FFF4D6"
GOLD = "9A6B00"
RED = "9B1C1C"
WHITE = "FFFFFF"

PAGE_WIDTH_DXA = 12240
CONTENT_WIDTH_DXA = 9360
TABLE_INDENT_DXA = 120


def sigmoid(z):
    return 1 / (1 + np.exp(-np.clip(z, -35, 35)))


def normal_p(z):
    return math.erfc(abs(float(z)) / math.sqrt(2))


def fit_logit(data, outcome, numeric, categorical):
    parts = [pd.Series(1.0, index=data.index, name="Intercept")]
    for col in numeric:
        parts.append(data[col].astype(float).rename(col))
    for col in categorical:
        parts.append(
            pd.get_dummies(
                data[col].astype(str),
                prefix=col,
                drop_first=True,
                dtype=float,
            )
        )

    x = pd.concat(parts, axis=1)
    y = data[outcome].astype(float).to_numpy()
    a = x.to_numpy(float)
    beta = np.zeros(a.shape[1])

    for _ in range(120):
        pred = sigmoid(a @ beta)
        weights = np.clip(pred * (1 - pred), 1e-6, None)
        z = a @ beta + (y - pred) / weights
        hessian = (a.T * weights) @ a + 1e-7 * np.eye(a.shape[1])
        candidate = np.linalg.solve(hessian, (a.T * weights) @ z)
        if np.max(np.abs(candidate - beta)) < 1e-8:
            beta = candidate
            break
        beta = candidate

    pred = sigmoid(a @ beta)
    weights = np.clip(pred * (1 - pred), 1e-6, None)
    hessian = (a.T * weights) @ a + 1e-7 * np.eye(a.shape[1])
    covariance = np.linalg.inv(hessian)
    se = np.sqrt(np.diag(covariance))
    z_stat = beta / se
    p_value = np.array([normal_p(z) for z in z_stat])
    ll = float(
        np.sum(
            y * np.log(np.clip(pred, 1e-12, 1))
            + (1 - y) * np.log(np.clip(1 - pred, 1e-12, 1))
        )
    )
    ybar = np.clip(y.mean(), 1e-12, 1 - 1e-12)
    ll_null = float(np.sum(y * np.log(ybar) + (1 - y) * np.log(1 - ybar)))

    result = pd.DataFrame(
        {
            "term": x.columns,
            "coef": beta,
            "se": se,
            "p": p_value,
            "odds_ratio": np.exp(beta),
            "or_low": np.exp(beta - 1.96 * se),
            "or_high": np.exp(beta + 1.96 * se),
        }
    )
    metrics = {
        "n": len(y),
        "log_likelihood": ll,
        "mcfadden_r2": 1 - ll / ll_null,
    }
    return result, covariance, list(x.columns), metrics


def coefficient_contrast(result, covariance, names, weights):
    index = {name: i for i, name in enumerate(names)}
    w = np.zeros(len(names))
    for name, value in weights.items():
        w[index[name]] = value
    beta = result["coef"].to_numpy()
    estimate = float(w @ beta)
    se = float(math.sqrt(w @ covariance @ w))
    p = normal_p(estimate / se)
    return {
        "estimate": estimate,
        "se": se,
        "p": p,
        "ratio_of_odds_ratios": math.exp(estimate),
    }


def prepare_data():
    df = pd.read_csv(DATA_FILE, low_memory=False)
    team_rows = df[df["position"].eq("team")].copy()
    blue = team_rows[team_rows["side"].eq("Blue")].copy()
    blue["patch_str"] = blue["patch"].astype(str)
    blue["blue_win"] = blue["result"].astype(int)
    blue["gold_diff15_k"] = blue["golddiffat15"] / 1000
    blue["xp_diff15_k"] = blue["xpdiffat15"] / 1000
    blue["cs_diff15_10"] = blue["csdiffat15"] / 10
    blue["kill_diff15"] = blue["killsat15"] - blue["opp_killsat15"]
    blue["grub_diff"] = blue["void_grubs"] - blue["opp_void_grubs"]

    players = df[
        df["position"].isin(ROLES) & df["side"].eq("Blue")
    ].copy()
    role_gold = players.pivot(
        index="gameid",
        columns="position",
        values="golddiffat15",
    )
    for role in ROLES:
        blue[f"{role}_gold_diff15_k"] = (
            blue["gameid"].map(role_gold[role]) / 1000
        )

    blue["non_top_gold_diff15_k"] = (
        blue["gold_diff15_k"] - blue["top_gold_diff15_k"]
    )
    blue["focus_league"] = blue["league"].isin(FOCUS_LEAGUES).astype(int)
    blue["focus_x_top"] = (
        blue["focus_league"] * blue["top_gold_diff15_k"]
    )
    blue["focus_x_non_top"] = (
        blue["focus_league"] * blue["non_top_gold_diff15_k"]
    )

    quality_cols = [
        "blue_win",
        "league",
        "patch_str",
        "gold_diff15_k",
        "xp_diff15_k",
        "cs_diff15_10",
        "kill_diff15",
    ]
    topic1_cols = [
        "blue_win",
        "league",
        "patch_str",
        "top_gold_diff15_k",
        "non_top_gold_diff15_k",
        "focus_x_top",
        "focus_x_non_top",
    ]
    objective_cols = [
        "blue_win",
        "league",
        "patch_str",
        "gold_diff15_k",
        "firstdragon",
        "firstherald",
        "grub_diff",
    ]

    topic1 = blue[topic1_cols].dropna().copy()
    quality = blue[quality_cols].dropna().copy()
    objective = blue[objective_cols].dropna().copy()

    topic1_result, topic1_cov, topic1_names, topic1_metrics = fit_logit(
        topic1,
        "blue_win",
        [
            "top_gold_diff15_k",
            "non_top_gold_diff15_k",
            "focus_x_top",
            "focus_x_non_top",
        ],
        ["league", "patch_str"],
    )
    quality_result, _, _, quality_metrics = fit_logit(
        quality,
        "blue_win",
        [
            "gold_diff15_k",
            "xp_diff15_k",
            "cs_diff15_10",
            "kill_diff15",
        ],
        ["league", "patch_str"],
    )
    objective_result, _, _, objective_metrics = fit_logit(
        objective,
        "blue_win",
        [
            "gold_diff15_k",
            "firstdragon",
            "firstherald",
            "grub_diff",
        ],
        ["league", "patch_str"],
    )

    contrast = coefficient_contrast(
        topic1_result,
        topic1_cov,
        topic1_names,
        {
            "top_gold_diff15_k": 1,
            "focus_x_top": 1,
            "non_top_gold_diff15_k": -1,
            "focus_x_non_top": -1,
        },
    )

    topic1_focus = []
    for label, base, interaction in [
        (
            "Top lane: per 1,000 gold lead",
            "top_gold_diff15_k",
            "focus_x_top",
        ),
        (
            "Other four roles combined: per 1,000 gold lead",
            "non_top_gold_diff15_k",
            "focus_x_non_top",
        ),
    ]:
        weights = {base: 1, interaction: 1}
        c = coefficient_contrast(
            topic1_result,
            topic1_cov,
            topic1_names,
            weights,
        )
        topic1_focus.append(
            {
                "Measure": label,
                "Odds ratio": math.exp(c["estimate"]),
                "CI lower": math.exp(c["estimate"] - 1.96 * c["se"]),
                "CI upper": math.exp(c["estimate"] + 1.96 * c["se"]),
                "p-value": c["p"],
            }
        )

    topic1_other = topic1_result[
        topic1_result["term"].isin(
            ["top_gold_diff15_k", "non_top_gold_diff15_k"]
        )
    ].copy()
    topic1_other["Measure"] = topic1_other["term"].map(
        {
            "top_gold_diff15_k": "Other leagues: top lane per 1,000 gold lead",
            "non_top_gold_diff15_k": "Other leagues: other four roles combined",
        }
    )

    data_quality = {
        "rows": len(df),
        "games": df["gameid"].nunique(),
        "start_date": str(df["date"].min())[:10],
        "end_date": str(df["date"].max())[:10],
        "leagues": team_rows["league"].nunique(),
        "teams": team_rows["teamname"].nunique(),
        "players": df.loc[
            ~df["position"].eq("team"), "playername"
        ].nunique(),
        "duplicate_rows": int(df.duplicated().sum()),
        "early_missing": int(
            df[
                [
                    "goldat10",
                    "goldat15",
                    "xpat10",
                    "xpat15",
                    "csat10",
                    "csat15",
                    "result",
                ]
            ]
            .isna()
            .sum()
            .sum()
        ),
        "patch_min": float(df["patch"].min()),
        "patch_max": float(df["patch"].max()),
    }

    return {
        "df": df,
        "blue": blue,
        "data_quality": data_quality,
        "topic1_result": topic1_result,
        "topic1_focus": pd.DataFrame(topic1_focus),
        "topic1_other": topic1_other,
        "topic1_metrics": topic1_metrics,
        "topic1_contrast": contrast,
        "quality_result": quality_result,
        "quality_metrics": quality_metrics,
        "objective_result": objective_result,
        "objective_metrics": objective_metrics,
    }


def font(size, bold=False):
    path = (
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf"
        if bold
        else "/System/Library/Fonts/Supplemental/Arial.ttf"
    )
    return ImageFont.truetype(path, size=size)


def create_coefficient_chart(
    rows,
    output,
    title,
    subtitle,
    x_min,
    x_max,
    ticks,
):
    width, height = 1500, 820
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    title_size = 44
    while title_size > 28 and draw.textlength(title, font=font(title_size, True)) > 1310:
        title_size -= 1
    draw.text((95, 55), title, fill="#" + DARK_BLUE, font=font(title_size, True))
    subtitle_size = 25
    while subtitle_size > 18 and draw.textlength(subtitle, font=font(subtitle_size)) > 1310:
        subtitle_size -= 1
    draw.text((95, 118), subtitle, fill="#" + MUTED, font=font(subtitle_size))

    left, right = 570, 1380
    top, bottom = 220, 670

    def x_pos(value):
        return left + (value - x_min) / (x_max - x_min) * (right - left)

    for tick in ticks:
        x = x_pos(tick)
        draw.line((x, top, x, bottom), fill="#E4E7EC", width=2)
        text = f"{tick:.1f}"
        bbox = draw.textbbox((0, 0), text, font=font(22))
        draw.text(
            (x - (bbox[2] - bbox[0]) / 2, bottom + 18),
            text,
            fill="#" + MUTED,
            font=font(22),
        )

    reference = x_pos(1.0)
    draw.line((reference, top - 15, reference, bottom), fill="#98A2B3", width=4)

    spacing = (bottom - top) / max(1, len(rows))
    for i, row in enumerate(rows):
        y = top + spacing * (i + 0.5)
        label = row["label"]
        label_size = 25
        while label_size > 14 and draw.textlength(label, font=font(label_size)) > left - 120:
            label_size -= 1
        draw.text((95, y - 19), label, fill="#" + INK, font=font(label_size))
        low = x_pos(max(x_min, row["low"]))
        high = x_pos(min(x_max, row["high"]))
        center = x_pos(row["value"])
        draw.line((low, y, high, y), fill=row["color"], width=8)
        draw.ellipse(
            (center - 11, y - 11, center + 11, y + 11),
            fill=row["color"],
        )
        value_text = f"{row['value']:.2f}"
        draw.text(
            (min(right - 10, high + 18), y - 17),
            value_text,
            fill=row["color"],
            font=font(23, True),
        )

    draw.text(
        (left + 220, 745),
        "Odds ratio",
        fill="#" + MUTED,
        font=font(24),
    )
    image.save(output, quality=95)


def build_charts(analysis):
    CHART_DIR.mkdir(parents=True, exist_ok=True)

    focus_rows = []
    for _, row in analysis["topic1_focus"].iterrows():
        focus_rows.append(
            {
                "label": "Focus leagues: " + row["Measure"],
                "value": row["Odds ratio"],
                "low": row["CI lower"],
                "high": row["CI upper"],
                "color": "#2E74B5",
            }
        )
    for _, row in analysis["topic1_other"].iterrows():
        focus_rows.append(
            {
                "label": row["Measure"],
                "value": row["odds_ratio"],
                "low": row["or_low"],
                "high": row["or_high"],
                "color": "#7A5A00",
            }
        )
    create_coefficient_chart(
        focus_rows,
        CHART_DIR / "figure1_top_vs_non_top_gold_odds_ratios.png",
        "The value of a 1,000 gold lead depends on its location",
        "League and patch controls; focus leagues: LCK, LEC, LCS, LCP, CBLOL",
        0.5,
        2.2,
        [0.5, 1.0, 1.5, 2.0],
    )

    quality_map = {
        "gold_diff15_k": ("Gold difference at 15 (per 1,000)", "#2E74B5"),
        "xp_diff15_k": ("XP difference at 15 (per 1,000)", "#344054"),
        "cs_diff15_10": ("CS difference at 15 (per 10)", "#7A5A00"),
        "kill_diff15": ("Kill difference at 15 (per kill)", "#9B1C1C"),
    }
    quality_rows = []
    for term, (label, color) in quality_map.items():
        row = analysis["quality_result"].set_index("term").loc[term]
        quality_rows.append(
            {
                "label": label,
                "value": row["odds_ratio"],
                "low": row["or_low"],
                "high": row["or_high"],
                "color": color,
            }
        )
    create_coefficient_chart(
        quality_rows,
        CHART_DIR / "figure2_gold_lead_composition.png",
        "XP and CS add information after controlling for total gold",
        "The additional kill coefficient is near zero; league and patch controls",
        0.85,
        1.55,
        [0.9, 1.0, 1.2, 1.4],
    )

    objective_map = {
        "gold_diff15_k": ("Gold difference at 15 (per 1,000)", "#344054"),
        "firstdragon": ("First dragon secured", "#2E74B5"),
        "firstherald": ("First Rift Herald secured", "#7A5A00"),
        "grub_diff": ("Void Grub difference (per grub)", "#9B1C1C"),
    }
    objective_rows = []
    for term, (label, color) in objective_map.items():
        row = analysis["objective_result"].set_index("term").loc[term]
        objective_rows.append(
            {
                "label": label,
                "value": row["odds_ratio"],
                "low": row["or_low"],
                "high": row["or_high"],
                "color": color,
            }
        )
    create_coefficient_chart(
        objective_rows,
        CHART_DIR / "figure3_neutral_objective_residual_value.png",
        "Dragons retain predictive value after controlling for gold at 15",
        "Herald retains an association; the grub difference is not significant",
        0.85,
        2.25,
        [0.9, 1.0, 1.5, 2.0],
    )


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in [
        ("top", top),
        ("start", start),
        ("bottom", bottom),
        ("end", end),
    ]:
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    table.autofit = False
    tbl_pr = table._tbl.tblPr

    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths)))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(TABLE_INDENT_DXA))
    tbl_ind.set(qn("w:type"), "dxa")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        for i, cell in enumerate(row.cells):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.first_child_found_in("w:tcW")
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(widths[i]))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_run_font(run, size=None, color=None, bold=None, italic=None):
    run.font.name = "Calibri"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Calibri")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Calibri")
    run._element.get_or_add_rPr().rFonts.set(
        qn("w:eastAsia"), "STHeiti"
    )
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def apply_style_font(style, size, color=INK, bold=False):
    style.font.name = "Calibri"
    style._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Calibri")
    style._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Calibri")
    style._element.get_or_add_rPr().rFonts.set(
        qn("w:eastAsia"), "STHeiti"
    )
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string(color)
    style.font.bold = bold


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    set_run_font(run, size=9, color=MUTED)
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)
    end = paragraph.add_run("")
    set_run_font(end, size=9, color=MUTED)


def add_custom_numbering(doc):
    numbering = doc.part.numbering_part.element
    existing_ids = [
        int(x.get(qn("w:abstractNumId")))
        for x in numbering.findall(qn("w:abstractNum"))
    ]
    abstract_id = max(existing_ids or [0]) + 1

    abstract = OxmlElement("w:abstractNum")
    abstract.set(qn("w:abstractNumId"), str(abstract_id))
    multi = OxmlElement("w:multiLevelType")
    multi.set(qn("w:val"), "singleLevel")
    abstract.append(multi)

    level = OxmlElement("w:lvl")
    level.set(qn("w:ilvl"), "0")
    start = OxmlElement("w:start")
    start.set(qn("w:val"), "1")
    num_fmt = OxmlElement("w:numFmt")
    num_fmt.set(qn("w:val"), "bullet")
    lvl_text = OxmlElement("w:lvlText")
    lvl_text.set(qn("w:val"), "•")
    lvl_jc = OxmlElement("w:lvlJc")
    lvl_jc.set(qn("w:val"), "left")
    p_pr = OxmlElement("w:pPr")
    tabs = OxmlElement("w:tabs")
    tab = OxmlElement("w:tab")
    tab.set(qn("w:val"), "num")
    tab.set(qn("w:pos"), "540")
    tabs.append(tab)
    ind = OxmlElement("w:ind")
    ind.set(qn("w:left"), "540")
    ind.set(qn("w:hanging"), "280")
    spacing = OxmlElement("w:spacing")
    spacing.set(qn("w:after"), "80")
    spacing.set(qn("w:line"), "290")
    spacing.set(qn("w:lineRule"), "auto")
    p_pr.append(tabs)
    p_pr.append(ind)
    p_pr.append(spacing)
    level.extend([start, num_fmt, lvl_text, lvl_jc, p_pr])
    abstract.append(level)
    numbering.append(abstract)

    num_ids = [
        int(x.get(qn("w:numId"))) for x in numbering.findall(qn("w:num"))
    ]
    num_id = max(num_ids or [0]) + 1
    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(num_id))
    abstract_ref = OxmlElement("w:abstractNumId")
    abstract_ref.set(qn("w:val"), str(abstract_id))
    num.append(abstract_ref)
    numbering.append(num)
    return num_id


def set_numbering(paragraph, num_id):
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = p_pr.find(qn("w:numPr"))
    if num_pr is None:
        num_pr = OxmlElement("w:numPr")
        p_pr.append(num_pr)
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num_id_node = OxmlElement("w:numId")
    num_id_node.set(qn("w:val"), str(num_id))
    num_pr.extend([ilvl, num_id_node])


def configure_document(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    normal = doc.styles["Normal"]
    apply_style_font(normal, 11, INK)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.line_spacing = 1.333
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    heading_tokens = {
        "Heading 1": (16, BLUE, 18, 10),
        "Heading 2": (13, BLUE, 12, 6),
        "Heading 3": (12, DARK_BLUE, 8, 4),
    }
    for name, (size, color, before, after) in heading_tokens.items():
        style = doc.styles[name]
        apply_style_font(style, size, color, True)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    caption = doc.styles["Caption"]
    apply_style_font(caption, 9.5, MUTED)
    caption.font.italic = True
    caption.paragraph_format.space_before = Pt(4)
    caption.paragraph_format.space_after = Pt(6)
    caption.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER

    if "Callout" not in doc.styles:
        callout = doc.styles.add_style("Callout", WD_STYLE_TYPE.PARAGRAPH)
    else:
        callout = doc.styles["Callout"]
    apply_style_font(callout, 11, DARK_BLUE, True)
    callout.paragraph_format.space_before = Pt(6)
    callout.paragraph_format.space_after = Pt(8)
    callout.paragraph_format.line_spacing = 1.25

    header = section.header
    hp = header.paragraphs[0]
    hp.text = ""
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hr = hp.add_run("2026_non_chinese_league_research_topics")
    set_run_font(hr, size=9, color=MUTED, bold=True)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.text = ""
    add_page_number(fp)


def add_cover(doc):
    for _ in range(4):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    r = p.add_run("Research Topic Assessment")
    set_run_font(r, size=12, color=GOLD, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(10)
    r = p.add_run("2026 Non-Chinese Leagues\nPotential Research Topics")
    set_run_font(r, size=29, color=DARK_BLUE, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(32)
    r = p.add_run("Location, composition, and realization of early-game advantages")
    set_run_font(r, size=15, color=BLUE)

    table = doc.add_table(rows=3, cols=2)
    set_repeat_table_header(table.rows[0])
    values = [
        ("Data period", "January 8–June 2, 2026"),
        ("Analysis sample", "5,000 games after excluding LPL and games involving LPL teams"),
        ("Report purpose", "Exploratory topic assessment and research plan"),
    ]
    for row, (label, value) in zip(table.rows, values):
        label_cell, value_cell = row.cells
        shade_cell(label_cell, LIGHT_BLUE)
        shade_cell(value_cell, LIGHT_GRAY)
        label_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        value_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p1 = label_cell.paragraphs[0]
        p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p1.paragraph_format.space_after = Pt(0)
        r1 = p1.add_run(label)
        set_run_font(r1, size=10, color=DARK_BLUE, bold=True)
        p2 = value_cell.paragraphs[0]
        p2.paragraph_format.space_after = Pt(0)
        r2 = p2.add_run(value)
        set_run_font(r2, size=10, color=INK)
    set_table_geometry(table, [2160, 7200])

    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(28)
    r = p.add_run("Report date: June 7, 2026")
    set_run_font(r, size=10, color=MUTED)
    doc.add_page_break()


def add_bullet(doc, text, num_id):
    p = doc.add_paragraph()
    set_numbering(p, num_id)
    r = p.add_run(text)
    set_run_font(r, size=11, color=INK)
    return p


def add_callout(doc, label, text, fill=LIGHT_BLUE):
    table = doc.add_table(rows=1, cols=1)
    set_repeat_table_header(table.rows[0])
    cell = table.cell(0, 0)
    shade_cell(cell, fill)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(label + " ")
    set_run_font(r, size=11, color=DARK_BLUE, bold=True)
    r = p.add_run(text)
    set_run_font(r, size=11, color=INK)
    set_table_geometry(table, [CONTENT_WIDTH_DXA])
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_table(doc, headers, rows, widths, numeric_cols=()):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    set_repeat_table_header(table.rows[0])
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        shade_cell(cell, LIGHT_BLUE)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(str(header))
        set_run_font(r, size=9.2, color=DARK_BLUE, bold=True)
    for row_data in rows:
        row = table.add_row()
        for i, value in enumerate(row_data):
            cell = row.cells[i]
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            p.alignment = (
                WD_ALIGN_PARAGRAPH.CENTER
                if i in numeric_cols
                else WD_ALIGN_PARAGRAPH.LEFT
            )
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(str(value))
            set_run_font(r, size=9.2, color=INK)
    set_table_geometry(table, widths)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def fmt_p(value):
    if value < 0.001:
        return "<0.001"
    return f"{value:.3f}"


def add_figure(doc, path, caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(2)
    picture = p.add_run().add_picture(str(path), width=Inches(6.25))
    picture._inline.docPr.set("descr", caption)
    picture._inline.docPr.set("title", path.stem)
    c = doc.add_paragraph(caption, style="Caption")
    c.paragraph_format.keep_with_next = False


def add_research_outline(doc, num_id, steps):
    for step in steps:
        add_bullet(doc, step, num_id)


def build_report(analysis):
    doc = Document()
    configure_document(doc)
    bullet_num_id = add_custom_numbering(doc)
    add_cover(doc)

    quality = analysis["data_quality"]
    q = analysis["quality_result"].set_index("term")
    obj = analysis["objective_result"].set_index("term")
    t1 = analysis["topic1_focus"].set_index("Measure")
    contrast = analysis["topic1_contrast"]

    doc.add_heading("Executive Summary", level=1)
    add_callout(
        doc,
        "Common question: ",
        "The value of an early lead depends on its size, location, composition, and whether objective value has already been realized.",
    )
    doc.add_paragraph(
        "This report excludes Chinese leagues and related Chinese-team games from the 2026 professional match data. "
        "Exploratory logistic regressions use one blue-side record per game to identify three counterintuitive, "
        "interpretable topics suitable for a course research project or data study."
    )
    add_table(
        doc,
        ["Priority", "Research topic", "Counterintuitive finding", "Suggested use"],
        [
            (
                "1",
                "The top-lane lead paradox in focus leagues",
                "Top-lane gold leads convert into wins less strongly than leads elsewhere",
                "Best fit for the main top-lane project",
            ),
            (
                "2",
                "The composition of a gold lead",
                "Kills add little information after controlling for total gold",
                "Most straightforward statistical design",
            ),
            (
                "3",
                "Residual value of neutral objectives",
                "Dragons retain more information than top-side objectives that yield gold sooner",
                "Best fit for presentations and visualizations",
            ),
        ],
        [820, 2400, 3600, 2540],
        numeric_cols=(0,),
    )

    doc.add_heading("1. Data Coverage and Quality", level=1)
    doc.add_paragraph(
        f"The file covers {quality['start_date']} through {quality['end_date']}, "
        f"with patches {quality['patch_min']:.2f} through {quality['patch_max']:.2f}. "
        "The analysis therefore covers data through June 2, 2026, rather than the complete 2026 calendar year."
    )
    add_table(
        doc,
        ["Item", "Result", "Interpretation"],
        [
            ("Final sample", f"{quality['games']:,} games; {quality['rows']:,} rows", "12 rows per game"),
            ("League coverage", f"{quality['leagues']} leagues", "After excluding China-related games"),
            ("Participants", f"{quality['teams']} teams; {quality['players']} players", "Counted by names in the data"),
            ("Duplicate records", str(quality["duplicate_rows"]), "No fully duplicated rows found"),
            ("Missing early-game variables", str(quality["early_missing"]), "10/15-minute gold, XP, CS, and match result"),
        ],
        [1900, 2300, 5160],
        numeric_cols=(1,),
    )

    doc.add_heading("1.1 Exclusion of China-Related Games", level=2)
    doc.add_paragraph(
        "The original file contains 5,454 games and 65,448 rows. The filter removes games with league code LPL "
        "and identifies teams appearing in LPL, removing their games in other competitions as well. "
        "This removes 454 games and 5,448 rows, including 25 non-LPL games involving LPL teams. "
        "This definition is stricter than excluding only league = LPL."
    )

    doc.add_heading("1.2 Observations, Units, and Variables", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "Original structure: two teams per game, each with five player rows and one team row, totaling 12 rows.",
            "Main model unit: one blue-side record per game, with blue-side win as the outcome, avoiding treatment of opposing match records as independent observations.",
            "Role gold differences compare blue and red counterparts at 15 minutes; the other-four-role difference equals team gold difference minus the top-lane difference.",
            "All proposed studies focus on variables available by 15 minutes, avoiding final damage, final gold, and other end-of-game outcomes as predictors.",
        ],
    )

    doc.add_heading("1.3 Statistical Methods and Interpretation", level=2)
    doc.add_paragraph(
        "All three preliminary analyses use logistic regression with league and patch controls. An odds ratio above 1 indicates that larger predictor values "
        "are associated with higher win odds; p-values measure compatibility with the no-association hypothesis. "
        "These exploratory associations support topic selection and should not be interpreted as causal strategy effects."
    )

    doc.add_page_break()
    doc.add_heading("2. Topic 1: The Top-Lane Lead Paradox in Focus Leagues", level=1)
    add_callout(
        doc,
        "Research question: ",
        "Does a 1,000 gold top-lane lead at 15 minutes have the same association with winning as a 1,000 gold lead across the other four roles?",
        PALE_GOLD,
    )

    doc.add_heading("2.1 Why This Is Counterintuitive", level=2)
    doc.add_paragraph(
        "A top-lane lead often creates split-push pressure, Herald control, side-lane priority, and a stronger frontline or flank. "
        "Intuitively, it should matter at least as much as an equal lead elsewhere. "
        "The preliminary analysis instead finds a weaker independent association for top-lane leads in the focus leagues; "
        "in other leagues, the two associations are closer."
    )

    doc.add_heading("2.2 Preliminary Model and Results", level=2)
    doc.add_paragraph(
        "The focus leagues are operationally defined as LCK, LEC, LCS, LCP, and CBLOL. "
        "The formal study should test alternative league groupings for robustness."
    )
    add_table(
        doc,
        ["Focus-league measure", "Odds ratio", "95% CI", "p-value"],
        [
            (
                "Top lane: per 1,000 gold lead",
                f"{t1.loc['Top lane: per 1,000 gold lead', 'Odds ratio']:.2f}",
                f"{t1.loc['Top lane: per 1,000 gold lead', 'CI lower']:.2f}–{t1.loc['Top lane: per 1,000 gold lead', 'CI upper']:.2f}",
                fmt_p(t1.loc["Top lane: per 1,000 gold lead", "p-value"]),
            ),
            (
                "Other four roles combined: per 1,000 gold lead",
                f"{t1.loc['Other four roles combined: per 1,000 gold lead', 'Odds ratio']:.2f}",
                f"{t1.loc['Other four roles combined: per 1,000 gold lead', 'CI lower']:.2f}–{t1.loc['Other four roles combined: per 1,000 gold lead', 'CI upper']:.2f}",
                fmt_p(t1.loc["Other four roles combined: per 1,000 gold lead", "p-value"]),
            ),
        ],
        [4080, 1320, 2240, 1720],
        numeric_cols=(1, 2, 3),
    )
    add_figure(
        doc,
        CHART_DIR / "figure1_top_vs_non_top_gold_odds_ratios.png",
        "Figure 1. Role-specific gold leads and match outcomes. Bars show 95% CIs; the reference at 1 indicates no additional association.",
    )
    doc.add_paragraph(
        f"Within the focus leagues, the ratio of the top-lane odds ratio to the non-top odds ratio is approximately "
        f"{contrast['ratio_of_odds_ratios']:.2f}(p{('=' + format(contrast['p'], '.3f')) if contrast['p'] >= 0.001 else '<0.001'}). "
        "An equal early gold advantage concentrated in top lane may therefore convert less strongly into wins."
    )

    doc.add_heading("2.3 Testable Hypotheses", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "H1: In the focus leagues, the win association of top gold difference at 15 is weaker than that of the other four roles combined.",
            "H2: The difference is larger for tanks, weak-side picks, or champions with low split-push pressure.",
            "H3: Herald, grubs, and top plates explain only part of top-lane gold leads and their lower conversion.",
            "H4: Stronger teams better neutralize enemy top leads through objective trades, avoiding fights, and bottom-side expansion.",
        ],
    )

    doc.add_heading("2.4 Research Plan", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "Data: construct one row per game and calculate 10- and 15-minute gold differences for all five roles.",
            "Baseline: BlueWin ~ TopGoldDiff15 + NonTopGoldDiff15 + Side/League/Patch controls.",
            "Main test: add focus-league interactions and directly test the difference between top and non-top coefficients.",
            "Mechanisms: add champion type, Herald, grubs, first turret, and top CS/XP differences to examine the sources of top leads.",
            "Robustness: vary the focus-league definition, split by playoffs, regular season, and patch, and validate using 2025 data.",
            "Outputs: league coefficient plots, role marginal effects, and predicted win probabilities for equal 1,000 gold leads.",
        ],
    )

    doc.add_heading("2.5 Risks and Limitations", level=2)
    doc.add_paragraph(
        "Top gold difference does not directly measure deliberate investment; it can reflect lane skill, matchups, kills, or opponent mistakes. "
        "The focus-league definition also reflects researcher choice and requires alternative groups and league-specific results."
    )

    doc.add_page_break()
    doc.add_heading("3. Topic 2: The Composition of a Gold Lead", level=1)
    add_callout(
        doc,
        "Research question: ",
        "At the same total gold difference at 15 minutes, do XP and CS advantages predict outcomes better than kill advantages?",
        PALE_GOLD,
    )

    doc.add_heading("3.1 Why This Is Counterintuitive", level=2)
    doc.add_paragraph(
        "Match narratives often focus on kills because they are visible and directly generate gold. "
        "Most kill information may already be absorbed by total gold difference. XP and CS differences may additionally reflect wave control, "
        "map control, rotation efficiency, and sustained farming, retaining predictive information at equal total gold."
    )

    doc.add_heading("3.2 Preliminary Model and Results", level=2)
    add_table(
        doc,
        ["Variable", "Unit", "Odds ratio", "95% CI", "p-value"],
        [
            (
                "Total gold difference",
                "Per 1,000 gold",
                f"{q.loc['gold_diff15_k', 'odds_ratio']:.2f}",
                f"{q.loc['gold_diff15_k', 'or_low']:.2f}–{q.loc['gold_diff15_k', 'or_high']:.2f}",
                fmt_p(q.loc["gold_diff15_k", "p"]),
            ),
            (
                "XP difference",
                "Per 1,000 XP",
                f"{q.loc['xp_diff15_k', 'odds_ratio']:.2f}",
                f"{q.loc['xp_diff15_k', 'or_low']:.2f}–{q.loc['xp_diff15_k', 'or_high']:.2f}",
                fmt_p(q.loc["xp_diff15_k", "p"]),
            ),
            (
                "CS difference",
                "Per 10 CS",
                f"{q.loc['cs_diff15_10', 'odds_ratio']:.2f}",
                f"{q.loc['cs_diff15_10', 'or_low']:.2f}–{q.loc['cs_diff15_10', 'or_high']:.2f}",
                fmt_p(q.loc["cs_diff15_10", "p"]),
            ),
            (
                "Kill difference",
                "Per kill",
                f"{q.loc['kill_diff15', 'odds_ratio']:.2f}",
                f"{q.loc['kill_diff15', 'or_low']:.2f}–{q.loc['kill_diff15', 'or_high']:.2f}",
                fmt_p(q.loc["kill_diff15", "p"]),
            ),
        ],
        [1900, 1820, 1360, 2380, 1900],
        numeric_cols=(2, 3, 4),
    )
    add_figure(
        doc,
        CHART_DIR / "figure2_gold_lead_composition.png",
        "Figure 2. Lead-composition coefficients controlling for total gold at 15 minutes, league, and patch.",
    )
    doc.add_paragraph(
        "This does not imply that kills have no value. Their immediate gold value is largely contained in total gold difference, "
        "while XP and CS add structural information not fully captured by gold."
    )

    doc.add_heading("3.3 Testable Hypotheses", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "H1: XP and CS differences remain positively associated with winning after controlling for gold at 15.",
            "H2: The additional kill association is weak after gold controls and may differ by role.",
            "H3: Farming-based leads are more stable than kill-based leads in close-gold games.",
            "H4: Kill leads improve prediction mainly when converted into turrets, waves, or neutral objectives.",
        ],
    )

    doc.add_heading("3.4 Research Plan", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "Lead types: use kills, XP, CS, and gold to classify games as kill-based, farming-based, mixed, or without a clear lead.",
            "Model comparison: add XP, CS, and kills to a gold-only baseline and compare likelihood, AUC, and calibration.",
            "Role decomposition: calculate lead sources for all five roles and test which combinations matter most.",
            "Nonlinearity: use quadratic terms or piecewise functions to test diminishing marginal value of CS and XP.",
            "Robustness: restrict to games within ±500 or ±1,000 gold and repeat by patch, league, and competition stage.",
            "Outputs: predicted win probabilities by lead composition at equal gold and incremental prediction metrics.",
        ],
    )

    doc.add_heading("3.5 Risks and Limitations", level=2)
    doc.add_paragraph(
        "Gold, XP, CS, and kills are strongly correlated, requiring multicollinearity checks. "
        "Lead types summarize match states rather than randomly assigned strategies, supporting prediction and association "
        "rather than claims that a particular type of lead causes victory."
    )

    doc.add_page_break()
    doc.add_heading("4. Topic 3: Residual Value of Neutral Objectives", level=1)
    add_callout(
        doc,
        "Research question: ",
        "After accounting for gold at 15 minutes, how much outcome information remains in first dragon, first Herald, and the grub difference?",
        PALE_GOLD,
    )

    doc.add_heading("4.1 Why This Is Counterintuitive", level=2)
    doc.add_paragraph(
        "Herald and grubs directly create plates, turrets, and immediate gold, seemingly making them more valuable than first dragon. "
        "Because that value quickly enters current gold, they may add little information once gold at 15 is controlled. "
        "Part of first dragon’s value comes from future soul progress, an option value not yet fully realized."
    )

    doc.add_heading("4.2 Preliminary Model and Results", level=2)
    add_table(
        doc,
        ["Variable", "Odds ratio", "95% CI", "p-value", "Preliminary interpretation"],
        [
            (
                "Gold difference at 15 (per 1,000)",
                f"{obj.loc['gold_diff15_k', 'odds_ratio']:.2f}",
                f"{obj.loc['gold_diff15_k', 'or_low']:.2f}–{obj.loc['gold_diff15_k', 'or_high']:.2f}",
                fmt_p(obj.loc["gold_diff15_k", "p"]),
                "Current realized advantage",
            ),
            (
                "First dragon",
                f"{obj.loc['firstdragon', 'odds_ratio']:.2f}",
                f"{obj.loc['firstdragon', 'or_low']:.2f}–{obj.loc['firstdragon', 'or_high']:.2f}",
                fmt_p(obj.loc["firstdragon", "p"]),
                "Strong residual association",
            ),
            (
                "First Herald",
                f"{obj.loc['firstherald', 'odds_ratio']:.2f}",
                f"{obj.loc['firstherald', 'or_low']:.2f}–{obj.loc['firstherald', 'or_high']:.2f}",
                fmt_p(obj.loc["firstherald", "p"]),
                "Moderate additional association",
            ),
            (
                "Void Grub difference (per grub)",
                f"{obj.loc['grub_diff', 'odds_ratio']:.2f}",
                f"{obj.loc['grub_diff', 'or_low']:.2f}–{obj.loc['grub_diff', 'or_high']:.2f}",
                fmt_p(obj.loc["grub_diff", "p"]),
                "Not significant after gold controls",
            ),
        ],
        [2280, 1120, 1820, 1220, 2920],
        numeric_cols=(1, 2, 3),
    )
    add_figure(
        doc,
        CHART_DIR / "figure3_neutral_objective_residual_value.png",
        "Figure 3. Remaining early-objective associations after controlling for gold at 15 minutes, league, and patch.",
    )

    doc.add_heading("4.3 Testable Hypotheses", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "H1: First dragon retains a significant win association after gold-at-15 controls.",
            "H2: Herald has substantial total value, partly realized through immediate gold and turrets.",
            "H3: Additional grub value depends on conversion into plates, first turret, or side-lane pressure.",
            "H4: Residual dragon value is stronger in leagues or patches emphasizing dragon-soul tempo.",
        ],
    )

    doc.add_heading("4.4 Research Plan", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "Two-stage models: estimate objective associations without gold, then add gold at 15 and compare coefficient attenuation.",
            "Objective trades: classify dragon plus Herald, dragon only, Herald only, and neither.",
            "Conversion: add turret counts at 15, plates, CS, and gold differences to examine Herald and grub realization.",
            "Heterogeneity: add side, league, and patch interactions to assess map and balance changes.",
            "Validation: hold out leagues or later months to test stability of objective value.",
            "Outputs: win rates by objective combination, coefficient attenuation, and a diagram of realized versus future option value.",
        ],
    )

    doc.add_heading("4.5 Risks and Limitations", level=2)
    doc.add_paragraph(
        "First dragon and Herald often reflect team strength, lane priority, and vision control. "
        "Dragon coefficients may therefore contain unobserved team quality. The formal study should add team fixed effects "
        "and avoid interpreting objective coefficients as pure causal benefits of securing them."
    )

    doc.add_page_break()
    doc.add_heading("5. Topic Comparison and Project Recommendations", level=1)
    add_table(
        doc,
        ["Criterion", "Topic 1: Top-lane paradox", "Topic 2: Lead composition", "Topic 3: Residual objective value"],
        [
            ("Counterintuitiveness", "High", "Moderately high", "High"),
            ("Fit with existing top-lane work", "Very strong", "Moderate", "Moderate"),
            ("Statistical difficulty", "Moderate", "Low", "Moderate"),
            ("Manual classification", "Needed for expanded champion classes", "Limited", "Limited"),
            ("Presentation potential", "Strong", "Clear and robust", "Very strong"),
            ("Main methodological risk", "League definitions and champion confounding", "Collinearity", "Team-strength confounding"),
        ],
        [1800, 2520, 2520, 2520],
    )

    doc.add_heading("5.1 Recommended Main Project", level=2)
    add_callout(
        doc,
        "First choice: ",
        "Develop Topic 1 as the main study. It connects to existing weak-side and carry-top work while asking why top advantages are harder to convert in high-level play.",
    )
    doc.add_paragraph(
        "Topic 2 can serve as a methods chapter or a compact independent project showing that lead composition adds to total gold. "
        "Topic 3 suits a second report or presentation because its strategy narrative and visual structure are especially clear."
    )

    doc.add_heading("5.2 An Integrated Research Plan", level=2)
    add_research_outline(
        doc,
        bullet_num_id,
        [
            "Part 1 asks where the advantage lies: compare gold conversion in top and other roles.",
            "Part 2 asks how it forms: distinguish XP, CS, and kill-based leads.",
            "Part 3 asks whether value is realized: compare residual dragon, Herald, and grub information after gold controls.",
        ],
    )
    add_callout(
        doc,
        "Suggested title: ",
        "The Structure of Early Leads: Location, Composition, Objective Realization, and Match Outcomes in Professional League of Legends, 2026",
        PALE_GOLD,
    )

    doc.add_heading("5.3 Suggested Schedule", level=2)
    add_table(
        doc,
        ["Stage", "Duration", "Main tasks", "Deliverable"],
        [
            ("Data freeze", "1 week", "Fix dates, leagues, and exclusions; build a data dictionary", "Reproducible analysis table"),
            ("Descriptive analysis", "1–2 weeks", "Distributions, correlations, league and patch comparisons", "Charts and anomaly list"),
            ("Main models", "2 weeks", "Logistic regression, interactions, and coefficient contrasts", "Main results tables"),
            ("Robustness", "2 weeks", "Alternative definitions, team effects, and 2025 validation", "Robustness appendix"),
            ("Writing and presentation", "2 weeks", "Report, figures, and presentation narrative", "Final report and slide deck"),
        ],
        [1400, 1400, 3600, 2960],
        numeric_cols=(1,),
    )

    doc.add_heading("6. Conclusion", level=1)
    doc.add_paragraph(
        "Across the three exploratory topics, the main finding concerns the structure of early advantages: "
        "equal amounts of gold may have different implications depending on their role location, source, "
        "and associated map objectives."
    )
    doc.add_paragraph(
        "The top-lane paradox fits the existing project best; lead composition supports rigorous statistical practice; "
        "and residual objective value offers the clearest presentation narrative. All three can support formal research, "
        "but causal interpretation requires further team, champion, patch, and league controls plus cross-year validation."
    )

    doc.add_heading("Appendix A: Main Model Equations", level=1)
    formulas = [
        (
            "Topic 1",
            "logit(P(BlueWin)) = β0 + β1 TopGoldDiff15 + β2 NonTopGoldDiff15 + β3 FocusLeague×TopGoldDiff15 + β4 FocusLeague×NonTopGoldDiff15 + League FE + Patch FE",
        ),
        (
            "Topic 2",
            "logit(P(BlueWin)) = β0 + β1 GoldDiff15 + β2 XPDiff15 + β3 CSDiff15 + β4 KillDiff15 + League FE + Patch FE",
        ),
        (
            "Topic 3",
            "logit(P(BlueWin)) = β0 + β1 GoldDiff15 + β2 FirstDragon + β3 FirstHerald + β4 GrubDiff + League FE + Patch FE",
        ),
    ]
    for label, formula in formulas:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(label + ": ")
        set_run_font(r, size=10, color=DARK_BLUE, bold=True)
        r = p.add_run(formula)
        set_run_font(r, size=9.5, color=INK)

    doc.add_heading("Appendix B: Reproduction", level=1)
    doc.add_paragraph(
        "The figures and results are computed by build_research_topics_report.py in this folder using "
        "topics/data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv. "
        "After a data update, repeat the China-related exclusion step before running the script, "
        "and record the new cutoff date to keep results from different periods distinct."
    )

    doc.save(REPORT_FILE)


def main():
    analysis = prepare_data()
    build_charts(analysis)
    build_report(analysis)
    print(REPORT_FILE)


if __name__ == "__main__":
    main()
