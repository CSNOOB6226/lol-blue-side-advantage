from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


TOPICS_DIR = Path(__file__).resolve().parents[2]
TOP_PLAYER_CSV = TOPICS_DIR / "data/general_toplane_data/non_chinese_league_toplane_games.csv"
ALL_CHAMP_CSV = TOPICS_DIR / "data/general_toplane_data/non_chinese_league_toplane_champions.csv"
OUTPUT_DIR = TOPICS_DIR / "data/early_analysis_data"


TANK_CHAMPIONS = {
    "K'Sante",
    "Sion",
    "Gnar",
    "Ornn",
    "Gragas",
    "Shen",
    "Malphite",
    "Galio",
    "Poppy",
    "Volibear",
    "Dr. Mundo",
    "Cho'Gath",
}


FEATURES = [
    "is_tank",
    "gamelength",
    "kills",
    "deaths",
    "assists",
    "damagetochampions",
    "dpm",
    "damageshare",
    "damagetakenperminute",
    "damagemitigatedperminute",
    "earnedgold",
    "earned gpm",
    "earnedgoldshare",
    "goldat10",
    "xpat10",
    "csat10",
    "golddiffat10",
    "xpdiffat10",
    "csdiffat10",
    "goldat15",
    "xpat15",
    "csat15",
    "golddiffat15",
    "xpdiffat15",
    "csdiffat15",
    "goldat20",
    "xpat20",
    "csat20",
    "golddiffat20",
    "xpdiffat20",
    "csdiffat20",
]


def load_study_champions() -> list[str]:
    champions = pd.read_csv(ALL_CHAMP_CSV)
    return champions.loc[champions["games"] >= 21, "champion"].tolist()


def build_dataset() -> pd.DataFrame:
    study_champions = load_study_champions()
    rows = pd.read_csv(TOP_PLAYER_CSV)
    rows = rows[rows["champion"].isin(study_champions)].copy()
    rows["champion_class"] = rows["champion"].where(
        rows["champion"].isin(TANK_CHAMPIONS), "warrior_carry"
    )
    rows.loc[rows["champion"].isin(TANK_CHAMPIONS), "champion_class"] = "tank"
    rows["is_tank"] = (rows["champion_class"] == "tank").astype(int)

    keep_columns = [
        "gameid",
        "date",
        "league",
        "split",
        "patch",
        "side",
        "teamname",
        "playername",
        "champion",
        "champion_class",
        "result",
    ] + FEATURES

    return rows[keep_columns].dropna().copy()


def fit_model(dataset: pd.DataFrame) -> tuple[Pipeline, pd.DataFrame, pd.DataFrame]:
    x = dataset[FEATURES]
    y = dataset["result"].astype(int)

    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.25, random_state=7, stratify=y
    )

    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("logit", LogisticRegression(max_iter=5000, C=1.0)),
        ]
    )
    model.fit(x_train, y_train)

    test_prob = model.predict_proba(x_test)[:, 1]
    test_pred = (test_prob >= 0.5).astype(int)

    coefficients = pd.DataFrame(
        {
            "variable": FEATURES,
            "standardized_coefficient": model.named_steps["logit"].coef_[0],
        }
    )
    coefficients["direction"] = coefficients["standardized_coefficient"].map(
        lambda value: "helps winning" if value > 0 else "hurts winning"
    )
    coefficients["absolute_strength"] = coefficients[
        "standardized_coefficient"
    ].abs()
    coefficients = coefficients.sort_values("absolute_strength", ascending=False)

    summary = pd.DataFrame(
        [
            {
                "rows_used": len(dataset),
                "champions_used": dataset["champion"].nunique(),
                "overall_win_rate": y.mean(),
                "test_accuracy": accuracy_score(y_test, test_pred),
                "test_auc": roc_auc_score(y_test, test_prob),
                "model_type": "logistic regression",
                "target_y": "result: 1 = win, 0 = loss",
            }
        ]
    )

    return model, coefficients, summary


def write_predictions(model: Pipeline, dataset: pd.DataFrame) -> pd.DataFrame:
    predictions = dataset[
        [
            "gameid",
            "date",
            "league",
            "split",
            "patch",
            "side",
            "teamname",
            "playername",
            "champion",
            "champion_class",
            "result",
        ]
    ].copy()
    predictions["predicted_win_probability"] = model.predict_proba(
        dataset[FEATURES]
    )[:, 1]
    predictions["predicted_result"] = (
        predictions["predicted_win_probability"] >= 0.5
    ).astype(int)
    return predictions


def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)

    dataset = build_dataset()
    dataset.to_csv(OUTPUT_DIR / "early_tank_vs_carry_regression_data.csv", index=False)

    model, coefficients, summary = fit_model(dataset)
    coefficients.to_csv(OUTPUT_DIR / "early_tank_vs_carry_regression_coefficients.csv", index=False)
    summary.to_csv(OUTPUT_DIR / "early_tank_vs_carry_regression_summary.csv", index=False)

    predictions = write_predictions(model, dataset)
    predictions.to_csv(OUTPUT_DIR / "early_tank_vs_carry_regression_predictions.csv", index=False)

    print(summary.to_string(index=False))
    print()
    print(coefficients.head(15).to_string(index=False))


if __name__ == "__main__":
    main()
