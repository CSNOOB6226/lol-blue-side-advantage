from pathlib import Path
import math
import numpy as np
import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
TOPICS_DIR = Path(__file__).resolve().parents[2]
DATA = TOPICS_DIR / 'data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv'
OUT = TOPICS_DIR / 'reports/topic1_weakside_toplane/topic1_weakside_toplane_report.docx'
ML_DATA_DIR = TOPICS_DIR / 'data/topic1_weakside_toplane'
ML_FIG_DIR = TOPICS_DIR / 'reports/topic1_weakside_toplane/machine_learning_figures'

def load_ml_results():
    return {'focused_metrics': pd.read_csv(ML_DATA_DIR / 'topic1_specific_features_model_metrics.csv'), 'focused_importance': pd.read_csv(ML_DATA_DIR / 'topic1_specific_features_permutation_importance.csv'), 'full_metrics': pd.read_csv(ML_DATA_DIR / 'topic1_full_15min_features_model_metrics.csv'), 'full_importance': pd.read_csv(ML_DATA_DIR / 'topic1_full_15min_features_permutation_importance.csv')}

def sigmoid(z):
    z = np.clip(z, -35, 35)
    return 1 / (1 + np.exp(-z))

def norm_sf_abs(z):
    return math.erfc(abs(z) / math.sqrt(2))

def chi2_sf(x, df):
    if x <= 0:
        return 1.0
    if df == 1:
        return math.erfc(math.sqrt(x / 2))
    if df % 2 == 0:
        half = x / 2
        total = 0.0
        term = 1.0
        for j in range(df // 2):
            if j > 0:
                term *= half / j
            total += term
        return min(1.0, max(0.0, math.exp(-half) * total))
    z = ((x / df) ** (1 / 3) - (1 - 2 / (9 * df))) / math.sqrt(2 / (9 * df))
    return 0.5 * math.erfc(z / math.sqrt(2))

def fit_logit(data, ycol, cont_cols, cat_cols=None, max_iter=100, ridge=1e-06):
    cat_cols = cat_cols or []
    parts = [pd.Series(1.0, index=data.index, name='Intercept')]
    for col in cont_cols:
        parts.append(data[col].astype(float).rename(col))
    for col in cat_cols:
        parts.append(pd.get_dummies(data[col].astype(str), prefix=col, drop_first=True, dtype=float))
    x = pd.concat(parts, axis=1)
    y = data[ycol].astype(float).to_numpy()
    xn = x.to_numpy(float)
    beta = np.zeros(xn.shape[1])
    for _ in range(max_iter):
        pred = sigmoid(xn @ beta)
        w = np.clip(pred * (1 - pred), 1e-06, None)
        z = xn @ beta + (y - pred) / w
        xtw = xn.T * w
        h = xtw @ xn + ridge * np.eye(xn.shape[1])
        nb = np.linalg.solve(h, xtw @ z)
        if np.max(np.abs(nb - beta)) < 1e-07:
            beta = nb
            break
        beta = nb
    pred = sigmoid(xn @ beta)
    w = np.clip(pred * (1 - pred), 1e-06, None)
    h = xn.T * w @ xn + ridge * np.eye(xn.shape[1])
    cov = np.linalg.inv(h)
    se = np.sqrt(np.diag(cov))
    zstat = beta / se
    pvals = np.array([norm_sf_abs(z) for z in zstat])
    ll = float(np.sum(y * np.log(np.clip(pred, 1e-12, 1)) + (1 - y) * np.log(np.clip(1 - pred, 1e-12, 1))))
    ybar = np.clip(y.mean(), 1e-12, 1 - 1e-12)
    ll_null = float(np.sum(y * np.log(ybar) + (1 - y) * np.log(1 - ybar)))
    res = pd.DataFrame({'term': x.columns, 'coef': beta, 'se': se, 'z': zstat, 'p': pvals, 'or': np.exp(beta), 'or_ci_low': np.exp(beta - 1.96 * se), 'or_ci_high': np.exp(beta + 1.96 * se)})
    metrics = {'n': len(y), 'df_model': x.shape[1] - 1, 'log_likelihood': ll, 'null_log_likelihood': ll_null, 'mcfadden_pseudo_r2': 1 - ll / ll_null}
    return (res, metrics)

def lr_row(data, ycol, full_cont, full_cat, drop_cont=(), drop_cat=(), label=''):
    _, full = fit_logit(data, ycol, full_cont, full_cat)
    red_cont = [c for c in full_cont if c not in set(drop_cont)]
    red_cat = [c for c in full_cat if c not in set(drop_cat)]
    _, reduced = fit_logit(data, ycol, red_cont, red_cat)
    lr = 2 * (full['log_likelihood'] - reduced['log_likelihood'])
    df = full['df_model'] - reduced['df_model']
    return {'Model': label, 'Dropped variable/group': ', '.join(list(drop_cont) + list(drop_cat)), 'LR Chi-square': lr, 'df': df, 'p-value': chi2_sf(lr, df)}

def fmt_p(p):
    if p < 0.001:
        return '<0.001'
    return f'{p:.3f}'

def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tc_pr.append(shd)

def set_cell_text(cell, text, bold=False):
    cell.text = ''
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(str(text))
    run.bold = bold
    run.font.size = Pt(8.5)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_table(doc, df, widths=None):
    table = doc.add_table(rows=1, cols=len(df.columns))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    for i, col in enumerate(df.columns):
        set_cell_text(table.rows[0].cells[i], col, bold=True)
        set_cell_shading(table.rows[0].cells[i], 'D9EAF7')
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for i, value in enumerate(row):
            if isinstance(value, float):
                if 'p-value' in df.columns[i] or df.columns[i] == 'p':
                    text = fmt_p(value)
                else:
                    text = f'{value:.3f}'
            else:
                text = str(value)
            set_cell_text(cells[i], text)
    if widths:
        for row in table.rows:
            for idx, width in enumerate(widths):
                row.cells[idx].width = Inches(width)
    for row in table.rows:
        tr_pr = row._tr.get_or_add_trPr()
        cant_split = OxmlElement('w:cantSplit')
        tr_pr.append(cant_split)
    doc.add_paragraph()

def add_heading(doc, text, level=1):
    doc.add_heading(text, level=level)

def add_formula(doc, formula):
    p = doc.add_paragraph()
    p.style = doc.styles['Intense Quote']
    run = p.add_run(formula)
    run.font.name = 'Courier New'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Courier New')
    run.font.size = Pt(9)

def build_analysis():
    df = pd.read_csv(DATA, low_memory=False)
    players = df[df['position'].isin(['top', 'jng', 'mid', 'bot', 'sup'])].copy()
    keys = ['gameid', 'side']
    team_gold15 = players.groupby(keys, dropna=False)['goldat15'].sum(min_count=5).rename('team_goldat15_calc')
    top = players[players['position'] == 'top'].merge(team_gold15, on=keys, how='left')
    top['top_gold_share15'] = top['goldat15'] / top['team_goldat15_calc']
    top['win'] = top['result'].astype(float)
    model = top.dropna(subset=['win', 'top_gold_share15', 'golddiffat15', 'side', 'patch', 'league', 'gamelength']).copy()
    model = model[np.isfinite(model['top_gold_share15']) & (model['top_gold_share15'] > 0)]
    q25 = model['top_gold_share15'].quantile(0.25)
    q50 = model['top_gold_share15'].quantile(0.5)
    q75 = model['top_gold_share15'].quantile(0.75)
    model['weak_side_q1'] = (model['top_gold_share15'] <= q25).astype(int)
    model['stable_weak_side'] = ((model['weak_side_q1'] == 1) & (model['golddiffat15'] >= -500)).astype(int)
    model['game_minutes'] = model['gamelength'] / 60
    model['top_gold_share15_pp'] = model['top_gold_share15'] * 100
    model['golddiffat15_500'] = model['golddiffat15'] / 500
    model['game_length_5min'] = model['game_minutes'] / 5
    model['patch_str'] = model['patch'].astype(str)
    summaries = {}
    summaries['quartiles'] = model.assign(TopGoldShareQuartile=pd.qcut(model['top_gold_share15'], 4, labels=['Q1 lowest', 'Q2', 'Q3', 'Q4 highest'])).groupby('TopGoldShareQuartile', observed=True).agg(N=('win', 'size'), WinRate=('win', 'mean'), AvgTopShare=('top_gold_share15', 'mean'), AvgTopGoldDiff15=('golddiffat15', 'mean')).reset_index()
    summaries['stable'] = model.groupby('stable_weak_side').agg(N=('win', 'size'), WinRate=('win', 'mean'), AvgTopShare=('top_gold_share15', 'mean'), AvgTopGoldDiff15=('golddiffat15', 'mean')).reset_index()
    specs = {'M1 Continuous Top Gold Share': (['top_gold_share15_pp', 'golddiffat15_500', 'game_length_5min'], ['side', 'league', 'patch_str']), 'M2 Weak-Side Indicator': (['weak_side_q1', 'golddiffat15_500', 'game_length_5min'], ['side', 'league', 'patch_str']), 'M3 Stable Weak-Side Top': (['stable_weak_side', 'game_length_5min'], ['side', 'league', 'patch_str'])}
    results = []
    fits = []
    for name, (cont, cat) in specs.items():
        res, met = fit_logit(model, 'win', cont, cat)
        focal = [c for c in cont if c != 'game_length_5min'] + ['game_length_5min']
        for term in focal:
            row = res[res['term'] == term].iloc[0]
            results.append({'Model': name, 'Variable': term, 'Coef': row['coef'], 'Odds Ratio': row['or'], '95% CI Low': row['or_ci_low'], '95% CI High': row['or_ci_high'], 'p': row['p']})
        fits.append({'Model': name, 'N': met['n'], 'Log Likelihood': met['log_likelihood'], 'Null LL': met['null_log_likelihood'], 'McFadden R2': met['mcfadden_pseudo_r2']})
    lr_rows = []
    lr_rows.append(lr_row(model, 'win', *specs['M1 Continuous Top Gold Share'], drop_cont=['top_gold_share15_pp'], label='M1'))
    lr_rows.append(lr_row(model, 'win', *specs['M1 Continuous Top Gold Share'], drop_cont=['golddiffat15_500'], label='M1'))
    lr_rows.append(lr_row(model, 'win', *specs['M1 Continuous Top Gold Share'], drop_cat=['side'], label='M1'))
    lr_rows.append(lr_row(model, 'win', *specs['M1 Continuous Top Gold Share'], drop_cat=['league'], label='M1'))
    lr_rows.append(lr_row(model, 'win', *specs['M1 Continuous Top Gold Share'], drop_cat=['patch_str'], label='M1'))
    lr_rows.append(lr_row(model, 'win', *specs['M2 Weak-Side Indicator'], drop_cont=['weak_side_q1'], label='M2'))
    lr_rows.append(lr_row(model, 'win', *specs['M2 Weak-Side Indicator'], drop_cont=['golddiffat15_500'], label='M2'))
    lr_rows.append(lr_row(model, 'win', *specs['M3 Stable Weak-Side Top'], drop_cont=['stable_weak_side'], label='M3'))
    return {'model': model, 'q25': q25, 'q50': q50, 'q75': q75, 'summaries': summaries, 'coef_table': pd.DataFrame(results), 'fit_table': pd.DataFrame(fits), 'lr_table': pd.DataFrame(lr_rows)}

def add_topic1_language(doc, a, ml, language):
    zh = language == 'zh'
    headings = {'research': '1. Research Question', 'data': '2. Data and Sample', 'variables': '3. Variables', 'models': '4. Regression Models', 'descriptive': '5. Descriptive Results', 'regression': '6. Regression Results', 'fit': '7. Model Fit and ANOVA-Style Tests', 'indicators': '8. Interpretation of Statistical Indicators', 'conclusion': '9. Preliminary Conclusion', 'ml': '10. Machine-Learning Robustness and Variable Importance', 'appendix': 'Appendix B. Full 15-Minute Feature Model'}
    add_heading(doc, headings['research'], 2)
    doc.add_paragraph('This study tests whether early-game resource allocation to top lane is associated with team win probability. Weak-side top is defined as a relatively low share of team gold at 15 minutes.')
    doc.add_paragraph('The central hypothesis is that weak-side top is beneficial only when the top laner remains stable and does not fall far behind the opposing top laner.')
    add_heading(doc, headings['data'], 2)
    doc.add_paragraph("The original Oracle's Elixir dataset contained 65,448 rows and 5,454 games. After removing all LPL games and related games involving LPL teams, the sample contains 5,000 games and 10,000 top-lane team-game observations.")
    add_heading(doc, headings['variables'], 2)
    variable_rows = pd.DataFrame([['result', 'Response variable', '1 = win, 0 = loss.'], ['goldat15', 'Input variable', 'Top-lane gold at 15 minutes.'], ['team_goldat15_calc', 'Derived variable', 'Team gold at 15, summed across all five roles.'], ['top_gold_share15', 'Main explanatory variable', 'Top gold at 15 divided by team gold at 15.'], ['top_gold_share15_pp', 'Scaled variable', 'Top gold share multiplied by 100, interpreted in percentage points.'], ['weak_side_q1', 'Indicator variable', f"1 when top gold share is in the bottom quartile; cutoff <= {a['q25']:.3f}."], ['stable_weak_side', 'Indicator variable', '1 when weak_side_q1 = 1 and top gold difference at 15 is at least -500.'], ['golddiffat15_500', 'Control variable', 'Top gold difference at 15 divided by 500.'], ['game_length_5min', 'Control variable', 'Game duration measured in five-minute units.'], ['side, league, patch_str', 'Controls', 'Controls for side, league, and patch.']], columns=['Variable', 'Role', 'Meaning'])
    add_table(doc, variable_rows, [1.35, 1.5, 4.8])
    add_heading(doc, headings['models'], 2)
    doc.add_paragraph('Because the outcome is binary, logistic regression is used to estimate win probability and odds ratios.')
    add_formula(doc, 'General: logit(P(Win_i = 1)) = ln(P_i / (1 - P_i))')
    add_formula(doc, 'M1: logit(P(Win_i=1)) = β0 + β1(top_gold_share15_pp_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i')
    add_formula(doc, 'M2: logit(P(Win_i=1)) = β0 + β1(weak_side_q1_i) + β2(golddiffat15_500_i) + β3(game_length_5min_i) + β4(side_i) + β5(league_i) + β6(patch_i) + ε_i')
    add_formula(doc, 'M3: logit(P(Win_i=1)) = β0 + β1(stable_weak_side_i) + β2(game_length_5min_i) + β3(side_i) + β4(league_i) + β5(patch_i) + ε_i')
    add_heading(doc, headings['descriptive'], 2)
    doc.add_paragraph('The lowest top-share quartile has a win rate of about 54.6%, while the stable weak-side group has a win rate of about 77.8%.')
    add_table(doc, a['summaries']['quartiles'], [1.55, 0.7, 0.9, 1.0, 1.25])
    add_table(doc, a['summaries']['stable'], [1.3, 0.8, 0.9, 1.0, 1.3])
    add_heading(doc, headings['regression'], 2)
    doc.add_paragraph('The table reports log-odds coefficients, odds ratios, 95% confidence intervals for odds ratios, and p-values.')
    add_table(doc, a['coef_table'], [1.45, 1.35, 0.65, 0.75, 0.75, 0.8, 0.55])
    add_heading(doc, headings['fit'], 2)
    doc.add_paragraph('McFadden pseudo R-squared is reported for logistic model fit, and likelihood-ratio chi-square tests compare full and reduced models.')
    add_table(doc, a['fit_table'], [1.8, 0.7, 1.1, 1.1, 1.0])
    add_table(doc, a['lr_table'], [0.7, 1.8, 1.0, 0.45, 0.65])
    add_heading(doc, headings['indicators'], 2)
    indicator_texts = ['The p-value measures how surprising the result would be if the true effect were zero; smaller values provide stronger evidence against the null.', 'A 95% confidence interval gives a plausible range for the odds ratio; intervals entirely above or below 1 indicate higher or lower win odds.', 'McFadden pseudo R-squared measures improvement in logistic-model fit relative to the null model.', 'Likelihood-ratio tests evaluate whether removing a variable or variable group significantly worsens model fit.']
    for text in indicator_texts:
        doc.add_paragraph(text)
    add_heading(doc, headings['conclusion'], 2)
    doc.add_paragraph('The preliminary conclusion is that weak-side top can be valuable only when the top laner remains stable. Low resource share alone is not the complete mechanism.')
    doc.add_paragraph('In simple terms: weak-side top works when the top laner receives fewer resources without collapsing.')
    add_heading(doc, headings['ml'], 2)
    doc.add_paragraph('The robustness analysis compares Logistic Regression, Random Forest, and XGBoost with five-fold cross-validation grouped by gameid, using only variables available by 15 minutes.')
    add_table(doc, ml['focused_metrics'][['model', 'cv_auc_mean', 'cv_auc_sd', 'heldout_auc']])
    doc.add_paragraph('Team gold difference at 15 dominates prediction; weak-side indicators add almost no held-out AUC once team state is known. Predictive importance is not a causal effect.')
    add_table(doc, ml['focused_importance'].head(9))
    for image_name in ['topic1_specific_features_permutation_importance.png', 'topic1_specific_features_model_auc.png']:
        image_path = ML_FIG_DIR / image_name
        if image_path.exists():
            doc.add_picture(str(image_path), width=Inches(6.4))
    add_heading(doc, headings['appendix'], 2)
    doc.add_paragraph("The full model adds all five roles' 10/15-minute gold differences, 15-minute experience differences, top CS difference, and team gold difference.")
    add_table(doc, ml['full_metrics'][['model', 'cv_auc_mean', 'cv_auc_sd', 'heldout_auc']])
    add_table(doc, ml['full_importance'].head(8))

def build_mirrored_docx(a):
    ml = load_ml_results()
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.75)
    sec.bottom_margin = Inches(0.75)
    sec.left_margin = Inches(0.75)
    sec.right_margin = Inches(0.75)
    styles = doc.styles
    styles['Normal'].font.name = 'Aptos'
    styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    styles['Normal'].font.size = Pt(10)
    for style_name in ['Heading 1', 'Heading 2', 'Heading 3']:
        styles[style_name].font.name = 'Aptos Display'
        styles[style_name]._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        styles[style_name].font.color.rgb = RGBColor(31, 78, 121)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('Topic 1 Research Report: Weak-Side Top Strategy')
    run.bold = True
    run.font.size = Pt(20)
    run.font.color.rgb = RGBColor(31, 78, 121)
    doc.add_paragraph('Research report').alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_heading(doc, 'English Report', 1)
    add_topic1_language(doc, a, ml, 'en')
    while doc.paragraphs and (not doc.paragraphs[-1].text.strip()):
        paragraph = doc.paragraphs[-1]
        paragraph._element.getparent().remove(paragraph._element)
    doc.save(OUT)
if __name__ == '__main__':
    analysis = build_analysis()
    build_mirrored_docx(analysis)
    print(OUT)
