from pathlib import Path

import pandas as pd

# Input file
topics_dir = Path(__file__).resolve().parents[2]
file_name = topics_dir / "data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv"

# Output folder
output_dir = topics_dir / "data/general_toplane_data"
output_dir.mkdir(parents=True, exist_ok=True)

# Load data
df = pd.read_csv(file_name, low_memory=False)

print("Full dataset shape:", df.shape)

print("\nAll leagues in dataset:")
print(df["league"].value_counts())

# Exclude China-related leagues
# LPL = main China league
# LDL = China development league, if included
china_leagues = ["LPL", "LDL"]

df_no_china = df[~df["league"].isin(china_leagues)].copy()

# Keep only top-lane rows
top_world_no_china = df_no_china[df_no_china["position"] == "top"].copy()

print("\nTop-lane rows outside China:", top_world_no_china.shape)
print("\nLeagues used after excluding China:")
print(top_world_no_china["league"].value_counts())

print("\nNumber of unique top champions outside China:")
print(top_world_no_china["champion"].nunique())

# Useful columns
wanted_cols = [
    "gameid", "date", "league", "split", "patch",
    "side", "position", "teamname", "opponent", "playername", "champion", "result",
    "gamelength",
    "kills", "deaths", "assists", "kda",
    "damagetochampions", "dpm", "damageshare",
    "damagetakenperminute", "damagemitigatedperminute",
    "wardsplaced", "wardskilled", "vspm", "wpm", "wcpm",
    "totalgold", "earnedgold", "earned gpm", "earnedgoldshare",
    "goldat10", "xpat10", "csat10",
    "golddiffat10", "xpdiffat10", "csdiffat10",
    "goldat15", "xpat15", "csat15",
    "golddiffat15", "xpdiffat15", "csdiffat15",
    "goldat20", "xpat20", "csat20",
    "golddiffat20", "xpdiffat20", "csdiffat20",
    "dragons", "opp_dragons",
    "heralds", "opp_heralds",
    "void_grubs", "opp_void_grubs",
    "towers", "opp_towers"
]

existing_cols = [c for c in wanted_cols if c in top_world_no_china.columns]
top_clean = top_world_no_china[existing_cols].copy()

# Summary for every top champion outside China
champion_summary = (
    top_clean
    .groupby("champion")
    .agg(
        games=("gameid", "count"),
        wins=("result", "sum"),
        winrate=("result", "mean"),
        avg_kills=("kills", "mean"),
        avg_deaths=("deaths", "mean"),
        avg_assists=("assists", "mean"),
        avg_dpm=("dpm", "mean"),
        avg_damage_share=("damageshare", "mean"),
        avg_damage_taken_per_min=("damagetakenperminute", "mean"),
        avg_damage_mitigated_per_min=("damagemitigatedperminute", "mean"),
        avg_earned_gold_share=("earnedgoldshare", "mean"),
        avg_gold_diff_10=("golddiffat10", "mean"),
        avg_xp_diff_10=("xpdiffat10", "mean"),
        avg_cs_diff_10=("csdiffat10", "mean"),
        avg_gold_diff_15=("golddiffat15", "mean"),
        avg_xp_diff_15=("xpdiffat15", "mean"),
        avg_cs_diff_15=("csdiffat15", "mean"),
        avg_gold_diff_20=("golddiffat20", "mean"),
        avg_xp_diff_20=("xpdiffat20", "mean"),
        avg_cs_diff_20=("csdiffat20", "mean")
    )
    .reset_index()
    .sort_values("games", ascending=False)
)

# Summary by champion and league, just in case you want to inspect regional differences later
champion_by_league = (
    top_clean
    .groupby(["champion", "league"])
    .agg(
        games=("gameid", "count"),
        wins=("result", "sum"),
        winrate=("result", "mean"),
        avg_gold_diff_15=("golddiffat15", "mean"),
        avg_xp_diff_15=("xpdiffat15", "mean"),
        avg_cs_diff_15=("csdiffat15", "mean"),
        avg_dpm=("dpm", "mean"),
        avg_damage_share=("damageshare", "mean"),
        avg_earned_gold_share=("earnedgoldshare", "mean")
    )
    .reset_index()
    .sort_values(["champion", "games"], ascending=[True, False])
)

# Save outputs
top_clean.to_csv(output_dir / "non_chinese_league_toplane_games.csv", index=False)
champion_summary.to_csv(output_dir / "non_chinese_league_toplane_champions.csv", index=False)
champion_by_league.to_csv(output_dir / "toplane_champions_by_league.csv", index=False)

print("\nTop 40 champions outside China:")
print(champion_summary.head(40))

print("\nDone. Saved:")
print(output_dir / "non_chinese_league_toplane_games.csv")
print(output_dir / "non_chinese_league_toplane_champions.csv")
print(output_dir / "toplane_champions_by_league.csv")
