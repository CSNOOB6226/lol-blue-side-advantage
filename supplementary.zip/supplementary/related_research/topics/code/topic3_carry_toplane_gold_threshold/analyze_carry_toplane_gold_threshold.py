from pathlib import Path
import math
import numpy as np
import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
TOPICS_DIR = Path(__file__).resolve().parents[2]
SRC = TOPICS_DIR / 'data/raw/2026_LoL_esports_match_data_from_OraclesElixir.csv'
DATA_DIR = TOPICS_DIR / 'data/topic3_carry_toplane_gold_threshold'
REPORT_DIR = TOPICS_DIR / 'reports/topic3_carry_toplane_gold_threshold'
DATASET_OUT = DATA_DIR / 'topic3_regression_data.csv'
COEF_OUT = DATA_DIR / 'topic3_logistic_coefficients.csv'
FIT_OUT = DATA_DIR / 'topic3_model_fit_metrics.csv'
LR_OUT = DATA_DIR / 'topic3_likelihood_ratio_tests.csv'
PRED_OUT = DATA_DIR / 'topic3_gold_threshold_predictions.csv'
MD_OUT = REPORT_DIR / 'topic3_carry_toplane_gold_threshold_report.md'
DOCX_OUT = REPORT_DIR / 'topic3_carry_toplane_gold_threshold_report.docx'
ML_FIG_DIR = REPORT_DIR / 'machine_learning_figures'

def load_ml_results():
    return {'focused_metrics': pd.read_csv(DATA_DIR / 'topic3_specific_features_model_metrics.csv'), 'focused_importance': pd.read_csv(DATA_DIR / 'topic3_specific_features_permutation_importance.csv'), 'full_metrics': pd.read_csv(DATA_DIR / 'topic3_full_15min_features_model_metrics.csv'), 'full_importance': pd.read_csv(DATA_DIR / 'topic3_full_15min_features_permutation_importance.csv')}
TANK_CHAMPIONS = {"K'Sante", 'Sion', 'Gnar', 'Ornn', 'Gragas', 'Shen', 'Malphite', 'Galio', 'Poppy', 'Volibear', 'Dr. Mundo', "Cho'Gath"}
MODEL_CONTINUOUS_FEATURES = ['is_carry', 'top_gold_diff15_500', 'carry_x_top_gold_diff15_500', 'non_top_gold_diff15_500', 'non_top_kill_diff15']

def sigmoid(z):
    z = np.clip(z, -35, 35)
    return 1 / (1 + np.exp(-z))

def normal_p(z):
    return math.erfc(abs(z) / math.sqrt(2))

def chi2_sf(x, df):
    if x <= 0:
        return 1.0
    if df == 1:
        return math.erfc(math.sqrt(x / 2))
    if df % 2 == 0:
        half = x / 2
        total = 0.0
        term = 1.0
        for j in range(df // 2):
            if j > 0:
                term *= half / j
            total += term
        return min(1.0, max(0.0, math.exp(-half) * total))
    z = ((x / df) ** (1 / 3) - (1 - 2 / (9 * df))) / math.sqrt(2 / (9 * df))
    return 0.5 * math.erfc(z / math.sqrt(2))

def markdown_table(df, floatfmt='.3f'):
    out = df.reset_index() if df.index.name else df.reset_index(drop=True)
    rows = ['| ' + ' | '.join(map(str, out.columns)) + ' |']
    rows.append('| ' + ' | '.join(('---' for _ in out.columns)) + ' |')
    for _, row in out.iterrows():
        vals = []
        for value in row:
            if isinstance(value, (float, np.floating)):
                vals.append(format(float(value), floatfmt))
            elif isinstance(value, (int, np.integer)):
                vals.append(str(int(value)))
            else:
                vals.append(str(value))
        rows.append('| ' + ' | '.join(vals) + ' |')
    return '\n'.join(rows)

def fit_logit(data, ycol, cont_cols, cat_cols=None, ridge=1e-06, max_iter=100):
    cat_cols = cat_cols or []
    parts = [pd.Series(1.0, index=data.index, name='Intercept')]
    for col in cont_cols:
        parts.append(data[col].astype(float).rename(col))
    for col in cat_cols:
        parts.append(pd.get_dummies(data[col].astype(str), prefix=col, drop_first=True, dtype=float))
    x = pd.concat(parts, axis=1)
    y = data[ycol].astype(float).to_numpy()
    xn = x.to_numpy(float)
    beta = np.zeros(xn.shape[1])
    for _ in range(max_iter):
        pred = sigmoid(xn @ beta)
        w = np.clip(pred * (1 - pred), 1e-06, None)
        z = xn @ beta + (y - pred) / w
        xtw = xn.T * w
        h = xtw @ xn + ridge * np.eye(xn.shape[1])
        nb = np.linalg.solve(h, xtw @ z)
        if np.max(np.abs(nb - beta)) < 1e-07:
            beta = nb
            break
        beta = nb
    pred = sigmoid(xn @ beta)
    w = np.clip(pred * (1 - pred), 1e-06, None)
    h = xn.T * w @ xn + ridge * np.eye(xn.shape[1])
    cov = np.linalg.inv(h)
    se = np.sqrt(np.diag(cov))
    zstat = beta / se
    p = np.array([normal_p(v) for v in zstat])
    ll = float(np.sum(y * np.log(np.clip(pred, 1e-12, 1)) + (1 - y) * np.log(np.clip(1 - pred, 1e-12, 1))))
    ybar = np.clip(y.mean(), 1e-12, 1 - 1e-12)
    ll_null = float(np.sum(y * np.log(ybar) + (1 - y) * np.log(1 - ybar)))
    res = pd.DataFrame({'variable': x.columns, 'coef_log_odds': beta, 'std_error': se, 'z_stat': zstat, 'p_value': p, 'odds_ratio': np.exp(beta), 'or_ci_low': np.exp(beta - 1.96 * se), 'or_ci_high': np.exp(beta + 1.96 * se)})
    metrics = {'N': int(len(y)), 'df_model': int(x.shape[1] - 1), 'log_likelihood': ll, 'null_log_likelihood': ll_null, 'mcfadden_pseudo_r2': 1 - ll / ll_null}
    return (res, x, metrics)

def lr_test(data, full_cont, full_cat, drop_cont=(), drop_cat=(), label=''):
    _, _, full = fit_logit(data, 'result', full_cont, full_cat)
    red_cont = [c for c in full_cont if c not in set(drop_cont)]
    red_cat = [c for c in full_cat if c not in set(drop_cat)]
    _, _, reduced = fit_logit(data, 'result', red_cont, red_cat)
    lr = 2 * (full['log_likelihood'] - reduced['log_likelihood'])
    df = full['df_model'] - reduced['df_model']
    return {'test': label, 'dropped': ', '.join(list(drop_cont) + list(drop_cat)), 'lr_chi_square': lr, 'df': df, 'p_value': chi2_sf(lr, df)}

def fmt_p(p):
    if p < 0.001:
        return '<0.001'
    return f'{p:.3f}'

def prepare_dataset():
    df = pd.read_csv(SRC, low_memory=False)
    team_rows_all = df[df['position'] == 'team'].copy()
    lpl_teams = set(team_rows_all.loc[team_rows_all['league'].eq('LPL'), 'teamname'].dropna())
    lpl_related_games = set(df.loc[df['league'].eq('LPL'), 'gameid'].dropna())
    lpl_related_games |= set(team_rows_all.loc[team_rows_all['teamname'].isin(lpl_teams), 'gameid'].dropna())
    df = df[~df['gameid'].isin(lpl_related_games)].copy()
    top = df[df['position'] == 'top'].copy()
    champion_counts = top['champion'].value_counts()
    study_champions = set(champion_counts[champion_counts >= 21].index)
    top = top[top['champion'].isin(study_champions)].copy()
    top['champion_class'] = np.where(top['champion'].isin(TANK_CHAMPIONS), 'tank', 'carry_warrior')
    top['is_carry'] = (top['champion_class'] == 'carry_warrior').astype(int)
    team_cols = ['gameid', 'side', 'goldat15', 'golddiffat15', 'killsat15', 'opp_killsat15']
    team = df[df['position'] == 'team'][team_cols].copy()
    team = team.rename(columns={'goldat15': 'team_goldat15', 'golddiffat15': 'team_gold_diff15', 'killsat15': 'team_killsat15', 'opp_killsat15': 'opp_team_killsat15'})
    data = top.merge(team, on=['gameid', 'side'], how='left')
    data['top_gold_diff15_500'] = data['golddiffat15'] / 500
    data['non_top_gold_diff15_500'] = (data['team_gold_diff15'] - data['golddiffat15']) / 500
    data['top_kill_diff15'] = data['killsat15'] - data['opp_killsat15']
    data['team_kill_diff15'] = data['team_killsat15'] - data['opp_team_killsat15']
    data['non_top_kill_diff15'] = data['team_kill_diff15'] - data['top_kill_diff15']
    data['patch_str'] = data['patch'].astype(str)
    data['carry_x_top_gold_diff15_500'] = data['is_carry'] * data['top_gold_diff15_500']
    keep = ['gameid', 'date', 'league', 'split', 'patch_str', 'side', 'teamname', 'playername', 'champion', 'champion_class', 'is_carry', 'result', 'gamelength', 'goldat15', 'golddiffat15', 'top_gold_diff15_500', 'carry_x_top_gold_diff15_500', 'team_gold_diff15', 'non_top_gold_diff15_500', 'team_kill_diff15', 'non_top_kill_diff15']
    model = data[keep].dropna(subset=['result', 'is_carry', 'top_gold_diff15_500', 'carry_x_top_gold_diff15_500', 'non_top_gold_diff15_500', 'non_top_kill_diff15', 'side', 'league', 'patch_str']).copy()
    return (df, model, champion_counts)

def average_prediction(data, coef, xcols, carry, gold500):
    pred_df = data.copy()
    pred_df['is_carry'] = carry
    pred_df['top_gold_diff15_500'] = gold500
    pred_df['carry_x_top_gold_diff15_500'] = carry * gold500
    parts = [pd.Series(1.0, index=pred_df.index, name='Intercept')]
    for col in MODEL_CONTINUOUS_FEATURES:
        parts.append(pred_df[col].astype(float).rename(col))
    for col in ['side', 'league', 'patch_str']:
        d = pd.get_dummies(pred_df[col].astype(str), prefix=col, drop_first=True, dtype=float)
        parts.append(d)
    x = pd.concat(parts, axis=1)
    aligned = x.reindex(columns=xcols, fill_value=0.0)
    beta = coef.set_index('variable').loc[xcols, 'coef_log_odds'].to_numpy()
    return float(sigmoid(aligned.to_numpy(float) @ beta).mean())

def style_doc(doc):
    sec = doc.sections[0]
    sec.top_margin = Inches(0.7)
    sec.bottom_margin = Inches(0.7)
    sec.left_margin = Inches(0.7)
    sec.right_margin = Inches(0.7)
    styles = doc.styles
    styles['Normal'].font.name = 'Aptos'
    styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    styles['Normal'].font.size = Pt(9.5)
    for name in ['Heading 1', 'Heading 2', 'Heading 3']:
        styles[name].font.name = 'Aptos Display'
        styles[name]._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        styles[name].font.color.rgb = RGBColor(31, 78, 121)

def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tc_pr.append(shd)

def cell_text(cell, text, bold=False):
    cell.text = ''
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(str(text))
    r.bold = bold
    r.font.size = Pt(8)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_table(doc, df, max_rows=None):
    if max_rows:
        df = df.head(max_rows)
    table = doc.add_table(rows=1, cols=len(df.columns))
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, col in enumerate(df.columns):
        cell_text(table.rows[0].cells[i], col, True)
        shade(table.rows[0].cells[i], 'D9EAF7')
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for i, value in enumerate(row):
            col = df.columns[i]
            if isinstance(value, (float, np.floating)):
                if col.lower() in {'p', 'p_value', 'p-value'}:
                    text = fmt_p(float(value))
                else:
                    text = f'{float(value):.3f}'
            elif isinstance(value, (int, np.integer)):
                text = str(int(value))
            else:
                text = str(value)
            cell_text(cells[i], text)
    for row in table.rows:
        tr_pr = row._tr.get_or_add_trPr()
        cant_split = OxmlElement('w:cantSplit')
        tr_pr.append(cant_split)
    doc.add_paragraph()

def add_formula(doc, formula):
    p = doc.add_paragraph()
    p.style = doc.styles['Intense Quote']
    r = p.add_run(formula)
    r.font.name = 'Courier New'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Courier New')
    r.font.size = Pt(8.5)

def build_reports(model, coef_focus, coef_full, fit, lr_table, pred_table, desc, threshold):
    ml = load_ml_results()
    eq = 'logit(P(Win_i = 1)) = beta0 + beta1(is_carry_i) + beta2(top_gold_diff15_500_i) + beta3(is_carry_i * top_gold_diff15_500_i) + beta4(non_top_gold_diff15_500_i) + beta5(non_top_kill_diff15_i) + beta6(side_i) + beta7(league_i) + beta8(patch_i) + error_i'
    threshold_sentence = f'The model reaches the 10 percentage-point dominance rule at about +{threshold:.0f} top-lane gold at 15 minutes.' if threshold is not None else 'The model does not find a point in the tested range where carry top exceeds tank top by at least 10 percentage points.'
    core_vars = ['is_carry', 'top_gold_diff15_500', 'carry_x_top_gold_diff15_500']
    team_control_vars = ['non_top_gold_diff15_500', 'non_top_kill_diff15']
    core_table = coef_focus[coef_focus['variable'].isin(core_vars)].copy()
    controls_table = coef_focus[coef_focus['variable'].isin(team_control_vars)].copy()
    appendix_table = coef_full.copy()
    appendix_table['p_value'] = appendix_table['p_value'].map(lambda v: '<0.001' if v < 0.001 else f'{v:.3f}')
    appendix_table = appendix_table[['variable', 'coef_log_odds', 'std_error', 'z_stat', 'p_value', 'odds_ratio', 'or_ci_low', 'or_ci_high']]
    md = ['# Topic 3: Carry Top Gold Threshold\n\n', '## English Report\n\n', '### Research Question\n\n', "After controlling for teammates' 15-minute gold and kill advantage, how much 15-minute top-lane gold advantage does a carry/warrior-carry top laner need before clearly outperforming a tank top laner in win probability?\n\n", '### Dataset\n\n', f"The analysis uses the 2026 Oracle's Elixir match dataset. LPL and LPL-related games were removed. The final model sample contains {len(model):,} top-lane team-game observations and {model['champion'].nunique()} champions with at least 21 top-lane appearances before complete-case filtering.\n\n", '### Model Equation\n\n', f'`{eq}`\n\n', '### Key Regression Results\n\n', 'Core carry-threshold variables:\n\n', markdown_table(core_table, '.4f'), '\n\nTeammate 15-minute controls:\n\n', markdown_table(controls_table, '.4f'), '\n\n### Model Fit\n\n', markdown_table(pd.DataFrame([fit]), '.4f'), '\n\n### ANOVA-Style Likelihood-Ratio Table\n\n', markdown_table(lr_table, '.4f'), '\n\n### Threshold Predictions\n\n', markdown_table(pred_table, '.3f'), '\n\n### Preliminary Conclusion\n\n', f'{threshold_sentence} The interaction term is the key test: it asks whether top-lane gold advantage changes win probability differently for carry tops than for tank tops, after controlling for 15-minute non-top teammate gold and kill advantage, side, league, and patch.\n\n', '### Machine-Learning Robustness and Variable Importance\n\n', 'Logistic Regression, Random Forest, and XGBoost were compared using five-fold cross-validation grouped by `gameid`. Only variables available by 15 minutes were used in these predictive models; final game length and end-of-game totals were excluded. Logistic regression remains the inferential model, while permutation importance and SHAP are used only to assess predictive contribution.\n\n', markdown_table(ml['focused_metrics'][['model', 'cv_auc_mean', 'cv_auc_sd', 'heldout_auc']], '.4f'), '\n\nFocused-model XGBoost permutation importance:\n\n', markdown_table(ml['focused_importance'].head(8), '.4f'), '\n\nThe 15-minute non-top teammate gold difference dominates the predictions. `is_carry` and `is_carry × top gold difference` have approximately zero permutation importance, reinforcing the regression result that carry identity does not create a meaningful gold-conversion premium.\n\n', '### Full 15-Minute Feature Appendix\n\n', markdown_table(ml['full_metrics'][['model', 'cv_auc_mean', 'cv_auc_sd', 'heldout_auc']], '.4f'), '\n\n', markdown_table(ml['full_importance'].head(15), '.4f'), '\n\nPredictive importance is not a causal effect and does not have the same interpretation as a coefficient, confidence interval, or p-value.\n\n']
    MD_OUT.write_text(''.join(md))
    build_mirrored_topic3_docx(model, core_table, controls_table, appendix_table, fit, lr_table, pred_table, threshold_sentence, eq, ml)

def add_topic3_language(doc, language, model, core_table, controls_table, appendix_table, fit, lr_table, pred_table, threshold_text, eq, ml):
    zh = language == 'zh'
    headings = {'research': '1. Research Question', 'data': '2. Dataset and Sample', 'variables': '3. Variables', 'why': '4. Why Logistic Regression Is Appropriate', 'equation': '5. Regression Equation', 'results': '6. Regression Results', 'core': '6.1 Core Carry-Threshold Variables', 'controls': '6.2 Teammate 15-Minute Controls', 'indicators': '7. Statistical Indicators', 'predictions': '8. Threshold Predictions', 'conclusion': '9. Practical Significance and Preliminary Conclusion', 'limits': '10. Limitations and Future Work', 'appendix_a': 'Appendix A. Full Coefficient Table', 'ml': '11. Machine-Learning Robustness and Variable Importance', 'appendix_b': 'Appendix B. Full 15-Minute Feature Model'}
    doc.add_heading(headings['research'], 2)
    doc.add_paragraph("After controlling for teammates' 15-minute gold and kill advantage, how much 15-minute top-lane gold advantage does a carry/warrior-carry top need before clearly outperforming a tank top in predicted win probability?")
    doc.add_heading(headings['data'], 2)
    doc.add_paragraph(f"The report uses the 2026 Oracle's Elixir dataset after removing LPL and LPL-related games. The model contains {len(model):,} top-lane team-game observations and retains champions with at least 21 top-lane appearances.")
    doc.add_heading(headings['variables'], 2)
    variables = pd.DataFrame([['result', 'Dependent', '1 = win, 0 = loss.'], ['is_carry', 'Main independent', '1 = carry/warrior-carry top, 0 = tank top.'], ['top_gold_diff15_500', 'Main independent', 'Top gold difference at 15 minutes, per 500 gold.'], ['is_carry × top_gold_diff15_500', 'Interaction', 'Tests whether carries convert top gold leads into win probability differently.'], ['non_top_gold_diff15_500', 'Control', 'Team gold difference at 15 excluding top, per 500 gold.'], ['non_top_kill_diff15', 'Control', 'Team kill difference at 15 excluding top.'], ['side / league / patch_str', 'Controls', 'Controls for side, league, and patch.']], columns=['Variable', 'Type', 'Meaning'])
    add_table(doc, variables)
    doc.add_heading(headings['why'], 2)
    doc.add_paragraph('Because result is binary, logistic regression is appropriate for estimating win probability and odds ratios.')
    doc.add_heading(headings['equation'], 2)
    add_formula(doc, eq)
    doc.add_heading(headings['results'], 2)
    doc.add_paragraph('The main results separate the carry-threshold variables from teammate 15-minute controls in two identically formatted tables.')
    doc.add_heading(headings['core'], 3)
    add_table(doc, core_table)
    doc.add_heading(headings['controls'], 3)
    add_table(doc, controls_table)
    doc.add_heading(headings['indicators'], 2)
    doc.add_paragraph('Coefficients are effects on log-odds, standard errors measure uncertainty, z statistics divide coefficients by standard errors, p-values test zero effects, and confidence intervals give plausible odds-ratio ranges. Logistic regression uses McFadden pseudo R-squared and likelihood-ratio tests rather than ordinary R-squared and F statistics.')
    add_table(doc, pd.DataFrame([fit]))
    add_table(doc, lr_table)
    doc.add_heading(headings['predictions'], 2)
    add_table(doc, pred_table)
    doc.add_heading(headings['conclusion'], 2)
    doc.add_paragraph(threshold_text)
    doc.add_paragraph("In gameplay terms, the study estimates how much gold advantage a carry top needs to become clearly preferable to a tank after controlling for teammates' 15-minute gold and kill advantage, rather than merely comparing average win rates.")
    doc.add_heading(headings['limits'], 2)
    doc.add_paragraph('The study is observational and supports association rather than causation. Future work can add champion and team fixed effects, patch-specific models, and alternative dominance thresholds.')
    doc.add_heading(headings['appendix_a'], 2)
    doc.add_paragraph('This appendix reports every logistic-regression coefficient, including side, league, and patch dummy controls.')
    add_table(doc, appendix_table)
    doc.add_heading(headings['ml'], 2)
    doc.add_paragraph('The predictive robustness analysis compares Logistic Regression, Random Forest, and XGBoost with five-fold cross-validation grouped by gameid, using only variables available by 15 minutes.')
    add_table(doc, ml['focused_metrics'][['model', 'cv_auc_mean', 'cv_auc_sd', 'heldout_auc']])
    doc.add_paragraph('The 15-minute non-top teammate gold difference dominates prediction; carry identity and its interaction with top gold difference add almost no importance. Predictive importance is not a causal effect.')
    add_table(doc, ml['focused_importance'].head(8))
    for image_name in ['topic3_specific_features_permutation_importance.png', 'topic3_specific_features_model_auc.png']:
        image_path = ML_FIG_DIR / image_name
        if image_path.exists():
            doc.add_picture(str(image_path), width=Inches(6.2))
    doc.add_heading(headings['appendix_b'], 2)
    doc.add_paragraph('The full model adds 10/15-minute gold, 15-minute experience, and top-lane CS variables across roles; the tables show model performance and the top five permutation importances.')
    add_table(doc, ml['full_metrics'][['model', 'cv_auc_mean', 'cv_auc_sd', 'heldout_auc']])
    add_table(doc, ml['full_importance'].head(5))

def build_mirrored_topic3_docx(model, core_table, controls_table, appendix_table, fit, lr_table, pred_table, threshold_sentence, eq, ml):
    doc = Document()
    style_doc(doc)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('Topic 3: Carry Top Gold Threshold')
    run.bold = True
    run.font.size = Pt(18)
    run.font.color.rgb = RGBColor(31, 78, 121)
    doc.add_paragraph('Research report').alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_heading('Research Report', 1)
    add_topic3_language(doc, 'en', model, core_table, controls_table, appendix_table, fit, lr_table, pred_table, threshold_sentence, eq, ml)
    while doc.paragraphs and (not doc.paragraphs[-1].text.strip()):
        paragraph = doc.paragraphs[-1]
        paragraph._element.getparent().remove(paragraph._element)
    doc.save(DOCX_OUT)

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    _, model, champion_counts = prepare_dataset()
    model.to_csv(DATASET_OUT, index=False)
    desc = model.groupby('champion_class').agg(N=('result', 'size'), win_rate=('result', 'mean'), avg_top_gold_diff15=('golddiffat15', 'mean'), avg_non_top_gold_diff15_500=('non_top_gold_diff15_500', 'mean')).reset_index()
    cont = MODEL_CONTINUOUS_FEATURES
    cats = ['side', 'league', 'patch_str']
    coef, x, fit = fit_logit(model, 'result', cont, cats)
    focus_vars = cont
    coef_focus = coef[coef['variable'].isin(focus_vars)].copy()
    coef_focus['p_value'] = coef_focus['p_value'].map(lambda v: '<0.001' if v < 0.001 else f'{v:.3f}')
    coef_focus = coef_focus[['variable', 'coef_log_odds', 'std_error', 'z_stat', 'p_value', 'odds_ratio', 'or_ci_low', 'or_ci_high']]
    coef.to_csv(COEF_OUT, index=False)
    pd.DataFrame([fit]).to_csv(FIT_OUT, index=False)
    lr_table = pd.DataFrame([lr_test(model, cont, cats, drop_cont=['is_carry', 'carry_x_top_gold_diff15_500'], label='Carry class terms'), lr_test(model, cont, cats, drop_cont=['top_gold_diff15_500', 'carry_x_top_gold_diff15_500'], label='Top gold advantage terms'), lr_test(model, cont, cats, drop_cont=['non_top_gold_diff15_500'], label='Non-top teammate gold advantage'), lr_test(model, cont, cats, drop_cont=['non_top_kill_diff15'], label='Non-top teammate kill advantage'), lr_test(model, cont, cats, drop_cat=['league'], label='League controls'), lr_test(model, cont, cats, drop_cat=['patch_str'], label='Patch controls')])
    lr_table.to_csv(LR_OUT, index=False)
    grid = np.arange(-2000, 3001, 250)
    pred_rows = []
    for gold in grid:
        gold500 = gold / 500
        tank_p = average_prediction(model, coef, list(x.columns), 0, gold500)
        carry_p = average_prediction(model, coef, list(x.columns), 1, gold500)
        pred_rows.append({'top_gold_diff15': gold, 'tank_pred_win_prob': tank_p, 'carry_pred_win_prob': carry_p, 'carry_minus_tank': carry_p - tank_p})
    pred_table = pd.DataFrame(pred_rows)
    pred_table.to_csv(PRED_OUT, index=False)
    over = pred_table[pred_table['carry_minus_tank'] >= 0.1]
    threshold = None if over.empty else float(over.iloc[0]['top_gold_diff15'])
    build_reports(model, coef_focus, coef, fit, lr_table, pred_table, desc, threshold)
    print('dataset', DATASET_OUT)
    print('coefficients', COEF_OUT)
    print('fit', FIT_OUT)
    print('lr', LR_OUT)
    print('predictions', PRED_OUT)
    print('markdown', MD_OUT)
    print('docx', DOCX_OUT)
    print('threshold', threshold)
    print('sample rows', len(model), 'champions', model['champion'].nunique())
    print(desc.to_string(index=False))
    print(coef_focus.to_string(index=False))
    print(pred_table.head().to_string(index=False))
    print(pred_table.tail().to_string(index=False))
if __name__ == '__main__':
    main()
