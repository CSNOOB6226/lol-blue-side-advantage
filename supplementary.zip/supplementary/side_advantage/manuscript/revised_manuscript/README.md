# Revised manuscript and build sources

| File | Contents |
|---|---|
| `manuscript_en_math_revised.md` | Mathematical-model manuscript with variable coding, model equations, and predictive comparisons. |
| `manuscript_en_rewrite.md` | Narrative manuscript with role-level selection timing, TOST, and FDR analyses. |
| `build_manuscript_docx.py` | Convert the Markdown manuscript to a Word document. |
| `build_paper_assets.py` | Build the gold-to-win conversion figure. |
| `build_path_figure.py` | Build the association-path decomposition figure. |
| `figures/fig_gold_conversion_en.png` | Gold-to-win conversion figure in English. |
| `figures/fig_path_decomposition_en.png` | Path decomposition figure in English. |
