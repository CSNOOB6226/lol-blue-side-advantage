"""
01_phenomenon.py — Does the blue-side advantage exist, replicate, and survive team-strength controls?

Outputs:
  - console summary
  - outputs/01_blue_by_season.csv, outputs/01_blue_by_league.csv
  - figures/01_blue_winrate_by_season.png
Key identification: team-season fixed effects (a team vs itself on blue vs red) removes team strength.
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
from statsmodels.stats.proportion import proportion_confint
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False

HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'), low_memory=False)
OUT=os.path.join(ROOT,'outputs'); FIG=os.path.join(ROOT,'figures')
blue=P[P.blue==1]

def logit_or(df, formula='win~blue'):
    m=smf.logit(formula, df).fit(disp=0, cov_type='cluster', cov_kwds={'groups':df.gameid})
    bse=m.bse['blue']; be=m.params['blue']
    return np.exp(be), np.exp(be-1.96*bse), np.exp(be+1.96*bse), m.pvalues['blue']

print('================ 1. THE PHENOMENON: does blue win more? ================')
n=len(blue); w=blue.win.sum(); wr=w/n
lo,hi=proportion_confint(int(w), n, method='wilson')
print(f'Overall blue win rate = {wr:.4f}  (95% CI {lo:.4f}-{hi:.4f}, n={n} team-games)')
o,olo,ohi,p=logit_or(P)
print(f'Pooled logistic blue OR = {o:.3f} (95% CI {olo:.3f}-{ohi:.3f}, p={p:.2g})')

print('\n--- by season (replication) ---')
rows=[]
for y,g in P.groupby('year'):
    b=g[g.blue==1]; wr_y=b.win.mean(); lo_y,hi_y=proportion_confint(int(b.win.sum()),len(b),method='wilson')
    o_y,olo_y,ohi_y,p_y=logit_or(g)
    rows.append(dict(year=y,n_games=g.gameid.nunique(),blue_wr=round(wr_y,4),ci_lo=round(lo_y,4),ci_hi=round(hi_y,4),
                     OR=round(o_y,3),OR_lo=round(olo_y,3),OR_hi=round(ohi_y,3),p=round(p_y,4)))
season=pd.DataFrame(rows); print(season.to_string(index=False)); season.to_csv(os.path.join(OUT,'01_blue_by_season.csv'),index=False)

print('\n--- by major league (>=600 team-games) ---')
rows=[]
for lg,g in P.groupby('league'):
    b=g[g.blue==1]
    if len(b)<600: continue
    lo_l,hi_l=proportion_confint(int(b.win.sum()),len(b),method='wilson')
    rows.append(dict(league=lg,n_games=g.gameid.nunique(),blue_wr=round(b.win.mean(),4),ci_lo=round(lo_l,4),ci_hi=round(hi_l,4)))
league=pd.DataFrame(rows).sort_values('blue_wr'); print(league.to_string(index=False)); league.to_csv(os.path.join(OUT,'01_blue_by_league.csv'),index=False)

print('\n================ 2. IDENTIFICATION: is it team strength? ================')
P['team_season']=P.teamname.astype(str)+'_'+P.year.astype(str)
P['opp_team_season']=P.opp_teamname.astype(str)+'_'+P.year.astype(str)
# Absorb high-dimensional FE via within-transformation (demeaning) -> fast & exact for the blue slope.
def absorb(df, cols, groups, n_iter=10):
    out=df[cols+['gameid']].copy()
    for _ in range(n_iter):
        for grp in groups:
            gm=df[grp]  # group labels aligned to out's rows
            for c in cols:
                out[c]=out[c]-out.groupby(gm)[c].transform('mean')
    return out
def within_blue(groups):
    w=absorb(P, ['win','blue'], groups)
    m=smf.ols('win~blue', w).fit(cov_type='cluster', cov_kwds={'groups':w.gameid})
    return m.params['blue'], m.pvalues['blue']
m_raw=smf.ols('win~blue',P).fit(cov_type='cluster',cov_kwds={'groups':P.gameid})
b_te,p_te=within_blue(['team_season'])                       # own-strength absorbed
b_te2,p_te2=within_blue(['team_season','opp_team_season'])   # own + opponent strength absorbed
print(f'blue effect (pp of win prob):')
print(f'  raw LPM                         : {m_raw.params.blue*100:+.2f} pp (p={m_raw.pvalues.blue:.2g})')
print(f'  + team-season FE (own strength) : {b_te*100:+.2f} pp (p={p_te:.2g})')
print(f'  + team & opponent-season FE     : {b_te2*100:+.2f} pp (p={p_te2:.2g})')
print('  -> if the blue effect is ~unchanged under team FE, it is NOT a team-strength artifact.')

# ---- figure: blue win rate by season with 95% CI ----
fig,ax=plt.subplots(figsize=(7.2,4.4))
ax.axhline(0.5,color='gray',ls='--',lw=1)
ax.errorbar(season.year, season.blue_wr*100, yerr=[(season.blue_wr-season.ci_lo)*100,(season.ci_hi-season.blue_wr)*100],
            fmt='o-',color='#2c6fbb',capsize=4,lw=2,markersize=7)
for _,r in season.iterrows(): ax.annotate(f'{r.blue_wr*100:.1f}%',(r.year,r.blue_wr*100),textcoords='offset points',xytext=(0,9),ha='center',fontsize=9)
ax.set_xticks(season.year); ax.set_ylabel('Blue-side win rate (%)'); ax.set_xlabel('Season')
ax.set_title('Blue-side advantage across 5 seasons (non-China professional LoL)',fontsize=11)
ax.set_ylim(48,56)
plt.tight_layout(); plt.savefig(os.path.join(FIG,'01_blue_winrate_by_season.png'),dpi=150)
print('\nsaved figures/01_blue_winrate_by_season.png')
