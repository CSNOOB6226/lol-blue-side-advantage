"""
03_structural_models.py — What structural advantages does SIDE cause?

Side is assigned by rule/coin (exogenous-ish within a team), so `Y ~ blue` estimates the
causal effect of being blue on each early structural outcome. Team-season FE confirms it is
structural (not team strength). This establishes the FIRST leg of the causal chain: side -> objectives/gold.

Outcomes: first herald/dragon/tower (binary), void grubs (count, 2024-26), early gold/xp/cs diffs,
team vision/control wards (the placebo: should be ~0).
Outputs: console + outputs/03_side_effects.csv + figures/03_side_causes.png
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False

HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'), low_memory=False)
P['team_season']=P.teamname.astype(str)+'_'+P.year.astype(str)
OUT=os.path.join(ROOT,'outputs'); FIG=os.path.join(ROOT,'figures')

# outcome, label, type, subset(years)
OUTCOMES=[('firstherald','First Herald','binary',None),
          ('firstdragon','First Dragon','binary',None),
          ('firsttower','First Tower','binary',None),
          ('firstblood','First Blood','binary',None),
          ('firstbaron','First Baron (late, caveat)','binary',None),
          ('void_grubs','Void Grubs (#)','cont',[2024,2025,2026]),
          ('golddiffat10','GoldDiff@10','cont',None),
          ('golddiffat15','GoldDiff@15','cont',None),
          ('xpdiffat15','XPDiff@15','cont',None),
          ('csdiffat15','CSDiff@15','cont',None),
          ('team_vision','Team Vision (PLACEBO)','cont',None),
          ('team_cwards','Control Wards (PLACEBO)','cont',None)]

def absorb(df, cols, groups, n_iter=10):
    out=df[cols+['gameid']].copy()
    for _ in range(n_iter):
        for grp in groups:
            g=df[grp]
            for c in cols:
                out[c]=out[c]-out.groupby(g)[c].transform('mean')
    return out
def fit(df, y, fe=False):
    if not fe:
        m=smf.ols(f'{y}~blue+C(year)', df).fit(cov_type='cluster',cov_kwds={'groups':df.gameid})
    else:
        # absorb year + team-season FE via demeaning (fast, exact for blue slope)
        w=absorb(df, [y,'blue'], ['team_season','year'])
        m=smf.ols(f'{y}~blue', w).fit(cov_type='cluster',cov_kwds={'groups':w.gameid})
    return m.params['blue'], m.bse['blue'], m.pvalues['blue'], int(m.nobs)

rows=[]
for y,lab,typ,yrs in OUTCOMES:
    if y not in P.columns: print('skip (missing):',y); continue
    d=P.dropna(subset=[y]).copy()
    if yrs: d=d[d.year.isin(yrs)]
    b_raw,se_raw,p_raw,n=fit(d,y,fe=False)
    b_fe,se_fe,p_fe,_=fit(d,y,fe=True)
    unit='pp' if typ=='binary' else 'native'
    scale=100 if typ=='binary' else 1   # binary LPM coef -> pp
    rows.append(dict(outcome=y,label=lab,type=typ,n=n,
                     blue_raw=round(b_raw*scale,3),p_raw=round(p_raw,4),
                     blue_teamFE=round(b_fe*scale,3),p_teamFE=round(p_fe,4),unit=unit))
res=pd.DataFrame(rows)
pd.set_option('display.width',200)
print('SIDE -> STRUCTURAL OUTCOMES (blue effect; team FE = strength-adjusted)')
print(res.to_string(index=False))
res.to_csv(os.path.join(OUT,'03_side_effects.csv'),index=False)
print('\nReading: binary outcomes in pp (percentage points); continuous in native units (gold/xp/cs count).')
print('PLACEBO check: team_vision / control wards blue effect should be ~0 if vision is NOT the channel.')

# figure: blue effect on binary objectives (pp), team-FE adjusted
bins=res[res.type=='binary'].copy()
fig,ax=plt.subplots(figsize=(7.6,4.2))
colors=['#2c6fbb' if v>0 else '#c0392b' for v in bins.blue_teamFE]
ax.barh(bins.label, bins.blue_teamFE, color=colors)
ax.axvline(0,color='k',lw=1)
for i,(_,r) in enumerate(bins.iterrows()):
    ax.annotate(f'{r.blue_teamFE:+.1f}pp',(r.blue_teamFE,i),
                xytext=(6 if r.blue_teamFE>0 else -6,0),textcoords='offset points',
                va='center',ha='left' if r.blue_teamFE>0 else 'right',fontsize=9)
ax.set_xlabel('Adjusted blue-side association with early objectives (pp, team FE)')
ax.set_title('Blue-side structural associations: top-side objectives up, dragon down',fontsize=11)
plt.tight_layout(); plt.savefig(os.path.join(FIG,'03_side_causes.png'),dpi=150)
print('saved figures/03_side_causes.png')
