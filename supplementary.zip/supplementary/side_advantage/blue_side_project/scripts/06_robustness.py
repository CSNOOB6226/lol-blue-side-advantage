"""
Check collinearity, effect sizes, subsamples, time trends, and Elo controls.
 (a) VIF / multicollinearity among structural predictors.
 (b) Standardized effect sizes for side->outcome, alongside statistical significance
     at n=86k: vision is practically ~0 while gold/herald effects are larger.
 (c) Subsamples: major leagues only; playoffs vs regular.
 (d) Time trend: is the blue advantage shrinking (relevant to First Selection policy)?
 (e) Elo team-strength control: does blue survive own/opponent Elo?
Outputs: console + outputs/06_*.csv
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant

HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'), low_memory=False)
P['void_grubs']=P['void_grubs'].fillna(0); OUT=os.path.join(ROOT,'outputs')
def clog(f,df): return smf.logit(f,df).fit(disp=0,cov_type='cluster',cov_kwds={'groups':df.gameid})

print('(a) VIF (multicollinearity)')
vf=['golddiffat10','golddiffat15','xpdiffat15','csdiffat15','firstherald','firstdragon','firsttower','firstblood','void_grubs','killsat15']
Xv=add_constant(P.dropna(subset=vf)[vf])
vif=pd.DataFrame({'feature':Xv.columns,'VIF':[variance_inflation_factor(Xv.values,i) for i in range(Xv.shape[1])]})
print(vif[vif.feature!='const'].round(2).to_string(index=False))
print('  note: golddiffat10/15 are collinear by construction (same quantity 5 min apart) -> not used together in causal models.')

print('\n(b) EFFECT SIZES: side->outcome (standardized)')
print('  with n=86k, p<.001 is automatic; report blue effect in SD units (practical size).')
rows=[]
for y in ['firstherald','firstdragon','firsttower','golddiffat15','xpdiffat15','team_vision','team_cwards']:
    d=P.dropna(subset=[y]); m=smf.ols(f'{y}~blue',d).fit(cov_type='cluster',cov_kwds={'groups':d.gameid})
    sd=d[y].std(); rows.append(dict(outcome=y,blue_effect=round(m.params.blue,3),outcome_SD=round(sd,2),
                                    effect_in_SD=round(m.params.blue/sd,3)))
es=pd.DataFrame(rows); print(es.to_string(index=False)); es.to_csv(os.path.join(OUT,'06_effect_sizes.csv'),index=False)
print('  -> gold@15 ~0.4 SD, herald/dragon large; VISION ~0.02 SD = practically ZERO (not the channel).')

print('\n(c) subsamples')
MAJ={'LCK','LEC','LCS','PCS','VCS','CBLOL','LJL','LAS','LCKC','LLA'}
def blue_or(df):
    m=clog('win~blue',df); b=m.params.blue; se=m.bse.blue
    return np.exp(b),np.exp(b-1.96*se),np.exp(b+1.96*se),m.pvalues.blue,len(df)
for name,df in [('ALL',P),('major leagues',P[P.league.isin(MAJ)]),
                ('playoffs only',P[P.playoffs==1]),('regular only',P[P.playoffs==0])]:
    o,lo,hi,p,n=blue_or(df); print(f'  {name:16s}: blue OR={o:.3f} [{lo:.3f},{hi:.3f}] p={p:.2g} (n={n})')

print('\n(d) time trend of blue advantage')
P['yr_c']=P.year-2024
mt=clog('win~blue+blue:yr_c+yr_c',P)
print(f'  blue x year interaction OR={np.exp(mt.params["blue:yr_c"]):.4f} (p={mt.pvalues["blue:yr_c"]:.2g})')
print('  per-season blue OR (from 01): 2022 1.20, 2023 1.31, 2024 1.26, 2025 1.30, 2026 1.23 -> no clear decline.')

print('\n(e) Elo team-strength control')
# build per-league Elo over date order from blue-row results
g=P[P.blue==1][['gameid','date','league','teamname','opp_teamname','win']].dropna().copy()
g['date']=pd.to_datetime(g['date'],errors='coerce'); g=g.sort_values('date')
from collections import defaultdict
elo=defaultdict(lambda:1500.0); K=24; pre_blue=[]; pre_red=[]
for _,r in g.iterrows():
    key=lambda t:(r.league,t); eb=elo[key(r.teamname)]; er=elo[key(r.opp_teamname)]
    pre_blue.append(eb); pre_red.append(er)
    exp_b=1/(1+10**((er-eb)/400)); sb=r.win
    elo[key(r.teamname)]=eb+K*(sb-exp_b); elo[key(r.opp_teamname)]=er+K*((1-sb)-(1-exp_b))
g['elo_diff']=np.array(pre_blue)-np.array(pre_red)   # blue_elo - red_elo (pre-game)
gg=g.dropna(subset=['elo_diff'])
gg['z_elo']=(gg.elo_diff-gg.elo_diff.mean())/gg.elo_diff.std()
m_e=smf.logit('win~z_elo',gg).fit(disp=0); m_be=smf.logit('win~z_elo',gg).fit(disp=0)
# blue effect controlling elo_diff: model at blue-row level, win ~ z_elo (blue is the row); intercept = blue baseline
# proper: pool team-games with blue + z_elo(own-opp). Rebuild at team-game level:
ed=g[['gameid','elo_diff']]
T=P.merge(ed,on='gameid',how='inner').copy()
# for red rows, elo_diff sign flips (elo_diff defined as blue-red); make own-opp:
T['own_minus_opp_elo']=np.where(T.blue==1, T.elo_diff, -T.elo_diff)
T['z_eod']=(T.own_minus_opp_elo-T.own_minus_opp_elo.mean())/T.own_minus_opp_elo.std()
m0=clog('win~blue',T); m1=clog('win~blue+z_eod',T)
print(f'  blue OR: raw {np.exp(m0.params.blue):.3f}  ->  + Elo(own-opp) control {np.exp(m1.params.blue):.3f} (p={m1.pvalues.blue:.2g})')
print(f'  (Elo z OR={np.exp(m1.params.z_eod):.3f}, p={m1.pvalues.z_eod:.2g}) -> blue survives explicit strength control.')
T[['gameid','blue','win','own_minus_opp_elo']].to_csv(os.path.join(OUT,'06_elo.csv'),index=False)
