"""
Describe the 44% residual using later game-state measures (baron@20, gold@20/25).

Extends the ordered decomposition with LATER checkpoints (gold@20, gold@25, first baron).
NOTE: these are CIRCULAR for win (consequences of leading) -> this is DESCRIPTIVE of *where in the
timeline* blue's edge lives, not a causal explanation. Sample fixed to games reaching 25 min
(so all checkpoints exist) -> conditions on game length (caveat).
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore'); import statsmodels.formula.api as smf
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'),low_memory=False)

need=['firstherald','firstdragon','firsttower','firstbaron','golddiffat15','golddiffat20','golddiffat25','win','blue','gameid','year']
d=P.dropna(subset=need).copy()
for c in ['golddiffat15','golddiffat20','golddiffat25']:
    d['z_'+c]=(d[c]-d[c].mean())/d[c].std()
def coef(f): return smf.ols(f,d).fit(cov_type='cluster',cov_kwds={'groups':d.gameid}).params['blue']

print(f'sample = games reaching 25 min: {d.gameid.nunique()} games ({len(d)} team-games)')
print(f'(for comparison, full sample blue edge was +5.79pp; this long-game subsample differs)\n')
stages=[('blue total (this subsample)','win~blue+C(year)'),
        ('+ early objectives (herald+dragon)','win~blue+C(year)+firstherald+firstdragon'),
        ('+ gold@15','win~blue+C(year)+firstherald+firstdragon+z_golddiffat15'),
        ('+ gold@20 (LATER)','win~blue+C(year)+firstherald+firstdragon+z_golddiffat15+z_golddiffat20'),
        ('+ gold@25 (LATER)','win~blue+C(year)+firstherald+firstdragon+z_golddiffat15+z_golddiffat20+z_golddiffat25'),
        ('+ first baron (LATER)','win~blue+C(year)+firstherald+firstdragon+z_golddiffat15+z_golddiffat20+z_golddiffat25+firstbaron')]
b0=coef(stages[0][1])
vals=[(stages[0][0],b0)]
print(f'{"stage":42s} {"blue resid(pp)":>14s} {"% of total":>11s}')
print(f'{stages[0][0]:42s} {b0*100:>13.2f}  {"100%":>11s}')
for name,f in stages[1:]:
    b=coef(f); print(f'{name:42s} {b*100:>13.2f}  {100*b/b0:>10.0f}%'); vals.append((name,b))

# figure: residual decay as later channels are added
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
labels=['Total','+early objectives','+gold@15','+gold@20','+gold@25','+Baron']
yv=[v*100 for _,v in vals]
fig,ax=plt.subplots(figsize=(8,4.6))
ax.plot(range(len(yv)),yv,'o-',color='#2c6fbb',lw=2,markersize=8)
ax.fill_between(range(len(yv)),yv,color='#2c6fbb',alpha=0.08)
for i,v in enumerate(yv): ax.annotate(f'{v:.2f}pp\n({100*v/yv[0]:.0f}%)',(i,v),textcoords='offset points',xytext=(0,10),ha='center',fontsize=8)
ax.axhline(yv[-1],color='#c0392b',ls='--',lw=1)
ax.annotate('Remaining association ~27%\n(timeline/coordinates needed)',(len(yv)-1,yv[-1]),textcoords='offset points',xytext=(-12,-32),ha='right',color='#c0392b',fontsize=8)
ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels,fontsize=8)
ax.set_ylabel('Remaining blue association (pp)'); ax.set_ylim(0,yv[0]*1.15)
ax.set_title('Residual probe: later game states reduce the blue remainder from 57% to ~27%',fontsize=10.5)
plt.tight_layout(); plt.savefig(os.path.join(ROOT,'figures','08_residual_decay.png'),dpi=150)
print('saved figures/08_residual_decay.png')
print(f'''
READING:
 - How much the residual drops when adding gold@20/@25/baron = the share of blue's edge that is
   "blue's lead PERSISTS / compounds into the later game" (measurable in OE, but circular for win).
 - Whatever remains after gold@25+baron = blue still wins even at EQUAL full-game gold trajectory
   -> THAT is the part needing positional/timeline data (true map-geometry candidate).
 - Caveat: restricted to games reaching 25 min (excludes early stomps); descriptive, not causal.''')
