"""07_figure_mediation.py — waterfall of blue's win advantage into causal-ordered channels."""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore'); import statsmodels.formula.api as smf
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'),low_memory=False)
d=P.dropna(subset=['firstherald','firstdragon','golddiffat15','firsttower']).copy()
d['z_gd15']=(d.golddiffat15-d.golddiffat15.mean())/d.golddiffat15.std()
def c(f): return smf.ols(f,d).fit(cov_type='cluster',cov_kwds={'groups':d.gameid}).params['blue']
b0=c('win~blue+C(year)'); b1=c('win~blue+C(year)+firstherald+firstdragon')
b2=c('win~blue+C(year)+firstherald+firstdragon+z_gd15'); b3=c('win~blue+C(year)+firstherald+firstdragon+z_gd15+firsttower')
parts=[('Objectives\n(herald−dragon)',(b0-b1)*100),('Early gold @15',(b1-b2)*100),
       ('First tower',(b2-b3)*100),('Unexplained\n(map geometry?)',b3*100)]
fig,ax=plt.subplots(figsize=(8,4.6)); cum=0; colors=['#2c6fbb','#1f9e6e','#8e7cc3','#c0392b']
ax.bar('Blue total', b0*100, color='#34495e'); ax.annotate(f'{b0*100:.2f}pp',('Blue total',b0*100),ha='center',va='bottom',fontsize=9,fontweight='bold')
for (lab,v),col in zip(parts,colors):
    ax.bar(lab, v, bottom=cum, color=col); ax.annotate(f'{v:+.2f}pp\n({100*v/(b0*100):.0f}%)',(lab,cum+v/2),ha='center',va='center',fontsize=8,color='white')
    cum+=v
ax.axhline(0,color='k',lw=0.8); ax.set_ylabel('Contribution to blue win-probability contrast (pp)')
ax.set_title('Sequential decomposition of blue-side advantage (pooled, year FE)',fontsize=11)
plt.tight_layout(); plt.savefig(os.path.join(ROOT,'figures','04_mediation_waterfall.png'),dpi=150)
print('saved figures/04_mediation_waterfall.png  total=%.2fpp parts=%s'%(b0*100,[round(v,2) for _,v in parts]))
