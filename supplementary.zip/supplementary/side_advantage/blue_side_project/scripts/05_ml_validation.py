"""
Evaluate <=15-min structural predictors with logistic regression, RandomForest,
and XGBoost. Use permutation importance and SHAP to summarize predictive features.

Estimate the incremental predictive value of `blue`; a value near zero is expected
if the structural channels mediate the side effect. Use 5-fold GroupKFold by gameid
to keep paired team-game rows together.

Outputs: console + outputs/05_ml_auc.csv, outputs/05_importance.csv + figures/05_importance.png
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GroupKFold, cross_val_score
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.inspection import permutation_importance
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
try:
    from xgboost import XGBClassifier; HAVE_XGB=True
except Exception: HAVE_XGB=False
try:
    import shap; HAVE_SHAP=True
except Exception: HAVE_SHAP=False

HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'), low_memory=False)
OUT=os.path.join(ROOT,'outputs'); FIG=os.path.join(ROOT,'figures')

# void grubs did not exist pre-2024 -> structurally 0
P['void_grubs']=P['void_grubs'].fillna(0)
FEATS=['blue','golddiffat10','golddiffat15','xpdiffat15','csdiffat15',
       'firstherald','firstdragon','firsttower','firstblood','void_grubs','killsat15']
d=P.dropna(subset=FEATS+['win','gameid']).copy()
X=d[FEATS].values; y=d['win'].values; groups=d['gameid'].values
print(f'ML sample: {len(d)} team-games, {d.gameid.nunique()} games, {len(FEATS)} features')

gkf=GroupKFold(n_splits=5)
def cv_auc(model, Xm):
    aucs=[]
    for tr,te in gkf.split(Xm,y,groups):
        m=model.__class__(**model.get_params()); m.fit(Xm[tr],y[tr])
        p=m.predict_proba(Xm[te])[:,1]; aucs.append(roc_auc_score(y[te],p))
    return np.mean(aucs),np.std(aucs)

Xs=StandardScaler().fit_transform(X)
models={'Logistic':LogisticRegression(max_iter=1000),
        'RandomForest':RandomForestClassifier(n_estimators=300,max_depth=8,n_jobs=-1,random_state=0)}
if HAVE_XGB: models['XGBoost']=XGBClassifier(n_estimators=300,max_depth=4,learning_rate=0.1,
                                             subsample=0.9,colsample_bytree=0.9,eval_metric='logloss',n_jobs=-1,random_state=0)
print('\n=== 5-fold CV AUC (GroupKFold by gameid) ===')
rows=[]
for name,m in models.items():
    Xin=Xs if name=='Logistic' else X
    a,s=cv_auc(m,Xin); rows.append(dict(model=name,cv_auc=round(a,4),sd=round(s,4))); print(f'  {name:13s} AUC={a:.4f} (+/-{s:.4f})')
pd.DataFrame(rows).to_csv(os.path.join(OUT,'05_ml_auc.csv'),index=False)

# Q2: incremental value of blue beyond structural channels (logistic)
struct=[f for f in FEATS if f!='blue']
a_struct,_=cv_auc(LogisticRegression(max_iter=1000), StandardScaler().fit_transform(d[struct].values))
a_all,_=cv_auc(LogisticRegression(max_iter=1000), Xs)
print(f'\n=== incremental predictive value of BLUE ===')
print(f'  structural-only AUC={a_struct:.4f}  ->  +blue AUC={a_all:.4f}  (delta={a_all-a_struct:+.4f})')
print('  -> tiny delta => blue side adds almost no info beyond the structural channels it creates (mediation).')

# importance: permutation (RF) + SHAP (XGB)
print('\n=== feature importance ===')
tr,te=next(gkf.split(X,y,groups))
rf=RandomForestClassifier(n_estimators=300,max_depth=8,n_jobs=-1,random_state=0).fit(X[tr],y[tr])
pi=permutation_importance(rf,X[te],y[te],n_repeats=8,random_state=0,scoring='roc_auc',n_jobs=-1)
imp=pd.DataFrame({'feature':FEATS,'perm_importance':pi.importances_mean}).sort_values('perm_importance',ascending=False)
shap_rank=None
if HAVE_XGB and HAVE_SHAP:
    xgb=models['XGBoost'].fit(X[tr],y[tr])
    samp=np.random.RandomState(0).choice(len(te),size=min(4000,len(te)),replace=False)
    sv=shap.TreeExplainer(xgb).shap_values(X[te][samp])
    msh=np.abs(sv).mean(0); shap_rank=pd.DataFrame({'feature':FEATS,'mean_abs_shap':msh}).sort_values('mean_abs_shap',ascending=False)
    imp=imp.merge(shap_rank,on='feature')
print(imp.to_string(index=False)); imp.to_csv(os.path.join(OUT,'05_importance.csv'),index=False)

# figure: permutation importance
fig,ax=plt.subplots(figsize=(7.4,4.6))
ii=imp.sort_values('perm_importance')
ax.barh(ii.feature, ii.perm_importance, color='#2c6fbb')
ax.set_xlabel('Permutation importance (AUC drop)'); ax.set_title('Which early structural features predict winning? (RF permutation importance)',fontsize=11)
plt.tight_layout(); plt.savefig(os.path.join(FIG,'05_importance.png'),dpi=150)
print('\nsaved figures/05_importance.png  | xgb=%s shap=%s'%(HAVE_XGB,HAVE_SHAP))
