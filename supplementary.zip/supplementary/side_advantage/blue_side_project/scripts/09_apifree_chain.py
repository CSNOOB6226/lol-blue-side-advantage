"""
09_apifree_chain.py — the OE-only (no API) causal chain:
  blue -> early objectives -> 15-min gold lead -> win.

Part 1: what the 15-min gold lead is MADE OF  (golddiffat15 ~ early objectives)
Part 2: how reliably the 15-min gold lead converts to a win  (conversion curve)
Part 3: partial-mediation summary (how much of blue's edge runs through gold@15)
Outputs: console + outputs/09_*.csv + figures/09_gold_conversion.png
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore'); import statsmodels.formula.api as smf
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['Arial Unicode MS']; plt.rcParams['axes.unicode_minus']=False
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
P=pd.read_csv(os.path.join(ROOT,'data','panel.csv'),low_memory=False)
P['void_grubs']=P['void_grubs'].fillna(0); OUT=os.path.join(ROOT,'outputs'); FIG=os.path.join(ROOT,'figures')

print('PART 1: what is the 15-min gold lead MADE OF?')
d=P.dropna(subset=['golddiffat15','firstherald','firstblood','firstdragon','firsttower']).copy()
m=smf.ols('golddiffat15 ~ firstherald + firstblood + firstdragon + firsttower + void_grubs + C(year)',
          d).fit(cov_type='cluster',cov_kwds={'groups':d.gameid})
rows=[]
for v in ['firstherald','firstblood','firstdragon','firsttower','void_grubs']:
    rows.append(dict(factor=v, gold_contribution=round(m.params[v],0), p=round(m.pvalues[v],4)))
comp=pd.DataFrame(rows); print(comp.to_string(index=False))
print(f'model R^2 = {m.rsquared:.3f}  (share of 15-min gold-diff variance explained by these early objectives)')
print('  -> reading: securing each early objective is associated with this many gold of 15-min lead (net, correlated).')
comp.to_csv(os.path.join(OUT,'09_gold_composition.csv'),index=False)

print('\nPART 2: does the 15-min gold lead convert to wins?')
c=P.dropna(subset=['golddiffat15','win']).copy()
lead=c[c.golddiffat15>0]
print(f'15-min gold LEADER win rate = {lead.win.mean():.3f}  (n={len(lead)})  <- "X% of 15-min gold leaders win"')
# binned conversion
bins=[-1e9,-3000,-2000,-1000,-500,0,500,1000,2000,3000,1e9]
labels=['<-3k','-3k~-2k','-2k~-1k','-1k~-.5k','-.5k~0','0~.5k','.5k~1k','1k~2k','2k~3k','>3k']
c['bin']=pd.cut(c.golddiffat15,bins=bins,labels=labels)
conv=c.groupby('bin').win.agg(['mean','size']).reset_index(); conv['mean']=conv['mean'].round(3)
print(conv.to_string(index=False)); conv.to_csv(os.path.join(OUT,'09_gold_conversion.csv'),index=False)

print('\nPART 3: how much of BLUE\'s edge runs through gold@15?')
P['z_gd15']=(P.golddiffat15-P.golddiffat15.mean())/P.golddiffat15.std()
pp=P.dropna(subset=['golddiffat15'])
b0=smf.ols('win~blue',pp).fit(cov_type='cluster',cov_kwds={'groups':pp.gameid}).params['blue']
b1=smf.ols('win~blue+z_gd15',pp).fit(cov_type='cluster',cov_kwds={'groups':pp.gameid}).params['blue']
print(f'blue edge: raw {b0*100:+.2f}pp -> controlling gold@15 {b1*100:+.2f}pp  => gold@15 mediates {100*(b0-b1)/b0:.0f}% of blue advantage')
print('  (all early channels together mediate ~56%; remainder is the honest residual / future work.)')

# figure: conversion curve
mid=[-3500,-2500,-1500,-750,-250,250,750,1500,2500,3500]
fig,ax=plt.subplots(figsize=(7.6,4.4))
ax.plot(mid, conv['mean']*100,'o-',color='#2c6fbb',lw=2,markersize=7)
ax.axhline(50,color='gray',ls='--',lw=1); ax.axvline(0,color='gray',ls=':',lw=1)
ax.annotate(f'15-minute leaders win {lead.win.mean()*100:.0f}%',(2500,lead.win.mean()*100),
            textcoords='offset points',xytext=(-4,-28),ha='right',fontsize=9,color='#2c6fbb')
ax.set_xlabel('15-minute gold difference'); ax.set_ylabel('Win rate (%)')
ax.set_title('15-minute gold lead and win rate (non-China professional LoL, 2022–2026)',fontsize=11)
plt.tight_layout(); plt.savefig(os.path.join(FIG,'09_gold_conversion.png'),dpi=150)
print('\nsaved figures/09_gold_conversion.png')
