"""
build_panel.py  —  Blue-Side Advantage project: master panel builder.

Reads the 5 raw Oracle's Elixir season files (2022-2026), filters to non-China
complete games, aggregates to ONE row per team-game with all structural variables
+ engineered fields + opponent linkage, and writes data/panel.csv.

Run once; every downstream analysis reads the small panel.csv (fast, reproducible).
"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.abspath(os.path.join(HERE, "../../../.."))
RAW = os.path.expanduser(os.environ.get("LOL_RAW_DIR", os.path.join(PROJECT, "data", "raw")))
OUT = os.path.join(HERE, 'panel.csv')

FILES = {2022:'2022_LoL_esports_match_data_from_OraclesElixir.csv', 2023:'2023_LoL_esports_match_data_from_OraclesElixir.csv',
         2024:'2024_LoL_esports_match_data_from_OraclesElixir.csv', 2025:'2025_LoL_esports_match_data_from_OraclesElixir.csv',
         2026:'2026_LoL_esports_match_data_from_OraclesElixir.csv'}

# team-level columns we want (kept if present in a given season)
TEAMCOLS = ['gameid','datacompleteness','league','year','split','playoffs','date','patch','side','position',
            'result','gamelength','teamname','teamid',
            'firstblood','firstdragon','dragons','opp_dragons','elementaldrakes','opp_elementaldrakes',
            'infernals','mountains','clouds','oceans','chemtechs','hextechs','elders','opp_elders',
            'firstherald','heralds','opp_heralds','void_grubs','opp_void_grubs',
            'firstbaron','barons','opp_barons','firsttower','towers','opp_towers','firstmidtower',
            'firsttothreetowers','turretplates','opp_turretplates','inhibitors','opp_inhibitors',
            'goldat10','xpat10','csat10','golddiffat10','xpdiffat10','csdiffat10',
            'goldat15','xpat15','csat15','golddiffat15','xpdiffat15','csdiffat15','killsat15','deathsat15',
            'goldat20','golddiffat20','golddiffat25','totalgold','gspd','gpr','ckpm','team kpm','kills','deaths']
# player-level columns we aggregate to team
PLAYERCOLS = ['gameid','side','position','firstPick','visionscore','wardsplaced','controlwardsbought']
NEEDED = set(TEAMCOLS) | set(PLAYERCOLS)
ROLES = ['top','jng','mid','bot','sup']

def load_year(y):
    path = os.path.join(RAW, FILES[y])
    df = pd.read_csv(path, usecols=lambda c: c in NEEDED, low_memory=False)
    df = df[df.get('datacompleteness', 'complete') == 'complete']
    # exclude China: EXACT match on 'LPL'/'LDL' (NOT substring -- 'LPLOL' is Liga Portuguesa, non-China).
    # Note: China rows are almost entirely dropped already by the completeness filter (China early-timing
    # data is incomplete in OE); this exact-match exclusion is belt-and-suspenders.
    CHINA = {'LPL','LDL'}
    china = [l for l in df.league.unique() if str(l) in CHINA]
    df = df[~df.league.isin(china)]
    team = df[df.position == 'team'].copy()
    # team rows carry empty player-only columns -> drop to avoid merge name collisions
    team = team.drop(columns=['firstPick','visionscore','wardsplaced','controlwardsbought'], errors='ignore')
    players = df[df.position.isin(ROLES)]
    agg = players.groupby(['gameid','side']).agg(
        team_vision=('visionscore','sum'),
        team_wards=('wardsplaced','sum'),
        team_cwards=('controlwardsbought','sum'),
        firstPick=('firstPick','max')).reset_index()
    team = team.merge(agg, on=['gameid','side'], how='left')
    team['year'] = y
    return team, sorted(china)

frames, excluded = [], {}
for y in FILES:
    t, ch = load_year(y); frames.append(t); excluded[y] = ch
    print(f'{y}: {len(t):6d} team-games | {t.gameid.nunique():5d} games | excluded China: {ch}')

panel = pd.concat(frames, ignore_index=True, sort=False)

# engineered fields
panel['blue'] = (panel.side == 'Blue').astype(int)
panel['win'] = panel['result'].astype(float)
# opponent linkage (same game, other side): bring opponent team id/name + a couple of opp metrics
opp = panel[['gameid','side','teamname','teamid','golddiffat15']].copy()
opp['side'] = opp.side.map({'Blue':'Red','Red':'Blue'})
opp = opp.rename(columns={'teamname':'opp_teamname','teamid':'opp_teamid','golddiffat15':'opp_golddiffat15'})
panel = panel.merge(opp, on=['gameid','side'], how='left')
# date + numeric patch
panel['date'] = pd.to_datetime(panel['date'], errors='coerce')
panel['patch'] = panel['patch'].astype(str)
panel['gamelength_min'] = panel['gamelength']/60.0
# net objective tempo diffs (descriptive)
for a,b,name in [('dragons','opp_dragons','drag_diff'),('void_grubs','opp_void_grubs','grub_diff'),
                 ('towers','opp_towers','tower_diff'),('turretplates','opp_turretplates','plate_diff'),
                 ('heralds','opp_heralds','herald_diff'),('barons','opp_barons','baron_diff')]:
    if a in panel and b in panel:
        panel[name] = panel[a] - panel[b]

# integrity filter: a valid decisive game has exactly one winner
gw = panel.groupby('gameid').win.transform('sum')
n0 = panel.gameid.nunique()
panel = panel[gw == 1].copy()
print(f'integrity filter: dropped {n0-panel.gameid.nunique()} games with sum(win)!=1 (remakes/invalid; e.g. <10-min voids)')

cols_order = ['gameid','year','date','league','split','playoffs','patch','teamname','teamid',
              'opp_teamname','opp_teamid','side','blue','result','win','gamelength_min','firstPick']
rest = [c for c in panel.columns if c not in cols_order]
panel = panel[cols_order + rest]
panel.to_csv(OUT, index=False)

print('\n=== PANEL BUILT ===')
print('rows (team-games):', len(panel), '| games:', panel.gameid.nunique(),
      '| seasons:', sorted(panel.year.unique()), '| leagues:', panel.league.nunique())
print('blue win rate overall: %.4f' % panel[panel.blue==1].win.mean())
print('firstPick non-null %%: %.1f' % (100*panel.firstPick.notna().mean()))
print('void_grubs non-null by year:')
print(panel.groupby('year').apply(lambda d: d['void_grubs'].notna().mean() if 'void_grubs' in d else np.nan).round(2).to_dict())
print('saved ->', OUT, '(%.1f MB)' % (os.path.getsize(OUT)/1e6))
