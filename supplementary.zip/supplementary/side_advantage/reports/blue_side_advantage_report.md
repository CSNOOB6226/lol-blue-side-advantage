# Full Report on Blue-Side Advantage in Professional League of Legends

> **Historical supplementary report.** This report preserves the July 2026 analysis and its numerical outputs. Current interpretation and manuscript scope are documented in the main repository's `docs/METHODS.md` and `docs/PAPER_STATUS.md`. Decompositions below describe associations; they do not establish causal mediation or identify map geometry as the cause of the remaining association. Historical figure references may require files outside the supplementary source package.

> **Update, 2026-07-10:** This version extended the June report with path analysis and bootstrap confidence intervals (§7), annual Elo controls and 2026 selection effects (§4), an expanded early-state residual check (§10), and a DiD assessment of First Selection (§11). These analyses were reproducible in the historical `../map-side-vs-draft/` package using `python run_all.py`; methodological choices were documented in its `docs/METHODS.md`.

> **Update, 2026-07-15:** A filtering bug was corrected. The previous rule excluded league names containing “LPL,” inadvertently removing Portugal's **LPLOL (763 games)** along with Chinese leagues. The extensions in §§4/7/10/11 had consequently used 84,548 team-games. Exact LPL/LDL matching restored LPLOL, and all analyses were recalculated. **This version uses the complete sample of 43,037 games / 86,074 team-games**, consistent with §§1–3, with the same qualitative conclusions. An external rewrite dated 2026-07-14 used 42,274 games and was archived in `../archive/revision_20260714/`; it is not the source of this report's conclusions.

## 1. Research objective

This study begins with a basic question: do blue-side teams win more often than
red-side teams in professional League of Legends, and, if so, where does the gap arise?

A higher blue win rate alone does not explain the phenomenon. Stronger teams may
appear on blue more often, side-selection rules may bundle blue with first-pick
priority, or map structure may favor access to particular early objectives.
The research therefore proceeds from documenting the pattern to assessing
alternative explanations and examining its associations with objectives, economy,
and final outcomes.

The population is professional play in non-Chinese leagues from 2022 through 2026.
LPL/LDL are excluded because their early-minute fields are frequently missing.
The final sample contains 43,037 games and 86,074 team-games from 80 league labels.
A team-game is one team's record in one match, so every match contributes a blue
row and a red row.

## 2. Data and analysis units

The first step is to construct comparable observations. Each row records one
team's result, side, first Herald/Dragon/tower ownership, and early-state measures
such as gold differences at minutes 10 and 15.

| Item | Description |
|---|---|
| Source | Oracle's Elixir public professional match data |
| Seasons | 2022–2026; 2026 is a partial season through the data cutoff |
| Regions | Non-Chinese leagues; LPL/LDL excluded for missing early-minute data |
| Final sample | 43,037 games / 86,074 team-games |
| League labels | 80 non-Chinese leagues |
| Unit | Team-game: one blue and one red row per match |
| Standard errors | Clustered by `gameid`, accounting for dependence between the two rows |

| Variable | Meaning | Role in the study |
|---|---|---|
| `win` | Win = 1, loss = 0 | Outcome |
| `blue` | Blue = 1, red = 0 | Main explanatory variable |
| `firstPick` | Global first-pick priority | Separates draft priority and map side |
| `firstherald`, `firstdragon`, `firsttower` | First Herald, Dragon, and tower ownership | Objective control |
| `golddiffat10`, `golddiffat15` | Gold differences at minutes 10/15 | Early economic state |
| `xpdiffat15`, `csdiffat15` | XP and CS differences at minute 15 | Additional lane/development measures |
| `team_vision`, `team_cwards` | Team vision score and control wards | Assessment of vision-related explanations |
| `team_season`, `opp_team_season` | Own and opponent team-season identifiers | Team-strength controls |

## 3. Step 1: Establishing the blue-side advantage

Before adding explanatory variables, the pooled blue win rate is 52.9%, versus
47.1% for red, a difference of approximately 5.8 percentage points.
The pattern is not confined to one season: blue wins more than 50% in every
observed season. OR denotes an odds ratio; OR = 1 means equal win odds, and
OR > 1 means higher blue-side win odds.

| Season | Games | Blue win rate | 95% CI | OR | OR 95% CI | p |
|---|---|---|---|---|---|---|
| 2022 | 10,641 | 52.3% | 51.3%–53.2% | 1.202 | 1.114–1.297 | <0.001 |
| 2023 | 9,372 | 53.3% | 52.3%–54.4% | 1.307 | 1.205–1.417 | <0.001 |
| 2024 | 8,803 | 52.9% | 51.8%–53.9% | 1.259 | 1.158–1.369 | <0.001 |
| 2025 | 9,221 | 53.3% | 52.3%–54.3% | 1.302 | 1.199–1.413 | <0.001 |
| 2026 | 5,000 | 52.6% | 51.2%–54.0% | 1.233 | 1.104–1.378 | <0.001 |

![Blue win rate by season](../blue_side_project/figures/01_blue_winrate_by_season.png)

The side gap is consistently observed across seasons. The next question is
whether differences in sample composition account for it.

## 4. Step 2: Controlling team strength and stronger-team selection

A common alternative explanation is that stronger teams happen to play blue more
often. If this fully explained the gap, strength adjustment should remove it.
Team-season fixed effects instead compare blue and red appearances within the
same team's season, while accounting for each team's general strength.

For example, T1 in 2024, T1 in 2025, and G2 in 2024 receive distinct indicator
variables. These absorb a team's overall level in a particular year. The remaining
`blue` coefficient estimates the side association after those stable differences
are controlled, rather than comparing all blue teams with all red teams indiscriminately.

| Model | Blue-side estimate | Interpretation |
|---|---|---|
| Unadjusted LPM | +5.79 pp | Pooled win-probability contrast before strength adjustment |
| Own team-season FE | +5.49 pp | Similar contrast within team-season |
| Own and opponent FE | +4.54 pp | Positive association after opponent-strength adjustment |
| Elo control | OR approximately 1.26 → 1.29 | Similar pooled conclusion after pre-match strength adjustment |

These historical estimates show that stable strength differences do not fully
account for the observed side association. They do not remove every possible
source of confounding.

**July 2026 extension: annual Elo controls and selection.** Pre-match Elo was
updated chronologically within league-season, using only prior information.
Elo itself is strongly predictive: each standard deviation of strength difference corresponds to an OR of about 2.15, making it a meaningful control.

| Season | Unadjusted blue OR | Elo-adjusted blue OR | Historical interpretation |
|---|---|---|---|
| 2022 | 1.202 | 1.205 | Side assignment and strength were weakly related; estimate stable |
| 2023 | 1.307 | 1.331 | Similar pattern |
| 2024 | 1.259 | 1.338 | Similar pattern |
| 2025 | 1.302 | 1.416 | Clearer association after strength adjustment |
| 2026 | 1.233 | **1.114**, CI 0.99–1.25, p = 0.072 | Compatible with stronger teams selecting blue under the new rule |

2026 is the only year with a substantial decrease after Elo adjustment.
After First Selection separated side and priority, allocation could reflect team
choices, and the raw blue win rate could contain a selection component.
A smaller positive estimate remained, with its interval including one.
The historical revealed-preference interpretation was that team choices suggested
that professionals valued blue map side more than first-pick priority; those
choices alone do not prove an objective causal advantage.

## 5. Step 3: Separating first pick from map side

Map side and first pick are often conflated because they were historically
bundled. In 2026 they can be observed separately:

| Side | Draft order | Win rate | Team-games |
|---|---|---|---|
| Blue | Second pick | 53.8% | 1,239 |
| Blue | First pick | 52.2% | 3,700 |
| Red | Second pick | 47.8% | 3,700 |
| Red | First pick | 46.2% | 1,239 |

If priority were the dominant explanation, first pick would be expected to show
a stable positive association. In the historical models, `firstPick` was
non-significant alone and remained so after including `blue`, which was positive
and significant.

| Model | Variable | OR | 95% CI | p |
|---|---|---|---|---|
| M0: firstPick only | firstPick | 1.057 | 0.946–1.182 | 0.326 |
| M1: firstPick + blue | firstPick | 0.939 | 0.825–1.068 | 0.340 |
| M1: firstPick + blue | blue | 1.269 | 1.115–1.443 | <0.001 |
| M2: + league/patch FE | firstPick | 0.939 | 0.825–1.069 | 0.341 |
| M2: + league/patch FE | blue | 1.269 | 1.115–1.444 | <0.001 |

Likelihood-ratio comparisons pointed in the same direction:

| Comparison | Result | Interpretation |
|---|---|---|
| Add blue to the firstPick model | χ² = 26.2, p ≈ 3e-7 | Significant fit improvement |
| Add firstPick to the blue model | χ² = 1.8, p ≈ 0.18 | No significant fit improvement |

The observed gap follows map side more closely than first-pick status in this
sample. The first-pick interval remains too wide to establish zero or negligible value.

## 6. Step 4: Early structural differences associated with map side

The next models use objective ownership and minute-15 economic state as outcomes,
rather than immediately predicting the final result. They examine which states
are associated with `blue`.

| State outcome | N | Blue coefficient | p | Standardized coefficient |
|---|---|---|---|---|
| First Herald | 86,072 | +19.2 pp | <0.001 | +0.387 SD |
| First Dragon | 86,072 | −19.7 pp | <0.001 | −0.390 SD |
| First Tower | 86,072 | +8.5 pp | <0.001 | +0.174 SD |
| First Blood | 86,072 | +2.7 pp | <0.001 | |
| Void grubs | 46,048 | +0.99 | <0.001 | |
| Minute-10 gold difference | 86,072 | +234 gold | <0.001 | |
| Minute-15 gold difference | 86,070 | +516 gold | <0.001 | +0.182 SD |
| Minute-15 XP difference | 86,070 | +80 XP | <0.001 | +0.050 SD |
| Minute-15 CS difference | 86,070 | +1.5 CS | <0.001 | |
| Team vision score | 86,074 | +2.29 | <0.001 | +0.038 SD |
| Control wards | 86,074 | −0.24 | <0.001 | −0.007 SD |

![Side associations with match-state variables](../blue_side_project/figures/03_side_causes.png)

The largest objective contrasts favor blue at first Herald and first tower,
while first Dragon favors red. The minute-15 gold-difference coefficient is
several hundred gold. This pattern suggests a concentration in top-side objective
ownership and economic state, rather than uniformly better control of every resource.
The gold-difference coefficient is a blue-minus-red contrast, not the mean lead
computed only on blue rows.

## 7. Step 5: From resource advantage to win-rate advantage

Sequential decomposition adds objectives, minute-15 gold, and first tower to
win models and records the reduction in the `blue` coefficient.

| Component | Blue win-probability contrast accounted for | Share of total contrast |
|---|---|---|
| First Herald + First Dragon | +0.76 pp | 13.1% |
| Minute-15 gold, added after objectives | +2.27 pp | 39.1% |
| First Tower, added after objectives/gold | +0.21 pp | 3.6% |
| Remaining association | +2.56 pp | 44.1% |

![Sequential decomposition waterfall](../blue_side_project/figures/04_mediation_waterfall.png)

A substantial part of the side association is absorbed by objectives and
minute-15 economy, with gold the largest added component in this sequence.
The pattern is compatible with a pathway involving objective ownership and an
early economic lead. It does not identify the causal direction among these states.
Across seasons, Herald's standalone component is larger in 2024–2026, while
Dragon's component stays negative.

| Season | Total side contrast | First Herald component | First Dragon component |
|---|---|---|---|
| 2022 | +4.60 pp | +2.54 pp | −3.17 pp |
| 2023 | +6.69 pp | +2.42 pp | −3.66 pp |
| 2024 | +5.75 pp | +6.12 pp | −3.59 pp |
| 2025 | +6.58 pp | +7.10 pp | −4.20 pp |
| 2026 | +5.24 pp | +8.60 pp | −4.74 pp |

**July 2026 extension: path analysis and bootstrap intervals.** Point estimates
alone do not convey sampling uncertainty. The extension used path products
(side-to-state × state-to-win coefficients) in additive linear probability models.
It resampled whole games 600 times, always preserving both mirrored rows, to
construct 95% intervals.

| Channel, 2026, n = 10,000 team-games | Path component | 95% bootstrap CI |
|---|---|---|
| First Herald, positive top-side channel | **+2.0 pp** | [+1.3, +2.8] |
| First Dragon, negative channel | **−1.9 pp** | [−2.4, −1.4] |
| Minute-15 gold difference | +2.6 pp | [+1.5, +3.7] |
| First Tower | +1.3 pp | [+0.7, +1.8] |
| Remaining component | +1.3 pp | [−1.1, +3.5] |

The 2025 pattern was similar: Herald **+2.5 [2.0, 2.9]**, Dragon **−2.8
[−3.3, −2.4]**, and residual **+2.0 [0.3, 3.6]**. The four named channel
intervals excluded zero, supporting their directions under the fitted model.
These estimates differ from sequential reductions because the latter allocate
shared associations to earlier variables, whereas the path model includes the
channels jointly. Their signs and broad relative pattern are consistent.
Neither method supplies mutually independent causal shares. Bootstrap quantifies
sampling uncertainty but does not establish sequential ignorability or remove
unmeasured channel-outcome confounding. Strict causal mediation remains
unidentified under the available observational design.

![Path decomposition, 2026, with 95% bootstrap intervals](../map-side-vs-draft/figures/fig4_mediation_channels.png)

## 8. Step 6: Rechecking the economic chain

The study also checks whether objective ownership is associated with gold and
whether gold is associated with winning. First tower, first blood, first Herald,
first Dragon, and void grubs each have positive conditional associations with
minute-15 gold. First tower and first blood have the largest coefficients.

| Variable | Minute-15 gold-difference coefficient | p |
|---|---|---|
| First Herald | +1203 | <0.001 |
| First Blood | +1431 | <0.001 |
| First Dragon | +590 | <0.001 |
| First Tower | +2773 | <0.001 |
| Void grubs | +235 | <0.001 |

Win rates rise with minute-15 gold difference; they approach 92% above +3,000 gold.

| Minute-15 gold difference | Win rate | Team-games |
|---|---|---|
| < −3k | 8.1% | 12,311 |
| −3k to −2k | 20.5% | 7,586 |
| −2k to −1k | 30.7% | 10,628 |
| −1k to −0.5k | 39.9% | 6,158 |
| −0.5k to 0 | 46.2% | 6,357 |
| 0 to +0.5k | 53.7% | 6,363 |
| +0.5k to +1k | 60.2% | 6,153 |
| +1k to +2k | 69.3% | 10,626 |
| +2k to +3k | 79.5% | 7,582 |
| > +3k | 91.9% | 12,306 |

![Minute-15 gold difference and win rate](../blue_side_project/figures/09_gold_conversion.png)

These comparisons connect side, objective ownership, economic state, and outcome
in an associational sequence. Objective timestamps are unavailable for some
fields, so the objective-to-gold coefficients must not be interpreted as verified
pre-15 causal contributions.

## 9. Step 7: Machine-learning validation

The predictive analysis asks whether more flexible models change the descriptive
picture. It complements interpretable regressions by checking discrimination from
the same match-state features and the additional information in `blue`.
The historical analysis described these as early-state variables; without reliable
objective timestamps, they form a match-state benchmark rather than a strictly
real-time minute-15 forecast.

The outcome is `win`. The complete-case sample contains **86,070 team-games**,
or **43,035 games**, with 11 predictors:

| Group | Predictors | Description |
|---|---|---|
| Side | `blue` | Blue versus red |
| Economy | `golddiffat10`, `golddiffat15` | Minute-10/15 gold differences |
| Lane/development state | `xpdiffat15`, `csdiffat15`, `killsat15` | Minute-15 XP difference, CS difference, and kills |
| Objectives | `firstherald`, `firstdragon`, `firsttower`, `firstblood`, `void_grubs` | First-objective ownership and grub count |

Logistic regression provides an interpretable linear benchmark:

```math
\Pr(win_i = 1) = \frac{1}{1 + \exp[-(\beta_0 + \beta_1x_{i1} + \cdots + \beta_{11}x_{i11})]}.
```

Random Forest uses **300 trees, maximum depth 8** to represent nonlinearities
and interactions. XGBoost uses **300 boosting trees, maximum depth 4, learning
rate 0.1**, fitting successive corrections. Logistic inputs are standardized;
tree models use their original scales.

Five-fold **GroupKFold** groups by `gameid`, keeping both sides of a match in the
same fold. Ordinary row-wise random splitting could place the blue record in
training and its red mirror in testing, causing within-game leakage.

AUC measures the probability that a randomly selected winner receives a higher
score than a randomly selected loser. AUC = 0.5 indicates chance-level ordering;
AUC = 1 indicates perfect ordering. It assesses discrimination, not causality.

| Model | Mean AUC | SD |
|---|---|---|
| Logistic | 0.835 | 0.003 |
| Random Forest | 0.834 | 0.003 |
| XGBoost | 0.834 | 0.003 |

All three models reach approximately 0.83–0.84, with small differences. The tested
state features contain substantial outcome information, while the fitted nonlinear
models do not materially outperform logistic regression under these settings.
That finding does not establish that all nonlinear approaches are unnecessary.

Two importance measures were compared. Permutation importance measures the loss
in held-out AUC when a variable is shuffled. SHAP importance summarizes the average
magnitude of a variable's contribution to individual predictions. Both concern
predictive information rather than causal effects.

| Variable | Permutation importance | SHAP importance |
|---|---|---|
| Minute-15 gold difference | 0.0828 | 0.8008 |
| Minute-15 XP difference | 0.0184 | 0.3389 |
| First Dragon | 0.0071 | 0.2978 |
| First Tower | 0.0041 | 0.1982 |
| Minute-15 CS difference | 0.0025 | 0.1383 |
| Minute-10 gold difference | 0.0020 | 0.0740 |
| First Herald | 0.0010 | 0.0995 |
| `blue` | 0.0002 | 0.0805 |
| Void grubs | 0.0002 | 0.0306 |
| `killsat15` | 0.0002 | 0.0421 |

![Predictive feature importance](../blue_side_project/figures/05_importance.png)

Minute-15 gold ranks first on both measures: **0.0828** permutation importance
and **0.8008** SHAP importance. Shuffling it causes the largest predictive decline.
Minute-15 XP, first Dragon, and first tower contribute less but still carry
information. `blue` has permutation importance of only **0.0002** after the model
observes economic, XP, objective, and kill state.

The prediction results are compatible with the decomposition: much of the
side-associated outcome information is also represented in match state.
Different model families and grouped validation provide a predictive consistency
check, but similar rankings or weak conditional side importance cannot validate
a causal mechanism.

## 10. Step 8: Robustness and mechanism limits

Sensitivity checks examine whether the observed side gap depends on one subset
or specification.

| Check | Method | Estimate | p | Interpretation |
|---|---|---|---|---|
| Major-league subset | Logistic | OR = 1.253 | <0.001 | Positive association in major professional leagues |
| Playoffs | Logistic | OR = 1.213 | <0.001 | Positive association in high-stakes matches |
| Regular season | Logistic | OR = 1.274 | <0.001 | Positive association in regular play |
| Blue × year trend | Interaction logistic | OR = 1.010 | 0.500 | No detectable monotonic annual trend |
| Fixed effects | Own team-season FE | +5.49 pp | <0.001 | Positive association after team-season adjustment |

A separate state-adjustment exercise asks how much of the side coefficient
remains as progressively later economic snapshots become available. Unlike the
path decomposition in §7, this is a descriptive boundary check.

| Variables added sequentially | Remaining blue coefficient | Share of unadjusted coefficient |
|---|---|---|
| Blue only | +5.05 pp | 100% |
| + objectives | +4.69 pp | 93% |
| + minute-15 gold | +2.89 pp | 57% |
| + minute-20 gold | +1.91 pp | 38% |
| + minute-25 gold | +1.46 pp | 29% |
| + first Baron | +1.38 pp | 27% |

![Residual side association after economic adjustment](../blue_side_project/figures/08_residual_decay.png)

Further conditional checks ask four different questions. The first three add
minute-10 gold to a state-outcome model. The fourth restricts the sample to games
with near-even minute-15 gold.

| Check | Specification | Result | Interpretation |
|---|---|---|---|
| First Herald, controlling minute-10 gold | Y = `firstherald`; X = `blue` + `goldDiff@10` | Blue approximately +16.7 pp | A first-Herald association remains at equal measured minute-10 gold |
| Minute-15 gold, controlling minute-10 gold | Y = `goldDiff@15`; X = `blue` + `goldDiff@10` | Blue approximately +133 gold | Additional economic association between minutes 10 and 15 |
| First Dragon, controlling minute-10 gold | Y = `firstdragon`; X = `blue` + `goldDiff@10` | Blue approximately −20.7 pp | Objective contrasts continue to favor different sides |
| Outcome with near-even minute-15 gold | Sample: absolute minute-15 gold difference <250; Y = `win`; X = `blue` | Blue win rate 50.2%, OR = 1.015, p = 0.83 | No detectable side association in this restricted sample |

The second row does not restrict minute-15 gold to zero. It treats that gold
difference as an outcome and adjusts for minute-10 gold; the **+133** coefficient
summarizes an additional conditional association over the next five minutes.
Only the final row selects near-even minute-15 games, yielding **50.2%** blue wins,
**OR = 1.015**, **p = 0.83**. Restricting on a downstream state does not recreate
a randomized counterfactual, but it describes where the side gap is less visible.

**July 2026 extension: expanded early-state residual check.** Nine channels were
included together: first blood, void grubs, minute-10 gold, minute-10/15 XP,
and the original Herald/Dragon/tower/minute-15 gold variables. The residual share
remained approximately **21–37%** in 2024–2026, similar to or slightly larger
than the four-channel version.

The historical interpretation emphasized Herald tempo and hypothesized unmeasured
map geometry, jungle routes, river vision, and pre-objective positioning.
The residual cannot distinguish these explanations. Coordinate-level timeline
data would be needed to test them directly, and more measured variables would
not automatically establish causal identification.

## 11. Step 9: Did First Selection weaken blue-side advantage? An exploratory DiD analysis

The June report had listed DiD as future work. The extension asked whether the
2026 First Selection rule coincided with a smaller blue-side gap, using variation
in adoption/decoupling across leagues.

**Design.** Decoupling intensity varied considerably: LCK was approximately
**D = 0.71**, while LJL/AL remained approximately **D = 0**. The historical
23-league, 2022–2026 panel used blue win-rate advantage as the outcome, league
and year fixed effects, and league-clustered errors. Under the proposed
hypothesis, more decoupled leagues would show a larger 2026 reduction.

All leagues adopted the rule simultaneously, leaving no standard untreated
comparison group. Decoupling intensity reflects postpolicy team choices, not
exogenous treatment assignment. The interaction therefore describes regional
heterogeneity rather than an identified causal policy effect.

| Test | Estimate | 95% CI | p |
|---|---|---|---|
| Main DiD: decoupling × 2026 | **+4.0 pp** | [−4.1, +12.2] | 0.33 |
| Placebo outcome: blue first-Herald rate | +2.6 pp | [−4.3, +9.4] | 0.47 |

The main estimate was non-significant and positive, providing no detectable
reduction. Its direction was compatible with the selection interpretation in §4.
The placebo was also non-significant. This is a useful diagnostic, not proof that
the design cannot generate spurious differences.

![First Selection event study](../map-side-vs-draft/figures/fig3_did_eventstudy.png)

**Qualification.** The event study showed a relatively high 2024 pre-trend of
**+3.7 pp**, comparable to **+4.6 pp** in 2026. Parallel trends were therefore
imperfect, and the panel contained only **23 leagues**. The DiD is suggestive
rather than a clean causal estimate. Descriptively, blue ORs remained around
**1.21–1.31** across five years, with 2026 inside that range, showing no obvious
break. This descriptive comparison does not rely on parallel trends.

![Blue-side odds ratios across five years](../map-side-vs-draft/figures/fig2_blue_or_by_year.png)

**Historical policy interpretation.** If spatial mechanisms explain the gap,
reassigning side and draft priority may change who receives blue without changing
its value. The report proposed that objectives, terrain, or camera perspective
might deserve study alongside draft procedures. The observational results do
not establish that First Selection failed causally or that a specific map change
would remove the imbalance.

## 12. League-level supplementary results

Most listed major leagues have blue win rates above 50%, with variation across leagues.

| League | Games | Blue win rate | 95% CI |
|---|---|---|---|
| NEXO | 689 | 48.0% | 44.3%–51.8% |
| EBL | 790 | 48.1% | 44.6%–51.6% |
| VCS | 1,169 | 50.7% | 47.9%–53.6% |
| LPLOL | 763 | 51.8% | 48.2%–55.3% |
| LCK | 2,320 | 51.9% | 49.9%–53.9% |
| LFL2 | 895 | 52.4% | 49.1%–55.7% |
| NLC | 952 | 52.5% | 49.4%–55.7% |
| LCS | 906 | 52.5% | 49.3%–55.8% |
| LJL | 1,303 | 52.6% | 49.9%–55.4% |
| HM | 745 | 52.8% | 49.2%–56.3% |
| PRM | 1,182 | 53.1% | 50.3%–56.0% |
| LAS | 1,513 | 53.1% | 50.6%–55.6% |
| CBLOL | 917 | 53.2% | 50.0%–56.4% |
| LCKC | 2,285 | 53.3% | 51.2%–55.3% |
| TCL | 964 | 53.3% | 50.2%–56.5% |
| LVP SL | 998 | 53.6% | 50.5%–56.7% |
| LFL | 1,219 | 53.6% | 50.8%–56.4% |
| NACL | 1,756 | 53.9% | 51.6%–56.2% |
| PCS | 1,208 | 54.0% | 51.1%–56.8% |
| AL | 854 | 54.1% | 50.7%–57.4% |
| ESLOL | 832 | 54.2% | 50.8%–57.6% |
| HC | 688 | 54.5% | 50.8%–58.2% |
| UL | 647 | 54.7% | 50.9%–58.5% |
| EM | 1,283 | 54.7% | 52.0%–57.4% |
| CBLOLA | 740 | 54.7% | 51.1%–58.3% |
| LEC | 1,369 | 55.1% | 52.4%–57.7% |

## 13. Methods guide

These methods examine different aspects of the same research question.

| Method | Purpose | How to interpret |
|---|---|---|
| Logistic regression | Model a binary outcome with side and controls | OR >1 indicates higher blue win odds |
| LPM | Linear model of a binary outcome | Percentage-point contrast; +5.49 pp means 5.49 points higher win probability |
| Fixed effects | Adjust for team-season and opponent categories | Assess confounding by stable strength differences |
| OLS | Model continuous outcomes, including gold and XP | Conditional mean difference in outcome units |
| Sequential/path decomposition | Summarize how included states absorb the side association | Associational components, dependent on specification |
| GroupKFold | Cross-validation grouped by game | Prevent mirrored rows from crossing training/testing folds |
| AUC | Rank winners above losers | Approximately 0.835 indicates strong discrimination for these features |
| Permutation importance | Shuffle a feature and measure AUC decline | Larger declines indicate greater predictive reliance |
| SHAP importance | Summarize feature contributions to individual predictions | A second predictive-importance summary, not causality |

## 14. Conclusions

First, a blue-side association is consistently observed. In the 2022–2026
non-Chinese professional sample, blue wins approximately **52.9%** of games.

Second, stable team strength and first-pick priority do not fully explain it.
Fixed-effects and pooled Elo adjustments preserve a positive side association;
in the 2026 joint model, `blue` is significant and `firstPick` is not.
The annual 2026 Elo-adjusted interval nevertheless includes one, and first-pick
non-significance does not establish zero value.

Third, top-side objective ownership and minute-15 economy are informative
associational channels. Blue more often owns first Herald and first tower, and
gold difference strongly orders final outcomes. In near-even minute-15 games,
the side association is not detectable. This supports further investigation of
a spatial/objective/economic pathway without proving that pathway causally.

The July extension adds uncertainty estimates: Herald **+2.0 pp [1.3, 2.8]** and
Dragon **−1.9 pp [−2.4, −1.4]** have intervals excluding zero. Expanded-state
models leave **21–37%** unexplained. First Selection DiD supplies no detected
reduction, but its pre-trend and selection limitations prevent a causal policy
conclusion. The historical hypothesis was that draft procedures alone might
leave spatial mechanisms intact; the residual cannot prove that hypothesis.

## 15. Limitations and next steps

The sample excludes LPL/LDL because of missing early-minute fields, so its
conclusions pertain to non-Chinese leagues. Team strength also changes within
a year through meta adaptation, roster development, and player form; team-season
fixed effects cannot absorb all such changes.

Herald, towers, and gold are dependent. Herald may facilitate towers, and towers
may increase gold, so their decomposition components are not non-overlapping
causal shares. Oracle's Elixir records objectives, economy, and outcomes but
lacks many tactical details: jungle paths, river-vision locations, lane swaps,
wave state, pre-objective positioning, and communication.

The 2026 first-pick analysis uses only a partial season and a smaller sample.
It helps distinguish side and priority associations in that setting; it cannot
provide a complete causal conclusion for every year. Objective ownership lacks
reliable timestamps, limiting strict minute-15 and causal interpretations.

Progress recorded in the July 2026 version:

1. **DiD extension completed (§11):** no detectable reduction, with explicit pre-trend and placebo limitations. It does not constitute a randomized natural experiment.
2. **Path analysis completed (§7):** whole-game bootstrap intervals were added. Full latent-variable SEM was assessed and rejected as unsuitable for the proposed setup, with a binary outcome, mostly binary channels, and no latent constructs; the historical discussion was in `../map-side-vs-draft/docs/METHODS.md`.
3. **Timeline extension deferred:** Riot API timelines, coordinates, vision, and events could test Herald access through jungle routes, lane priority, river vision, and positioning. The API was described as free but engineering-intensive, and solo-queue observations would require population-transport assumptions. Such data could investigate the **21–37%** residual, without guaranteeing its elimination.
4. **Heterogeneity partly examined (§§10/12):** leagues, patches, team strength, and playoffs/regular season; match-duration analyses could be developed further.
5. **Draft timing completed as a separate historical branch:** five roles across two seasons had no detectable positive timing association, and **10/10** tests passed equivalence within the chosen bounds. These proxy results do not establish that all counter-picking strategies are ineffective or unable to offset a side gap. Materials are in `related_research/draft_exploration_archive/`.
6. **Formal manuscript and literature work pending:** prepare the report and its path/DiD extensions for a submission format, complete exact Google Scholar searches, and write Related Work.
