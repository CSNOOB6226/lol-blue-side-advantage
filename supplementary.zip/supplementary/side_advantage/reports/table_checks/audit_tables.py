import importlib.util
import re

from docx import Document

spec = importlib.util.spec_from_file_location("builder", "side_advantage/reports/build_enhanced_final_report.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)

lines = builder.SOURCE.read_text(encoding="utf-8").splitlines()
expected = []
i = 0
while i < len(lines):
    if not lines[i].startswith("|"):
        i += 1
        continue
    raw = []
    while i < len(lines) and lines[i].startswith("|"):
        raw.append(lines[i])
        i += 1
    rows = []
    for index, row in enumerate(raw):
        cells = builder.split_markdown_row(row)
        if index == 1 and all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells):
            continue
        cleaned = []
        for value in cells:
            value = re.sub(r"\*\*(.*?)\*\*", r"\1", value.strip())
            value = re.sub(r"`(.*?)`", r"\1", value)
            cleaned.append(builder.clean_markdown_escapes(value))
        rows.append(cleaned)
    expected.append(rows)

doc = Document("side_advantage/reports/blue_side_advantage_enhanced_report.docx")
actual = [
    [[cell.text for cell in row.cells] for row in table.rows]
    for table in doc.tables
    if len(table.rows) > 1
]

print(f"expected={len(expected)} actual={len(actual)} equal={expected == actual}")
if expected != actual:
    for index, (left, right) in enumerate(zip(expected, actual)):
        if left != right:
            print(f"first_diff={index}")
            print(left)
            print(right)
            raise SystemExit(1)
