#!/usr/bin/env python3
"""Create the pedagogical final report from the retained 43,037-match DOCX."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from docx.text.paragraph import Paragraph

import build_enhanced_final_report as base


HERE = Path(__file__).resolve().parent
REFERENCE = HERE / 'blue_side_advantage_enhanced_report.docx'
OUTPUT = HERE / 'blue_side_advantage_final_report.docx'


STEP_GUIDES = {
    '1. Research objective': [
        ('Research sequence', 'The report proceeds through the existence of the advantage, stronger-team selection, separation of map side from first pick, early resource and economic paths, predictive validation, robustness, and policy evaluation.'),
        ('The central distinction', 'Description asks what happened in the data; prediction asks which variables predict wins; causal claims require stronger identification conditions to determine whether a factor caused an outcome. The report distinguishes these three levels.'),
    ],
    '2. Data and analysis units': [
        ('Question', 'First establish the sample, what each row represents, and which observations are dependent. Valid statistical methods depend on correctly defining the analysis unit.'),
        ('Statistical concepts', '43,037 matches yield 86,074 team-game rows. The blue and red rows of each match mirror one another, so regression standard errors are clustered by gameid. N denotes observations used in each analysis; missingness makes N vary across tables.'),
    ],
    '3. Step 1: Establishing the blue-side advantage': [
        ('Question', 'Before adding complex controls, test whether the overall blue-side win rate consistently exceeds the no-advantage benchmark of 50%.'),
        ('Statistical concepts', 'The analysis uses sample proportions, standard errors, 95% confidence intervals, odds, odds ratios (OR), logistic regression, and p-values. A win-rate interval crossing 50% corresponds to an OR interval crossing 1.'),
        ('Presentation focus', 'Report effect size before uncertainty: the blue-red win-rate gap is about 5.8 percentage points; all five seasonal win-rate intervals exceed 50% and all OR intervals exceed 1.'),
    ],
    '4. Step 2: Controlling team strength and stronger-team selection': [
        ('Question', 'Does blue-side advantage arise simply because stronger teams appear on blue side more often, or constitute a greater share of the blue sample?'),
        ('Statistical concepts', 'The LPM estimates win-rate differences in percentage points. Team-season dummy variables and fixed effects compare blue and red performance within a team and season; opponent fixed effects and pregame Elo further control opponent strength and rating differences.'),
        ('Identification limits', 'A positive adjusted coefficient means stronger-team composition cannot fully explain the result. Fixed effects do not remove all match-varying strategy, lineup, and form confounding, so this remains a conditional association.'),
    ],
    '5. Step 3: Separating first pick from map side': [
        ('Question', 'Blue side usually also has first pick. After the 2026 First Selection decoupling, blue and firstPick can enter the same model to examine their independent information.'),
        ('Statistical concepts', 'A four-cell cross-tabulation shows the joint distribution of two binary variables. Multivariable logistic regression estimates an OR conditional on the other variable; nested-model likelihood-ratio tests assess whether an added variable improves fit.'),
        ('Presentation focus', 'In the 2026 joint model, blue has an OR significantly above 1, while the firstPick interval crosses 1. Adding blue clearly improves fit; adding firstPick does not.'),
    ],
    '6. Step 4: Early structural differences associated with map side': [
        ('Question', 'If map side is associated with win rate, which observable early events first exhibit this association?'),
        ('Statistical concepts', 'LPM coefficients express probability differences for binary outcomes; OLS coefficients express average unit differences for continuous outcomes. Standardized effects use outcome standard deviations (SD) to compare gold, experience, and probability measures.'),
        ('Presentation focus', 'Blue side is associated with first Herald, first tower, and gold leads within 15 minutes, but a lower first-dragon probability. Resources therefore exhibit a top-side versus bottom-side split rather than uniformly favoring blue.'),
    ],
    '7. Step 5: From resource advantage to win-rate advantage': [
        ('Question', 'How much of the blue-side win-rate gap is absorbed by first Herald, first dragon, 15-minute gold, and first tower paths?'),
        ('Statistical concepts', 'Sequential decomposition tracks the decline in the blue coefficient as variables enter. A path term multiplies the blue-to-channel association by the channel-to-win association. Whole-match cluster bootstrap resampling estimates sampling uncertainty.'),
        ('Identification limits', 'This is descriptive path analysis. Unobserved strategy may jointly influence channels, and entry order changes attribution; the explained share is therefore not an identified causal mediation proportion.'),
    ],
    '8. Step 6: Rechecking the economic chain': [
        ('Question', 'Are early objectives associated with 15-minute gold advantage, and is gold advantage associated with higher win rates?'),
        ('Statistical concepts', 'OLS coefficients measure average gold differences conditional on other model variables. Binned win rates divide continuous gold differences into intervals to display possible nonlinearity.'),
        ('Presentation focus', 'First tower, first blood, and first Herald are associated with larger 15-minute gold leads. As gold differences move from large deficits to large leads, win rate rises monotonically from about 8% to about 92%.'),
    ],
    '9. Step 7: Machine-learning validation': [
        ('Question', 'When models allow nonlinearity and interactions, does early gold remain the key predictor rather than the blue label itself?'),
        ('Statistical concepts', 'GroupKFold splits training and test data by match, preventing leakage between mirrored blue and red rows. AUC measures ranking ability; permutation importance and SHAP assess predictive contribution from different perspectives.'),
        ('Identification limits', 'Predictive importance does not establish causality. Highly correlated gold, experience, and objective variables also share importance.'),
    ],
    '10. Step 8: Robustness and mechanism limits': [
        ('Question', 'Do the conclusions depend on a particular league, competition stage, model specification, or control combination?'),
        ('Statistical concepts', 'Subsamples, interactions, fixed effects, and sequential controls assess stability. Residual attenuation shows how much of the blue coefficient is absorbed by observable early states.'),
        ('Identification limits', 'Robustness checks can reveal fragility but do not create causal identification. Controlling midgame variables may also be overcontrol, so both residual and absorbed portions require careful labels.'),
    ],
    '11. Step 9: Did First Selection weaken blue-side advantage? An exploratory DiD analysis': [
        ('Question', 'After the 2026 First Selection rule, did regions with different decoupling levels exhibit different changes in blue-side advantage?'),
        ('Statistical concepts', 'Exploratory DiD includes region and year fixed effects and a decoupling-by-2026 interaction. An event study checks prepolicy trends; a placebo outcome checks for similar spurious policy patterns.'),
        ('Identification limits', 'All regions adopted the rule simultaneously, leaving no standard untreated group. Decoupling is a postpolicy team choice and pretrends are nonflat. This section describes heterogeneity rather than an identified policy effect.'),
    ],
    '12. League-level supplementary results': [
        ('Question', 'Is the direction of blue-side advantage broadly consistent across leagues, and which estimates are more precise?'),
        ('Statistical concepts', 'Binomial proportions and 95% CIs are calculated separately for each league. Larger samples usually have smaller standard errors and narrower intervals; wide intervals in small leagues do not imply no effect.'),
        ('Reading reminder', 'Do not rank leagues solely by point estimates. An interval crossing 50% does not mean the true rate equals 50%; it means the sample cannot exclude that benchmark with the current precision.'),
    ],
    '13. Methods guide': [
        ('Purpose', 'Collect recurring methods in one reference table to explain why each model is used and the units of its results.'),
        ('Selection principle', 'Use logistic regression or LPM for binary wins and OLS for continuous gold or experience outcomes. Fixed effects address repeated-team structure, while clustered standard errors address mirrored rows within a match.'),
    ],
}


TABLE_EXPLANATIONS = [
    {
        "title": 'Sample coverage and analysis units',
        "purpose": 'Identify the data, exclusions, and meaning of each row.',
        "knowledge": 'Matches and team-games are distinct analysis units. Each match creates blue and red rows, so 43,037 matches yield 86,074 rows. Mirrored outcomes are not independent observations.',
        "read": 'Season and league coverage determine generalizability. Clustering by gameid allows the two rows in a match to have correlated errors when calculating standard errors, CIs, and p-values.',
        "result": 'The correct scope is 80 non-China leagues and 43,037 matches, retaining LPLOL and excluding exact LPL/LDL matches because key early-game data are missing.',
        "caution": '86,074 is the row count, not 86,074 independent matches. Ignoring the paired structure may understate standard errors.',
        "script": 'We model team-games but cluster inference by match, so the blue and red rows are not treated as two independent matches.',
    },
    {
        "title": 'Variable dictionary',
        "purpose": 'Explain the roles of outcomes, core predictors, mechanism variables, and controls.',
        "knowledge": 'win is the binary outcome and blue the core predictor. firstPick, early objectives, and gold differences describe possible paths; team-season and opponent variables control persistent strength differences.',
        "read": 'Ask whether each variable arises before, during, or after the match. Later variables are closer to the outcome, but controlling them may describe pathways rather than the total map-side association.',
        "result": 'The variable system covers map side, draft order, early resources, economy, vision, and team and opponent strength.',
        "caution": '15-minute gold and objectives are potential post-blue intermediate states. Controlling them absorbs part of the blue association and differs from controlling pregame confounding.',
        "script": 'This table maps the research design: win is the outcome, blue is the core predictor, and other variables control confounding or describe paths.',
    },
    {
        "title": 'Seasonal blue win rates, 95% CIs, and ORs',
        "purpose": 'Test whether each seasonal blue win rate exceeds 50% and express blue-red odds differences with ORs.',
        "knowledge": 'The proportion is p̂=x/n; SE≈√[p̂(1-p̂)/n]; 95% CI≈p̂±1.96×SE. odds=p/(1-p), OR=odds_blue/odds_red. In logistic regression OR=e^β and its interval is e^(β±1.96SEβ).',
        "read": 'A win-rate CI excluding 50% or OR CI excluding 1 rejects equal blue-red outcomes at the 5% level. p<0.001 means the current or a more extreme result has low probability under the null.',
        "result": 'All five seasonal blue win rates are around 52%–53%; every win-rate interval exceeds 50% and every OR interval exceeds 1.',
        "caution": 'The 2022 OR=1.202 means blue odds are about 20.2% higher than red odds, not a 20.2-percentage-point win-rate gain or a 120.2% win probability.',
        "script": 'In 2022, blue win rate is 52.3% with a 95% CI of 51.3%–53.2%; OR=1.202 with interval 1.114–1.297. Both intervals exclude the no-difference benchmark.',
    },
    {
        "title": 'Blue estimates with LPM, fixed effects, and Elo controls',
        "purpose": 'Check whether the advantage persists after controlling persistent team and opponent strength.',
        "knowledge": 'The LPM regresses 0/1 win directly; the blue coefficient is expressed in pp. Team-season fixed effects add team-season dummy variables and use within-team, within-season side changes.',
        "read": 'Compare the raw +5.79 pp with +5.49 and +4.54 pp after fixed effects. A modest decline means observed team composition cannot explain the full gap.',
        "result": 'After team-season, opponent, or pregame Elo controls, blue estimates remain positive and close to the raw estimates.',
        "caution": 'Fixed effects control factors constant within groups, not automatically match form, lineup matchups, patch strategy, or side-selection motives.',
        "script": 'After team-season and opponent fixed effects, the advantage remains about 4.5–5.5 pp, so stronger-team sample composition alone cannot explain it.',
    },
    {
        "title": 'Seasonal raw and Elo-adjusted ORs',
        "purpose": 'Compare blue ORs by season before and after controlling pregame strength differences.',
        "knowledge": 'Elo measures pregame team strength. The adjusted OR comes from logistic regression containing blue and the Elo difference, estimating conditional blue odds at equal pregame strength.',
        "read": 'Compare raw and adjusted ORs within each row, then check whether the adjusted CI crosses 1. In 2026 OR=1.114, CI≈0.99–1.25, p=0.072: weak evidence rather than conventional 5% significance.',
        "result": 'Adjusted conclusions are stable in 2022–2025, while the 2026 estimate shrinks markedly, consistent with stronger teams choosing blue more often under the new rule.',
        "caution": 'Elo is an imperfect strength measure. Rules, strategy, and the shorter 2026 sample may also matter; the entire change cannot be attributed to stronger-team selection.',
        "script": '2026 is the only year with marked attenuation after Elo control, suggesting side choice enters the raw win rate under the new rule, although the direction remains positive.',
    },
    {
        "title": '2026 map-side-by-first-pick cross-tabulation',
        "purpose": 'Show win rates and sample sizes for all four combinations after decoupling blue and firstPick.',
        "knowledge": 'The 2×2 joint distribution of two binary variables reveals structure hidden by marginal means and identifies sparse combinations.',
        "read": 'Compare blue first versus second pick to examine pick order within a side; compare blue versus red first pick to examine side within a pick order.',
        "result": 'Blue second pick wins 53.8%, blue first pick 52.2%; red second pick 47.8%, red first pick 46.2%. Side differences stand out more than pick-order differences.',
        "caution": 'This is not a randomized four-cell experiment. Rules and strategy influence team choices, so raw cell differences may reflect selection.',
        "script": 'Blue wins more often under either pick order in the cross-tabulation; the next regression controls league, patch, and related factors.',
    },
    {
        "title": 'Joint logistic model of first pick and map side',
        "purpose": 'Estimate the blue association conditional on firstPick and the independent information in firstPick conditional on blue.',
        "knowledge": 'A multivariable logistic OR is conditional on other included variables. A CI crossing 1 usually indicates insufficient evidence; one excluding 1 indicates significance at the chosen threshold.',
        "read": 'M0 includes firstPick alone; M1 adds blue; M2 adds league and patch fixed effects. Check stability of directions, intervals, and p-values.',
        "result": 'firstPick OR≈0.94 has a CI crossing 1; blue OR≈1.269 has a CI excluding 1 and changes little with league and patch controls.',
        "caution": 'The OR is a conditional association, not the causal effect of randomized side assignment. Unmeasured selection motives may still bias blue.',
        "script": 'After controlling first pick in the same model, blue OR remains 1.269 and significant; firstPick has no significant independent association.',
    },
    {
        "title": 'Nested-model likelihood-ratio comparisons',
        "purpose": 'Test whether adding blue or firstPick to existing variables improves model fit.',
        "knowledge": 'The likelihood-ratio statistic for nested logistic models is approximately chi-square distributed. Larger chi-square and smaller p-values indicate information from the added variable.',
        "read": 'Adding blue to a firstPick model tests the incremental value of blue; adding firstPick to a blue model tests the reverse question.',
        "result": 'Adding blue: chi-square=26.2, p≈3×10⁻⁷. Adding firstPick: chi-square=1.8, p≈0.18. Only blue clearly improves fit.',
        "caution": 'Improved fit neither establishes causal importance nor ensures all confounders are included.',
        "script": 'Model comparisons agree: adding map side beyond firstPick improves explanatory fit, while adding firstPick beyond side does not clearly improve it.',
    },
    {
        "title": 'Associations between blue side and early outcomes',
        "purpose": 'Compare blue with first Herald, first dragon, first tower, gold, experience, CS, and vision measures.',
        "knowledge": 'Binary-outcome LPM coefficients express probability differences in pp. Continuous-outcome OLS coefficients retain original units. Dividing by outcome SD enables comparisons in SD units.',
        "read": 'Positive values mean a higher blue mean; negative values a lower blue mean. Different N often reflects season-specific availability or missingness. Small p-values do not guarantee large gameplay effects.',
        "result": 'The largest standardized gaps concern first Herald +0.387 SD and first dragon −0.390 SD; 15-minute gold is about +516, indicating a marked top-side/bottom-side resource split.',
        "caution": 'Multiple correlated outcomes are tested. These coefficients primarily describe structural differences and are not separate identified causal effects.',
        "script": 'Blue does not lead in every objective: it takes Herald and first tower more often, first dragon less often, and averages about 516 more gold at 15 minutes.',
    },
    {
        "title": 'Sequential decomposition of the blue win-rate gap',
        "purpose": 'Partition the total gap into early objectives, 15-minute gold, first tower, and a remaining component.',
        "knowledge": 'Sequential decomposition tracks blue-coefficient reductions as intermediate variables enter. Explained share=pp absorbed at a step÷original blue pp; components sum to the total gap.',
        "read": 'Read explained pp before shares. Gold at 15 adds 2.27 pp beyond objectives, the largest quantified component. The remaining 2.56 pp is not a pure map-geometry effect.',
        "result": 'Objective allocation explains 13.1%, 15-minute gold adds 39.1%, first tower adds 3.6%, and 44.1% remains in the model.',
        "caution": 'Shares depend on entry order and intermediate variables may share unobserved strategic causes. These are not identified causal mediation proportions.',
        "script": 'Observable channels absorb over half the blue gap; 15-minute gold is the largest single explanatory path.',
    },
    {
        "title": 'Seasonal first-Herald and first-dragon path contributions',
        "purpose": 'Check seasonal stability of the positive Herald and negative first-dragon paths.',
        "knowledge": "A path's sign indicates amplification or suppression of the blue gap. A positive term aligns blue-to-channel and channel-to-win associations; a negative term offsets part of the advantage.",
        "read": 'Compare Herald, dragon, and total terms within each row. A contribution may exceed the total because positive and negative paths offset.',
        "result": 'The positive Herald contribution strengthens in 2024–2026; dragon remains negative, matching a descriptive top-side engine and bottom-side suppressor pattern.',
        "caution": 'Contributions are not win-rate points caused by a resource alone and require the model and other channels for interpretation.',
        "script": 'Herald stays positive and first dragon negative; their offsetting contributions form part of the observed net blue difference.',
    },
    {
        "title": '2026 path terms and 600 cluster-bootstrap replications',
        "purpose": 'Report resampling intervals alongside path point estimates to show uncertainty.',
        "knowledge": 'Each cluster-bootstrap replication samples whole matches, keeping blue and red rows together. After 600 replications, the 2.5% and 97.5% quantiles form a 95% CI.',
        "read": 'An interval excluding 0 indicates stability in this sample and model; negative terms indicate suppression. The direct-residual interval crosses 0, leaving its sign and magnitude imprecise.',
        "result": 'Herald contributes about +2.0 pp, first dragon −1.9 pp, 15-minute gold +2.6 pp, and first tower +1.3 pp. The first three core-path intervals exclude 0.',
        "caution": 'Bootstrap addresses sampling uncertainty, not omitted confounding, measurement error, or incorrect causal ordering. Stability does not establish causal identification.',
        "script": 'We bootstrap whole matches 600 times. Herald and gold are stable positive paths, dragon a stable negative path, while the direct-residual interval crosses 0.',
    },
    {
        "title": 'Early events and 15-minute gold differences',
        "purpose": 'Quantify conditional associations of first Herald, first blood, first dragon, first tower, and grubs with 15-minute gold leads.',
        "knowledge": 'OLS coefficients use gold units. A first-tower coefficient of +2773 means teams taking first tower average a 2773-gold larger difference at 15 minutes, conditional on other model variables.',
        "read": "Consider event meaning and timing when comparing coefficients. Conditional differences cannot simply be added as a match's total gold.",
        "result": 'First tower and first blood correspond to the largest gold gaps. Herald and dragon also relate to positive gold differences; each Void Grub corresponds to about +235 gold.',
        "caution": 'Stronger and leading teams take objectives more easily, and objectives and gold can reinforce each other. The table supports an association chain rather than a randomized objective experiment.',
        "script": 'Early objectives are associated with 15-minute gold, especially first tower, first blood, and first Herald.',
    },
    {
        "title": 'Binned 15-minute gold differences and final win rates',
        "purpose": 'Display the monotonic, nonlinear gold-lead/win-rate association using interpretable intervals.',
        "knowledge": 'Binning divides a continuous variable into intervals and calculates average win rate in each. It displays nonlinearity but loses within-bin detail and involves partly discretionary cutoffs.',
        "read": 'Bins near 0 show small gold differences; extreme bins show win rates under large leads and deficits. Counts indicate the sample support for each estimate.',
        "result": 'Moving from a deficit exceeding 3000 gold to a lead exceeding 3000 gold, win rate rises from 8.1% to 91.9%; near equal gold it is close to 50%.',
        "caution": 'Gold difference is an in-game outcome jointly influenced with wins by strength and game state. This table does not imply that adding 1000 gold causes a fixed win-rate change.',
        "script": "The clear monotonic association between 15-minute gold and final wins helps explain gold's strong predictive value in later models.",
    },
    {
        "title": 'Machine-learning feature groups',
        "purpose": 'Specify the inputs available to logistic regression, random forest, and XGBoost so the model remains interpretable.',
        "knowledge": 'Features are prediction inputs. Grouping them into side, economy, development, and early objectives helps assess outcome leakage and interpret importance.',
        "read": 'Inputs describe map side or states within the first 15 minutes; the target is final win. blue enters separately to measure incremental information after observing early states.',
        "result": 'Linear and nonlinear algorithms use the same inputs, enabling comparison of AUC and importance results.',
        "caution": 'Predicting final wins from first-15-minute variables is an in-game prediction task, not pregame forecasting. It asks which states rank outcomes at 15 minutes.',
        "script": 'All three models use the same early variables, so comparisons concern algorithms rather than differences in input information.',
    },
    {
        "title": 'GroupKFold AUC for three model classes',
        "purpose": 'Compare out-of-sample ranking ability of interpretable logistic regression and nonlinear models.',
        "knowledge": 'GroupKFold splits by gameid so mirrored blue and red rows cannot appear on opposite sides of a training/test split. AUC is the probability of assigning a higher score to a randomly selected winner than loser.',
        "read": 'AUC=0.5 indicates approximately random ranking; 1 indicates perfect ranking. Mean AUC averages folds, and SD reflects variation across folds rather than a coefficient standard error.',
        "result": 'All three AUCs are about 0.834–0.835, differing by only 0.001. Complex nonlinear models do not materially change overall predictive performance.',
        "caution": 'AUC is neither accuracy nor a direct measure of calibration; 0.835 does not mean 83.5% of match predictions are correct.',
        "script": 'Logistic regression, random forest, and XGBoost have nearly identical AUCs, indicating that the simpler interpretable model captures the main predictive structure.',
    },
    {
        "title": 'Permutation and SHAP feature importance',
        "purpose": 'Use two complementary measures to identify variables supporting out-of-sample prediction.',
        "knowledge": 'Permutation importance measures the AUC drop after shuffling a variable. SHAP importance averages absolute contributions to individual model outputs. Their units differ, so compare rankings within each column.',
        "read": 'A large AUC drop indicates dependence on a variable; large SHAP values indicate frequent substantial shifts in predictions. Correlated variables share or substitute information, diluting individual values.',
        "result": '15-minute gold ranks first under both measures. blue permutation importance is only 0.0002, indicating almost no incremental prediction gain once early states are known.',
        "caution": 'Importance is not causality. Values from different algorithms or scales cannot be directly subtracted or interpreted as percentage contributions.',
        "script": 'Both measures rank 15-minute gold first and blue near the bottom, suggesting much of map-side information is already represented by early game state.',
    },
    {
        "title": 'Subsample, trend, and fixed-effect robustness',
        "purpose": 'Check whether blue results depend on match type, competition stage, or model specification.',
        "knowledge": 'Subsample models cover major leagues, playoffs, and regular seasons. blue×year tests a linear annual trend in the blue association; fixed effects use within-group comparisons.',
        "read": 'Compare direction, CIs/p-values, and effect sizes. Interaction OR=1.010, p=0.500 indicates no detected stable linear annual change.',
        "result": 'Major-league, playoff, regular-season, and team-season fixed-effect results are positive and significant, with stable directions.',
        "caution": 'Consistent robustness results increase confidence, but share the same underlying data and are not independent replications.',
        "script": 'Blue estimates remain positive in major leagues, playoffs, and regular seasons; annual interactions show no clear strengthening or attenuation trend.',
    },
    {
        "title": 'Remaining blue association as early states enter',
        "purpose": 'Track attenuation of blue as objective and economic variables are added sequentially.',
        "knowledge": 'Each row represents a richer model. Relative-to-original effect=current blue coefficient÷blue-only coefficient; this describes absorption by observable states.',
        "read": 'A decline from 5.05 pp to 1.38 pp means the conditional blue association decreases as models observe more game states. Steep declines identify stages carrying concentrated information.',
        "result": '57% remains after 15-minute gold; adding 20/25-minute gold and first Baron reduces the remainder to 27%.',
        "caution": 'These variables are intermediate outcomes and may block pathways. Attenuation supports a mechanism narrative but does not identify a causal mediation proportion.',
        "script": 'As more economic states are observed, the residual blue association falls from 100% to 27%, suggesting game-state information increasingly replaces the side label.',
    },
    {
        "title": 'Mechanism stress tests',
        "purpose": 'Assess the top-side-resource→gold→win narrative using conditional models and restricted samples.',
        "knowledge": 'The first three rows condition on goldDiff@10. The final row restricts |goldDiff@15|<250 to create a nearly equal-gold subsample before estimating the blue-win association.',
        "read": 'After controlling 10-minute gold, blue remains associated with first Herald by about +16.7 pp and first dragon by −20.7 pp. Under nearly equal 15-minute gold, OR=1.015 and p=0.83.',
        "result": '10-minute gold does not fully explain objective differences; under nearly equal 15-minute gold, the blue win-rate gap largely disappears.',
        "caution": 'Restricting to equal-gold games changes sample composition and may induce selection or collider bias. This is a stress test rather than an experiment randomizing gold.',
        "script": 'Herald and dragon side differences remain conditional on 10-minute gold, while blue win-rate advantage is nearly zero at approximately equal 15-minute gold.',
    },
    {
        "title": 'Exploratory DiD and placebo outcomes',
        "purpose": 'Test whether regions with greater postrule decoupling exhibit different changes in blue advantage.',
        "knowledge": 'The decoupling×2026 interaction is measured in pp; its 95% CI indicates precision. The placebo outcome is blue first-Herald rate, checking for a similar unexpected policy pattern.',
        "read": 'The main estimate is +4.0 pp, CI −4.1 to +12.2, p=0.33. The wide interval allows negative, zero, and positive effects. The placebo is also nonsignificant.',
        "result": 'No pattern of greater decoupling accompanying a larger reduction in blue advantage is detected, but this does not prove the rule has no effect.',
        "caution": 'No untreated group, postpolicy treatment-intensity selection, and unfavorable pretrends prevent standard DiD identification.',
        "script": 'The exploratory interval is wide and crosses 0. The current data do not detect weakening; nonsignificance cannot establish policy ineffectiveness.',
    },
    {
        "title": 'League-level blue win rates and intervals',
        "purpose": 'Show league sample sizes, point estimates, and precision, and verify retention of LPLOL.',
        "knowledge": 'Each 95% CI depends mainly on sample size and win rate. SE≈√[p̂(1-p̂)/n], so larger n generally yields narrower intervals.',
        "read": 'Point estimates show direction; intervals show uncertainty. LPLOL has 763 matches, blue win rate 51.8%, CI 48.2%–55.3%: a positive direction with limited league-specific precision.',
        "result": 'Most listed leagues have blue estimates above 50%. Larger leagues such as LEC, LCKC, and NACL have more informative intervals.',
        "caution": 'Examining many leagues increases chance extremes. Do not rank significance using point estimates alone or ignore differences in style and schedules.',
        "script": 'The appendix describes heterogeneity and precision. All 763 LPLOL games remain; wide individual-league intervals favor pooled models over simple league rankings.',
    },
    {
        "title": 'Methods reference table',
        "purpose": "Pair each method's research task with its result units to guide interpretation.",
        "knowledge": 'Logistic regression gives ORs; LPM gives win-rate pp; OLS gives continuous-unit differences. Fixed effects control group-invariant factors. GroupKFold/AUC assess prediction; permutation/SHAP explain prediction models.',
        "read": 'Do not mix metrics: ordinary R² and F tests are not primary logistic measures, AUC cannot replace causal coefficients, and path decomposition is not merely a prediction metric.',
        "result": 'The report combines description, controls, paths, prediction, robustness, and exploratory policy analysis.',
        "caution": 'More methods do not automatically strengthen causal evidence. Credibility requires appropriate methods, transparent assumptions, and stability across reasonable specifications.',
        "script": 'The table is a methods index: identify the outcome type, then explain the choice of logistic regression, LPM, OLS, fixed effects, or machine learning.',
    },
]


FIGURE_EXPLANATIONS = [
    {
        "title": 'Blue win rates across seasons',
        "read": 'Season is on the horizontal axis and blue win rate on the vertical. Points are seasonal estimates, error bars are 95% CIs, and 50% is the no-side-advantage benchmark.',
        "result": 'All five points and their intervals exceed 50%, showing a consistent seasonal blue advantage.',
        "caution": 'Error bars represent sampling uncertainty, not all measurement error, competition-format differences, or omitted variables.',
    },
    {
        "title": 'Blue associations with early structural variables',
        "read": 'Each bar is the estimated blue difference for an early outcome. Right indicates a higher blue value, left a lower value; error bars indicate uncertainty.',
        "result": 'First Herald and first tower favor blue; first dragon favors red, showing a top-side/bottom-side split.',
        "caution": 'Outcome units may be standardized. Bar lengths cannot be read as win-rate contributions without checking axis units.',
    },
    {
        "title": 'Sequential-decomposition waterfall',
        "read": 'Starting with the total blue gap, the waterfall subtracts portions absorbed by early objectives, 15-minute gold, and first tower, leaving the model remainder.',
        "result": '15-minute gold is the largest quantified absorption term; nearly half the total gap remains.',
        "caution": 'Attribution changes with variable order. Omitted variables and measurement error may contribute to the remainder, so it is not an identified map-geometry effect.',
    },
    {
        "title": '2026 path terms and bootstrap intervals',
        "read": 'Bar heights are path estimates; error bars are 95% CIs from 600 whole-match bootstrap replications. Zero indicates no path term.',
        "result": 'Herald, 15-minute gold, and first tower are positive; dragon is negative. The direct-residual interval crosses zero.',
        "caution": 'An interval excluding zero indicates model-specific stability, not satisfaction of causal mediation assumptions.',
    },
    {
        "title": '15-minute gold differences and win rates',
        "read": 'Gold-difference bins are on the horizontal axis and final win rate on the vertical, showing the change from large deficits to large leads.',
        "result": 'The association is steep and nearly monotonic. Win rate is near 50% at equal gold and exceeds 90% with leads over 3000 gold.',
        "caution": 'This is a binned association curve, not a causal response to randomized gold interventions.',
    },
    {
        "title": 'Machine-learning feature importance',
        "read": 'Longer bars mean a larger AUC drop after shuffling or greater average SHAP contribution. Check figure labels to identify the metric.',
        "result": '15-minute gold dominates other variables; the blue label has low importance.',
        "caution": 'Correlated variables substitute for one another, and model and scale affect importance. Rankings are not causal contribution shares.',
    },
    {
        "title": 'Attenuation of the remaining blue association',
        "read": 'The horizontal axis adds progressively later states; the vertical axis is the remaining blue coefficient in win-rate pp. Dashed lines mark reference levels.',
        "result": 'With 15-, 20-, and 25-minute gold and first Baron, the remaining blue association falls to about 1.38 pp.',
        "caution": 'Attenuation indicates absorption by game-state information. Intermediate controls may overcontrol, so it is not a causal mediation percentage.',
    },
    {
        "title": 'DiD event study',
        "read": 'The horizontal axis shows policy-relative years; the vertical shows year-by-decoupling interactions. The reference-year coefficient is 0; error bars are 95% CIs.',
        "result": 'The 2024 prepolicy estimate is already elevated and close to 2026, weakening the parallel-trends assumption.',
        "caution": 'Nonflat prepolicy coefficients undermine DiD interpretation. A nonsignificant postpolicy point estimate does not establish no policy effect.',
    },
    {
        "title": 'Five-year stability of blue ORs',
        "read": 'Points are annual ORs with 95% CIs. OR=1 denotes equal blue-red odds; shading or markers indicate the 2026 rule period.',
        "result": 'The 2026 OR remains within the range of earlier annual variation, without a visible discontinuity.',
        "caution": 'Absence of a visual break is descriptive. Concurrent patch, regional-composition, or selection changes prevent policy identification from this figure alone.',
    },
]


GLOSSARY = [
    ('N and analysis units', 'N is the number of observations in an analysis. Match-level N is 43,037, while 86,074 team-games is a row count. Missing variables reduce effective table N. Independence must be established before interpreting standard errors.'),
    ('Proportions, percentages, and percentage points', '52.9% is a proportion. The change from 47.1% to 52.9% is 5.8 percentage points, not a 5.8% relative increase. Relative changes and percentage points differ.'),
    ('Standard error (SE)', 'SE measures estimator variability under repeated sampling. For a proportion, SE≈√[p̂(1-p̂)/n]. Larger samples usually reduce SE, but mirrored rows and repeated teams invalidate independent-observation formulas; this report clusters by gameid.'),
    ('95% confidence interval', 'A 95% CI often uses estimate±1.96×SE or bootstrap quantiles. Under repeated sampling, about 95% of intervals from the same procedure cover the true parameter; this is not a 95% probability that a fixed parameter lies in this particular interval.'),
    ('Null hypothesis and p-value', 'The p-value is the probability, under the null, of the observed or a more extreme statistic. p<0.05 is conventionally significant, but is neither the probability the null is true nor a measure of practical gameplay importance.'),
    ('Odds and OR', 'For probability p, odds=p/(1-p). OR is a ratio of group odds: 1 denotes equality and OR>1 higher odds in the first group. OR=1.20 means 20% higher odds, not a 20-percentage-point win-rate gain.'),
    ('Regression coefficients and controls', 'A regression coefficient describes a conditional association. Controlling other variables compares observations with the same included covariates within the model; it does not randomize real-world conditions.'),
    ("LPM", 'The LPM applies OLS to 0/1 wins. blue=+0.055 indicates about +5.5 pp. Interpretation is intuitive, but heteroskedasticity and predictions outside 0–1 require robust or clustered standard errors.'),
    ('Logistic regression', 'Logistic regression models binary outcomes through log-odds. Exponentiating a coefficient gives an OR, usually with interval e^(β±1.96SEβ). It does not require normally distributed errors as in a standard linear-regression assumption.'),
    ("OLS", 'Ordinary least squares models continuous outcomes such as 15-minute gold. Coefficients retain gold, experience, or CS units; significant associations may still reflect omitted variables or reverse relationships.'),
    ('Dummy variables and fixed effects', 'Categorical variables expand into 0/1 dummies. Team-season fixed effects add team×season dummies to absorb average strength and style constant within the group.'),
    ('Elo and confounding control', 'Elo proxies pregame strength. If stronger teams both choose blue and win more often, strength confounds the association. Elo and fixed effects reduce this bias, but imperfect proxies cannot guarantee elimination of all confounding.'),
    ('Clustered standard errors', 'Related rows within a match or repeated games for a team can make ordinary SEs overstate information. Clustered SEs allow within-cluster error dependence. Team-game regressions cluster by gameid; bootstrap also resamples whole matches.'),
    ('Interactions', 'Interactions test whether an association varies with another variable. blue×year tests annual changes in blue OR; decoupling×2026 tests differential postpolicy changes by regional decoupling.'),
    ('Likelihood-ratio tests and chi-square', 'Nested logistic models compare log likelihoods before and after adding variables. Twice the log-likelihood difference is approximately chi-square distributed. A smaller p-value indicates improved fit, not causality.'),
    ('Standardized effects (SD)', 'Dividing coefficients by outcome SD places different units on a comparable scale. 0.39 SD is generally larger than 0.04 SD, but practical meaning still depends on game mechanisms and original units.'),
    ('Cross-validation and GroupKFold', 'Cross-validation repeatedly divides training and test sets to assess out-of-sample performance. GroupKFold places both rows of a gameid in one fold, preventing exposure to mirrored test-match information.'),
    ("AUC", 'AUC measures ranking of winners above losers. AUC=0.835 means roughly an 83.5% probability of scoring a randomly selected winner above a loser; it is not 83.5% accuracy and does not guarantee calibration.'),
    ('Permutation importance and SHAP', 'Permutation importance measures performance loss after shuffling. SHAP aggregates local contributions to individual predictions. Both explain predictive models, not causal paths; correlated variables share information.'),
    ("bootstrap", 'Bootstrap repeatedly samples observations with replacement and recomputes statistics to form an empirical sampling distribution. This report uses 600 whole-match draws to retain pairing. More replications stabilize intervals but do not repair design bias.'),
    ('Path analysis and direct residual', 'A descriptive path term is a×b: a links blue to a channel and b links the channel to wins conditionally. The direct residual is unabsorbed by measured channels and may reflect unmeasured mechanisms, omitted variables, measurement error, or specification.'),
    ('Robustness checks', 'Subsamples, controls, models, and variable definitions assess sensitivity. Stable results increase confidence, but multiple models on one dataset are not independent experiments.'),
    ('DiD, event studies, and parallel trends', 'Standard DiD compares treatment/control changes before and after policy. Event studies display period interactions and examine approximately flat pretrends. Without untreated controls or with nonflat pretrends, interpretation remains exploratory.'),
    ('Placebo tests', "Placebos replace policy timing, treatment, or outcomes with versions expected to be unaffected. Similar significant patterns may reveal other trends. This report's nonsignificant placebo does not validate the main design."),
    ('Description, prediction, and causality', 'Description asks what patterns occur in the sample; prediction asks about outcomes in new matches; causality asks about interventions. Fixed effects, machine learning, or significant p-values alone do not turn description into causality.'),
]


def set_paragraph_shading(paragraph, fill):
    ppr = paragraph._p.get_or_add_pPr()
    shd = ppr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        ppr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_left_border(paragraph, color=base.BLUE, size=18, space=8):
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    left = pbdr.find(qn("w:left"))
    if left is None:
        left = OxmlElement("w:left")
        pbdr.append(left)
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), str(size))
    left.set(qn("w:space"), str(space))
    left.set(qn("w:color"), color)


def configure_explanation_styles(doc):
    styles = doc.styles
    if "Explanation Title" not in styles:
        style = styles.add_style("Explanation Title", WD_STYLE_TYPE.PARAGRAPH)
    else:
        style = styles["Explanation Title"]
    base.set_style_font(style, 9.4, bold=True, color=base.NAVY)
    style.paragraph_format.space_before = Pt(5)
    style.paragraph_format.space_after = Pt(2)
    style.paragraph_format.left_indent = Pt(7)
    style.paragraph_format.right_indent = Pt(3)
    style.paragraph_format.keep_with_next = True

    if "Explanation Body" not in styles:
        style = styles.add_style("Explanation Body", WD_STYLE_TYPE.PARAGRAPH)
    else:
        style = styles["Explanation Body"]
    base.set_style_font(style, 8.8, color=base.TEXT)
    style.paragraph_format.space_before = Pt(0)
    style.paragraph_format.space_after = Pt(1.8)
    style.paragraph_format.left_indent = Pt(11)
    style.paragraph_format.right_indent = Pt(3)
    style.paragraph_format.line_spacing = 1.12

    if "Glossary Term" not in styles:
        style = styles.add_style("Glossary Term", WD_STYLE_TYPE.PARAGRAPH)
    else:
        style = styles["Glossary Term"]
    base.set_style_font(style, 10.2, bold=True, color=base.BLUE)
    style.paragraph_format.space_before = Pt(6)
    style.paragraph_format.space_after = Pt(1.5)
    style.paragraph_format.keep_with_next = True


def insert_paragraph_after(doc, anchor, style=None):
    paragraph = doc.add_paragraph(style=style)
    anchor.addnext(paragraph._p)
    return paragraph


def add_labeled_paragraph(doc, anchor, label, text):
    paragraph = insert_paragraph_after(doc, anchor, "Explanation Body")
    run = paragraph.add_run(f"{label} | ")
    base.set_run_font(run, 8.8, bold=True, color=base.BLUE)
    run = paragraph.add_run(text)
    base.set_run_font(run, 8.8, color=base.TEXT)
    return paragraph._p


def add_explanation_box(doc, anchor, title, fields):
    title_p = insert_paragraph_after(doc, anchor, "Explanation Title")
    set_paragraph_shading(title_p, base.PALE_BLUE)
    set_left_border(title_p)
    run = title_p.add_run(title)
    base.set_run_font(run, 9.4, bold=True, color=base.NAVY)
    current = title_p._p
    for label, text in fields:
        current = add_labeled_paragraph(doc, current, label, text)
    return current


def replace_paragraph_text(paragraph, text, size=10, color=base.MID_GREY):
    for run in list(paragraph.runs):
        paragraph._p.remove(run._r)
    for index, line in enumerate(text.split("\n")):
        if index:
            paragraph.add_run().add_break()
        run = paragraph.add_run(line)
        base.set_run_font(run, size, color=color, bold=index == 0)


def collect_image_caption_anchors(doc):
    anchors = []
    body = list(doc.element.body.iterchildren())
    for index, child in enumerate(body):
        if child.tag == qn("w:p") and child.xpath(".//w:drawing"):
            anchor = child
            if index + 1 < len(body) and body[index + 1].tag == qn("w:p"):
                anchor = body[index + 1]
            anchors.append(anchor)
    return anchors


def add_step_guides(doc):
    original_paragraphs = list(doc.paragraphs)
    found = set()
    for paragraph in original_paragraphs:
        heading = paragraph.text.strip()
        if heading not in STEP_GUIDES:
            continue
        found.add(heading)
        add_explanation_box(
            doc,
            paragraph._p,
            'Section reading guide',
            STEP_GUIDES[heading],
        )
    missing = set(STEP_GUIDES) - found
    if missing:
        raise RuntimeError("Missing step headings: " + " | ".join(sorted(missing)))


def add_table_explanations(doc, data_tables):
    if len(data_tables) != len(TABLE_EXPLANATIONS):
        raise RuntimeError(f"Expected {len(TABLE_EXPLANATIONS)} data tables, found {len(data_tables)}")
    for index, (table, info) in enumerate(zip(data_tables, TABLE_EXPLANATIONS), start=1):
        fields = [
            ('Research question', info["purpose"]),
            ('Statistical concepts', info["knowledge"]),
            ('How to read', info["read"]),
            ('Key result', info["result"]),
            ('Interpretation limits', info["caution"]),
            ('Suggested presentation wording', info["script"]),
        ]
        add_explanation_box(
            doc,
            table._tbl,
            f"Table explanation {index} | {info['title']}",
            fields,
        )


def add_figure_explanations(doc, image_caption_anchors):
    if len(image_caption_anchors) != len(FIGURE_EXPLANATIONS):
        raise RuntimeError(
            f"Expected {len(FIGURE_EXPLANATIONS)} figures, found {len(image_caption_anchors)}"
        )
    for index, (anchor, info) in enumerate(zip(image_caption_anchors, FIGURE_EXPLANATIONS), start=1):
        add_explanation_box(
            doc,
            anchor,
            f"Figure explanation {index} | {info['title']}",
            [
                ('How to read the figure', info["read"]),
                ('Figure finding', info["result"]),
                ('Interpretation limits', info["caution"]),
            ],
        )


def append_glossary(doc):
    page = doc.add_paragraph()
    page.add_run().add_break(WD_BREAK.PAGE)

    heading = doc.add_paragraph('Appendix A: Statistical reference', style="Heading 1")
    base.set_keep(heading)
    intro = doc.add_paragraph()
    intro.paragraph_format.space_after = Pt(5)
    base.add_inline(
        intro,
        'This appendix explains recurring statistical concepts: what a measure represents, its no-difference benchmark, and the conclusions that are or are not supported.',
        9.5,
    )

    for term, explanation in GLOSSARY:
        p = doc.add_paragraph(term, style="Glossary Term")
        set_left_border(p, color=base.LIGHT_BLUE, size=12, space=5)
        p = doc.add_paragraph(style="Explanation Body")
        p.paragraph_format.left_indent = Pt(8)
        run = p.add_run(explanation)
        base.set_run_font(run, 9.0, color=base.TEXT)

    closing = doc.add_paragraph()
    closing.paragraph_format.space_before = Pt(8)
    set_paragraph_shading(closing, base.PALE_BLUE)
    set_left_border(closing)
    run = closing.add_run('General interpretation sequence | ')
    base.set_run_font(run, 9.3, bold=True, color=base.NAVY)
    run = closing.add_run(
        'State the question and method rationale, then effect size, 95% CI, and p-value; conclude with gameplay meaning and identification limits.'
    )
    base.set_run_font(run, 9.3, color=base.TEXT)


def update_cover_and_metadata(doc):
    cover_changed = False
    for paragraph in doc.paragraphs[:12]:
        if 'Enhanced final version · 2026-07-15' in paragraph.text:
            replace_paragraph_text(
                paragraph,
                'Final version · July 15, 2026; statistical concepts and table explanations',
                10,
                base.MID_GREY,
            )
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cover_changed = True
            break
    if not cover_changed:
        raise RuntimeError("Cover version line not found")

    for section in doc.sections:
        for paragraph in section.header.paragraphs:
            if "43,037-Match Enhanced Final Report" in paragraph.text:
                replace_paragraph_text(
                    paragraph,
                    "Map Side vs Draft Timing · 43,037-Match Final Report · Statistical Guide",
                    7.6,
                    base.MID_GREY,
                )
                paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    props = doc.core_properties
    props.title = 'Professional League of Legends: Complete Blue-Side Advantage Report, Final Version'
    props.subject = 'Complete analysis, statistical concepts, and table explanations for 43,037 matches'
    props.author = "Vincent"
    props.keywords = (
        'League of Legends; blue-side advantage; confidence intervals; OR; fixed effects; LPM; Logistic; bootstrap; machine learning; DiD'
    )
    props.comments = 'Final version dated July 15, 2026; LPLOL retained; statistical explanations for each table and figure.'
    props.modified = datetime(2026, 7, 15, 15, 0, 0)


def main():
    doc = Document(REFERENCE)
    configure_explanation_styles(doc)

    data_tables = [table for table in doc.tables if len(table.rows) > 1]
    image_caption_anchors = collect_image_caption_anchors(doc)

    update_cover_and_metadata(doc)
    add_step_guides(doc)
    add_table_explanations(doc, data_tables)
    add_figure_explanations(doc, image_caption_anchors)
    append_glossary(doc)

    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
