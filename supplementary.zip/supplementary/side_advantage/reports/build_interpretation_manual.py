#!/usr/bin/env python3
"""Build a standalone companion manual for interpreting the blue-side report."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from build_teaching_final_report import (
    FIGURE_EXPLANATIONS,
    GLOSSARY,
    TABLE_EXPLANATIONS,
)


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / 'blue_side_advantage_statistical_interpretation_manual_20260715.docx'
FONT = "Arial"
NAVY = "0B2545"
BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
TEXT = "202938"
MUTED = "667085"
LIGHT = "F4F6F9"
TABLE_FILL = "E8EEF5"
BORDER = "B8C2CC"
GOLD = "7A5A00"
WIDTH_DXA = 9360
INDENT_DXA = 120


TABLE_GROUPS = [
    ('A. Data and research design', [1, 2]),
    ('B. Step 1: Establishing the blue-side advantage', [3]),
    ('C. Step 2: Team strength and stronger-team selection', [4, 5]),
    ('D. Step 3: Separating first pick from map side', [6, 7, 8]),
    ('E. Step 4: Early structural differences', [9]),
    ('F. Step 5: Resource and economic paths', [10, 11, 12]),
    ('G. Step 6: Economic-chain checks', [13, 14]),
    ('H. Step 7: Machine-learning validation', [15, 16, 17]),
    ('I. Step 8: Robustness and mechanism limits', [18, 19, 20]),
    ('J. Step 9: Exploratory policy evaluation', [21]),
    ('K. Supplementary tables and methods index', [22, 23]),
]


def set_run_font(run, size=None, bold=None, italic=None, color=None, mono=False):
    name = "Courier New" if mono else FONT
    run.font.name = name
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    fonts.set(qn("w:ascii"), name)
    fonts.set(qn("w:hAnsi"), name)
    fonts.set(qn("w:eastAsia"), FONT)
    fonts.set(qn("w:cs"), name)


def set_style_font(style, size, color=TEXT, bold=False):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string(color)
    style.font.bold = bold
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)


def set_keep(paragraph, next_paragraph=True, lines=True):
    ppr = paragraph._p.get_or_add_pPr()
    if next_paragraph and ppr.find(qn("w:keepNext")) is None:
        ppr.append(OxmlElement("w:keepNext"))
    if lines and ppr.find(qn("w:keepLines")) is None:
        ppr.append(OxmlElement("w:keepLines"))


def shade_paragraph(paragraph, fill):
    ppr = paragraph._p.get_or_add_pPr()
    shd = ppr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        ppr.append(shd)
    shd.set(qn("w:fill"), fill)


def left_border(paragraph, color=BLUE, size=16, space=7):
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    node = pbdr.find(qn("w:left"))
    if node is None:
        node = OxmlElement("w:left")
        pbdr.append(node)
    node.set(qn("w:val"), "single")
    node.set(qn("w:sz"), str(size))
    node.set(qn("w:space"), str(space))
    node.set(qn("w:color"), color)


def add_page_field(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    paragraph._p.append(field)


def mark_repeat_header(row):
    trpr = row._tr.get_or_add_trPr()
    header = trpr.find(qn("w:tblHeader"))
    if header is None:
        header = OxmlElement("w:tblHeader")
        trpr.append(header)
    header.set(qn("w:val"), "true")


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tcpr = cell._tc.get_or_add_tcPr()
    tcm = tcpr.find(qn("w:tcMar"))
    if tcm is None:
        tcm = OxmlElement("w:tcMar")
        tcpr.append(tcm)
    for side, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcm.find(qn(f"w:{side}"))
        if node is None:
            node = OxmlElement(f"w:{side}")
            tcm.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcpr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_borders(cell, color=BORDER, size=5):
    tcpr = cell._tc.get_or_add_tcPr()
    borders = tcpr.find(qn("w:tcBorders"))
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tcpr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        node = borders.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            borders.append(node)
        node.set(qn("w:val"), "single")
        node.set(qn("w:sz"), str(size))
        node.set(qn("w:color"), color)


def set_table_geometry(table, widths):
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    tblpr = table._tbl.tblPr
    tblw = tblpr.find(qn("w:tblW"))
    if tblw is None:
        tblw = OxmlElement("w:tblW")
        tblpr.append(tblw)
    tblw.set(qn("w:w"), str(sum(widths)))
    tblw.set(qn("w:type"), "dxa")
    tblind = tblpr.find(qn("w:tblInd"))
    if tblind is None:
        tblind = OxmlElement("w:tblInd")
        tblpr.append(tblind)
    tblind.set(qn("w:w"), str(INDENT_DXA))
    tblind.set(qn("w:type"), "dxa")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        trpr = row._tr.get_or_add_trPr()
        cant_split = trpr.find(qn("w:cantSplit"))
        if cant_split is None:
            trpr.append(OxmlElement("w:cantSplit"))
        for cell, width in zip(row.cells, widths):
            tcpr = cell._tc.get_or_add_tcPr()
            tcw = tcpr.find(qn("w:tcW"))
            if tcw is None:
                tcw = OxmlElement("w:tcW")
                tcpr.append(tcw)
            tcw.set(qn("w:w"), str(width))
            tcw.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            set_cell_borders(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def configure_document(doc):
    section = doc.sections[0]
    doc.settings.odd_and_even_pages_header_footer = True
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    normal = doc.styles["Normal"]
    set_style_font(normal, 11, TEXT)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    h1 = doc.styles["Heading 1"]
    set_style_font(h1, 16, BLUE, True)
    h1.paragraph_format.space_before = Pt(18)
    h1.paragraph_format.space_after = Pt(10)
    h1.paragraph_format.keep_with_next = True

    h2 = doc.styles["Heading 2"]
    set_style_font(h2, 13, BLUE, True)
    h2.paragraph_format.space_before = Pt(14)
    h2.paragraph_format.space_after = Pt(7)
    h2.paragraph_format.keep_with_next = True

    h3 = doc.styles["Heading 3"]
    set_style_font(h3, 12, DARK_BLUE, True)
    h3.paragraph_format.space_before = Pt(10)
    h3.paragraph_format.space_after = Pt(5)
    h3.paragraph_format.keep_with_next = True

    if "Manual Label" not in doc.styles:
        label = doc.styles.add_style("Manual Label", WD_STYLE_TYPE.PARAGRAPH)
    else:
        label = doc.styles["Manual Label"]
    set_style_font(label, 10.5, DARK_BLUE, True)
    label.paragraph_format.space_before = Pt(3)
    label.paragraph_format.space_after = Pt(2)
    label.paragraph_format.keep_with_next = True

    if "Manual Detail" not in doc.styles:
        detail = doc.styles.add_style("Manual Detail", WD_STYLE_TYPE.PARAGRAPH)
    else:
        detail = doc.styles["Manual Detail"]
    set_style_font(detail, 10.5, TEXT)
    detail.paragraph_format.space_before = Pt(0)
    detail.paragraph_format.space_after = Pt(5)
    detail.paragraph_format.line_spacing = 1.25
    detail.paragraph_format.left_indent = Inches(0.12)

    for header in (section.header.paragraphs[0], section.even_page_header.paragraphs[0]):
        header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run = header.add_run('Blue-Side Advantage: Statistical Concepts and Table Interpretation')
        set_run_font(run, 8.3, color=MUTED)
    add_page_field(section.footer.paragraphs[0])
    add_page_field(section.even_page_footer.paragraphs[0])

    defaults = doc.styles.element.find(qn("w:docDefaults"))
    rpr_default = defaults.find(qn("w:rPrDefault"))
    rpr = rpr_default.find(qn("w:rPr"))
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)


def add_cover(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(108)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("COMPANION HANDBOOK")
    set_run_font(run, 10, bold=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(20)
    p.paragraph_format.space_after = Pt(10)
    run = p.add_run('Blue-Side Advantage: Statistical Concepts and Table Interpretation')
    set_run_font(run, 29, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(44)
    run = p.add_run('Table explanations · Statistical concepts · Result interpretation')
    set_run_font(run, 14, italic=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run('Companion report: 43,037 matches / 86,074 team-games')
    set_run_font(run, 11.5, bold=True, color=DARK_BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(54)
    run = p.add_run('July 15, 2026')
    set_run_font(run, 12, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(24)
    p.paragraph_format.left_indent = Inches(0.45)
    p.paragraph_format.right_indent = Inches(0.45)
    shade_paragraph(p, LIGHT)
    left_border(p)
    run = p.add_run(
        'Scope | This companion manual explains statistical concepts, 23 tables, and 9 figures in the main report. It supplements the main report rather than replacing it.'
    )
    set_run_font(run, 10.5, color=TEXT)
    p.add_run().add_break(WD_BREAK.PAGE)


def add_labeled(doc, label, text, fill=None, caution=False):
    p = doc.add_paragraph(style="Manual Label")
    if fill:
        shade_paragraph(p, fill)
        left_border(p, color=GOLD if caution else BLUE)
    run = p.add_run(label)
    set_run_font(run, 10.5, bold=True, color=GOLD if caution else DARK_BLUE)
    set_keep(p)
    p = doc.add_paragraph(style="Manual Detail")
    if fill:
        shade_paragraph(p, fill)
    run = p.add_run(text)
    set_run_font(run, 10.5, color=TEXT)
    return p


def add_intro(doc):
    doc.add_paragraph('1. Using this manual', style="Heading 1")
    p = doc.add_paragraph(
        "Entries follow the main report's table numbers. Each addresses six points: research question, statistical concepts, reading guidance, key findings, interpretation limits, and presentation wording."
    )
    set_keep(p, next_paragraph=False)

    add_labeled(
        doc,
        'General interpretation sequence',
        'State the research question and method rationale, then effect size, 95% CI, and p-value; finish with gameplay meaning and identification limits.',
        LIGHT,
    )
    add_labeled(
        doc,
        'Three distinct kinds of conclusions',
        'Description concerns sample patterns; prediction concerns ranking outcomes in new matches; causality concerns interventions. Significant p-values, fixed effects, and machine learning alone do not convert description into causality.',
        LIGHT,
    )


def add_or_worked_example(doc):
    doc.add_paragraph('2. Worked example: Win-rate CIs and odds ratios', style="Heading 1")
    p = doc.add_paragraph(
        "Table 3's 2022 results use n=10,641 matches and blue win rate p̂=0.523. The example illustrates four common statistical concepts."
    )
    set_keep(p, next_paragraph=False)

    add_labeled(
        doc,
        'Step 1 | Win-rate standard error',
        'SE(p̂)=√[p̂(1-p̂)/n]≈√[0.523×0.477/10,641]≈0.00484. This measures repeated-sampling variability of the blue win-rate estimate, not the standard deviation of individual match outcomes.',
        LIGHT,
    )
    add_labeled(
        doc,
        'Step 2 | 95% CI for the win rate',
        'p̂±1.96×SE≈0.523±1.96×0.00484≈[0.5135, 0.5325], displayed at table precision as about 51.3%–53.2%. The interval exceeds 50%, supporting a win rate above the no-advantage benchmark.',
        LIGHT,
    )
    add_labeled(
        doc,
        'Step 3 | Odds and OR',
        'Blue odds=0.523/0.477≈1.096; red odds=0.477/0.523≈0.912; OR=1.096/0.912≈1.202. Blue odds are about 20.2% higher, not a 20.2-percentage-point win-rate gain.',
        LIGHT,
    )
    add_labeled(
        doc,
        'Step 4 | 95% CI for the OR',
        'In logistic regression, OR=e^β and its interval is e^(β±1.96×SEβ). With SEs clustered by gameid, the 2022 OR interval is 1.114–1.297. It exceeds 1, indicating a significant odds difference.',
        LIGHT,
    )
    add_labeled(
        doc,
        'Common interpretation errors',
        'A 95% CI is not a 95% probability that a fixed parameter lies in this interval; p<0.001 is not a 99.9% probability that the conclusion is true.',
        "FFF8E8",
        caution=True,
    )


def add_table_index(doc):
    doc.add_paragraph('3. Main-report table index', style="Heading 1")
    p = doc.add_paragraph(
        'The index lists numbers and purposes; full numerical results remain in the main report. Its Table 22 retains all 763 LPLOL matches.'
    )
    set_keep(p, next_paragraph=False)

    rows = [['Table', 'Research step', 'Topic']]
    group_name_by_table = {}
    for group, numbers in TABLE_GROUPS:
        for number in numbers:
            group_name_by_table[number] = group
    for number, info in enumerate(TABLE_EXPLANATIONS, start=1):
        rows.append([str(number), group_name_by_table[number], info["title"]])

    table = doc.add_table(rows=len(rows), cols=3)
    set_table_geometry(table, [720, 3240, 5400])
    mark_repeat_header(table.rows[0])
    for row_index, row in enumerate(rows):
        for col_index, value in enumerate(row):
            cell = table.cell(row_index, col_index)
            if row_index == 0:
                shade_cell(cell, TABLE_FILL)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if col_index == 0 else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(0)
            run = p.add_run(value)
            set_run_font(run, 9.2, bold=row_index == 0, color=NAVY if row_index == 0 else TEXT)


def add_table_manual(doc):
    doc.add_paragraph('4. Table-by-table interpretation', style="Heading 1")
    p = doc.add_paragraph(
        'The following entries explain all 23 tables in report order, retaining the key interpretation numbers without reproducing the full report.'
    )
    set_keep(p, next_paragraph=False)

    for group_name, numbers in TABLE_GROUPS:
        doc.add_paragraph(group_name, style="Heading 2")
        for number in numbers:
            info = TABLE_EXPLANATIONS[number - 1]
            doc.add_paragraph(f"Table {number} | {info['title']}", style="Heading 3")
            add_labeled(doc, 'Research question', info["purpose"])
            add_labeled(doc, 'Statistical concepts', info["knowledge"])
            add_labeled(doc, 'How to read', info["read"])
            add_labeled(doc, 'Key result', info["result"], LIGHT)
            add_labeled(
                doc,
                'Interpretation limits',
                info["caution"],
                "FFF8E8",
                caution=True,
            )
            add_labeled(doc, 'Suggested presentation wording', info["script"], LIGHT)


def add_figure_manual(doc):
    doc.add_paragraph('5. Figure-by-figure interpretation', style="Heading 1")
    p = doc.add_paragraph(
        'Figures show directions, trends, and uncertainty. Identify axes, reference lines, and error bars before interpreting point estimates.'
    )
    set_keep(p, next_paragraph=False)

    for index, info in enumerate(FIGURE_EXPLANATIONS, start=1):
        heading = doc.add_paragraph(f"Figure {index} | {info['title']}", style="Heading 2")
        if index == 6:
            heading.paragraph_format.page_break_before = True
        add_labeled(doc, 'How to read the figure', info["read"])
        add_labeled(doc, 'Figure finding', info["result"], LIGHT)
        add_labeled(
            doc,
            'Interpretation limits',
            info["caution"],
            "FFF8E8",
            caution=True,
        )


def add_glossary(doc):
    doc.add_paragraph('6. Statistical reference', style="Heading 1")
    p = doc.add_paragraph(
        'Interpretation requires knowing what a measure represents, its no-difference benchmark, and the claims supported or unsupported by the analysis.'
    )
    set_keep(p, next_paragraph=False)

    for term, explanation in GLOSSARY:
        heading = doc.add_paragraph(style="Heading 2")
        heading.paragraph_format.space_before = Pt(6)
        heading.paragraph_format.space_after = Pt(2)
        heading.paragraph_format.line_spacing = 1.0
        run = heading.add_run(term)
        set_run_font(run, 11.5, bold=True, color=BLUE)
        p = doc.add_paragraph(explanation)
        p.paragraph_format.left_indent = Inches(0.1)
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(4)


def add_final_checklist(doc):
    doc.add_paragraph('7. Presentation checklist', style="Heading 1")
    checks = [
        ('Sample', '43,037 matches; 86,074 team-games; LPLOL retained; exact LPL/LDL matches excluded.'),
        ('Effect size', 'Report win-rate differences or pp before ORs; p-values alone are insufficient.'),
        ('Uncertainty', 'Check whether CIs cross the no-difference benchmark: 50% for win rate, 1 for OR, and 0 for path terms.'),
        ('Statistical and gameplay importance', 'Statistical significance does not guarantee gameplay importance; relate gold, objectives, and win-rate differences to game context.'),
        ('Causal limits', 'Fixed effects, path analysis, SHAP, bootstrap, and exploratory DiD do not automatically establish causality.'),
        ('Interpretation order', 'Question → Method → Numbers → Gameplay meaning → Limits.'),
    ]
    for label, text in checks:
        add_labeled(doc, label, text, LIGHT)


def set_properties(doc):
    props = doc.core_properties
    props.title = 'Blue-Side Advantage: Statistical Concepts and Table Interpretation'
    props.subject = 'Companion manual for the blue-side advantage report covering 43,037 professional League of Legends matches'
    props.author = "Vincent"
    props.keywords = 'blue-side advantage; statistical manual; 95% CI; OR; LPM; Logistic; fixed effects; bootstrap; DiD'
    props.comments = 'Companion manual supplementing the main report; dated July 15, 2026.'
    props.modified = datetime(2026, 7, 15, 16, 0, 0)


def main():
    doc = Document()
    configure_document(doc)
    add_cover(doc)
    add_intro(doc)
    add_or_worked_example(doc)
    add_table_index(doc)
    add_table_manual(doc)
    add_figure_manual(doc)
    add_glossary(doc)
    add_final_checklist(doc)
    set_properties(doc)
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
