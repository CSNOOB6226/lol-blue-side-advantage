#!/usr/bin/env python3
"""Build the 43,037-match enhanced final report without deleting legacy content."""
from __future__ import annotations

import re
import textwrap
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "blue_side_advantage_report.md"
OUTPUT = HERE / 'blue_side_advantage_enhanced_report_with_elo.docx'

FONT = "Arial"
NAVY = "17365D"
BLUE = "2F5597"
TEXT = "202938"
MID_GREY = "667085"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREY = "F2F4F7"
PALE_BLUE = "EEF5FB"
BORDER = "98A2B3"
TABLE_DXA = 10150


def set_run_font(run, size=None, bold=None, italic=None, color=None, mono=False, strike=None):
    name = "Courier New" if mono else FONT
    run.font.name = name
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if strike is not None:
        run.font.strike = strike
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    fonts.set(qn("w:ascii"), name)
    fonts.set(qn("w:hAnsi"), name)
    fonts.set(qn("w:eastAsia"), FONT)
    fonts.set(qn("w:cs"), name)


def set_style_font(style, size, bold=False, color=None, italic=False):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.italic = italic
    if color:
        style.font.color.rgb = RGBColor.from_string(color)
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)


def set_cell_margins(cell, top=78, start=92, bottom=78, end=92):
    tcpr = cell._tc.get_or_add_tcPr()
    tcm = tcpr.first_child_found_in("w:tcMar")
    if tcm is None:
        tcm = OxmlElement("w:tcMar")
        tcpr.append(tcm)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcm.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tcm.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcpr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_borders(cell, color=BORDER, size=5):
    tcpr = cell._tc.get_or_add_tcPr()
    borders = tcpr.find(qn("w:tcBorders"))
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tcpr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = borders.find(qn(f"w:{edge}"))
        if tag is None:
            tag = OxmlElement(f"w:{edge}")
            borders.append(tag)
        tag.set(qn("w:val"), "single")
        tag.set(qn("w:sz"), str(size))
        tag.set(qn("w:color"), color)


def set_keep(paragraph, together=False):
    ppr = paragraph._p.get_or_add_pPr()
    if ppr.find(qn("w:keepNext")) is None:
        ppr.append(OxmlElement("w:keepNext"))
    if together and ppr.find(qn("w:keepLines")) is None:
        ppr.append(OxmlElement("w:keepLines"))


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    set_run_font(run, 8, color=MID_GREY)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    paragraph._p.append(fld)


def clean_markdown_escapes(text):
    return (text.replace("\\<", "<").replace("\\>", ">")
                .replace("\\[", "[").replace("\\]", "]")
                .replace("\\_", "_"))


def add_inline(paragraph, text, default_size=9.5, color=TEXT):
    text = clean_markdown_escapes(text.replace("  ", " "))
    pattern = r"(\*\*.*?\*\*|~~.*?~~|`.*?`|(?<!\*)\*[^*]+?\*(?!\*))"
    for token in re.split(pattern, text):
        if not token:
            continue
        if token.startswith("**") and token.endswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, default_size, bold=True, color=color)
        elif token.startswith("~~") and token.endswith("~~"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, default_size, color=MID_GREY, strike=True)
        elif token.startswith("`") and token.endswith("`"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, max(8, default_size - 0.5), mono=True, color="344054")
        elif token.startswith("*") and token.endswith("*"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, default_size, italic=True, color=color)
        else:
            run = paragraph.add_run(token)
            set_run_font(run, default_size, color=color)


def add_body_paragraph(doc, text, first_line=True):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.18
    if first_line:
        p.paragraph_format.first_line_indent = Pt(18)
    add_inline(p, text)
    return p


def add_callout(doc, lines, fill=LIGHT_BLUE):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    shade_cell(cell, fill)
    set_cell_margins(cell, top=110, start=150, bottom=110, end=150)
    cell.paragraphs[0]._element.getparent().remove(cell.paragraphs[0]._element)
    for line in lines:
        p = cell.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.line_spacing = 1.08
        add_inline(p, line, 9.1)
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)


def display_len(text):
    return sum(2 if ord(ch) > 127 else 1 for ch in text)


def compute_widths(rows, total=TABLE_DXA):
    ncols = len(rows[0])
    raw = []
    for j in range(ncols):
        longest = max(display_len(str(row[j])) for row in rows)
        raw.append(max(8, min(36, longest + 2)))
    if ncols >= 6:
        raw = [min(v, 19) for v in raw]
    denom = sum(raw)
    widths = [max(720, round(total * v / denom)) for v in raw]
    widths[-1] += total - sum(widths)
    return widths


def set_table_geometry(table, widths):
    tblpr = table._tbl.tblPr
    for node in list(tblpr.findall(qn("w:tblW"))):
        tblpr.remove(node)
    tw = OxmlElement("w:tblW")
    tw.set(qn("w:w"), str(sum(widths)))
    tw.set(qn("w:type"), "dxa")
    tblpr.append(tw)
    ind = tblpr.find(qn("w:tblInd"))
    if ind is None:
        ind = OxmlElement("w:tblInd")
        tblpr.append(ind)
    ind.set(qn("w:w"), "120")
    ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        for j, cell in enumerate(row.cells):
            tcw = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            if tcw is None:
                tcw = OxmlElement("w:tcW")
                cell._tc.get_or_add_tcPr().append(tcw)
            tcw.set(qn("w:w"), str(widths[min(j, len(widths) - 1)]))
            tcw.set(qn("w:type"), "dxa")


def add_table(doc, rows):
    ncols = len(rows[0])
    if any(len(row) != ncols for row in rows):
        raise ValueError(f"Inconsistent Markdown table width: {rows}")
    table = doc.add_table(rows=len(rows), cols=ncols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.style = "Table Grid"
    set_table_geometry(table, compute_widths(rows))
    font_size = 7.2 if ncols >= 7 else 7.7 if ncols >= 5 else 8.2
    for i, row in enumerate(rows):
        trpr = table.rows[i]._tr.get_or_add_trPr()
        trpr.append(OxmlElement("w:cantSplit"))
        if i == 0:
            repeat = OxmlElement("w:tblHeader")
            repeat.set(qn("w:val"), "true")
            trpr.append(repeat)
        for j, value in enumerate(row):
            cell = table.cell(i, j)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            set_cell_borders(cell)
            if i == 0:
                shade_cell(cell, NAVY)
            elif i % 2 == 0:
                shade_cell(cell, LIGHT_GREY)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if (j == 0 or ncols <= 3) else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            value = re.sub(r"\*\*(.*?)\*\*", r"\1", value.strip())
            value = re.sub(r"`(.*?)`", r"\1", value)
            value = clean_markdown_escapes(value)
            run = p.add_run(value)
            set_run_font(run, font_size, bold=(i == 0), color="FFFFFF" if i == 0 else TEXT)
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)


def add_code(doc, lines):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_geometry(table, [TABLE_DXA])
    cell = table.cell(0, 0)
    shade_cell(cell, "F6F8FA")
    set_cell_margins(cell, top=100, start=130, bottom=100, end=130)
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(0)
    wrapped = []
    for line in lines:
        wrapped.extend(textwrap.wrap(clean_markdown_escapes(line), width=92,
                                     break_long_words=False, break_on_hyphens=False) or [""])
    for idx, line in enumerate(wrapped):
        run = p.add_run(line)
        set_run_font(run, 7.7, mono=True, color="24292F")
        if idx != len(wrapped) - 1:
            run.add_break()
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)


def add_figure(doc, alt, src):
    path = (HERE / src).resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_together = True
    run = p.add_run()
    shape = run.add_picture(str(path), width=Inches(6.55))
    shape._inline.docPr.set("descr", alt)
    shape._inline.docPr.set("title", alt)
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(6)
    cap.paragraph_format.keep_with_next = False
    r = cap.add_run(alt)
    set_run_font(r, 8.2, italic=True, color=MID_GREY)


def configure_document(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)
    section.header_distance = Inches(0.30)
    section.footer_distance = Inches(0.30)

    normal = doc.styles["Normal"]
    set_style_font(normal, 9.5, color=TEXT)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.18
    set_style_font(doc.styles["Heading 1"], 14.5, True, NAVY)
    set_style_font(doc.styles["Heading 2"], 11.5, True, BLUE)
    for name in ("Heading 1", "Heading 2"):
        style = doc.styles[name]
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(10 if name == "Heading 1" else 7)
        style.paragraph_format.space_after = Pt(4)
    set_style_font(doc.styles["List Bullet"], 9.5, color=TEXT)
    set_style_font(doc.styles["List Number"], 9.5, color=TEXT)

    styles = doc.styles.element
    defaults = styles.find(qn("w:docDefaults"))
    rpr_default = defaults.find(qn("w:rPrDefault"))
    rpr = rpr_default.find(qn("w:rPr"))
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(qn(f"w:{key}"), FONT)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = header.add_run("Map Side vs Draft Timing · 43,037-Match Enhanced Final Report")
    set_run_font(r, 7.6, color=MID_GREY)
    add_page_number(section.footer.paragraphs[0])


def add_cover(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(78)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("" "")
    set_run_font(r, 19, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run('Professional League of Legends: Complete Blue-Side Advantage Report')
    set_run_font(r, 25, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(16)
    r = p.add_run("Map Side, Draft Timing, Team Strength, and Early-Game Pathways")
    set_run_font(r, 11.5, italic=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(34)
    r = p.add_run('43,037 matches · 86,074 team-games; 2022-01-10 — 2026-06-02')
    set_run_font(r, 13, bold=True, color="344054")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(42)
    r = p.add_run('Enhanced final version · 2026-07-15; research process, statistical methods, and identification limits')
    set_run_font(r, 10, color=MID_GREY)
    p.add_run().add_break(WD_BREAK.PAGE)


def is_special(line):
    stripped = line.strip()
    return (not stripped or stripped == "---" or line.startswith(("## ", "### ", ">", "```", "|", "!["))
            or re.match(r"^-\s+", line) or re.match(r"^\d+\.\s+", line)
            or stripped.startswith(("<figure", "</figure", "<figcaption", "</figcaption", "aria-hidden")))


def split_markdown_row(line):
    """Split table cells while preserving literal pipes inside inline code."""
    text = line.strip().strip("|")
    cells, current, in_code = [], [], False
    for char in text:
        if char == "`":
            in_code = not in_code
            current.append(char)
        elif char == "|" and not in_code:
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(char)
    cells.append("".join(current).strip())
    return cells


def parse_markdown(doc, text):
    lines = text.splitlines()
    i = 1  # cover replaces Markdown H1 title
    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if not stripped or stripped == "---":
            i += 1
            continue
        if stripped.startswith(("<figure", "</figure", "<figcaption", "</figcaption", "aria-hidden")):
            i += 1
            continue
        if line.startswith(">"):
            block = []
            while i < len(lines) and lines[i].startswith(">"):
                block.append(lines[i][1:].strip().rstrip("  "))
                i += 1
            add_callout(doc, [" ".join(block)])
            continue
        if line.startswith("## "):
            p = doc.add_paragraph(line[3:].strip(), style="Heading 1")
            set_keep(p)
            i += 1
            continue
        if line.startswith("### "):
            p = doc.add_paragraph(line[4:].strip(), style="Heading 2")
            set_keep(p)
            i += 1
            continue
        if line.startswith("```"):
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            i += 1
            add_code(doc, code)
            continue
        image_match = re.match(r"!\[(.*?)\]\((.*?)\)", line)
        if image_match:
            add_figure(doc, image_match.group(1), image_match.group(2))
            i += 1
            continue
        if line.startswith("|"):
            raw = []
            while i < len(lines) and lines[i].startswith("|"):
                raw.append(lines[i])
                i += 1
            rows = []
            for idx, row in enumerate(raw):
                cells = split_markdown_row(row)
                if idx == 1 and all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                    continue
                rows.append(cells)
            add_table(doc, rows)
            continue
        if re.match(r"^-\s+", line):
            while i < len(lines) and re.match(r"^-\s+", lines[i]):
                content = re.sub(r"^-\s+", "", lines[i]).strip()
                i += 1
                while i < len(lines) and lines[i].startswith("  ") and not re.match(r"^-\s+", lines[i]):
                    content += " " + lines[i].strip()
                    i += 1
                p = doc.add_paragraph(style="List Bullet")
                p.paragraph_format.space_after = Pt(2)
                add_inline(p, content)
            continue
        if re.match(r"^\d+\.\s+", line):
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i]):
                match = re.match(r"^(\d+)\.\s+(.*)", lines[i])
                number, content = match.group(1), match.group(2).strip()
                i += 1
                while i < len(lines) and (lines[i].startswith("    ") or lines[i].startswith("  ")):
                    content += " " + lines[i].strip()
                    i += 1
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(2)
                p.paragraph_format.left_indent = Pt(18)
                p.paragraph_format.first_line_indent = Pt(-18)
                add_inline(p, f"{number}.  {content}")
            continue

        para = [stripped.rstrip("  ")]
        i += 1
        while i < len(lines) and not is_special(lines[i]):
            para.append(lines[i].strip().rstrip("  "))
            i += 1
        add_body_paragraph(doc, " ".join(para))


def replace_paragraph(paragraph, new_text, size=9.5):
    for run in list(paragraph.runs):
        paragraph._p.remove(run._r)
    add_inline(paragraph, new_text, size)


def apply_identification_edits(doc):
    """Validate identification caveats retained in the reviewed English source."""
    text = " ".join(paragraph.text for paragraph in doc.paragraphs)
    required = [
        "Neither method supplies mutually independent causal shares.",
        "Strict causal mediation remains unidentified",
        "The residual cannot distinguish these explanations.",
        "leaving no standard untreated comparison group",
        "Decoupling intensity reflects postpolicy team choices",
        "rather than a clean causal estimate",
    ]
    missing = [fragment for fragment in required if fragment not in text]
    if missing:
        raise RuntimeError("Identification caveats missing: " + " | ".join(missing))


def inject_boundary_callout(text):
    marker = '\n## 1. Research objective'
    note = ('\n> **Identification limits**: This report retains fixed effects, dummy variables, LPM, logistic regression, machine learning, path analysis, bootstrap, and DiD. Path decomposition describes fitted differences and does not automatically identify causal mediation. Without untreated controls, with postpolicy treatment-intensity selection and nonflat pretrends, the DiD remains exploratory policy-panel analysis.\n')
    if marker not in text:
        raise RuntimeError("Cannot locate section 1 marker")
    return text.replace(marker, note + marker, 1)


def inject_elo_detail(text):
    """Add a reproducible explanation of the Elo control without deleting legacy text."""
    marker = (
        'Elo itself is strongly predictive: each standard deviation of strength difference corresponds to an OR of about 2.15, making it a meaningful control.'
    )
    detail = '\n\n### Construction of the Elo control\n\n1. **Grouping and initialization.** Each team starts at 1500 in each region×season. This is a common anchor, not measured true strength. Elo is relative: rating differences, rather than absolute scores, enter the calculation.\n2. **Chronological processing.** Within a region and season, matches are sorted by date and gameid. Pregame ratings are saved before the outcome is used for postgame updates, preventing current-outcome leakage.\n3. **Expected win probability.** For pregame ratings R_i and R_j:\n\n```\nE_i = 1 / (1 + 10^((R_j - R_i) / 400))\n```\n\n4. **Postgame updates.** K=24; S_i=1 denotes a win and S_i=0 a loss:\n\n```\nR_i(new) = R_i(old) + 24 × (S_i - E_i)\n```\n\nAn expected favorite win produces a smaller update than an upset. Opposing updates have equal magnitude and opposite signs, preserving relative ratings.\n\n5. **Regression variable.** Each team-game receives `rating_diff = own pregame Elo - opponent pregame Elo`, standardized across the full sample as `z(rating_diff)`:\n\n```\nlogit[P(win=1)] = α + β_blue × blue + β_Elo × z(rating_diff)\n```\n\nStandard errors are clustered by gameid, keeping mirrored blue and red rows in one cluster. β_blue describes the conditional odds difference at the same pregame Elo gap. A 1-SD gap increase, about 90 Elo points in this sample, corresponds to an OR of about 2.15, showing substantial pregame strength information.\n\n### Elo versus team-season fixed effects\n\n| Dimension | Team-season fixed effects | Elo control |\n|---|---|---|\n| Strength representation | Fixed team-season identities absorbed by dummy variables | Dynamic pregame rating |\n| Time variation | Baseline unobserved strength assumed constant within a season | Updates after each match |\n| Opponent handling | Requires opponent fixed effects for explicit adjustment | `rating_diff` includes both current ratings |\n| Functional assumptions | Flexible identities but many dummies | Strength summarized by one score evolving under Elo |\n| Comparison | Blue versus red within the same team and season | Blue versus red at similar pregame rating gaps |\n| Main costs | Many parameters and approximately static seasonal strength | Cold starts, K selection, and rating error |\n\nFixed effects control team-season identity; Elo controls estimated strength against the current opponent on the match date. These approaches have complementary assumptions and weaknesses. Team-season FE, team-plus-opponent FE, and pregame Elo do not eliminate the overall blue estimate, so stronger-team composition alone is insufficient. They reduce strength confounding but cannot guarantee complete control of time-varying strength, lineups, patches, or side-selection strategy, nor establish a causal side effect.\n\n### Initial ratings, cold starts, and robustness limits\n\nStarting every team at 1500 does not assume their true opening strength is equal. Adding the same constant to all initial ratings, such as changing them to 1000 or 2000, changes neither expected probabilities, updates, nor `rating_diff`. The limitation is the opening matches, when ratings remain near 1500 and strength information is weak. Stabilization depends on K, opponents, and schedules; it is not universally achieved after 10 or 15 matches.\n\nCold starts introduce measurement error in the pregame-strength proxy, usually weakening control. Without additional assumptions, the direction of resulting bias in blue cannot be known in advance. Significance despite cold starts is not causal proof. More useful evidence combines similar fixed-effect directions, strong Elo predictive performance, and annual results revealing 2026 selection changes.\n\nPossible sensitivity analyses include previous-season warm starts, excluding initial matches by team or region-season as burn-in, varying K, and Glicko ratings with uncertainty. Warm starts can carry outdated strength across roster and patch changes, so these are sensitivity analyses rather than automatically superior replacements.\n'.strip()
    if marker not in text:
        raise RuntimeError("Cannot locate Elo introduction marker")
    return text.replace(marker, marker + "\n\n" + detail, 1)


def correct_source_version_note(text):
    """The reviewed English source already contains the corrected sample history."""
    return text


def main():
    source_text = correct_source_version_note(SOURCE.read_text(encoding="utf-8"))
    doc = Document()
    configure_document(doc)
    add_cover(doc)
    parse_markdown(doc, inject_elo_detail(inject_boundary_callout(source_text)))
    apply_identification_edits(doc)

    props = doc.core_properties
    props.title = 'Professional League of Legends: Complete Blue-Side Advantage Report, Enhanced Final Version'
    props.subject = "43,037-match project-process report with statistical methods and identification boundaries"
    props.author = "Vincent"
    props.keywords = "League of Legends; map side; team-season fixed effects; LPM; Logistic; bootstrap; DiD"
    props.comments = "43,037 games; LPLOL retained; LPL/LDL excluded by exact match."

    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
