"""Blue-side mechanism replication across years.
Where does blue's win edge come from? By-side objective/vision/gold rates + mediation.
Excludes China (LPL/LDL). Run: python blue_side_mechanism.py
"""
import pandas as pd, numpy as np, warnings, os
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
RAW = os.path.expanduser(os.environ.get("LOL_RAW_DIR", os.path.join(ROOT, "data", "raw")))

# year -> candidate filenames (first existing wins)
FILES = {
    2022: ['2022_LoL_esports_match_data_from_OraclesElixir.csv', '2022_LoL_esports_match_data_from_OraclesElixir.csv'],
    2023: ['2023_LoL_esports_match_data_from_OraclesElixir.csv', '2023_LoL_esports_match_data_from_OraclesElixir.csv'],
    2024: ['2024_LoL_esports_match_data_from_OraclesElixir.csv', '2024_LoL_esports_match_data_from_OraclesElixir.csv'],
    2025: ['2025_LoL_esports_match_data_from_OraclesElixir.csv'],
    2026: ['2026_LoL_esports_match_data_from_OraclesElixir.csv'],
}
COLS = ['position','gameid','side','result','league','datacompleteness',
        'firstblood','firstdragon','firstherald','firsttower','firstbaron',
        'dragons','void_grubs','golddiffat15','visionscore']

def find(year):
    for fn in FILES[year]:
        p = os.path.join(RAW, fn)
        if os.path.exists(p): return p
    return None

def analyze(path, year):
    d = pd.read_csv(path, usecols=lambda c: c in COLS, low_memory=False)
    china = [l for l in d.league.unique() if str(l).strip() in ('LPL','LDL')]  # exact: keep LPLOL (Portugal)
    d = d[~d.league.isin(china)]
    if 'datacompleteness' in d: d = d[d.datacompleteness == 'complete']
    tm = d[d.position == 'team'].copy()
    pl = d[d.position.isin(['top','jng','mid','bot','sup'])]
    vis = pl.groupby(['gameid','side']).visionscore.sum().rename('team_vision').reset_index()
    tm = tm.merge(vis, on=['gameid','side'], how='left')
    b = tm[tm.side=='Blue']; r = tm[tm.side=='Red']
    print(f'\n===== {year}  (non-China games: {len(tm)//2}, excluded: {china}) =====')
    print('%-13s %8s %8s %9s'%('metric','Blue','Red','B - R'))
    rows = [('winrate','result',1),('firstblood','firstblood',1),('firstdragon','firstdragon',1),
            ('firstherald','firstherald',1),('firsttower','firsttower',1),('firstbaron','firstbaron',1),
            ('grubs','void_grubs',0),('golddiff15','golddiffat15',0),('team_vision','team_vision',0)]
    for name,col,pct in rows:
        if col not in tm or tm[col].notna().sum()==0: print('%-13s  (not in this season)'%name); continue
        bb,rr = b[col].mean(), r[col].mean()
        if pct: print('%-13s %7.1f%% %7.1f%% %+7.1fpp'%(name,100*bb,100*rr,100*(bb-rr)))
        else:   print('%-13s %8.0f %8.0f %+9.0f'%(name,bb,rr,bb-rr))
    # mediation: does blue OR shrink after controlling early channels?
    tm['blue'] = (tm.side=='Blue').astype(int)
    tm['z_gd15'] = (tm.golddiffat15 - tm.golddiffat15.mean())/tm.golddiffat15.std()
    chans = [c for c in ['firstdragon','firstherald','firsttower','void_grubs','z_gd15']
             if c in tm and tm[c].notna().any() and tm[c].nunique(dropna=True) > 1]
    try:
        m0 = smf.logit('result~blue', tm).fit(disp=0, cov_type='cluster', cov_kwds={'groups':tm.gameid})
        m1 = smf.logit('result~blue+'+'+'.join(chans), tm).fit(disp=0, cov_type='cluster', cov_kwds={'groups':tm.gameid})
        print('blue OR: alone=%.3f (p=%.2g)  ->  controlling %s = %.3f (p=%.2g)'%(
            np.exp(m0.params.blue), m0.pvalues.blue, '+'.join(chans), np.exp(m1.params.blue), m1.pvalues.blue))
    except Exception as e:
        print('mediation skipped:', repr(e))

if __name__ == '__main__':
    for y in [2022,2023,2024,2025,2026]:
        p = find(y)
        if p: analyze(p, y)
        else: print(f'\n===== {y}: file not found (skip) =====')
