"""Sequential (ordered) mediation of the blue-side win advantage, 2022-2026.
Causal chain:  blue -> top-side objectives (herald/grubs) -> early gold@15 -> first tower -> win.
Linear probability models (additive => decomposable) with cluster SE by gameid.
Reports how many pp of blue's total win-prob edge is explained at each ordered stage + residual.
Dragon (where blue is BEHIND) is reported separately as a suppressor.
"""
import pandas as pd, numpy as np, warnings, os
warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
RAW = os.path.expanduser(os.environ.get("LOL_RAW_DIR", os.path.join(ROOT, "data", "raw")))
FILES = {2022:'2022_LoL_esports_match_data_from_OraclesElixir.csv', 2023:'2023_LoL_esports_match_data_from_OraclesElixir.csv',
         2024:'2024_LoL_esports_match_data_from_OraclesElixir.csv', 2025:'2025_LoL_esports_match_data_from_OraclesElixir.csv',
         2026:'2026_LoL_esports_match_data_from_OraclesElixir.csv'}
COLS = ['position','gameid','side','result','league','datacompleteness',
        'firstdragon','firstherald','firsttower','void_grubs','golddiffat15']

def load(y):
    d = pd.read_csv(os.path.join(RAW, FILES[y]), usecols=lambda c: c in COLS, low_memory=False)
    ch = [l for l in d.league.unique() if str(l).strip() in ('LPL','LDL')]  # exact: keep LPLOL (Portugal)
    d = d[~d.league.isin(ch)]; d = d[d.datacompleteness=='complete']
    tm = d[d.position=='team'].copy()
    tm['blue'] = (tm.side=='Blue').astype(int)
    tm['z_gd15'] = (tm.golddiffat15 - tm.golddiffat15.mean())/tm.golddiffat15.std()
    return tm

def b(formula, tm):
    return smf.ols(formula, tm).fit(cov_type='cluster', cov_kwds={'groups':tm.gameid}).params['blue']

def decompose(tm, year):
    # Stage 1 = early objective ALLOCATION: first herald (+blue) AND first dragon (-blue) together.
    #   They are contemporaneous early river objectives on opposite map halves -> same stage, not a chain.
    objs = ['firstherald','firstdragon']
    need = objs + ['z_gd15','firsttower','result','blue']
    sub = tm.dropna(subset=need).copy()
    o = '+'.join(objs)
    b0 = b('result~blue', sub)                              # total
    b1 = b(f'result~blue+{o}', sub)                         # net of early-objective allocation
    b2 = b(f'result~blue+{o}+z_gd15', sub)                  # + early gold@15
    b3 = b(f'result~blue+{o}+z_gd15+firsttower', sub)       # + first tower
    bh = b('result~blue+firstherald', sub)                  # herald-only (insight)
    bd = b('result~blue+firstdragon', sub)                  # dragon-only (insight)
    print(f'\n=== {year}  (n={len(sub)} team-games) ===')
    print(f'  blue TOTAL win-prob edge                     : {b0*100:+5.1f} pp  (100%)')
    print(f'  -> via early objective allocation (herald+dragon): {(b0-b1)*100:+5.1f} pp ({100*(b0-b1)/b0:3.0f}%)')
    print(f'  -> via early gold@15 (beyond above)              : {(b1-b2)*100:+5.1f} pp ({100*(b1-b2)/b0:3.0f}%)')
    print(f'  -> via first tower   (beyond above)              : {(b2-b3)*100:+5.1f} pp ({100*(b2-b3)/b0:3.0f}%)')
    print(f'  -> UNEXPLAINED direct residual                   : {b3*100:+5.1f} pp ({100*b3/b0:3.0f}%)')
    print(f'     [insight: herald ALONE explains {(b0-bh)*100:+.1f}pp; dragon ALONE {(b0-bd)*100:+.1f}pp '
          f'(dragon negative = blue wins DESPITE conceding it)]')

if __name__ == '__main__':
    print('SEQUENTIAL MEDIATION of blue-side win advantage (LPM, pp = percentage points of win prob)')
    for y in [2022,2023,2024,2025,2026]:
        decompose(load(y), y)
