#!/usr/bin/env python3
"""Build the audited English report DOCX from the canonical Markdown file."""
from __future__ import annotations

import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "blue_side_advantage_report.md"
OUTPUT = HERE / "blue_side_advantage_report_20260714.docx"
LATIN = "Noto Sans CJK SC"
CJK = "Noto Sans CJK SC"
NAVY = "17365D"
BLUE = "2F5597"
LIGHT_BLUE = "D9EAF7"
LIGHT_GREY = "F2F4F7"
MID_GREY = "667085"


def set_run_font(run, size=None, bold=None, italic=None, color=None, mono=False):
    name = "Courier New" if mono else LATIN
    east = CJK
    run.font.name = name
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    fonts.set(qn("w:ascii"), name)
    fonts.set(qn("w:hAnsi"), name)
    fonts.set(qn("w:eastAsia"), east)
    fonts.set(qn("w:cs"), name)


def set_style_font(style, size, bold=False, color=None):
    style.font.name = LATIN
    style.font.size = Pt(size)
    style.font.bold = bold
    if color:
        style.font.color.rgb = RGBColor.from_string(color)
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.rFonts
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    fonts.set(qn("w:ascii"), LATIN)
    fonts.set(qn("w:hAnsi"), LATIN)
    fonts.set(qn("w:eastAsia"), CJK)
    fonts.set(qn("w:cs"), LATIN)


def shade_cell(cell, fill):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = tcpr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcpr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=70, start=70, bottom=70, end=70):
    tc = cell._tc
    tcpr = tc.get_or_add_tcPr()
    tcm = tcpr.first_child_found_in("w:tcMar")
    if tcm is None:
        tcm = OxmlElement("w:tcMar")
        tcpr.append(tcm)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcm.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tcm.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_keep_with_next(paragraph):
    ppr = paragraph._p.get_or_add_pPr()
    keep = OxmlElement("w:keepNext")
    ppr.append(keep)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    set_run_font(run, 8, color=MID_GREY)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    paragraph._p.append(fld)


def add_inline(paragraph, text, default_size=9.5):
    text = text.replace("  ", " ")
    tokens = re.split(r"(\*\*.*?\*\*|(?<!\*)\*[^*]+?\*(?!\*)|`.*?`)", text)
    for tok in tokens:
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**"):
            run = paragraph.add_run(tok[2:-2])
            set_run_font(run, default_size, bold=True)
        elif tok.startswith("`") and tok.endswith("`"):
            run = paragraph.add_run(tok[1:-1])
            set_run_font(run, default_size - 0.5, mono=True, color="344054")
        elif tok.startswith("*") and tok.endswith("*"):
            run = paragraph.add_run(tok[1:-1])
            set_run_font(run, default_size, italic=True)
        else:
            run = paragraph.add_run(tok)
            set_run_font(run, default_size)


def add_paragraph(doc, text, style=None, align=None, first_line=True):
    p = doc.add_paragraph(style=style)
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.18
    if first_line and style is None:
        p.paragraph_format.first_line_indent = Pt(18)
    add_inline(p, text)
    return p


def add_table(doc, rows):
    ncols = len(rows[0])
    table = doc.add_table(rows=len(rows), cols=ncols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    table.autofit = True
    tblpr = table._tbl.tblPr
    width = OxmlElement("w:tblW")
    width.set(qn("w:w"), "5000")
    width.set(qn("w:type"), "pct")
    tblpr.append(width)
    for i, row in enumerate(rows):
        trpr = table.rows[i]._tr.get_or_add_trPr()
        cant = OxmlElement("w:cantSplit")
        trpr.append(cant)
        if i == 0:
            repeat = OxmlElement("w:tblHeader")
            repeat.set(qn("w:val"), "true")
            trpr.append(repeat)
        for j, value in enumerate(row):
            cell = table.cell(i, j)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            if i == 0:
                shade_cell(cell, NAVY)
            elif i % 2 == 0:
                shade_cell(cell, LIGHT_GREY)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if ncols >= 4 else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            clean = re.sub(r"\*\*(.*?)\*\*", r"\1", value.strip())
            clean = re.sub(r"`(.*?)`", r"\1", clean)
            run = p.add_run(clean)
            set_run_font(run, 7.4 if ncols >= 7 else 8.1,
                         bold=(i == 0), color="FFFFFF" if i == 0 else None)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_callout(doc, lines):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    shade_cell(cell, LIGHT_BLUE)
    set_cell_margins(cell, top=100, start=140, bottom=100, end=140)
    cell.paragraphs[0]._element.getparent().remove(cell.paragraphs[0]._element)
    for line in lines:
        p = cell.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        add_inline(p, line, 9)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_code(doc, lines):
    table = doc.add_table(rows=1, cols=1)
    cell = table.cell(0, 0)
    shade_cell(cell, "F6F8FA")
    set_cell_margins(cell, top=90, start=120, bottom=90, end=120)
    p = cell.paragraphs[0]
    for idx, line in enumerate(lines):
        run = p.add_run(line)
        set_run_font(run, 8.4, mono=True, color="24292F")
        if idx != len(lines) - 1:
            run.add_break()
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_figure(doc, alt, src):
    path = (HERE / src).resolve()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_together = True
    run = p.add_run()
    shape = run.add_picture(str(path), width=Inches(6.65))
    shape._inline.docPr.set("descr", alt)
    shape._inline.docPr.set("title", alt)
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(6)
    r = cap.add_run(alt)
    set_run_font(r, 8.2, italic=True, color=MID_GREY)


def configure_document(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)
    section.header_distance = Inches(0.3)
    section.footer_distance = Inches(0.3)

    normal = doc.styles["Normal"]
    set_style_font(normal, 9.5)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.18
    set_style_font(doc.styles["Heading 1"], 15, True, NAVY)
    set_style_font(doc.styles["Heading 2"], 11.5, True, BLUE)
    for name in ("Heading 1", "Heading 2"):
        style = doc.styles[name]
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.page_break_before = False
        style.paragraph_format.space_before = Pt(10 if name == "Heading 1" else 7)
        style.paragraph_format.space_after = Pt(4)
    set_style_font(doc.styles["List Bullet"], 9.5)
    set_style_font(doc.styles["List Number"], 9.5)

    # Explicit default fonts in docDefaults, including East Asian text.
    styles = doc.styles.element
    defaults = styles.find(qn("w:docDefaults"))
    rpr_default = defaults.find(qn("w:rPrDefault"))
    rpr = rpr_default.find(qn("w:rPr"))
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.insert(0, fonts)
    fonts.set(qn("w:ascii"), LATIN)
    fonts.set(qn("w:hAnsi"), LATIN)
    fonts.set(qn("w:eastAsia"), CJK)
    fonts.set(qn("w:cs"), LATIN)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = header.add_run("Map Side vs Draft Timing · Canonical 42,274-Match Report")
    set_run_font(r, 7.6, color=MID_GREY)
    add_page_number(section.footer.paragraphs[0])


def add_cover(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(115)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Professional League of Legends\nComplete Blue-Side Advantage Report")
    set_run_font(r, 25, bold=True, color=NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(18)
    r = p.add_run("Map Side, Draft Timing, Team Strength, and Early-Game Pathways")
    set_run_font(r, 12, italic=True, color=BLUE)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(42)
    r = p.add_run("42,274 matches · 84,548 team-games\n2022-01-10 — 2026-06-02")
    set_run_font(r, 13, bold=True, color="344054")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(65)
    r = p.add_run("Historical version · 2026-07-14\nAssociation analysis and descriptive path decomposition")
    set_run_font(r, 10, color=MID_GREY)
    p.add_run().add_break(WD_BREAK.PAGE)


def parse_markdown(doc, text):
    lines = text.splitlines()
    i = 1  # skip Markdown title; cover replaces it
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip() or line.strip() == "---":
            i += 1
            continue
        if line.startswith(">"):
            block = []
            while i < len(lines) and lines[i].startswith(">"):
                block.append(lines[i][1:].strip().rstrip("  "))
                i += 1
            add_callout(doc, block)
            continue
        if line.startswith("## "):
            p = doc.add_paragraph(line[3:].strip(), style="Heading 1")
            set_keep_with_next(p)
            i += 1
            continue
        if line.startswith("### "):
            p = doc.add_paragraph(line[4:].strip(), style="Heading 2")
            set_keep_with_next(p)
            i += 1
            continue
        if line.startswith("```"):
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            i += 1
            add_code(doc, code)
            continue
        m = re.match(r"!\[(.*?)\]\((.*?)\)", line)
        if m:
            add_figure(doc, m.group(1), m.group(2))
            i += 1
            continue
        if line.startswith("|"):
            raw = []
            while i < len(lines) and lines[i].startswith("|"):
                raw.append(lines[i])
                i += 1
            rows = []
            for idx, row in enumerate(raw):
                cells = [c.strip() for c in row.strip().strip("|").split("|")]
                if idx == 1 and all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                    continue
                rows.append(cells)
            add_table(doc, rows)
            continue
        if re.match(r"^- ", line):
            while i < len(lines) and re.match(r"^- ", lines[i]):
                p = doc.add_paragraph(style="List Bullet")
                p.paragraph_format.space_after = Pt(2)
                add_inline(p, lines[i][2:].strip())
                i += 1
            continue
        if re.match(r"^\d+\. ", line):
            while i < len(lines) and re.match(r"^\d+\. ", lines[i]):
                match = re.match(r"^(\d+)\.\s+(.*)", lines[i])
                number, content = match.group(1), match.group(2).strip()
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(2)
                p.paragraph_format.left_indent = Pt(18)
                p.paragraph_format.first_line_indent = Pt(-18)
                add_inline(p, f"{number}.  {content}")
                i += 1
            continue

        para = [line.strip().rstrip("  ")]
        i += 1
        while i < len(lines):
            nxt = lines[i].rstrip()
            if (not nxt.strip() or nxt.startswith(("## ", "### ", ">", "```", "|", "!["))
                    or re.match(r"^- ", nxt) or re.match(r"^\d+\. ", nxt)
                    or nxt.strip() == "---"):
                break
            para.append(nxt.strip().rstrip("  "))
            i += 1
        add_paragraph(doc, " ".join(para))


def main():
    doc = Document()
    configure_document(doc)
    add_cover(doc)
    parse_markdown(doc, SOURCE.read_text(encoding="utf-8"))
    props = doc.core_properties
    props.title = "Professional League of Legends: Complete Blue-Side Advantage Report"
    props.subject = "Map side, draft timing, team strength, and early-game pathways"
    props.author = "Vincent"
    props.keywords = "League of Legends; esports; map side; draft timing; Elo"
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
